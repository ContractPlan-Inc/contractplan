<script lang="ts">
  import {title} from "$lib/state/store";
  import { userdata } from "../../store"
  import IconProfile from "$lib/assets/svg/profile.svg";
  import editIcon from '$lib/assets/svg/edit.svg';
  import {GraphQLQueryRepository} from "$lib/api/query-repository";
  import {UpdateUserDoc, type UserInput, ProfileImageUrlDoc} from "$lib/generated/graphql";
  import {onMount, tick} from "svelte";
  import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
  import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
  import { env } from '$env/dynamic/public';
  import { graphql } from "graphql";

  let enableEdit=false
  title.set("Profile");
  let userData: { ID?: string; Email: string; VisibleName: string; Image?: string };
  userdata.subscribe((value) => {
    userData = value;
  });
  let fileInput: HTMLInputElement;
  let file

  const s3Client = new S3Client({
    region: 'us-east-1',
    credentials: {
      accessKeyId: env.PUBLIC_AWS_ACCESS_KEY_ID || '',
      secretAccessKey: env.PUBLIC_AWS_SECRET_ACCESS_KEY || '',
    },
  });

  const BUCKET_NAME = env.PUBLIC_S3_BUCKET_NAME || 'contractplan-profile-image';

  onMount(async () => {
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: `${userData.ID}`,
    });
    userData.Image = await getSignedUrl(s3Client as any, command, { expiresIn: 90 });
  });

  async function save() {
    const userId = userData.ID;
    if (userId) {
      delete userData.ID;
    }

    const queryRepository = new GraphQLQueryRepository<UserInput>();

    try {
      const response = await queryRepository.updateItem(UpdateUserDoc, {
        id: userId,
        input: {
          Email: userData.Email,
          VisibleName: userData.VisibleName,
          Username: userData.Email,
        },
      });

      if (response.error) {
        console.log("Error", response.error);
      }

      await tick();
      enableEdit = false;
    } catch (error) {
      const errorMessage = "Error submitting contract. Please try again.";
      alert(errorMessage);
      console.error(error);
    }
  }
  async function handleFileUpload(event: Event) {
    const target = event.target as HTMLInputElement;
    file = target?.files?.[0];
    if (!file) {
      console.error("No file selected");
      return;
    }

    const queryRepository = new GraphQLQueryRepository<UserInput>();
    try {
      // Get presigned URL from backend
      const response = await queryRepository.updateItem(ProfileImageUrlDoc, {
        input: {
          filename: file.name,
          contentType: file.type
        }
      });
      if (response.error) {
        throw new Error(response.error);
      }
      const presignedUrl = response.data?.profileImageUrl;
      if (!presignedUrl) {
        throw new Error("Failed to get upload URL");
      }
      // Upload file using presigned URL
      const uploadResponse = await fetch(presignedUrl, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type
        }
      });
      if (!uploadResponse.ok) {
        throw new Error(`Upload failed: ${uploadResponse.statusText}`);
      }
      console.log("File uploaded successfully");
      // Update refresh command to use environment variable
      // const command = new GetObjectCommand({
      //   Bucket: BUCKET_NAME,
      //   Key: `${userData.ID}`,
      // });
      // userData.Image = await getSignedUrl(s3Client as any, command, { expiresIn: 90 });
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Error uploading file: " + (error as Error).message);
    }
  }
</script>
<style>
  .file-input {
    display: none;
  }
  .custom-file-upload {
    display: flex;
    align-items: center;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  .custom-file-upload:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
  :global(.dark) .custom-file-upload {
    background-color: #374151;
    color: white;
  }
</style>

<div class="max-w-4xl mx-auto p-6 space-y-6">
  <div class="flex items-center justify-between mb-6 pb-4 border-b">
    <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Profile Settings</h1>
    <button 
      onclick={() => {enableEdit = !enableEdit}} 
      class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
    >
      <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
      </svg>
      Edit Profile
    </button>
  </div>
  <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
    <div class="p-8">
      <div class="flex flex-col w-fit items-center justify-center py-6 h-[180px] mx-auto">
        <div class="flex items-center justify-center h-[100px] w-full">
          {#if userData.ProfileImageUrl}
            <div class="relative w-[120px] h-[120px] rounded-full border-4 border-primary overflow-hidden">
              <img 
                src={userData.ProfileImageUrl} 
                class="w-full h-full object-cover"
                alt="Profile"
              />
              <div class="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 transition-opacity duration-200" />
            </div>
          {:else}
            <div class="relative w-[120px] h-[120px] rounded-full border-4 border-gray-200 overflow-hidden bg-gray-50 flex items-center justify-center">
              <img 
                src={IconProfile} 
                alt="User Image" 
                class="w-[60px] h-[60px] text-gray-400"
              />
            </div>
          {/if}
        </div>
        <div 
          class="custom-file-upload mt-4 px-4 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200 flex items-center gap-2 cursor-pointer dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600"
          onclick={() => fileInput.click()}
        >
          <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <span>Change Photo</span>
        </div>
        <input class="file-input" type="file" bind:this={fileInput} onchange={handleFileUpload} accept="image/*" />
      </div>

      <div class="mt-8 space-y-6">
        <div class="grid grid-cols-1 gap-6">
          <div class="relative flex flex-col">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="id">ID</label>
            <input 
              bind:value={userData.ID}
              type="text"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 text-gray-900 text-sm disabled:bg-gray-100 disabled:text-gray-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
              id="id"
              disabled
            />
          </div>

          <div class="relative flex flex-col">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="name">Name</label>
            <input 
              bind:value={userData.VisibleName}
              type="text"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 text-gray-900 text-sm focus:ring-primary focus:border-primary disabled:bg-gray-100 disabled:text-gray-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
              id="name"
              disabled={!enableEdit}
            />
          </div>

          <div class="relative flex flex-col">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="email">Email</label>
            <input 
              bind:value={userData.Email}
              type="email"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 text-gray-900 text-sm focus:ring-primary focus:border-primary disabled:bg-gray-100 disabled:text-gray-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
              id="email"
              disabled={!enableEdit}
            />
          </div>
        </div>

        {#if enableEdit}
          <div class="flex justify-end mt-6 pt-6 border-t">
            <button 
              onclick={() => {save()}} 
              class="inline-flex justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
              </svg>
              Save Changes
            </button>
          </div>
        {/if}
      </div>
    </div>
  </div>
</div>

