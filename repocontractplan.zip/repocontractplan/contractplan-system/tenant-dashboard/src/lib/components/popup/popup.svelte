<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  const dispatch = createEventDispatcher();

  function handleClose() {
    dispatch('close');
  }

  function handleSubmit() {
    dispatch('submit');
  }

  interface PopupProps {
    popupTitle: String,
    buttonText: String,
  }

  let { popupTitle, buttonText, submitHandler } = $props();


</script>

<!-- svelte-ignore a11y-click-events-have-key-events -->
<!-- svelte-ignore a11y-no-static-element-interactions -->
<div class=" w-full   h-full !fixed top-0 left-0 z-40 bg-white/50     backdrop-blur-sm" role="button" onclick={handleClose}></div>
<div class=" absolute w-full h-full top-0 left-0 flex items-center justify-center">

  <div class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-2xl shadow-xl border border-gray-300  ">
    <form class="w-full my-"  onsubmit={(event) => { event.preventDefault(); submitHandler(); }}>
      <div class=" p-5">
        <div class="w-full mb-3 flex    ">
          <h1 class=" text-2xl  font-semibold">{popupTitle}</h1>
        </div>

        <div class="  space-y-4">
          <slot />
          <div class="w-full my-5 flex items-center justify-center ">
            <button class=" px-3 py-2 w-full border bg-gradient-to-b from-gray-600 to-gray-800 rounded-lg text-white "
                    type="submit">{buttonText}
            </button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
