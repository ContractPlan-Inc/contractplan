package models

import (
	"encoding/json"
	"os"

	"github.com/aws/aws-lambda-go/events"
	jsoniter "github.com/json-iterator/go"
	"github.com/kr/pretty"
)

// UnmarshalStreamImage converts events.DynamoDBAttributeValue to struct
func UnmarshalStreamImage[F Model](model F, attribute map[string]events.DynamoDBAttributeValue, testing bool) (F, error) {
	baseAttrMap := make(map[string]interface{})
	for k, v := range attribute {
		baseAttrMap[k] = ExtractVal(k, v)
	}
	if testing {
		pretty.Println(baseAttrMap)
	}
	marshalledMap, _ := json.Marshal(baseAttrMap)
	if testing {
		pretty.Println("MARSHALLED", string(marshalledMap))
	}
	jsoniterr := jsoniter.Config{TagKey: "dynamodbav"}.Froze()
	if testing {
		pretty.Println("UNMARSHALLING")
	}
	err := jsoniterr.Unmarshal(marshalledMap, &model)
	if testing {
		pretty.Println("MODEL", model)
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println("BASE MAP", baseAttrMap)
		pretty.Println("MARSHALLED", string(marshalledMap))
		pretty.Println("UNMARSHALLED MODEL", model)
	}
	return model, err
}

func ExtractVal(key string, v events.DynamoDBAttributeValue) interface{} {
	var val interface{}
	switch v.DataType() {
	case events.DataTypeString:
		val = v.String()
	case events.DataTypeNumber:
		val, _ = v.Float()
	case events.DataTypeBinary:
		val = v.Binary()
	case events.DataTypeBoolean:
		val = v.Boolean()
	case events.DataTypeNull:
		val = nil
	case events.DataTypeList:
		list := make([]interface{}, len(v.List()))
		for _, item := range v.List() {
			list = append(list, ExtractVal(key, item))
		}
		val = list
	case events.DataTypeMap:
		mapAttr := make(map[string]interface{}, len(v.Map()))
		for k, v := range v.Map() {
			mapAttr[k] = ExtractVal(key, v)
		}
		val = mapAttr
	case events.DataTypeBinarySet:
		set := make([][]byte, len(v.BinarySet()))
		set = append(set, v.BinarySet()...)
		val = set
	case events.DataTypeNumberSet:
		set := make([]string, len(v.NumberSet()))
		set = append(set, v.NumberSet()...)
		val = set
	case events.DataTypeStringSet:
		set := make([]string, len(v.StringSet()))
		set = append(set, v.StringSet()...)
		val = set
	}
	return val
}
