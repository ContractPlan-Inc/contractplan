package models

type Plan struct {
	ID       string   `json:"ID"`
	Price    string   `json:"Price"`
	Features []string `json:"Features"`
	Period   string   `json:"Period"`
}
