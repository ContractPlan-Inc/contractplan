<script lang="ts">
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';

  let isHovered = false;
  let isScrolled = false;
  let currentSection = '';
  let showLogo = false;

  // Handle scroll for sticky navbar and section tracking
  onMount(() => {
    const sections = document.querySelectorAll('section[id]');
    
    const handleScroll = () => {
      isScrolled = window.scrollY > 50;
      
      // Find current section
      let current = '';
      sections.forEach(section => {
        const sectionTop = (section as HTMLElement).offsetTop;
        const sectionHeight = (section as HTMLElement).clientHeight;
        if (window.scrollY >= sectionTop - 100) {
          current = section.getAttribute('id') || '';
        }
      });
      currentSection = current;

      // Check if we're near the bottom of the page
      const bottomThreshold = 100; // pixels from bottom
      const isAtBottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - bottomThreshold;
      showLogo = isAtBottom;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  });

  // Function to scroll to a section without changing URL
  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      const navbarHeight = 80;
      const sectionPosition = section.offsetTop - navbarHeight;
      window.scrollTo({
        top: sectionPosition,
        behavior: 'smooth'
      });
    }
  };
</script>

<svelte:head>
  <title>ContractPlan: Optimize Your Contracts</title>
  <meta name="description" content="ContractPlan provides cutting-edge, cloud-based tools to model, monitor, and maximize service contract utilization effortlessly." />
</svelte:head>

<!-- Sticky Navbar -->
<nav class="fixed top-0 left-0 w-full bg-zinc-900/90 backdrop-blur-md z-50 transition-all duration-300 {isScrolled ? 'shadow-lg py-2' : 'py-4'}">
  <div class="container mx-auto px-6 flex justify-between items-center">
    <a href="/" class="text-2xl font-bold text-white">ContractPlan</a>
    <ul class="flex space-x-6 text-zinc-200">
      <li><a href="#our-story" class="hover:text-orange-400 transition-colors">Our Story</a></li>
      <li><a href="#services" class="hover:text-orange-400 transition-colors">Services</a></li>
      <li><a href="#faqs" class="hover:text-orange-400 transition-colors">FAQs</a></li>
      <li><a href="#team" class="hover:text-orange-400 transition-colors">Team</a></li>
      <li><a href="#contact-us" class="hover:text-orange-400 transition-colors">Contact</a></li>
    </ul>
  </div>
</nav>

<!-- Hero Section with Animation -->
<div class="bg-gradient-to-br from-zinc-900 via-zinc-800 to-orange-900/20 min-h-screen flex items-center justify-center">
  <div class="container mx-auto px-6 text-center text-white animate-fade-in">
    <h1 class="text-5xl md:text-7xl font-extrabold mb-6 animate-slide-up">
      Optimize Contracts with Ease
    </h1>
    <p class="text-lg md:text-xl text-zinc-300 mb-10 md:w-2/3 mx-auto animate-slide-up delay-100">
      Unlock the full potential of your service contracts with ContractPlan's intuitive, cloud-based solutions.
    </p>
    <button 
      on:click={() => goto('/auth/registration/')}
      on:mouseenter={() => isHovered = true}
      on:mouseleave={() => isHovered = false}
      class="bg-orange-500 text-white px-10 py-4 rounded-full text-lg font-semibold hover:bg-orange-600 transform hover:scale-105 transition-all duration-300 animate-slide-up delay-200"
    >
      Start Now
    </button>
  </div>
</div>

<!-- Our Story Section -->
<section id="our-story" class="py-24 bg-white">
  <div class="container mx-auto px-6">
    <h2 class="text-4xl font-bold text-zinc-900 text-center mb-10">Our Story</h2>
    <p class="text-lg text-zinc-700 md:w-2/3 mx-auto text-center">
      Founded by Nick Kirley, ContractPlan was created to fill the gap in user-friendly contract management. Drawing from his operations experience, Nick developed ContractPlan to streamline service modeling, output tracking, variance analysis, and compliance management.
    </p>
  </div>
</section>

<!-- Services Section with Accordion -->
<section id="services" class="py-24 bg-gray-50">
  <div class="container mx-auto px-6">
    <h2 class="text-4xl font-bold text-zinc-900 text-center mb-12">Our Services</h2>
    <div class="flex flex-col items-center">
      <!-- Services Section with Features and Industries -->
      <div class="overflow-hidden bg-gray-50 py-20 sm:py-24" id="services-inner">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          <!-- Features Column -->
          <div class="space-y-6">
            <h3 class="text-2xl font-semibold text-zinc-900">Key Features</h3>
            <ul class="list-disc list-inside space-y-4 text-zinc-700">
              <li>Take Charge of Your Contracts: Organize contract facts, never miss deadlines, and visualize your performance.</li>
              <li>Get Perspective: Build and track multi-unit service contract schedules for informed utilization patterns.</li>
              <li>Evaluate Early & Often: Recognize and respond to contract utilization variance with analytics and dashboards.</li>
            </ul>
          </div>
          <!-- Features Accordion -->
          <div class="space-y-4 mx-auto max-w-2xl w-full">
            <details class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <summary class="text-xl font-semibold text-zinc-900 cursor-pointer">Take Charge of Your Contracts</summary>
              <p class="mt-4 text-zinc-700">Organize contract details, track deadlines, and visualize performance metrics effortlessly.</p>
            </details>
            <details class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <summary class="text-xl font-semibold text-zinc-900 cursor-pointer">Get Perspective</summary>
              <p class="mt-4 text-zinc-700">Create and monitor multi-unit service schedules for smarter utilization insights.</p>
            </details>
            <details class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <summary class="text-xl font-semibold text-zinc-900 cursor-pointer">Evaluate Early & Often</summary>
              <p class="mt-4 text-zinc-700">Spot variances and optimize with real-time analytics and dashboards.</p>
            </details>
          </div>
        </div>
      </div>
      <!-- Industries Grid -->
      <div class="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl">
        {#each [
          { title: 'Small Business', desc: 'Boost sales and streamline insights.' },
          { title: 'Local Government', desc: 'Enhance accountability in contract portfolios.' },
          { title: 'Nonprofit', desc: 'Affordable tools for grants and services.' }
        ] as industry}
          <div class="bg-white p-6 rounded-xl shadow-md text-center hover:scale-105 transition-transform">
            <h3 class="text-xl font-semibold text-orange-600">{industry.title}</h3>
            <p class="mt-2 text-zinc-700">{industry.desc}</p>
          </div>
        {/each}
      </div>
    </div>
  </div>
</section>

<!-- FAQs Section -->
<section id="faqs" class="py-24 bg-gray-100">
  <div class="container mx-auto px-6">
    <h2 class="text-4xl font-bold text-zinc-900 text-center mb-12">FAQs</h2>
    <div class="space-y-4 md:w-2/3 mx-auto">
      <details class="bg-white p-6 rounded-xl shadow-md">
        <summary class="text-xl font-semibold text-zinc-900 cursor-pointer">What is contract utilization?</summary>
        <p class="mt-4 text-zinc-700">It's the efficient use of contracted services or resources to hit performance goals.</p>
      </details>
      <details class="bg-white p-6 rounded-xl shadow-md">
        <summary class="text-xl font-semibold text-zinc-900 cursor-pointer">Why manage contract utilization?</summary>
        <p class="mt-4 text-zinc-700">To cut costs, ensure compliance, and get the most value from your contracts.</p>
      </details>
    </div>
  </div>
</section>

<!-- Team Section -->
<section id="team" class="py-24 bg-gradient-to-b from-white to-gray-50">
  <div class="container mx-auto px-6">
    <h2 class="text-4xl font-bold text-zinc-900 text-center mb-12">Our Team</h2>
    <div class="flex justify-center">
      <div class="max-w-sm bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow text-center">
        <h3 class="text-2xl font-semibold text-zinc-900">Nick Kirley</h3>
        <p class="text-orange-600 font-medium">President</p>
        <p class="mt-2 text-zinc-700">Visionary founder revolutionizing contract management.</p>
      </div>
    </div>
  </div>
</section>

<!-- Contact Us Section with Updated Reddit Icon -->
<section id="contact-us" class="py-24 bg-zinc-900 text-white">
  <div class="container mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-12 animate-fade-in">Reach Out Anytime</h2>
    <ul class="max-w-md mx-auto space-y-6">
      <li class="flex items-center justify-center animate-slide-up delay-100">
        <span class="mr-3 text-orange-500 transition-transform duration-300 hover:rotate-12">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
            <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 2l-8 5-8-5h16zM4 18V8l8 5 8-5v10H4z"/>
          </svg>
        </span>
        <a href="mailto:contact@contractplan.com" class="text-zinc-200 hover:text-orange-400 transition-colors duration-300 text-lg">
          contact@contractplan.com
        </a>
      </li>
      <li class="flex items-center justify-center animate-slide-up delay-200">
        <span class="mr-3 text-orange-500 transition-transform duration-300 hover:scale-110">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
            <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0C.488 3.43.029 5.804 0 12c-.029 6.185.458 8.566 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.25 4.356-2.633 4.385-8.816-.029-6.196-.488-8.57-4.385-8.816zm-10.615 12.816v-8l6 4-6 4z"/>
          </svg>
        </span>
        <a href="https://youtube.com/@ContractPlan" target="_blank" class="text-zinc-200 hover:text-orange-400 transition-colors duration-300 text-lg">
          @ContractPlan on YouTube
        </a>
      </li>
      <li class="flex items-center justify-center animate-slide-up delay-300">
        <span class="mr-3 text-orange-500 transition-transform duration-300 hover:rotate-45">
          <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/>
          </svg>
        </span>
        <a href="https://reddit.com/r/ContractPlan" target="_blank" class="text-zinc-200 hover:text-orange-400 transition-colors duration-300 text-lg">
          r/ContractPlan on Reddit
        </a>
      </li>
    </ul>
    <p class="mt-8 text-zinc-400 animate-fade-in delay-400">
      We're here to assist—get in touch today!
    </p>
  </div>
</section>

<!-- Copyright Footer -->
<footer class="bg-zinc-900 text-zinc-400 text-center py-4 text-sm">
  <p>© 2025 ContractPlan. All Rights Reserved.</p>
</footer>

<style>
  /* Reuse existing animations */
  .delay-100 {
    animation-delay: 0.1s;
  }
  .delay-200 {
    animation-delay: 0.2s;
  }
  .delay-300 {
    animation-delay: 0.3s;
  }
  .delay-400 {
    animation-delay: 0.4s;
  }

  /* SVG hover effects */
  li:hover span {
    transform-origin: center;
  }

  /* Corner logo animations */
  .corner-logo {
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    pointer-events: none;
  }

  .logo-wrapper {
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
    background: rgba(0, 0, 0, 0.9);
    border-radius: 8px;
    margin-bottom: 5rem;
    margin-right: 1rem;
    animation: fadeIn 0.3s ease forwards;
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  .corner-logo {
    filter: brightness(0) invert(1);
  }

  .built-by {
    opacity: 0;
    transform: translateY(5px);
    transition: all 0.2s ease-in-out;
  }

  .logo-wrapper:hover .built-by {
    opacity: 1;
    transform: translateY(0);
  }
</style>

<!-- Add this right before the closing body tag -->
{#if showLogo}
  <div class="logo-wrapper fixed bottom-0 right-0 w-40 flex flex-col items-center p-4 z-50">
    <span class="built-by text-sm font-medium text-zinc-800 leading-none mb-1">Built by</span>
    <a href="https://cloudparallax.com/" 
       target="_blank" 
       rel="noopener noreferrer" 
       class="pointer-events-{showLogo ? 'auto' : 'none'}">
      <img 
        src="/company-logo.svg" 
        alt="Company Logo" 
        class="corner-logo w-40 h-8 object-contain"
      />
    </a>
  </div>
{/if}



