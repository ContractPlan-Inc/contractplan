package models

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"errors"
	"math/rand"
	"os"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/mohae/deepcopy"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/expression"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/beego/beego/v2/core/logs"
	jsoniter "github.com/json-iterator/go"
	"github.com/kr/pretty"

	"cloudparallax.com/backend/services/aws/config"
	dynamodb2 "cloudparallax.com/backend/services/aws/dynamodb"
	"cloudparallax.com/backend/services/cache"
)

var jsonIter = jsoniter.ConfigCompatibleWithStandardLibrary

func StoreReports[F Model](ctx context.Context, newRecord F, reportType string, mode string, testing bool, actualFields ...string) error {
	jsonIter = jsoniter.Config{TagKey: "dynamodbav"}.Froze()
	if len(ReportsMap[reportType]) == 0 {
		// pretty.Println("ReportsMap[reportType] is empty")
		return errors.New("no reports found")
	}
	if os.Getenv("RETURN_LOAD_ENV_MODE") != "" {
		return nil
	}
	actualFields = append(actualFields, BaseDynamoFields...)
	var fields []string
	reflectedType := reflect.TypeOf(newRecord)
	numberOfFields := reflectedType.Elem().NumField()
	for i := 0; i < numberOfFields; i++ {
		actualFields = append(actualFields, reflectedType.Elem().Field(i).Name)
	}
	for _, field := range actualFields {
		if reflectedField, ok := reflectedType.Elem().FieldByName(field); ok {
			avField := reflectedField.Tag.Get("dynamodbav")
			splitField := strings.Split(avField, ",")
			finalField := ""
			if avField != "-" && strings.TrimSpace(splitField[0]) != "" {
				finalField = strings.TrimSpace(splitField[0])
			} else {
				finalField = field
			}
			fields = append(fields, finalField)
			if os.Getenv("SHOWQUERY") == "1" {
				logs.Debug(field, avField)
			}
		}
	}
	conditionRecord, _, _ := BuildGSI(ctx, newRecord, "SK", reportType, false, true)
	// pretty.Println("CONDITION RECORD", conditionRecord)
	conditionMarshal, _ := attributevalue.MarshalMap(conditionRecord)

	transactionItems := []types.TransactWriteItem{
		{
			Put: &types.Put{
				Item: map[string]types.AttributeValue{
					"PK": conditionMarshal["PK"],
					"SK": conditionMarshal["SK"],
				},
				TableName:                           aws.String(config.DDBTable),
				ConditionExpression:                 aws.String("attribute_not_exists(PK) and attribute_not_exists(SK)"),
				ReturnValuesOnConditionCheckFailure: types.ReturnValuesOnConditionCheckFailureAllOld,
				// ExpressionAttributeNames:            expr.Names(),
				// ExpressionAttributeValues:           expr.Values(),
			},
		},
	}
	if mode == "SUB" {
		transactionItems = []types.TransactWriteItem{
			{
				Delete: &types.Delete{
					Key: map[string]types.AttributeValue{
						"PK": conditionMarshal["PK"],
						"SK": conditionMarshal["SK"],
					},
					TableName: aws.String(config.DDBTable),
				},
			},
		}
	}
	if testing {
		transactionItems = []types.TransactWriteItem{}
	}
	for recordType := range ReportsMap[reportType] {
		morphedRecord := ReportsMap[reportType][recordType].Model
		morphedPointer := reflect.New(reflect.TypeOf(morphedRecord)).Interface()
		morphedPointer = DeepCopier(newRecord, morphedPointer)
		morphedPointer, _, _ = BuildGSI(ctx, morphedPointer, recordType, reportType, false, true)
		reflectedValue := reflect.ValueOf(morphedPointer).Elem()
		reflectedField := reflectedValue.FieldByName("DDBAddFields")
		var addFields []string
		if reflectedField.IsValid() {
			addFields = strings.Split(reflectedField.Interface().(string), ",")
		}
		reflectedField = reflectedValue.FieldByName("IfNotFields")
		var ifNotFields []string
		if reflectedField.IsValid() {
			ifNotFields = strings.Split(reflectedField.Interface().(string), ",")
		}

		updateBuilder := expression.UpdateBuilder{}
		mapBuilder := expression.UpdateBuilder{}
		var conditionBuilder expression.ConditionBuilder
		morphedMarshal, err := attributevalue.MarshalMap(morphedPointer)
		if testing {
			pretty.Println("MORPHED MARSHAL", morphedMarshal)
		}
		if err != nil {
			logs.Error(err)
			continue
		}
		flatMap := make(map[string]interface{})
		destMap := make(map[string]interface{})
		attributevalue.UnmarshalMap(morphedMarshal, &flatMap)
		Flatten2("", flatMap, destMap)
		if testing {
			// pretty.Println("FLAT MAP", flatMap)
			// pretty.Println("DEST MAP", destMap)
		}
		mapFields := make(map[string]string)
		for key, newVal := range destMap {
			if ok, _ := StringInSlice(key, addFields...); ok {
				updateBuilder = fieldUpdate(updateBuilder, key, mode, false, newVal)
			} else if ok, _ := StringInSliceBeginsWith(key, addFields...); ok {
				ifnot, _ := StringInSlice(key, ifNotFields...)
				updateBuilder = fieldUpdate(updateBuilder, key, mode, ifnot, newVal)
				if _, ok := mapFields[strings.Split(key, ".")[0]]; !ok && strings.Contains(key, ".") {
					mapFields[strings.Split(key, ".")[0]] = key
					condition := expression.Name(strings.Split(key, ".")[0]).AttributeNotExists()
					if conditionBuilder.IsSet() {
						conditionBuilder = conditionBuilder.And(condition)
					} else {
						conditionBuilder = condition
					}
					mapBuilder = mapBuilder.Set(expression.Name(strings.Split(key, ".")[0]), expression.Value(&types.AttributeValueMemberM{Value: map[string]types.AttributeValue{}}))
				}
			} else if ok, _ := StringInSlice(key, fields...); ok {
				updateBuilder = updateBuilder.Set(expression.Name(key), expression.Value(newVal))
			} else if ok, _ := StringInSlice(key, ifNotFields...); ok {
				updateBuilder = updateBuilder.Set(expression.Name(key), expression.IfNotExists(expression.Name(key), expression.Value(newVal)))
			}
		}
		expr, err := expression.NewBuilder().WithUpdate(updateBuilder).Build()

		if err != nil {
			continue
		}
		if morphedMarshal["PK"] == nil || morphedMarshal["SK"] == nil {
			continue
		}
		if conditionBuilder.IsSet() {
			mapExpression, err := expression.NewBuilder().WithUpdate(mapBuilder).WithCondition(conditionBuilder).Build()

			//
			if err != nil {
				panic(err)
			}
			//  generate a hash of the expression
			hash := sha1.New()
			condition := mapExpression.Condition()
			hash.Write([]byte(*condition + *mapExpression.Update() + destMap["PK"].(string) + destMap["SK"].(string)))
			hashed := hex.EncodeToString(hash.Sum(nil))
			redisLink := cache.UniversalRedis()
			random := rand.Intn(100)
			failure := true
			if os.Getenv("FAIL") != "" {
				failure = random > 75 || !testing
			}
			if exists, errR := redisLink.HExists(ctx, "MAP_HASH", hashed).Result(); errR == nil && !exists && failure {
				logs.Debug("HASH NOT FOUND:", hashed)
				putItem := &dynamodb.UpdateItemInput{
					Key: map[string]types.AttributeValue{
						"PK": morphedMarshal["PK"],
						"SK": morphedMarshal["SK"],
					},
					TableName:                 aws.String(config.DDBTable),
					UpdateExpression:          mapExpression.Update(),
					ConditionExpression:       mapExpression.Condition(),
					ExpressionAttributeNames:  mapExpression.Names(),
					ExpressionAttributeValues: mapExpression.Values(),
				}
				dynamodb2.DDBClient.UpdateItem(ctx, putItem)
				redisLink.HSet(ctx, "MAP_HASH", hashed, true)
			}
		}
		transactWriteItem2 := types.TransactWriteItem{
			Update: &types.Update{
				Key: map[string]types.AttributeValue{
					"PK": morphedMarshal["PK"],
					"SK": morphedMarshal["SK"],
				},
				TableName:                 aws.String(config.DDBTable),
				UpdateExpression:          expr.Update(),
				ExpressionAttributeNames:  expr.Names(),
				ExpressionAttributeValues: expr.Values(),
			},
		}
		transactionItems = append(transactionItems, transactWriteItem2)
		// if testing {
		// 	pretty.Println("TRANSACTION ITEM", transactWriteItem2)
		// }

	}
	if len(transactionItems) <= 1 {
		return errors.New("no fields to update")
	}
	repeat := 0
REPEAT:
	_, err := dynamodb2.DDBClient.TransactWriteItems(ctx,
		&dynamodb.TransactWriteItemsInput{
			TransactItems: transactionItems,
		},
	)

	if err != nil || testing {
		if !testing && repeat < 10 && !strings.Contains(err.Error(), "ConditionalCheckFailed") {
			repeat++
			time.Sleep(1 * time.Second * time.Duration(repeat))
			goto REPEAT
		}
	}
	return err
}

func fieldUpdate(updateBuilder expression.UpdateBuilder, key, mode string, ifnot bool, value interface{}) expression.UpdateBuilder {
	var nameBuilder expression.NameBuilder
	var valueBuilder expression.ValueBuilder
	if mode == "SUB" {
		switch value.(type) {
		case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64:
			value = value.(int) * -1
		case float32, float64:
			value = value.(float64) * -1
		}
	}
	nameBuilder = expression.Name(key)
	valueBuilder = expression.Value(value)
	switch value.(type) {
	case string:
		if ifnot {
			updateBuilder = updateBuilder.Set(nameBuilder, expression.IfNotExists(nameBuilder, valueBuilder))
		} else {
			updateBuilder = updateBuilder.Set(nameBuilder, valueBuilder)
		}
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64, float64, float32:
		updateBuilder = updateBuilder.Add(nameBuilder, valueBuilder)
	}
	return updateBuilder
}
func StoreItemWithFields[F Model](ctx context.Context, newRecord F, recordType string, updateOnly, consistency, updateAll bool, actualFields ...string) (*dynamodb.UpdateItemOutput, *dynamodb.PutItemOutput, error) {
	if os.Getenv("RETURN_LOAD_ENV_MODE") != "" {
		return nil, nil, nil
	}
	actualFields = append(actualFields, DefaultDynamoFields...)
	var fields []string
	reflectedType := reflect.TypeOf(newRecord)
	reflectedTyped := reflect.TypeOf(newRecord)
	if reflect.TypeOf(newRecord).Kind() == reflect.Ptr {
		reflectedTyped = reflect.TypeOf(reflect.ValueOf(newRecord).Elem().Interface())
	}
	if updateAll {
		for i := 0; i < reflectedTyped.NumField(); i++ {
			actualFields = append(actualFields, reflectedTyped.Field(i).Name)
		}
	}
	for _, field := range actualFields {
		if reflectedField, ok := reflectedType.Elem().FieldByName(field); ok {
			avField := reflectedField.Tag.Get("dynamodbav")
			splitField := strings.Split(avField, ",")
			if avField != "-" && strings.TrimSpace(splitField[0]) != "" {
				fields = append(fields, strings.TrimSpace(splitField[0]))
			} else {
				fields = append(fields, field)
			}
			if os.Getenv("SHOWQUERY") == "1" {
				logs.Debug(field, avField)
			}
		}
	}
	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug(fields)
	}
	var newRecordMarshal map[string]types.AttributeValue
	var oldRecordMarshal map[string]types.AttributeValue
	// build the GSI to compute PK & SK
	newRecord, _, err := BuildGSI(ctx, newRecord, recordType, "", false, true)
	if err != nil {
		return nil, nil, err
	}
	// marshall the map for loading
	newRecordMarshal, _ = attributevalue.MarshalMap(newRecord)
	// reload the original item from ddb
	if oldRecordMarshal = getItemFromDDB(ctx, newRecordMarshal, consistency); oldRecordMarshal == nil {
		if updateOnly {
			return nil, nil, errors.New("record not found")
		}
		// get item has failed, item does not exist
		marshalledRecord, err := attributevalue.MarshalMap(newRecord)
		putItem := &dynamodb.PutItemInput{
			Item:                   marshalledRecord,
			TableName:              aws.String(config.DDBTable),
			ReturnConsumedCapacity: types.ReturnConsumedCapacityTotal,
		}
		put, err := dynamodb2.DDBClient.PutItem(ctx, putItem, func(options *dynamodb.Options) {})
		if err == nil && put != nil && put.ConsumedCapacity != nil && put.ConsumedCapacity.CapacityUnits != nil {
			dynamodb2.DDBUsage.IncrementWriteCount(*put.ConsumedCapacity.CapacityUnits)
		}
		// if err == nil {
		// 	TODO: logic for generating reports
		// }
		return nil, put, err
	} else {
		// unmarshall the loaded item
		attributevalue.UnmarshalMap(oldRecordMarshal, newRecord)
		// unmarshall the changed object
		attributevalue.UnmarshalMap(newRecordMarshal, newRecord)
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println(newRecordMarshal, oldRecordMarshal, newRecord)
	}
	if ok, _ := CompareRecordsForUpdate(oldRecordMarshal, newRecordMarshal); ok {
		return nil, nil, nil
	}
	updateBuilder := expression.UpdateBuilder{}
	for key := range oldRecordMarshal {
		if ok, _ := StringInSlice(key, "PK", "SK"); ok {
			continue
		}
		if newVal, ok := newRecordMarshal[key]; ok {
			if ok, _ := StringInSlice(key, fields...); ok {
				updateBuilder = updateBuilder.Set(expression.Name(key), expression.Value(newVal))
			}
		} else if !ok {
			if !updateOnly {
				updateBuilder = updateBuilder.Remove(expression.Name(key))
			}
		}
	}
	for key, val := range newRecordMarshal {
		if ok, _ := StringInSlice(key, "PK", "SK"); ok {
			continue
		}
		if _, ok := oldRecordMarshal[key]; !ok {
			if ok, _ := StringInSlice(key, fields...); ok {
				updateBuilder = updateBuilder.Set(expression.Name(key), expression.Value(val))
			}
		}
	}
	expr, _ := expression.NewBuilder().WithUpdate(updateBuilder).Build()
	updateItemInput := &dynamodb.UpdateItemInput{
		TableName: aws.String(config.DDBTable),
		Key: map[string]types.AttributeValue{
			"PK": newRecordMarshal["PK"],
			"SK": newRecordMarshal["SK"],
		},
		ExpressionAttributeNames:  expr.Names(),
		ExpressionAttributeValues: expr.Values(),
		UpdateExpression:          expr.Update(),
		ReturnConsumedCapacity:    types.ReturnConsumedCapacityTotal,
	}
	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug(updateItemInput)
	}
	repeat := 0
retry:
	update, err := dynamodb2.DDBClient.UpdateItem(ctx, updateItemInput)
	if err == nil && update.ConsumedCapacity != nil && update.ConsumedCapacity.CapacityUnits != nil {
		dynamodb2.DDBUsage.IncrementWriteCount(*update.ConsumedCapacity.CapacityUnits)
	}
	for err != nil && repeat < 5 && !strings.Contains(err.Error(), "ConditionalCheckFailed") {
		repeat++
		time.Sleep(500 * time.Millisecond * time.Duration(1<<repeat))
		goto retry
	}
	return update, nil, err
}

func getItemFromDDB(ctx context.Context, newRecordMarshal map[string]types.AttributeValue, consistent bool) map[string]types.AttributeValue {
	getItem := &dynamodb.GetItemInput{
		TableName: aws.String(config.DDBTable),
		Key: map[string]types.AttributeValue{
			"PK": newRecordMarshal["PK"],
			"SK": newRecordMarshal["SK"]},
		ConsistentRead:         aws.Bool(consistent),
		ReturnConsumedCapacity: types.ReturnConsumedCapacityTotal,
	}
	if result, err := dynamodb2.DDBClient.GetItem(ctx, getItem, func(options *dynamodb.Options) {}); err == nil && result.Item != nil {
		if result.ConsumedCapacity != nil && result.ConsumedCapacity.CapacityUnits != nil {
			dynamodb2.DDBUsage.IncrementReadCount(*result.ConsumedCapacity.CapacityUnits)
		}
		return result.Item
	} else {
		return nil
	}
}

func StoreItem[F Model](ctx context.Context, record F, recordType string, force ...bool) (*dynamodb.PutItemOutput, error) {
	if os.Getenv("RETURN_LOAD_ENV_MODE") != "" {
		return nil, nil
	}
	record, _, err := BuildGSI(ctx, record, recordType, "", false, true)
	if err != nil {
		return nil, err
	}
	marshalledRecord, err := attributevalue.MarshalMap(record)
	if err != nil {
		return nil, err
	}
	putItem := &dynamodb.PutItemInput{
		Item:                        marshalledRecord,
		TableName:                   aws.String(config.DDBTable),
		ConditionExpression:         aws.String("attribute_not_exists(PK) AND attribute_not_exists(SK)"),
		ReturnConsumedCapacity:      types.ReturnConsumedCapacityTotal,
		ReturnItemCollectionMetrics: types.ReturnItemCollectionMetricsSize,
	}
	if len(force) > 0 && force[0] {
		putItem.ConditionExpression = nil
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println("PUT ITEM:", putItem)
	}
	repeat := 0
retry:
	put, err := dynamodb2.DDBClient.PutItem(ctx, putItem, func(options *dynamodb.Options) {})
	if put != nil && put.ConsumedCapacity != nil && put.ConsumedCapacity.CapacityUnits != nil {
		dynamodb2.DDBUsage.IncrementWriteCount(*put.ConsumedCapacity.CapacityUnits)
	}
	for err != nil && repeat < 3 && !strings.Contains(err.Error(), "ConditionalCheckFailed") {
		repeat++
		time.Sleep(500 * time.Millisecond * time.Duration(1<<repeat))
		goto retry
	}
	return put, err
}
func StoreItems[F Model](ctx context.Context, records []F, recordType string) (*dynamodb.BatchWriteItemOutput, error) {
	if os.Getenv("RETURN_LOAD_ENV_MODE") != "" {
		return nil, nil
	}
	var recordMap []map[string]types.AttributeValue
	items := 0
	for _, record := range records {
		items++
		_, _, err := BuildGSI(ctx, record, recordType, "", false, true)
		if err != nil {
			return nil, err
		}
		marshalledRecord, err := attributevalue.MarshalMap(record)
		if err != nil {
			continue
		}
		recordMap = append(recordMap, marshalledRecord)
		if items >= 25 {
			output, err := BatchWrite(ctx, config.DDBTable, recordMap)
			if err != nil {
				return output, err
			}
			recordMap = []map[string]types.AttributeValue{}
			items = 0
		}
	}
	if len(recordMap) > 0 {
		return BatchWrite(ctx, config.DDBTable, recordMap)
	}
	return nil, nil
}

func CompareRecordsForUpdate(record1 map[string]types.AttributeValue, record2 map[string]types.AttributeValue) (bool, string) {
	hash1, err1 := CreateDynamoHash(record1)
	hash2, err2 := CreateDynamoHash(record2)
	if err1 == nil && err2 == nil {
		return hash1 == hash2, hash2
	}
	return false, ""
}

func CreateDynamoHash(record map[string]types.AttributeValue) (string, error) {
	recordMarshal, err := json.Marshal(record)
	if err != nil {
		return "", err
	}
	hashString := asSha256(string(recordMarshal))
	return hashString, nil
}
func Flatten2(prefix string, src map[string]interface{}, dest map[string]interface{}) {
	if len(prefix) > 0 {
		prefix += "."
	}
	for k, v := range src {
		switch child := v.(type) {
		case map[string]interface{}:
			Flatten2(prefix+k, child, dest)
		case []interface{}:
			for i := 0; i < len(child); i++ {
				dest[prefix+k+"."+strconv.Itoa(i)] = child[i]
			}
		default:
			dest[prefix+k] = v
		}
	}
}
func DeepCopier[F any, T any](in F, out T) T {
	out = deepcopy.Copy(in).(T)
	return out
}

func BatchWrite(ctx context.Context, table string, records []map[string]types.AttributeValue) (*dynamodb.BatchWriteItemOutput, error) {
	requestItems := make(map[string][]types.WriteRequest)
	for _, record := range records {
		requestItems[table] = append(requestItems[table], types.WriteRequest{PutRequest: &types.PutRequest{Item: record}})
	}
	batchWriteItems := &dynamodb.BatchWriteItemInput{
		RequestItems:                requestItems,
		ReturnConsumedCapacity:      "TOTAL",
		ReturnItemCollectionMetrics: "SIZE",
	}
	batchWriteItemsOutput, err := dynamodb2.DDBClient.BatchWriteItem(ctx, batchWriteItems, func(options *dynamodb.Options) {})

	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug("ITEMS", pretty.Sprint(batchWriteItems))
		logs.Debug("ERROR", err)
	}
	if err != nil {
		logs.Debug(err)
	} else {
		for _, p := range batchWriteItemsOutput.ConsumedCapacity {
			if p.CapacityUnits != nil {
				dynamodb2.DDBUsage.IncrementWriteCount(*p.CapacityUnits)
			}
		}
	}
	return batchWriteItemsOutput, err
}
