package tracing

import (
	"context"
	"encoding/json"
	
	"github.com/99designs/gqlgen/graphql"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
)

type (
	Tracer struct{}
)

var _ interface {
	graphql.HandlerExtension
	graphql.ResponseInterceptor
	graphql.FieldInterceptor
	graphql.OperationInterceptor
} = Tracer{}

func (Tracer) ExtensionName() string {
	return "AWS-XRay"
}

func (Tracer) Validate(graphql.ExecutableSchema) error {
	return nil
}

func (Tracer) InterceptField(ctx context.Context, next graphql.Resolver) (interface{}, error) {
	if tracing {
		fc := graphql.GetFieldContext(ctx)
		ctx, span := tracerHandle.Start(ctx, "GQL Field "+fc.Field.Name, trace.WithSpanKind(trace.SpanKindProducer))
		span.SetAttributes(
			attribute.Bool("IsMethod", fc.IsMethod),
			attribute.Bool("IsResolver", fc.IsResolver),
			attribute.String("Object", fc.Object),
		)
		span.SetAttributes()
		defer span.End()
		return next(ctx)
	}
	return next(ctx)
}

func (Tracer) InterceptOperation(ctx context.Context, next graphql.OperationHandler) graphql.ResponseHandler {
	if tracing {
		reqCtx := graphql.GetOperationContext(ctx)
		// this span will be translated to a subsegment in X-Ray backend
		ctx, span := tracerHandle.Start(ctx, "GQL Operation", trace.WithSpanKind(trace.SpanKindProducer))
		out, _ := json.Marshal(reqCtx.Variables)
		span.SetAttributes(
			attribute.String("VARIABLES", string(out)),
			attribute.String("OPNAME", reqCtx.OperationName),
			attribute.String("Query", reqCtx.RawQuery),
		)
		span.SetAttributes()
		defer span.End()
		return next(ctx)
	}
	return next(ctx)
}

func (Tracer) InterceptResponse(ctx context.Context, next graphql.ResponseHandler) *graphql.Response {
	
	return next(ctx)
}
