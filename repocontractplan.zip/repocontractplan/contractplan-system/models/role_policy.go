package models

type RolePolicy struct {
	DynamoDBBaseModel
	ID          string `dynamodbav:"a,omitempty"`
	RoleID      string
	PolicyID    string
	Description string
	IsActive    bool
	CreatedAt   string
	UpdatedAt   string
}
