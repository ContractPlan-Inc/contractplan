package config

import (
	"context"
	"log"
	"os"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
)

func init() {
	var err error
	// Load the AWS configuration with explicit region and endpoint resolver
	AWSConfig, err = config.LoadDefaultConfig(context.TODO(),
		config.WithRegion(os.Getenv("AWS_REGION")),
		config.WithEndpointResolverWithOptions(
			aws.EndpointResolverWithOptionsFunc(
				func(service, region string, options ...interface{}) (aws.Endpoint, error) {
					if endpoint := os.Getenv("AWS_ENDPOINT"); endpoint != "" {
						return aws.Endpoint{
							URL: endpoint,
						}, nil
					}
					// Return EndpointNotFoundError to use default endpoint
					return aws.Endpoint{}, &aws.EndpointNotFoundError{}
				},
			),
		),
	)

	if err != nil {
		log.Fatal("Unable to load AWS SDK config:", err)
	}
}
