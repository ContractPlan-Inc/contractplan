<script lang="ts">
    import ConfirmNewPassword from "./confirmNewPassword.svelte"
    import ResetPassword from "./resetPassword.svelte"

    let email: string = $state('');
    let step = $state('ResetPassword');

    let componentMap: { [key: string]: any } = {
      ResetPassword: ResetPassword,
      ConfirmNewPassword: ConfirmNewPassword,
    };

</script>

<div class=" w-full item-center justify-center relative">
  <svelte:component this={componentMap[step]} bind:email bind:step />
</div>




