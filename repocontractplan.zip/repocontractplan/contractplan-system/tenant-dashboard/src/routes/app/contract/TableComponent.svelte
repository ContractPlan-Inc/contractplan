<script lang="ts">
  import Table, { type Column } from '$lib/components/table/table.svelte';
  import { DataSourceConnector } from "$lib/api/table-datasource";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import deleteIcon from "$lib/assets/svg/trash.svg";
  import editIcon from "$lib/assets/svg/edit.svg";
  import dashboardIcon from "$lib/assets/svg/dashboard.svg";
  import { goto } from "$app/navigation";
  import { type Contract, ListTenantsDoc, type Tenant } from '$lib/generated/graphql';

  let queryRepository = new GraphQLQueryRepository<Tenant>();
  let tableDataSource = new DataSourceConnector<Tenant>(
    queryRepository,
    ListTenantsDoc,
  );
  let addButton = { text: "New Contract", path: "/app/contract/create" };
  const isLabel = true;
  let label = "Columns";
  const columns = [
    { key: "ID", title: "ID", sortable: false },
    { key: "ContractAlias", title: "Contract No.", sortable: false },
    { key: "ContractName", title: "Contract Name", sortable: false },
    { key: "ContractPartner.Company", title: "Partner Name", sortable: true },
    { key: "StartDate", title: "Start Date", sortable: false },
    { key: "EndDate", title: "End Date", sortable: false },
    { key: "ServiceDays", title: "Service Days", sortable: false },
    { key: "ContractValue", title: "Contract Value", sortable: false },
    { key: "Units", title: "Units ", sortable: false },
    { key: "plannedAmount", title: "Planned Amount", sortable: false },
    { key: "Status", title: "Status", sortable: false },
  ] as Column[];
  let availableColumns = [
    "ContractAlias",
    "Date",
    "StartDate",
    "EndDate",
    "ServiceDays",
    "ContractValue",
    // "Units",
    // "Status",
  ];
  let dateColumns = ["StartDate", "EndDate"];
  let currencyColumns = ["ContractValue"];
  let actions = true;
  let actionList = [
    { name: "Day Report", icon: editIcon, function: contractDay },
    {
      name: "Dashboard",
      icon: dashboardIcon,
      iconColor: "text-gray-200",
      function: dashboardFunction,
    },
    { name: "Edit", icon: editIcon, function: editFunction },
    { name: "Delete", icon: deleteIcon, function: deleteFunction },
  ];
  let bulkActions = [
    "Activate",
    "Deactivate",
    "Delete",
    "Export to CSV",
    "Export to PDF",
  ];

  function contractDay(node: Contract) {
    goto("/app/contract/day/" + node.ID);
  }
  function dashboardFunction(node: Contract) {
    goto("/app/contract/single_contract/" + node.ID);
  }
  function editFunction(node: Contract) {
    goto("/app/contract/edit/" + node.ID);
  }
  function deleteFunction(node: Contract) {
    console.log("/app/contract/delete/" + node.ID);
  }

</script>

<div>
  <Table
    tabletitle={"Contracts"}
    {tableDataSource}
    rootAccessPath="data.listContracts.edges"
    {columns}
    {isLabel}
    {label}
    {availableColumns}
    {dateColumns}
    {currencyColumns}
    {actions}
    {actionList}
    {bulkActions}
  >
    <span slot="buttons" class="flex space-x-2">
      <slot/>
    </span>
  </Table>
</div>
