package utils

import (
	"context"
	"fmt"

	"github.com/gin-gonic/gin"
)

// A private key for context that only this package can access. This is important
// to prevent collisions between different context uses
var UserCtxKey = &ContextKey{"user_token"}

type ContextKey struct {
	name string
}

// UserForContext finds the user from the context. REQUIRES Middleware to have run.
func UserForContext(ctx context.Context) any {
	if raw := ctx.Value(UserCtxKey.name); raw != nil {
		return raw
	}
	return nil
}

// getTenant finds the Tenant from the context. REQUIRES Middleware to have run.
func GetTenant(ctx context.Context) string {
	if raw := ctx.Value("Tenant"); raw != nil {
		return raw.(string)
	}
	return ""
}

func GetOrigin(ctx context.Context) string {
	GinContext, err := GinContextFromContext(ctx)
	if err != nil {
		return ""
	}
	return GinContext.Request.Header.Get("Origin")

}

func UserWithContext(ctx context.Context, user any) context.Context {
	return context.WithValue(ctx, UserCtxKey.name, user)
}

func TenantWithContext(ctx context.Context, tenant string) context.Context {
	return context.WithValue(ctx, "Tenant", tenant)
}

func GinContextFromContext(ctx context.Context) (*gin.Context, error) {
	ginContext := ctx.Value("GinContextKey")
	if ginContext == nil {
		err := fmt.Errorf("could not retrieve gin.Context")
		return nil, err
	}

	gc, ok := ginContext.(*gin.Context)
	if !ok {
		err := fmt.Errorf("gin.Context has wrong type")
		return nil, err
	}
	return gc, nil
}
