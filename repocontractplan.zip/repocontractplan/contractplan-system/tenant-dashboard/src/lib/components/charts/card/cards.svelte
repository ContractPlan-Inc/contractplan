<script lang="ts">

</script>
<main class="flex items-center justify-between w-full bg-white p-2 rounded-md ">
  <slot />
</main>
