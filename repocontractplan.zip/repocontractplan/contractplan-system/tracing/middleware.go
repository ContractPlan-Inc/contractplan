package tracing

import (
	"log"
	"net/http"
	"os"
	
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	beego "github.com/beego/beego/v2/server/web"
	"go.opentelemetry.io/contrib/detectors/aws/ec2"
	"go.opentelemetry.io/contrib/instrumentation/github.com/aws/aws-sdk-go-v2/otelaws"
	"go.opentelemetry.io/contrib/propagators/aws/xray"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc"
	"go.opentelemetry.io/otel/sdk/trace"
	"google.golang.org/grpc"
	
	"cloudparallax.com/backend/services/aws/config"
	dynamodb2 "cloudparallax.com/backend/services/aws/dynamodb"
)

var tracerHandle = otel.Tracer(beego.BConfig.AppName + "-" + beego.BConfig.RunMode)
var tracing = false

func Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if os.Getenv("TRACING") == "1" {
			tracing = true
			traceExporter, err := otlptracegrpc.New(r.Context(), otlptracegrpc.WithInsecure(), otlptracegrpc.WithEndpoint("0.0.0.0:4317"), otlptracegrpc.WithDialOption(grpc.WithBlock()))
			if err != nil {
				log.Fatalf("%s: %v", "failed to create new OTLP trace exporter", err)
			}
			idg := xray.NewIDGenerator()
			// Instantiate a new EC2 Resource detector
			ec2ResourceDetector := ec2.NewResourceDetector()
			resource, err := ec2ResourceDetector.Detect(r.Context())
			
			tp := trace.NewTracerProvider(
				trace.WithSampler(trace.AlwaysSample()),
				trace.WithBatcher(traceExporter),
				trace.WithIDGenerator(idg),
				trace.WithResource(resource),
			)
			// ctx, seg := xray.BeginSegment(r.Context(), "Root")
			otel.SetTracerProvider(tp)
			otel.SetTextMapPropagator(xray.Propagator{})
			ctx, span := tracerHandle.Start(r.Context(), "Root Span")
			defer span.End()
			
			// instrument all aws clients
			otelaws.AppendMiddlewares(&config.AWSConfig.APIOptions)
			dynamodb2.DDBClient = dynamodb.NewFromConfig(config.AWSConfig)
			r = r.WithContext(ctx)
		}
		next.ServeHTTP(w, r)
	})
}
