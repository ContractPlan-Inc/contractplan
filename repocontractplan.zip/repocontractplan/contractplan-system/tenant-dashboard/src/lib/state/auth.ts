import { goto } from '$app/navigation';
import { createLocalStorage, persist } from '@macfja/svelte-persistent-store';
import { writable } from 'svelte/store';

export interface AuthState {
  user?: {
    name: string;
    id: string;
    Roles: {
      name: string;
    }[];
  };
  loggedIn: boolean;
  redirectPage: string;
  token: string;
  refreshToken: string;
  viewLoaded?: boolean;
  loginAs?: {
    token: string;
    displayName: string;
    email: string;
    userType: string;
  };
}

// export const userType = persist(
//   writable(''),
//   createLocalStorage(),
//   'userType'
// );
export const authState = persist(
  writable({
    loggedIn: false,
    token: '',
    refreshToken: '',
    loginAs: {
      token: '',
      displayName: '',
      email: '',
      userType: ''
    },
    redirectPage: '/'
  } as AuthState),
  createLocalStorage(),
  'authState'
);

export let auth: AuthState = { loggedIn: false, redirectPage: '', token: '',refreshToken:'' } satisfies AuthState;
authState.subscribe((authStateS) => {
  auth = authStateS;
  if (auth.loggedIn && auth.token.length > 5) {
    if (auth.redirectPage !== '/') {
      goto(auth.redirectPage);
    }
  }
});
