import * as cdk from 'aws-cdk-lib';
import { aws_dynamodb, aws_ecr_assets, aws_kms, aws_s3, CfnOutput, Duration, IgnoreMode, pipelines } from 'aws-cdk-lib';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import { OriginProtocolPolicy } from 'aws-cdk-lib/aws-cloudfront';
import * as cloudfront_origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';
import { BuildEnvironmentVariableType, BuildSpec, ComputeType } from 'aws-cdk-lib/aws-codebuild';
import * as codecommit from 'aws-cdk-lib/aws-codecommit';
import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import * as codepipeline_actions from 'aws-cdk-lib/aws-codepipeline-actions';
import { EcsDeployAction } from 'aws-cdk-lib/aws-codepipeline-actions';
import { BillingMode, CfnGlobalTableProps } from 'aws-cdk-lib/aws-dynamodb';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { IVpc } from 'aws-cdk-lib/aws-ec2';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import { ICluster } from 'aws-cdk-lib/aws-ecs';
import * as elb from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as targets from 'aws-cdk-lib/aws-route53-targets';
import { Bucket, BucketEncryption, IBucket, StorageClass } from 'aws-cdk-lib/aws-s3';
import { CodeBuildStep, CodePipeline, CodePipelineSource, ShellStep } from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
import { BaseStack } from './base-stack';
import { QueueStack } from './queue-stack';
import { BackendCdkStack } from './backend-cdk-stack';
import { ClusterCdkStack } from './cluster-stack';
import { DockerImageAsset, Platform } from 'aws-cdk-lib/aws-ecr-assets';
import { StringParameter } from 'aws-cdk-lib/aws-ssm';
import { CognitoStack } from './cognito-stack';
import { FrontendCdkStack } from './frontend-cdk-stack';
import {LambdaCdkStack} from './lambda-cdk-stack';

// import * as sqs from 'aws-cdk-lib/aws-sqs';
export interface BackendCiCdProps extends cdk.StackProps {
}

export class CicdStack extends cdk.Stack {
  public readonly pipeline: CodePipeline;
  public readonly ecr_repository: ecr.Repository;
  public readonly ecr_repository_frontend: ecr.Repository;
  public readonly bucket: aws_s3.IBucket;
  public readonly dockerBuildImage: DockerImageAsset;
  public readonly backendImage: DockerImageAsset;
  public readonly otelImage: DockerImageAsset;
  private vpc: IVpc;
  private testTable: aws_dynamodb.CfnTable;
  public readonly x86dockerBuildImage: DockerImageAsset;

  constructor(scope: Construct, id: string, props: BackendCiCdProps) {
    super(scope, id, props);
    this.vpc = ec2.Vpc.fromLookup(this, 'VPC', { vpcName: 'PRIMARY_VPC' });

    this.dockerBuildImage = new aws_ecr_assets.DockerImageAsset(this, 'BuildImage', {
      file: 'build.Dockerfile',
      directory: './build',
      platform: Platform.LINUX_ARM64,
    });
    this.x86dockerBuildImage = new aws_ecr_assets.DockerImageAsset(this, 'X86BuildImage', {
      file: 'buildx86.Dockerfile',
      directory: './build',
      platform: Platform.LINUX_AMD64,
    });
    this.backendImage = new aws_ecr_assets.DockerImageAsset(this, 'BackendImage', {
      file: 'Dockerfile',
      directory: './',
      platform: Platform.LINUX_ARM64,
      ignoreMode: IgnoreMode.DOCKER
    });
    this.otelImage = new aws_ecr_assets.DockerImageAsset(this, 'OtelImage', {
      file: 'otel.Dockerfile',
      directory: './',
      platform: Platform.LINUX_ARM64,
      ignoreMode: IgnoreMode.DOCKER
    });
    const repositoryLifecycleRules = {
      lifecycleRules: [
        {
          rulePriority: 1,
          maxImageAge: cdk.Duration.days(1),
          tagStatus: ecr.TagStatus.UNTAGGED
        }
      ]
    };
    const kmsKey = aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));
    this.ecr_repository = new ecr.Repository(this, 'backend-ecr-repo', {
      ...repositoryLifecycleRules,
      // encryption: ecr.RepositoryEncryption.KMS,
      // encryptionKey: kmsKey
    });
    const environment = new cdk.CfnParameter(this, 'Environment', {
      type: 'String',
      description: 'Environment'
    });
    const connectionArn = new cdk.CfnParameter(this, 'ConnectionArn', {
      type: 'String',
      description: 'Environment'
    });
    new StringParameter(this, 'SSMBackendRepositoryArn', {
      parameterName: `/backend/repository/arn`,
      stringValue: this.ecr_repository.repositoryArn
    });
    new StringParameter(this, 'SSMBackendRepositoryName', {
      parameterName: `/backend/repository/name`,
      stringValue: this.ecr_repository.repositoryName
    });
    new CfnOutput(this, 'BackendRepositoryArn', {
      description: 'BackendRepositoryArn',
      exportName: `backend-repository-arn`,
      value: this.ecr_repository.repositoryArn
    });
    new CfnOutput(this, 'BackendRepositoryName', {
      description: 'BackendRepositoryName',
      exportName: `backend-repository-name`,
      value: this.ecr_repository.repositoryName
    });


    const dataSource = new DataProviderDynamo(environment.valueAsString);
    const attributeDefinitions = dataSource.getDynamoAttributes();
    const globalSecondaryIndexes = dataSource.getDynamoglobalSecondaryIndexes();
    const replicaGlobalIndexesRead = {
      readProvisionedThroughputSettings: {
        readCapacityAutoScalingSettings: {
          maxCapacity: 4000,
          minCapacity: environment.valueAsString === 'production' ? 25 : 1,
          targetTrackingScalingPolicyConfiguration: {
            targetValue: 75,
            scaleInCooldown: 300,
            scaleOutCooldown: 300
          }
        }
      }
    };
    const writeSpecification = {
      writeProvisionedThroughputSettings: {
        writeCapacityAutoScalingSettings: {
          maxCapacity: 4000,
          minCapacity: environment.valueAsString === 'production' ? 21 : 7,
          targetTrackingScalingPolicyConfiguration: {
            targetValue: 75,
            // the properties below are optional
            disableScaleIn: false,
            scaleInCooldown: 300,
            scaleOutCooldown: 300
          }
        }
      }
    };
    new codecommit.Repository(this, 'system', {
      repositoryName: 'system'
    });
    let maintableObject: CfnGlobalTableProps = {
      timeToLiveSpecification: {
        enabled: true,
        attributeName: '_ttl'
      },

      sseSpecification: {
        sseEnabled: true,
        sseType: 'KMS'
      },
      keySchema: [
        {
          attributeName: 'PK',
          keyType: 'HASH'
        },
        {
          attributeName: 'SK',
          keyType: 'RANGE'
        }
      ],
      attributeDefinitions: attributeDefinitions,
      globalSecondaryIndexes: globalSecondaryIndexes,
      billingMode: 'PROVISIONED',
      streamSpecification: { streamViewType: 'NEW_AND_OLD_IMAGES' },
      replicas: [
        {
          region: process.env.CDK_DEFAULT_REGION ?? '',
          pointInTimeRecoverySpecification: {
            pointInTimeRecoveryEnabled: true
          },
          globalSecondaryIndexes: [
            { indexName: 'InvertedIndex', ...replicaGlobalIndexesRead },
            { indexName: 'EntityStream', ...replicaGlobalIndexesRead },
            { indexName: 'EntityFilter', ...replicaGlobalIndexesRead },
            { indexName: 'IDFilter', ...replicaGlobalIndexesRead },
            { indexName: 'GSI1', ...replicaGlobalIndexesRead },
            { indexName: 'GSI2', ...replicaGlobalIndexesRead },
            { indexName: 'GSI3', ...replicaGlobalIndexesRead },
            { indexName: 'GSI4', ...replicaGlobalIndexesRead }
          ],
          sseSpecification: {
            kmsMasterKeyId: kmsKey.keyId
          },
          ...replicaGlobalIndexesRead
        }
      ],
      ...writeSpecification
    };
    this.testTable = new aws_dynamodb.CfnTable(this, 'TestsTable', {
      ...maintableObject,
      billingMode: BillingMode.PAY_PER_REQUEST
    });
    new CfnOutput(this, 'TestTableName', {
      description: 'Main Table Name',
      value: this.testTable.ref
    });
    this.bucket = aws_s3.Bucket.fromBucketArn(this, 's3-bucket', cdk.Fn.importValue('BaseInfrastructure-website-bucket-arn'));
    const baseDomain = cdk.Fn.importValue('BaseInfrastructure-base-domain');
    const zone = cdk.Fn.importValue('BaseInfrastructure-zone');
    const hostedZone = route53.HostedZone.fromHostedZoneAttributes(this, 'HostedZone', {
      hostedZoneId: zone,
      zoneName: baseDomain
    });

    const appDomain = baseDomain;

    // tslint:disable-next-line:no-unused-expression
    new CfnOutput(this, 'FrontendDomains', {
      description: 'FRONTEND_DOMAINS',
      exportName: `app-frontend-domains`,
      value: `${appDomain}`
    });


    const codePipeline = new codepipeline.Pipeline(this, 'BackendPipelineV2', {
      pipelineType: codepipeline.PipelineType.V2,
      pipelineName: 'BackendPipelineV2'
    });
    const s3Bucket = new aws_s3.Bucket(this, 'PipelineCacheBucket', {
      encryption: BucketEncryption.KMS,
      encryptionKey: kmsKey,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      bucketKeyEnabled: true,
      versioned: false,
      lifecycleRules: [
        {
          id: 'intelligent_tiering_all',
          enabled: true,
          abortIncompleteMultipartUploadAfter: cdk.Duration.days(7),
          noncurrentVersionExpiration: cdk.Duration.days(7),
          noncurrentVersionsToRetain: 1,
          expiration: cdk.Duration.days(30),
          transitions: [
            {
              storageClass: StorageClass.INTELLIGENT_TIERING,
              transitionAfter: cdk.Duration.days(0)
            }
          ]
        }
      ],
      publicReadAccess: false,
      blockPublicAccess: aws_s3.BlockPublicAccess.BLOCK_ALL
    });
    this.pipeline = new CodePipeline(this, 'BackendPipeline', {
      codePipeline: codePipeline,
      publishAssetsInParallel: false,
      dockerEnabledForSynth: true,
      codeBuildDefaults: {
        cache: codebuild.Cache.local(codebuild.LocalCacheMode.SOURCE, codebuild.LocalCacheMode.CUSTOM),
        buildEnvironment: {
          buildImage: codebuild.LinuxArmBuildImage.fromEcrRepository(this.dockerBuildImage.repository, this.dockerBuildImage.imageTag),
          computeType: ComputeType.SMALL,
          privileged: true,
          environmentVariables: {
            CDK_DOCKER: {
              type: BuildEnvironmentVariableType.PLAINTEXT,
              value: 'podman'
            },
            BACKEND_REPOSITORY_URL: {
              value: this.ecr_repository.repositoryUri
            },
            ENVIRONMENT: {
              value: environment.valueAsString ?? 'sandbox'
            }
          }
        },
        partialBuildSpec: BuildSpec.fromObject({
          cache: {
            paths: [
              '~/.local/share/pnpm/store/**',
              '/codebuild/output/.pnpm-store/v3',
              '/cache/**/*',
              '/go/**/*',
              '~/.npm/**/*',
              '~/.pnpm/**/*'
            ]
          }
        })

      },
      assetPublishingCodeBuildDefaults: {
        cache: codebuild.Cache.local(codebuild.LocalCacheMode.SOURCE, codebuild.LocalCacheMode.CUSTOM),
        buildEnvironment: {
          buildImage: codebuild.LinuxArmBuildImage.fromEcrRepository(this.dockerBuildImage.repository, this.dockerBuildImage.imageTag),
          computeType: ComputeType.SMALL,
          privileged: true
        }
      },
      selfMutationCodeBuildDefaults: {
        cache: codebuild.Cache.local(codebuild.LocalCacheMode.SOURCE, codebuild.LocalCacheMode.CUSTOM),
        buildEnvironment: {
          buildImage: codebuild.LinuxArmBuildImage.fromEcrRepository(this.dockerBuildImage.repository, this.dockerBuildImage.imageTag),
          computeType: ComputeType.SMALL,
          privileged: true
        }
      },
      synthCodeBuildDefaults: {
        cache: codebuild.Cache.local(codebuild.LocalCacheMode.SOURCE, codebuild.LocalCacheMode.CUSTOM),
        buildEnvironment: {
          buildImage: codebuild.LinuxBuildImage.fromEcrRepository(this.dockerBuildImage.repository, this.x86dockerBuildImage.imageTag),
          computeType: ComputeType.SMALL,
          privileged: true
        },
        rolePolicy: [
          new iam.PolicyStatement({
            actions: [
              'cloudformation:*',
              'dynamodb:*',
              'ecr:*',
              'ecs:*',
              'iam:*',
              'lambda:*',
              'logs:*',
              's3:*',
              'secretsmanager:*',
              'sns:*',
              'ssm:*',
              'states:*',
              'sqs:*',
              'kms:*'
            ],
            resources: ['*']
          })
        ]
      },
      synth: new ShellStep('SynthesizeBackend', {
        input: CodePipelineSource.connection('CloudParallax/contractplan-system',environment.valueAsString, {
          connectionArn: connectionArn.valueAsString,
          triggerOnPush: true,
          codeBuildCloneOutput: true,
        }),
        installCommands: [
          'pnpm install'
        ],
        commands: [
          'export DATE=$(date +"%Y-%m-%d")',
          'export GOPATH=/go/path/',
          'export PATH=$PATH:$GOPATH/bin',
          'export GOCACHE=/go/cache',
          'chmod +x ./push_images.sh && ./push_images.sh',
          'make test-all',
          'make build'
        ],
        env: {
          CDK_DOCKER: 'podman',
          ENVIRONMENT: environment.valueAsString,
          CDK_DEFAULT_ACCOUNT: process.env.CDK_DEFAULT_ACCOUNT ?? '',
          CDK_DEFAULT_REGION: process.env.CDK_DEFAULT_REGION ?? '',
          AWS_DEFAULT_REGION: process.env.CDK_DEFAULT_REGION ?? '',
          AWS_ACCOUNT_ID: process.env.CDK_DEFAULT_ACCOUNT ?? ''
        }
      })
    });
    let strip = new CodeBuildStep('StripAssetsFromAssembly', {
      input: this.pipeline.synth.primaryOutput,
      buildEnvironment: {
        buildImage: codebuild.LinuxBuildImage.STANDARD_6_0,
        computeType: ComputeType.SMALL,
        privileged: true
      },
      commands: [
        'S3_PATH=${CODEBUILD_SOURCE_VERSION#"arn:aws:s3:::"}',
        'ZIP_ARCHIVE=$(basename $S3_PATH)',
        'echo $S3_PATH',
        'echo $ZIP_ARCHIVE',
        'ls',
        'rm -rfv asset.*',
        'zip -r -q -A $ZIP_ARCHIVE *',
        'ls',
        'aws s3 cp $ZIP_ARCHIVE s3://$S3_PATH'
      ],
      rolePolicyStatements: [new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        resources: ['*'],
        actions: ['s3:*']
      }),
        new iam.PolicyStatement({
          effect: iam.Effect.ALLOW,
          resources: ['*'],
          actions: ['kms:GenerateDataKey']
        })]
    });
    const preChecks = [];
    if (process.env.ENVIRONMENT === 'production') {
      preChecks.push(new pipelines.ManualApprovalStep('Pre-Stack Check'));
    }
    this.pipeline.addStage(new BackendDeploymentStage(this, 'Deployment', {
        env: {
          region: this.region,
          account: this.account
        },
        frontendBucket: this.bucket,
        backendImageUri: this.backendImage.imageUri,
        otelImageUri: this.otelImage.imageUri,
        environment: process.env.ENVIRONMENT ?? 'sandbox'
      }),
      {
        pre: process.env.ENVIRONMENT === 'production' ? [new pipelines.ManualApprovalStep('Pre-Stack Check'),strip] : [strip]
      }
    );

    this.pipeline.buildPipeline();
    const pipeline = this.pipeline.pipeline;
    const pipelineRole = pipeline.role;
    // Add application source action
    // const sourceStage = pipeline.stage('Source');
    // if (sourceStage) {
    //   const sourceOutputs = sourceStage.actions[0].actionProperties.outputs;
    //   const codebuildServiceRole = this.createCodeBuildServiceRole(this, pipelineRole);
    //   if (sourceOutputs && sourceOutputs.length > 0) {
    //     const sourceArtifact = sourceOutputs[0];
    //     const codeBuildProjectSvelte = new codebuild.PipelineProject(this, 'SvelteBuildProject', {
    //       environment: {
    //         buildImage: codebuild.LinuxBuildImage.STANDARD_7_0,
    //         computeType: ComputeType.SMALL,
    //         privileged: true
    //       },
    //       buildSpec: codebuild.BuildSpec.fromSourceFilename('svelte-frontend/build/buildspec-svelte.yml'),
    //       role: codebuildServiceRole
    //     });
    //     const svelteBuildAction = new codepipeline_actions.CodeBuildAction({
    //       actionName: 'SvelteBuild',
    //       project: codeBuildProjectSvelte,
    //       input: sourceArtifact,
    //       outputs: [codepipeline.Artifact.artifact('SvelteBuildOutput')],
    //       environmentVariables: {
    //         AWS_DEFAULT_REGION: {
    //           value: this.region
    //         },
    //         AWS_ACCOUNT_ID: {
    //           value: this.account
    //         },
    //         ENVIRONMENT: {
    //           value: process.env.ENVIRONMENT ?? 'sandbox'
    //         },
    //         NODE_ENV: {
    //           value: process.env.ENVIRONMENT ?? 'sandbox'
    //         },
    //         FRONTEND_REPOSITORY_URL: {
    //           value: this.ecr_repository_frontend.repositoryUri
    //         }
    //       }
    //     });
    //     pipeline.stage('Build').addAction(svelteBuildAction);
    //     const codeBuildProject = new codebuild.PipelineProject(this, 'DockerBuildProject', {
    //       environment: {
    //         buildImage: codebuild.LinuxArmBuildImage.AMAZON_LINUX_2_STANDARD_3_0,
    //         computeType: ComputeType.SMALL,
    //         privileged: true
    //       },
    //       buildSpec: codebuild.BuildSpec.fromSourceFilename('build/buildspec.yml'),
    //       role: codebuildServiceRole
    //     });
    //     const buildAction = new codepipeline_actions.CodeBuildAction({
    //       actionName: 'BackendBuild',
    //       project: codeBuildProject,
    //       input: sourceArtifact,
    //       outputs: [codepipeline.Artifact.artifact('DockerBuildOutput')],
    //       environmentVariables: {
    //         AWS_DEFAULT_REGION: {
    //           value: this.region
    //         },
    //         AWS_ACCOUNT_ID: {
    //           value: this.account
    //         },
    //         IMAGE_REPO: {
    //           value: 'backend'
    //         },
    //         IMAGE_TAG: {
    //           value: 'latest'
    //         },
    //         BACKEND_REPOSITORY_URL: {
    //           value: this.ecr_repository.repositoryUri
    //         },
    //         ENVIRONMENT: {
    //           value: process.env.ENVIRONMENT ?? 'sandbox'
    //         }
    //       }
    //     });
    //     pipeline.stage('Build').addAction(buildAction);
    //   }
    // }
    const buildStage = pipeline.stage('Build');

    if (buildStage) {
      const buildOutputs = buildStage.actions[0].actionProperties.outputs;
      const cluster = ecs.Cluster.fromClusterAttributes(this, `ApplicationCluster`, {
        clusterName: 'application-cluster',
        vpc: this.vpc,
        securityGroups: []
      });
      if (buildOutputs && buildOutputs.length > 0) {
        const buildArtifact = buildOutputs[0];
        pipeline.addStage({
          stageName: 'ECSDeployment',
          actions: [
            this.createDeployAction(buildArtifact, cluster, 'backend-service')
          ]
        });
      }
      const svelteBuildOutputs = buildStage.actions[0].actionProperties.outputs;
      // const invalidateAction = new codepipeline_actions.CodeBuildAction({
      //   actionName: 'InvalidateCache',
      //   project: invalidateBuildProject,
      //   input: svelteBuildOutputs[0],
      //   runOrder: 2
      // });
      // const deployAction2 = new codepipeline_actions.S3DeployAction({
      //   actionName: 'S3DeploySvelte',
      //   bucket: this.bucket,
      //   input: svelteBuildOutputs[0],
      //   cacheControl: [
      //     codepipeline_actions.CacheControl.maxAge(Duration.days(365))
      //   ],
      //   role: role
      // });
      // const stage = pipeline.addStage({
      //   stageName: 'S3Deployment',
      //   actions: [
      //     invalidateAction
      //   ]
      // });
    }

    // Add this where you need the S3 bucket URL
    const s3BucketUrl = cdk.Fn.importValue('cognito-s3-bucket-url');
  }

  createDeployAction(input: codepipeline.Artifact, cluster: ICluster, serviceName: string): EcsDeployAction {
    const serviceDeploy: ecs.IBaseService = this.getService(cluster, serviceName);
    //  console.log('Deploy input', input)
    return new codepipeline_actions.EcsDeployAction({
      actionName: `ECSDeploy-${serviceName}`,
      service: serviceDeploy,
      imageFile: input.atPath(`${serviceName}.imagedefinitions.json`)
    });
  }

  getService(cluster: ICluster, serviceName: string): ecs.IBaseService {
    const ec2ServiceAttributes: ecs.Ec2ServiceAttributes = {
      cluster: cluster,
      serviceName: serviceName
    };
    return ecs.Ec2Service.fromEc2ServiceAttributes(this, `ec2service-${serviceName}`, ec2ServiceAttributes);
  }

  updateCodeBuildPolicy(scope: Construct, pipelineRole: iam.IRole): iam.Role {
    const role = new iam.Role(scope, 'CodeBuildServiceRole', {
      assumedBy: new iam.ServicePrincipal('codebuild.amazonaws.com')
    });
    role.assumeRolePolicy?.addStatements(new iam.PolicyStatement({
      sid: 'PipelineAssumeCodeBuildServiceRole',
      effect: iam.Effect.ALLOW,
      actions: ['sts:AssumeRole'],
      principals: [pipelineRole]
    }));

    // Required policies to create an AWS CodeBuild service role
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'CloudWatchLogsPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        'logs:CreateLogGroup',
        'logs:CreateLogStream',
        'logs:PutLogEvents'
      ],
      resources: ['*']
    }));
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'CodeCommitPolicy',
      effect: iam.Effect.ALLOW,
      actions: ['codecommit:GitPull'],
      resources: ['*']
    }));
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'S3GetObjectPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        's3:GetObject',
        's3:GetObjectVersion'
      ],
      resources: ['*']
    }));
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'S3PutObjectPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        's3:PutObject'
      ],
      resources: ['*']
    }));
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'S3BucketIdentity',
      effect: iam.Effect.ALLOW,
      actions: [
        's3:GetBucketAcl',
        's3:GetBucketLocation'
      ],
      resources: ['*']
    }));

    // This statement allows CodeBuild to upload Docker images to Amazon ECR repositories.
    // source: https://docs.aws.amazon.com/codebuild/latest/userguide/sample-docker.html#sample-docker-running
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'ECRUploadPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        'ecr:BatchCheckLayerAvailability',
        'ecr:CompleteLayerUpload',
        'ecr:GetAuthorizationToken',
        'ecr:GetDownloadUrlForLayer',
        'ecr:GetRepositoryPolicy',
        'ecr:DescribeRepositories',
        'ecr:ListImages',
        'ecr:DescribeImages',
        'ecr:BatchGetImage',
        'ecr:ListTagsForResource',
        'ecr:DescribeImageScanFindings',
        'ecr:InitiateLayerUpload',
        'ecr:PutImage',
        'ecr:UploadLayerPart'
      ],
      resources: ['*']
    }));
    // This statement allows CodeBuild to test against a non-used dynamodb table
    // source: https://docs.aws.amazon.com/codebuild/latest/userguide/sample-docker.html#sample-docker-running
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'DynamoDBAccessPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        'dynamodb:*'
      ],
      resources: [
        this.testTable.attrArn,
        `${this.testTable.attrArn}/index/*`
      ]
    }));
    // This statement allows CodeBuild to Retrieve Cloudformation Values
    // source: https://docs.aws.amazon.com/codebuild/latest/userguide/sample-docker.html#sample-docker-running
    role.addToPolicy(new iam.PolicyStatement({
      sid: 'CFNAccessPolicy',
      effect: iam.Effect.ALLOW,
      actions: [
        'cloudformation:DescribeStacks'
      ],
      resources: [
        `*`
      ]
    }));

    return role;
  }
}

export interface BackendDeploymentProps extends cdk.StackProps {
  frontendBucket: IBucket;
  environment: string;
  backendImageUri: string;
  otelImageUri: string;
}

export class BackendDeploymentStage extends cdk.Stage {
  constructor(scope: Construct, id: string, props: BackendDeploymentProps) {
    super(scope, id, props);
    const clusterStack = new ClusterCdkStack(this, 'ClusterCdkStack', {
      environment: props.environment,
      env: {
        account: this.account,
        region: this.region
      }
    });
    const queueStack = new QueueStack(this, 'QueueCdkStack', {
      environment: props.environment,
      env: {
        account: this.account,
        region: this.region
      }
    });
    const cognitoStack = new CognitoStack(this, 'CognitoStack', {
      environment: props.environment,
      env: {
        account: this.account,
        region: this.region
      }
    });
    const baseStack = new BaseStack(this, 'BaseCdkStack', {
      environment: props.environment,
      env: {
        account: this.account,
        region: this.region
      }
    });

    const backendStack = new BackendCdkStack(this, 'BackendCdkStack', {
      env: {
        account: this.account,
        region: this.region
      },
      cluster: clusterStack.cluster,
      capacityProvider: clusterStack.capacityProvider,
      ecsSG: clusterStack.ecsSG,
      environment: props.environment,
      logGroup: clusterStack.logGroup,
      email_queue: queueStack.email_queue,
      backendImageUri: props.backendImageUri,
      otelImageUri: props.otelImageUri,
      stripe_secret: baseStack.stripeSecret,
      userPool: cognitoStack.userPool,
      userPoolClient: cognitoStack.userPoolClient
    });
    const frontendStack = new FrontendCdkStack(this, 'FrontendCdkStack', {
      path: '',
      src: 'svelte-frontend/svelte-app',
      subdomain: '',
      env: {
        account: this.account,
        region: this.region
      }
    });
    const dashboardStack = new FrontendCdkStack(this, 'TenantDashboardStack', {
      path: '',
      src: 'tenant-dashboard/svelte-app',
      subdomain: 'tenants',
      env: {
        account: this.account,
        region: this.region
      }
    });

    const lambdaStack =  new LambdaCdkStack(this, 'LambdaCdkStack', {
      env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION
      },
      environment: process.env.ENVIRONMENT ?? 'sandbox',
      stripe_secret: baseStack.stripeSecret,
    })


  }
}

export class DataProviderDynamo {
  public baseAttributes: any = [
    { name: 'a', type: 'S' },
    { name: 'EntityType', type: 'S' },
    { name: 'EntitySK', type: 'S' },
    { name: '¶', type: 'S' },
    { name: 'PK', type: 'S' },
    { name: 'SK', type: 'S' },
    { name: 'GSI1PK', type: 'S' },
    { name: 'GSI1SK', type: 'S' },
    { name: 'GSI2PK', type: 'S' },
    { name: 'GSI2SK', type: 'S' },
    { name: 'GSI3PK', type: 'S' },
    { name: 'GSI3SK', type: 'S' },
    { name: 'GSI4PK', type: 'S' },
    { name: 'GSI4SK', type: 'S' }
  ];
  public baseObjectAutoScaling: any = {
    targetName: '{{targetname}}',
    policyName: '{{policyname}}',
    resourceId: '{{resourceId}}',
    scalableDimension: '{{sacleableunits}}',
    predefinedMetricType: '{{predefinedMetricType}}',
    props: {
      maxCapacity: 4000,
      minCapacity: 10,
      targetValue: 40,
      scaleInCooldown: 20,
      scaleOutCooldown: 20
    }
  };
  private environment: string;

  constructor(environment: string) {
    this.environment = environment;
  }

  getDynamoAttributes() {
    const attributes = [];
    for (const attr of this.baseAttributes) {
      const attributeDefinitionProperty: aws_dynamodb.CfnGlobalTable.AttributeDefinitionProperty =
        {
          attributeName: attr.name,
          attributeType: attr.type
        };
      attributes.push(attributeDefinitionProperty);
    }
    return attributes;
  }

  getDynamoglobalSecondaryIndexes() {
    const indexs: any = [
      {
        name: 'InvertedIndex',
        keyschema: [
          { name: 'SK', type: 'HASH' },
          { name: 'PK', type: 'RANGE' }
        ]
      },
      {
        name: 'EntityStream',
        keyschema: [
          { name: '¶', type: 'HASH' },
          { name: 'PK', type: 'RANGE' }
        ]
      },
      {
        name: 'EntityFilter',
        keyschema: [
          { name: 'EntityType', type: 'HASH' },
          { name: 'EntitySK', type: 'RANGE' }
        ]
      },
      {
        name: 'IDFilter',
        keyschema: [
          { name: 'EntityType', type: 'HASH' },
          { name: 'a', type: 'RANGE' }
        ]
      },
      {
        name: 'GSI1',
        keyschema: [
          { name: 'GSI1PK', type: 'HASH' },
          { name: 'GSI1SK', type: 'RANGE' }
        ]
      },
      {
        name: 'GSI2',
        keyschema: [
          { name: 'GSI2PK', type: 'HASH' },
          { name: 'GSI2SK', type: 'RANGE' }
        ]
      },
      {
        name: 'GSI3',
        keyschema: [
          { name: 'GSI3PK', type: 'HASH' },
          { name: 'GSI3SK', type: 'RANGE' }
        ]
      },
      {
        name: 'GSI4',
        keyschema: [
          { name: 'GSI4PK', type: 'HASH' },
          { name: 'GSI4SK', type: 'RANGE' }
        ]
      }
    ];
    const writeThroughput: aws_dynamodb.CfnGlobalTable.WriteProvisionedThroughputSettingsProperty =
      {
        writeCapacityAutoScalingSettings: {
          maxCapacity: 4000,
          minCapacity: this.environment === 'production' ? 25 : 1,
          seedCapacity: 10,
          targetTrackingScalingPolicyConfiguration: {
            targetValue: 75,
            scaleInCooldown: 300,
            scaleOutCooldown: 300
          }
        }
      };
    const globalSecondaryIndexes = [];
    for (const index of indexs) {
      const keySchema = [];
      for (const attr of index.keyschema) {
        keySchema.push({ attributeName: attr.name, keyType: attr.type });
      }
      const globalSecondaryIndexe: any = {
        indexName: index.name,
        keySchema: keySchema,
        projection: {
          projectionType: 'KEYS_ONLY'
        },
        contributorInsightsSpecification: {
          enabled: false
        }
      };
      globalSecondaryIndexe.writeProvisionedThroughputSettings =
        writeThroughput;
      globalSecondaryIndexes.push(globalSecondaryIndexe);
    }
    // console.log(globalSecondaryIndexes)
    return globalSecondaryIndexes;
  }
}
