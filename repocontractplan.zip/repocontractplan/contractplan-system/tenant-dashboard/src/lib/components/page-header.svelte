<script lang="ts">
  export let Title = '';
  export let Subtitle = '';
</script>

<slot />

