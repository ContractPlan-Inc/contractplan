<script lang="ts">
  import {userPool} from "$lib/cognito/pool.js";
  import {CognitoUser} from "amazon-cognito-identity-js";
  import {validateConfirmNewPasswordForm} from './service';
  import * as yup from 'yup';
  import {goto} from '$app/navigation';


  interface ResetPasswordProps {
    email: string;
    step: string
  }

  let { email = $bindable(), step = $bindable() }: ResetPasswordProps = $props();

  let verificationCode: string = $state('');
  let newPassword: string = $state('');

  let errors: { [key: string]: string } = $state({});
  let loading:boolean = $state(false);

  let isPasswordChanged = $state(false);



  let createNewPasswordSchema = yup.object().shape({
    verificationCode: yup.string().required()
      .matches(/^[0-9]+$/, "Must be only digits")
      .min(6, 'Must be exactly 6 digits')
      .max(6, 'Must be exactly 6 digits'),
    newPassword: yup
      .string()
      .required('Password is required')
      .min(8, 'Password is too short - should be 8 chars minimum.')
      .test(
        'password-validation',
        'Password must have at least one uppercase letter, one lowercase letter, one number, and one special character',
        (value) => {
          if (!value) {
            return true;
          }
          const hasUppercase = /[A-Z]/.test(value);
          const hasLowercase = /[a-z]/.test(value);
          const hasNumber = /[0-9]/.test(value);
          const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(
            value
          );

          return hasUppercase && hasLowercase && hasNumber && hasSpecialChar;
        }
      )
  })

  function confirmPassword(){
    loading = true
    let userData = {
      Username: email,
      Pool: userPool
    };

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.confirmPassword(verificationCode, newPassword, {
      onFailure(err) {
        loading = false

        console.log("password confirmation error", err)

        if(err.name === "CodeMismatchException"){
          errors.verificationCode = "Invalid verification code"
        }else{
          console.error('Unknown error verificationCode:', err.name, 'Exception:', err);
        }
      },
      onSuccess(data){

        verificationCode = "";
        newPassword = "";

        loading = false
        isPasswordChanged = true;

        setTimeout(() => {
          goto('/auth/signin');
        }, 2500)
      }
    })
  }

  async function validateConfirmNewPassword(){
    let returnedError = await validateConfirmNewPasswordForm({ verificationCode, newPassword}, createNewPasswordSchema);
    console.log("returnedError", returnedError)
    if (returnedError != null){
      errors = returnedError
    }else{
      errors = {};
      confirmPassword();
    }
  }
</script>

<form class="w-1/2 p-9 flex-grow  min-w-[450px]"  onsubmit={(event)=>{event.preventDefault;validateConfirmNewPassword()}}>
  <p>We have sent a password reset verification code by email to {email} Enter it below to reset your password. </p>

  <div class="space-y-4 my-4">
    <div class="relative flex flex-col items-start w-full  ">
      <label class="text-sm my-2" for="verificationCode">
        Verification Code
      </label>
      <input bind:value={verificationCode}
             type="text"
             class="bg-gray-50 border mb-1  text-gray-900 text-sm rounded-lg {errors.verificationCode ? ' border-red-500' : ''} focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 [-moz-appearance:_textfield] [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:m-0 [&::-webkit-outer-spin-button]:appearance-none"
             id="verificationCode"
             placeholder="112345"
      />
      <div class=" h-2">
        {#if errors.verificationCode}
          <p class="text-xs text-red-500 ">{errors.verificationCode}</p>
        {/if}
      </div>
    </div>

    <div class="relative flex flex-col items-start w-full  ">
      <label class="text-sm my-2" for="password">
        New Password
      </label>
      <input bind:value={newPassword}
             type="password"
             class="bg-gray-50 border mb-1  text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block {errors.newPassword ? ' border-red-500' : ''}  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
             id="password"
             placeholder="********"
      />
      <div class=" h-2">
        {#if errors.newPassword}
          <p class="text-xs text-red-500 ">{errors.newPassword}</p>
        {/if}
      </div>
    </div>


  </div>
    <button class="bg-black text-white px-3 py-2 mt-4 rounded-lg w-full" type="submit" >Change password</button>


  {#if isPasswordChanged}
    <p class=" text-primary-dark text-center  text-md my-4">Your password has been changed successfully </p>
  {/if}

</form>

<div class="fixed z-40 top-0 bottom-0 left-0 right-0 bg-black bg-opacity-50 flex items-center justify-center"
     style="display: {loading ? 'flex' : 'none'};">
  <div
    class="z-50 fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mx-auto flex justify-center items-center p-5 bg-white rounded-lg "
    role="alert">
    <div class="animate-spin rounded-full border-t-4 border-green-600 border-solid h-16 w-16"></div>
  </div>
</div>

