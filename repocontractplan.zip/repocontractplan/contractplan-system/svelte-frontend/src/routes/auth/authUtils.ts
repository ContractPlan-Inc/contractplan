import { goto } from "$app/navigation";
import { authError, authUser } from "$lib/state/store";
import { getCurrentPlan } from "./signin/service";
import type { Auth } from "$lib/state/auth";
import { auth } from "$lib/state/auth";

export async function handleAuthSuccess(result: any): Promise<Auth> {
  const auth = {
    token: result.getAccessToken().getJwtToken(),
    refreshToken: result.getRefreshToken().getToken(),
    loggedIn: true
  };

  const currentPlan = await getCurrentPlan();

  if (currentPlan === null || currentPlan === undefined) {
    authError.set('PlanNotSelected');
    await goto('/auth/registration');
  } else {
    await goto('/app/');
  }

  return auth;
}

export function handleAuthError(err: any, email?: string, password?: string): { authentication: string } {
  let errors = { authentication: '' };

  if (err.code === 'UserNotConfirmedException') {
    errors.authentication = 'Account not confirmed. Please check your email for confirmation.';
    authError.set('UserNotConfirmed');
    if (email && password) {
      authUser.set({ email, password });
    }
    goto('/auth/registration');
  } else if (err.code === 'PasswordResetRequiredException') {
    errors.authentication = 'Password reset required. Please reset your password.';
  } else if (err.code === 'UserNotFoundException') {
    errors.authentication = 'User not found. Please check your email and password.';
  } else if (err.code === 'NotAuthorizedException') {
    errors.authentication = 'Invalid email or password. Please check your email and password.';
  } else {
    console.error('Unknown error code:', err.code, 'Exception:', err);
  }

  return errors;
}

export function sayHello() {
  console.log('Hello');
}

export function checkAuthAndRedirect() {
  if (auth.token && auth.loggedIn) {
    goto('/app');
    return true;
  }
  return false;
}
