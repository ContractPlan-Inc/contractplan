package models

import (
	"encoding/json"
	"io"

	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type DynamoLastEvaluatedKey struct {
	GsiKeyMap map[string]map[string]types.AttributeValue
}

// UnmarshalGQL implements the graphql.Unmarshaler interface
func (y DynamoLastEvaluatedKey) UnmarshalGQL(v interface{}) error {
	if err := json.Unmarshal(v.([]byte), &y); err != nil {
		return err
	}
	return nil
}

// MarshalGQL implements the graphql.Marshaler interface
func (y DynamoLastEvaluatedKey) MarshalGQL(w io.Writer) {
	if out, err := json.Marshal(y); err == nil {
		_, err := w.Write(out)
		if err != nil {
			panic(err)
		}
	} else {
		_, err := w.Write([]byte(``))
		panic(err)
	}
}
