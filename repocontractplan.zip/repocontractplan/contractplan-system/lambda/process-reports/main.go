package main

import (
	"context"
	originalJson "encoding/json"
	"fmt"
	"os"

	opensearch2 "cloudparallax.com/backend/services/aws/opensearch"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/aws/aws-sdk-go-v2/service/sqs/types"
	"github.com/aws/aws-secretsmanager-caching-go/secretcache"
	jsoniter "github.com/json-iterator/go"
	"github.com/kr/pretty"

	"cloudparallax.com/backend/models"
)

var json = jsoniter.ConfigCompatibleWithStandardLibrary

var secretCache, _ = secretcache.New()
var queueUrl string
var sqsClient *sqs.Client

func handler(ctx context.Context, request events.DynamoDBEvent) (string, error) {
	var err error
	//print current working directory
	dir, err := os.Getwd()
	if err != nil {
		pretty.Println(err)
	}
	pretty.Println("CUR DIR:", dir)

	var SHOWQUERY = os.Getenv("SHOWQUERY")
	if SHOWQUERY == "1" {
		requestJson, _ := originalJson.Marshal(request)
		pretty.Println(string(requestJson))
	}
	openSearchClient, err := opensearch2.NewClient()
	if err != nil {
		pretty.Println("ERROR", err)
	}
	pretty.Println("TOTAL RECORDS TO PROCESS:", len(request.Records))
	for _, record := range request.Records {
		if eType, ok := record.Change.NewImage["¶"]; ok && eType.String() != "" {
			switch eType.String() {
			case "USERS":
				users, err := models.UnmarshalStreamImage(models.User{}, record.Change.NewImage, false)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(users.Tenant, users.ID, users, openSearchClient, users.Tenant)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
			case "ROLE_USER":
				roleUser, err := models.UnmarshalStreamImage(models.UserRole{}, record.Change.NewImage, false)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(roleUser.Tenant, roleUser.RoleID+roleUser.UserID, roleUser, openSearchClient, roleUser.Tenant)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
			case "ROLES":
				roles, err := models.UnmarshalStreamImage(models.Role{}, record.Change.NewImage, false)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(roles.Tenant, roles.ID, roles, openSearchClient, roles.Tenant)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
			case "ROLE_POLICY":
				rolePolicy, err := models.UnmarshalStreamImage(models.RolePolicy{}, record.Change.NewImage, false)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(rolePolicy.Tenant, rolePolicy.PolicyID+rolePolicy.RoleID, rolePolicy, openSearchClient, rolePolicy.Tenant)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
			case "POLICY":
				permissions, err := models.UnmarshalStreamImage(models.Policy{}, record.Change.NewImage, false)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(permissions.Tenant, permissions.ID, permissions, openSearchClient, permissions.Tenant)

				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
			case "CONTRACT_DAY_RECORD":
				contractDayRecord, err := models.UnmarshalStreamImage(models.ContractDayRecord{}, record.Change.NewImage, false)
				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(contractDayRecord.Tenant, contractDayRecord.ID, contractDayRecord, openSearchClient, contractDayRecord.Tenant)
			case "CONTRACT":
				contract, err := models.UnmarshalStreamImage(models.Contract{}, record.Change.NewImage, false)
				if err != nil {
					pretty.Println("ERROR", err)
					return "", err
				}
				err = models.InsertIndexIntoOS(contract.Tenant, contract.ID, contract, openSearchClient, contract.Tenant)
			}
		}
	}
	if err != nil {
		pretty.Println("ERROR", err)
		return "", err
	}
	return "", err
}

func main() {
	cfg, err := config.LoadDefaultConfig(context.TODO())
	if err != nil {
		panic("configuration error, " + err.Error())
	}
	sqsClient = sqs.NewFromConfig(cfg)
	queueUrl = os.Getenv("BILLING_QUEUE_URL")
	lambda.Start(handler)
}

// SQSSendMessageAPI defines the interface for the GetQueueUrl and SendMessage functions.
// We use this interface to test the functions using a mocked service.
type SQSSendMessageAPI interface {
	GetQueueUrl(ctx context.Context,
		params *sqs.GetQueueUrlInput,
		optFns ...func(*sqs.Options)) (*sqs.GetQueueUrlOutput, error)

	SendMessage(ctx context.Context,
		params *sqs.SendMessageInput,
		optFns ...func(*sqs.Options)) (*sqs.SendMessageOutput, error)
}

// SendMsg sends a message to an Amazon SQS queue.
// Inputs:
//
//	c is the context of the method call, which includes the AWS Region.
//	api is the interface that defines the method call.
//	input defines the input arguments to the service call.
//
// RouteOutput:
//
//	If success, a SendMessageOutput object containing the result of the service call and nil.
//	Otherwise, nil and an error from the call to SendMessage.
func SendMsg(c context.Context, api SQSSendMessageAPI, input *sqs.SendMessageInput) (*sqs.SendMessageOutput, error) {
	return api.SendMessage(c, input)
}

func send[F models.Model](modelType string, model F) error {
	message, err := json.MarshalToString(model)
	if err != nil {
		return err
	}
	sMInput := &sqs.SendMessageInput{
		DelaySeconds: 10,
		MessageAttributes: map[string]types.MessageAttributeValue{
			"Model": {
				DataType:    aws.String("String"),
				StringValue: aws.String(modelType),
			},
		},
		MessageBody: aws.String(message),
		QueueUrl:    aws.String(queueUrl),
	}

	resp, err := SendMsg(context.TODO(), sqsClient, sMInput)
	if err != nil {
		fmt.Println("Got an error sending the message:")
		fmt.Println(err)
		return err
	}
	fmt.Println("Sent message with ID: " + *resp.MessageId)
	return nil
}
