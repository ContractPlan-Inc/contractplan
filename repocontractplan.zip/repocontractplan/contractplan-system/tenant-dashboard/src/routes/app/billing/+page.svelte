<script lang="ts">
  import SubscriptionCard from './subscription.svelte';

  // let data: any = [{ planPrice:100, currentPlan:true },{ planPrice:200 },{ planPrice:300 }];
  export let data;

  console.log('Plans:', data);
</script>

<div class=" space-y-6 p-6">
  <div class="">
    <SubscriptionCard data={data} />
  </div>

  <div class=" relative border rounded-lg border-gray-200 p-6">
    <p class=" text-xs text-gray-500 my-1">Payment</p>
    <div class=" border-b flex  items-center justify-between py-3">
      <p class=" font-medium">Card Nubmer</p>
      <p>XXXX XXXX XXXX 1234</p>
    </div>
    <div class=" border-b flex  items-center justify-between py-3">
      <p class=" font-medium">Next Payment</p>
      <p>$100.00</p>
    </div>
    <div class=" flex  items-center justify-between py-3">
      <p class=" font-medium">Payment Due</p>
      <p>12/12/2023</p>
    </div>
  </div>
  <button class=" text-red-500 text-sm">Cancel Subscription</button>
</div>



