package sqs

import (
	"context"
	"fmt"
	
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/aws/aws-sdk-go-v2/service/sqs/types"
	jsoniter "github.com/json-iterator/go"
	
	"cloudparallax.com/backend/models"
	"cloudparallax.com/backend/services/aws/config"
)

type SQSSendMessageAPI interface {
	GetQueueUrl(ctx context.Context,
		params *sqs.GetQueueUrlInput,
		optFns ...func(*sqs.Options)) (*sqs.GetQueueUrlOutput, error)
	
	SendMessage(ctx context.Context,
		params *sqs.SendMessageInput,
		optFns ...func(*sqs.Options)) (*sqs.SendMessageOutput, error)
}

var json = jsoniter.ConfigCompatibleWithStandardLibrary
var queueUrl string
var sqsClient *sqs.Client

func SqsSend[F models.Model](modelType string, model F, url string) error {
	
	sqsClient := sqs.NewFromConfig(config.AWSConfig)
	queueUrl := url // os.Getenv("PENDING_BILL_EMAIL_QUEUE")
	message, err := json.MarshalToString(model)
	
	sMInput := &sqs.SendMessageInput{
		DelaySeconds: 10,
		MessageAttributes: map[string]types.MessageAttributeValue{
			"Model": {
				DataType:    aws.String("String"),
				StringValue: aws.String(modelType),
			},
		},
		MessageBody: aws.String(message),
		QueueUrl:    aws.String(queueUrl),
	}
	resp, err := SendMsg1(context.TODO(), sqsClient, sMInput)
	if err != nil {
		fmt.Println("Got an error sending the message:")
		fmt.Println(err)
		return err
	}
	fmt.Println("Sent message with ID: " + *resp.MessageId)
	if err != nil {
		return nil
	}
	return nil
	
}

func SendMsg1(c context.Context, api SQSSendMessageAPI, input *sqs.SendMessageInput) (*sqs.SendMessageOutput, error) {
	return api.SendMessage(c, input)
}
