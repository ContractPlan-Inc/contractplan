<script lang="ts">
  // import { navigate } from 'svelte-routing';
  import { flip } from 'svelte/animate';
  import { dndzone, TRIGGERS } from 'svelte-dnd-action';
  import { createEventDispatcher, onMount } from 'svelte';

  const dispatch = createEventDispatcher();

  const flipDurationMs = 150;
  export let name: string;

  export let items: any;
  export let onDrop: any;

  const onload = () => {
    items.forEach((item) => {
      // console.log('this is ', item);
      item.expanded = false;
    });
    // console.log('this is the items', items);
  };
  onload();
  onMount(() => {
    // push a new item 'expand' to the array (items) using forEach
    // console.log('this is the items', items);
  });

  function expand(id: number) {
    items = items.map((item) => {
      if (item.id === id) {
        return { ...item, expanded: !item.expanded };
      }
      return item;
    });
  }

  const sendId = (selectedId, name: string) => {
    dispatch('contractStatus', { selectedId, name });
  };

  function handleDndConsiderCards(e) {
    items = e.detail.items;
  }

  function handleDndFinalizeCards(e, name: string) {
    // console.log("handleDndFinalizeCards")
    let { info: { trigger, id } } = e.detail;
    onDrop(e.detail.items);
    if (trigger === TRIGGERS.DROPPED_INTO_ZONE) {
      sendId(id, name);
    }
  }

  function edit(id: number) {
    // console.log('this is passed',id);
    // myStore.set(id);
  }

  function calculateDays(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diff = end.getTime() - start.getTime();
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round(diff / oneDay);
  }

</script>
<div class='border-2 border-gray-600 bg-gray-200 rounded-md p-2 w-full'>
  <div
    class="{name === 'TODO' ? 'bg-primary-light':''} {name === 'IN PROGRESS' ? 'bg-primary':''} {name === 'DONE' ? 'bg-primary-dark':''}  {name === 'CHECKED' ? 'bg-cyan-600':''} {name === 'DEPLOYED' ? 'bg-cyan-700':''} py-2 -mx-2 -mt-2 text-center">
    {name}
  </div>
  <div class="space-y-2 py-2 " onconsider={(e) => {handleDndConsiderCards(e)}}
       onfinalize={(e) => {handleDndFinalizeCards(e, name)}}
       use:dndzone={{items, flipDurationMs, zoneTabIndex: -1}}
  >
    {#each items as item (item.id) }
      <div class="flex flex-col p-1 border-2 bg-white border-gray-400 rounded-md cursor-move space-y-1"
           animate:flip="{{duration: flipDurationMs}}">
        <div class="flex justify-between items-center">
          <div>{item.contract_name}</div>
          <div class="flex items-center">
            <!-- <a href={`/calculator/${item.id}`} onclick={()=>edit(item.id)} class="hover:cursor-pointer">-->
            <a href="/calculator" onclick={()=>edit(item.id)} class="hover:cursor-pointer">
                      <span
                        class="material-symbols-outlined ">
                        edit
                        </span>
            </a>
            {#if item.expanded}
              <button onclick={()=> expand(item.id)} class=" ">
                        <span class="material-symbols-outlined">
                          expand_less
                          </span>
              </button>
            {:else}
              <button onclick={()=> expand(item.id)} class=" ">
                          <span class="material-symbols-outlined">
                            expand_more
                            </span>
              </button>
            {/if}

          </div>

        </div>
        <div class="text-xs flex justify-between items-center ">
          <div>{item.contract_partner}</div>
          <div>{item.contract_alias}</div>
        </div>
        <div class="space-y-1 {item.expanded ? 'block' : 'hidden'} ">

          <div class="border rounded-md p-0.5">
            <div class="font-bold">Basic Info</div>
            <div class="flex justify-between">
              <div class=" text-sm">Service Period - {item.service_period}</div>
              <div class=" text-sm">{calculateDays(item.start_date, item.end_date)} Days</div>
            </div>
            <div class="flex justify-between">
              <div class="text-sm">From : {item.start_date}</div>
              <div class="text-sm">To : {item.end_date}</div>
            </div>

            <div class="w-full text-sm">Amount: ${item.dollar_amount}</div>
            <!-- <div class="w-full text-sm">{item.resource_identifier}</div>-->
            <hr />
            <div class="font-bold">Service Info</div>
            <div class="flex items-center justify-between">
              <!-- <div class="text-xs truncate">Frequency: {item.service_info.service_frequency}</div>-->
              <!-- <div class="text-xs truncate">Period: {item.service_info.service_period}</div>-->
              <div class="text-xs truncate">Period: {item.service_period}</div>
            </div>

          </div>
          <div class="border rounded-md p-0.5">
            <div class="font-bold">Service</div>
            {#each item.services as service}
              <div class="w-full">{service.name}</div>
              {#if service.separatePeriod}
                <div class="w-full text-sm">Service Period (separate): {service.period}</div>
                <div class="flex justify-between">
                  <div class="text-xs">From: {service.startDate}</div>
                  <div class="text-xs">To: {service.endDate}</div>
                </div>

              {:else}
                <div class="w-full text-sm">Service Period: {service.service_period}</div>
              {/if}
              <div class="flex items-center justify-between">
                <div class="text-xs truncate">Price: ${service.totalPrice}</div>
                <div class="text-xs truncate">Engagements: {service.engagementsPerDay}</div>
              </div>
              {#if item.services.length > 1 && item.services.indexOf(service) !== item.services.length - 1}
                <hr />
              {/if}

            {/each}
          </div>
          <!--                   <div class="border rounded-md p-0.5">-->
          <!--                       <div class="font-bold">Service Days</div>-->
          <!--                       &lt;!&ndash;{#each item.service_days as unit}&ndash;&gt;-->
          <!--                       &lt;!&ndash;  <div class="flex items-center justify-between">&ndash;&gt;-->
          <!--                       &lt;!&ndash;    <div class="w-full">{unit.name}</div>&ndash;&gt;-->
          <!--                       &lt;!&ndash;    <div class="text-xs truncate">({unit.days})</div><br/>&ndash;&gt;-->
          <!--                       &lt;!&ndash;  </div>&ndash;&gt;-->
          <!--                       &lt;!&ndash;  &lt;!&ndash;{#if item.service_days.length > 1 && item.service_days.indexOf(unit) !== item.service_days.length - 1}&ndash;&gt;&ndash;&gt;-->
          <!--                       &lt;!&ndash;  &lt;!&ndash;  <hr/>&ndash;&gt;&ndash;&gt;-->
          <!--                       &lt;!&ndash;  &lt;!&ndash;{/if}&ndash;&gt;&ndash;&gt;-->
          <!--                       &lt;!&ndash;{/each}&ndash;&gt;-->
          <!--                   </div>-->
        </div>
      </div>

    {/each}
  </div>
  <a
    class="{name === 'TODO'? 'block':'hidden'} bg-cyan-500 hover:bg-cyan-700 hover:cursor-pointer text-white font-bold py-1 px-4 w-full rounded text-center"
    href="/calculator">
    Add New Task
  </a>
</div>
<!-- {JSON.stringify(items)} -->
