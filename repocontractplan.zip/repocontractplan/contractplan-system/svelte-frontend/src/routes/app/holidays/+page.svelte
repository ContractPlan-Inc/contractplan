<script lang="ts">
  import { onMount } from 'svelte';

  import Input from '$lib/components/elements/input.svelte';
  import Select from '$lib/components/elements/select.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Table from '$lib/components/table/table.svelte';
  import json from '$lib/mock/holidays.json';
  import { editId, title } from '$lib/state/store';
  import editIcon from '$lib/assets/svg/edit.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { GetHolidaysDoc, type Holiday, type HolidayInput, InsertHolidayDoc } from '$lib/generated/graphql';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import Popup from '$lib/components/popup/popup.svelte';

  title.set('Holidays');

  let recordCount = 0;

  // table attributes
  let queryRepository = new GraphQLQueryRepository<Holiday>();
  let tableDataSource = new DataSourceConnector<Holiday>(
    queryRepository,
    GetHolidaysDoc
  );
  const columns = [
    { key: 'ID', title: 'ID', sortable: true },
    { key: 'Date', title: 'Date', sortable: false },
    { key: 'Name', title: 'Name', sortable: true },
    { key: 'Category', title: 'Category', sortable: true }
  ];
  let isLabel = true;
  let label = 'Columns';
  let availableColumns = ['ID', 'Date', 'Name', 'Category'];
  let dateColumns = ['Date'];
  let searchableColumns = ['ID', 'Date', 'Name', 'Category'];
  let actions = true;
  let actionList = [
    { name: 'Edit', icon: editIcon, function: editFunction },
    { name: 'Delete', icon: deleteIcon, function: deleteFunction }
  ];
  let bulckActions = [
    'Activate',
    'Deactivate',
    'Delete',
    'Export to CSV',
    'Export to PDF'
  ];

  let popupTitle = 'New Member';
  let options = [
    { title: 'Public Holiday', value: 'public' },
    { title: 'Bank Holiday', value: 'bank' },
    { title: 'Mercantile Holiday', value: 'Mercantile' }
  ];
  let pop = $state(false);
  let holiday = $state({
    Name: '',
    Date: '',
    Category: ''
  });

  let errors = $state({
    Name: '',
    Date: '',
    Category: ''
  });

  editId.subscribe((value) => {
    console.log('val : ', value);
    if (value != 0) {
      popupTitle = 'Edit Holiday';
      edit(value);
      pop = true;
    }
  });


  function handleSubmit() {

    errors = {
      Name: '',
      Date: '',
      Category: ''
    };

    if (!holiday.Name) {
      errors.Name = 'Name is required';
    }
    if (!holiday.Date) {
      errors.Date = 'Date is required';
    }
    if (!holiday.Category) {
      errors.Category = 'Category is required';
    }


    if (!errors.Name && !errors.Date && !errors.Category) {
      holiday.Date = new Date(holiday.Date).toISOString();
      let queryRepository = new GraphQLQueryRepository<HolidayInput>();
      queryRepository
        .updateItem(InsertHolidayDoc, { input: holiday })
        .then(() => {
          console.log('new holiday', holiday);
          checked = false;
          pop = false;
          window.location.reload();
        });
    }
  }

  function edit(id) {
    holiday = json.find((obj) => obj.id === id);
  }

  let checked = $state(false);

  function popup() {
    pop = !pop;
    editId.set(0);
    popupTitle = 'New Holiday ';
    holiday = {
      Name: '',
      Date: '',
      Category: 'public'
    };
  }

  function editFunction() {
  }

  function deleteFunction() {
  }

  // Update recordCount after fetching data
  onMount(async () => {
    if (tableDataSource) {
      const result = await tableDataSource.currentRows;
      recordCount = result.data ? result.data.length : 0;
    }
  });
</script>

<!--{JSON.stringify(holidays)}-->

{#if pop}
  <Popup
    on:close={popup}
    popupTitle="Add New Holiday"
    buttonText="Add Holiday"
    submitHandler={handleSubmit}
  >
    <div class="w-full flex flex-col dark:text-white">
      <Input
        type="text"
        label="Name"
        {checked}
        bind:value={holiday.Name}
      />
      {#if errors.Name}
        <div class="text-red-500 text-xs mt-1">{errors.Name}</div>
      {/if}
    </div>

    <div class="w-full flex flex-col dark:text-primary-dark-text">
      <Select {options} label="Type" bind:value={holiday.Category} />
      {#if errors.Category}
        <div class="text-red-500 text-xs mt-1">{errors.Category}</div>
      {/if}
    </div>

    <div class="w-full flex flex-col dark:text-white">
      <Input type="date" label="Date" bind:value={holiday.Date}/>
      {#if errors.Date}
        <div class="text-red-500 text-xs mt-1">{errors.Date}</div>
      {/if}
    </div>
  </Popup>
  <!-- <div class=" w-full h-full !absolute top-0 left-0 z-30 bg-black/30" onclick={()=>popup()}></div>
    <div class=" absolute w-full h-full top-0 left-0 flex items-center justify-center">

        <div class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-lg shadow ">
            <form onsubmit={(event)=>{event.preventDefault;handleSubmit}} class="w-full px-5 my-5">
                <div class="w-full px-5 my-5 flex  items-center justify-center ">
                    <h1 class=""> {popupTitle}</h1>
                </div>
                <div class="w-full px-5 my-5 flex  items-center ">
                    <div class="w-1/3 pl-5"> Name</div>
                    <Input type="text" {checked} bind:value={holiday.Name} required
                           validationText="This field id required"/>
                </div>
                <div class="w-full px-5 my-5 flex  items-center ">
                    <div class="w-1/3 pl-5"> Type</div>
                    <Select {options} label="" bind:value="{holiday.Category}"/>
                </div>
                <div class="w-full px-5 my-5 flex  items-center ">
                    <div class="w-1/3 pl-5"> Date</div>
                    <Input type="date" label="" bind:value={holiday.Date} required/>
                </div>
                <div class="w-full my-5 flex items-center justify-center ">
                    <button onclick={()=>checked = true} type="submit"
                            class=" px-3 py-2 border rounded text-white bg-[#62CDFF]">Save
                    </button>
                </div>
            </form>
        </div>
    </div> -->
{/if}
<PageHeader />

<PageBody>
  <Table
    {actionList}
    {actions}
    {availableColumns}
    {bulckActions}
    {columns}
    {isLabel}
    {label}
    {dateColumns}
    rootAccessPath="data.listHolidays.edges"
    {searchableColumns}
    {tableDataSource}
  >
    {#snippet buttons()}
        <span >
        <AddNewButton
          btnText="New Holiday"
          on:message={popup}
          openAsPopup={true}
        />
      </span>
      {/snippet}
  </Table>
</PageBody>
