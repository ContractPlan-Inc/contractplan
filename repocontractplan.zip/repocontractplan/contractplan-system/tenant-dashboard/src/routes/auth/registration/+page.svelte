<script lang="ts">
  import PersonalInfo from "./personalInfo.svelte";
  import CompanyInfo from "./companyInfo.svelte";
  import EmailVerification from "./emailVerification.svelte";
  import PlanSelection from "./planSelection.svelte";
  import type { Company, SignUpInput } from "$lib/generated/graphql";
  import { authError, authUser } from "$lib/state/store";

  class RegForm implements SignUpInput {
    address = $state("");
    email = $state($authUser?.email || "");
    firstName = $state("");
    lastName = $state("");
    middleName = $state("");
    password = $state($authUser.password || "");
    telephone = $state("");
    company = $state<Company>({
      address: "",
      name: "",
      telephone: "",
      companySize: 0,
      category: "",
      state: "",
      country: "",
    });
  }

  let regForm = $state(new RegForm());
  let status = $state(
    $authError === "UserNotConfirmed"
      ? "email"
      : $authError === "PlanNotSelected"
        ? "plan"
        : "personal",
  );

  let componentMap: { [key: string]: any } = {
    personal: PersonalInfo,
    company: CompanyInfo,
    email: EmailVerification,
    plan: PlanSelection,
  };
</script>

<svelte:head>
  <title>Contract Plan: Sign Up</title>
</svelte:head>
<div class=" w-full item-center justify-center relative">
  <!--{status}-->
  <svelte:component this={componentMap[status]} bind:regForm bind:status />
</div>
