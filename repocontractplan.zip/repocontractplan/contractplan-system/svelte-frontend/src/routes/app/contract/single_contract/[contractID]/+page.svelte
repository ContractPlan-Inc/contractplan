<script lang="ts">
  import type { PageData } from './$types';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import CommonChartSmall from '$lib/components/charts/commonChartSmall.svelte';
  import ChartLabel from '$lib/components/elements/chartLabel.svelte';
  import Icon from '@iconify/svelte';
  import AssignedUser from '$lib/components/elements/assignedUser.svelte';
  import PartnerComponent from '$lib/components/elements/PartnerComponent.svelte';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { type ContractPartner, GetSummaryDoc, type GetSummaryQuery, type Service } from '$lib/generated/graphql';
  import Loader from '$lib/components/elements/loader.svelte';
  import { page } from '$app/stores';
  import { title } from '$lib/state/store';
  import dayjs from 'dayjs';
  import ContractFileUpload from '$lib/components/elements/ContractFileUpload.svelte';
  import { onMount } from 'svelte';

  const contractId = $page.params.contractID;
  let engagementsType = $state('day');

  // let { data }: PageData = $props();

  interface TargetValue {
    __typename?: "TargetValue";
    sum?: number | null;
  }

  interface SummaryTotal {
    __typename?: "SummaryContractDayRecord";
    currency: string | null;
    doc_count: number;
    key: number;
    key_as_string: string;
    engagements: TargetValue | null;
    engagement_cost: TargetValue | null;
    target_engagements: TargetValue | null;
    target_engagement_cost: TargetValue | null;
  }

  interface SummaryRecord {
    __typename?: "SummaryContractDayRecord";
    key_as_string: string;
    engagements?: TargetValue | null;
    engagement_cost?: TargetValue | null;
    target_engagements?: TargetValue | null;
    target_engagement_cost?: TargetValue | null;
    currency?: any;
    doc_count: number;
    key: number;
  }

  let summaryRecords = $state<SummaryRecord[]>([]);
  let summaryTotal = $state<SummaryTotal | {} >({});
  let services = $state<Service[]>([]);
  let partner = $state<ContractPartner>();
  title.set('Contract Dashboard ' + contractId);
  let selectedService = $state('');
  let loading = $state(true);
  let formatter = $state(new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2,
    minimumFractionDigits: 2
  }))

  let selectedDate = $state(dayjs().format('YYYY-MM-DD'));
  let selectedDateIndex = $state(0)
  let actualUnitsAtDate = $state(0);
  let plannedUnitsAtDate = $state(0);
  let unitVarienceAtDate = $state(0);

  onMount(async () => {
    const currentDate = dayjs().format('YYYY-MM-DD');
    selectedDate = currentDate;
    handleDateChange();
    
    const queryRepository = new GraphQLQueryRepository<GetSummaryQuery>();
    const result = await queryRepository.getItems(GetSummaryDoc, {
      ID: contractId,
      Type: engagementsType,
      ServiceID: selectedService
    }, 1, 1);
    
    // Map ServicePeriod to engagementsType
    const servicePeriod = result.data?.getSummary?.Contract?.ServicePeriod?.toLowerCase();
    engagementsType = servicePeriod === 'monthly' ? 'month' 
                    : servicePeriod === 'weekly' ? 'week'
                    : servicePeriod === 'daily' ? 'day'
                    : 'day'; 
  });

  $effect(async () => {
    loading = true;
    const queryRepository = new GraphQLQueryRepository<GetSummaryQuery>();
    const engagementsResult = await queryRepository.getItems(GetSummaryDoc, {
      ID: contractId,
      Type: engagementsType,
      ServiceID: selectedService
    }, 1, 1);
    summaryRecords = engagementsResult.data?.getSummary?.SummaryRecords ?? [];
    summaryTotal = engagementsResult.data?.getSummary?.SummaryTotal ?? {};
    title.set(engagementsResult.data?.getSummary?.Contract?.ContractName ?? '');

    // Only set selectedDate if it hasn't been set yet
    if (!selectedDate) {
      selectedDate = dayjs().format('YYYY-MM-DD');
    }
    handleDateChange();

    services = engagementsResult.data?.getSummary?.Contract?.Services ?? [];
    partner = engagementsResult.data?.getSummary?.Contract?.ContractPartner as ContractPartner;
    
    let currency = engagementsResult.data?.getSummary?.SummaryRecords?.[0]?.currency || "USD";

    formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      maximumFractionDigits: 2,
      minimumFractionDigits: 2
    });
    loading = false;
  });

  // function getActualEngagements() {
  //   summaryRecords.forEach(element => {
  //     if (element && element.sum !== null && element.sum !== undefined) {
  //       console.log("elements", element);
  //     } else {
  //       console.warn("Element is null or sum is not defined", element);
  //     }
  //   });
  // }

  // function getTodayIndexOfDays(records){
  //   const today = dayjs("2024-01-31T00:00:00.000Z")
  //   console.log("today", today)
  //   let index = 0
  //   records.forEach((item, i) => {
  //     if (item && today.isSame(dayjs(item.key_as_string), 'day')) {
  //       index = i;
  //     }
  //   });

  //   return index;
  // }

  function getPlannedUnitsAsAtDate(date: number, records ){
    return records.reduce((sum: number, record, i:number) => {
      if(i < date && record?.target_engagements?.sum !== undefined) {
        return sum + record.target_engagements.sum;
      }
      return sum
    }, 0)
  }

  function getActualUnitsAsAtDate(date: number, records ){
    return records.reduce((sum: number, record, i: number) => {
      if(i < date && record?.engagements?.sum !== undefined) {
        return sum + record.engagements.sum;
      }
      return sum
    }, 0)
  }

  function getSumOfObjectArray(array, attribute1, attribute2) {
    let tar = 0
    array.forEach(value => {
      if (value[attribute1] && value[attribute1][attribute2] !== undefined) {
        tar += value[attribute1][attribute2];
      }
    });
    return tar
  }

  function projection1() {

    let remaining = 0;
    let remaining_days = summaryRecords.length-selectedDateIndex-1;

    // let act2_per_day = 0
    summaryRecords.forEach(value => {
      if (dayjs(value.key_as_string).format('YYYY-MM-DD') <= selectedDate) {
        if (value.engagements && value.engagements.sum !== undefined) {
          remaining += value.target_engagements.sum - value.engagements.sum;
        }
      }
    });

    console.log("$$$ remaining to complete", remaining)
    console.log("$$$ remaining days", remaining_days)

    if (remaining > 0) {
      let avg_remainder = remaining / remaining_days
      console.log("$$$ remaining average per day", avg_remainder)

      if (Math.round(avg_remainder) < avg_remainder && avg_remainder < avg_remainder+1) {
        avg_remainder = Math.round(avg_remainder)+1
      } else {
        avg_remainder = Math.round(avg_remainder)
      }
      console.log("$$$rounded avg_remainder", avg_remainder)

      if (avg_remainder > 0) {
        console.log("$$$final outcome", `You need to add ${avg_remainder} units/day for the next ${Math.round(remaining/avg_remainder)} days`)
        return `You need to add ${avg_remainder} units/day for the next ${Math.round(remaining/avg_remainder)} days`
      }
    } else {

      remaining = remaining*-1

      let avg_remainder = remaining / remaining_days
      console.log("$$$ remaining average per day", avg_remainder)

      if (Math.round(avg_remainder) < avg_remainder && avg_remainder < avg_remainder+1) {
        avg_remainder = Math.round(avg_remainder)+1
      } else {
        avg_remainder = Math.round(avg_remainder)
      }
      console.log("$$$rounded avg_remainder", avg_remainder)

      console.log("$$$final outcome", `You need to subtract ${avg_remainder} units/day for the next ${Math.round(remaining/avg_remainder)} days`)
      return `You need to subtract ${avg_remainder} units/day for the next ${Math.round(remaining/avg_remainder)} days` 
    }
  }

  function projection3() {
    
    let actualCost = 0;
    let expectedCost = 0;
    let days = 0;
    let month_days = 0;

    summaryRecords.forEach(day => {

      if (dayjs(day.key_as_string).format("MMM") === dayjs(summaryRecords[selectedDateIndex]?.key_as_string).format("MMM")) {
        expectedCost += day.target_engagement_cost.sum;
        if (dayjs(day.key_as_string).format('YYYY-MM-DD') <= selectedDate) {
          actualCost += day.engagement_cost.sum;
          days++;
        }
        month_days++;
      }
    });

    console.log("$# actualCost", actualCost/100)
    console.log("$# expectedCost", expectedCost/100)
    console.log("$# days", days)
    console.log("$# month_days", month_days)
    const projectedActual = (((actualCost/days))*month_days);
    const estimatedLoss = expectedCost - projectedActual;


    console.log("$# Projected Actual Cost: " + projectedActual.toFixed(2));
    console.log("$# Estimated Loss: " + estimatedLoss.toFixed(2));

    if (estimatedLoss > 0) {
      console.log(`$# You are expected to lose ${(estimatedLoss/100).toFixed(2)} USD from ${(expectedCost/100).toFixed(2)} which is ${(estimatedLoss/expectedCost*100).toFixed(2)}% lose`)
      return `You are expected to lose ${(estimatedLoss/100).toFixed(2)} USD from ${(expectedCost/100).toFixed(2)} which is ${(estimatedLoss/expectedCost*100).toFixed(2)}% lose`
    } else {
      console.log(`$# You are expected to have extra ${(estimatedLoss/100*-1).toFixed(2)} USD from ${(expectedCost/100).toFixed(2)} which is ${(estimatedLoss/expectedCost*100*-1).toFixed(2)}% gain`)
      return `You are expected to have extra ${(estimatedLoss/100*-1).toFixed(2)} USD from ${(expectedCost/100).toFixed(2)} which is ${(estimatedLoss/expectedCost*100*-1).toFixed(2)}% gain`
    }

  }

  function getEngagementVariance(){
    let tar = getSumOfObjectArray(summaryRecords, 'target_engagements','sum')
    let act = 0

    summaryRecords.forEach(value => {
      if (dayjs(value.key_as_string).format('YYYY-MM-DD') === selectedDate) {
        if (value.engagements && value.engagements.sum !== undefined) {
          act += value.engagements.sum;
        }
      }
    });

    console.log("getActualEngagementCost",tar)
    console.log("getPlannedEngagementCost",act)
    return tar-act;
    return tar-act;
  }

  function getEngagementCostVariance(){
    let tar = getSumOfObjectArray(summaryRecords, 'target_engagement_cost','sum')
    let act = 0
    if( summaryRecords.length != 0) {
      summaryRecords.forEach(value => {
        if (value.engagement_cost && value.engagement_cost.sum !== undefined) {
          act += value.engagement_cost.sum;
        }
      });
    }
    console.log("getActualEngagementCost",tar)
    console.log("getPlannedEngagementCost",act)
    return (tar-act)/100.00;
  }

  function getLoseAmountCurrentMonth() {
    let eng_cost = 0;
    let tar_eng_cost = 0;
    let num_days = 0;
    console.log("summaryTotal", summaryTotal)
    summaryRecords.forEach(obj => {
      if (dayjs(obj.key_as_string).format("MMM") === dayjs(summaryRecords[selectedDateIndex]?.key_as_string).format("MMM")) {
      console.log("obj", obj)
        if (obj.engagement_cost && obj.engagement_cost.sum !== undefined) {
          eng_cost += obj.engagement_cost.sum;
        }
        if (obj.target_engagement_cost && obj.target_engagement_cost.sum !== undefined) {
          tar_eng_cost += obj.target_engagement_cost.sum;
        }
        num_days++;
      }
    });
    console.log("obj_eng_cost", eng_cost)
    console.log("obj_tar_eng_cost", tar_eng_cost)
    console.log("obj_num_days", num_days)
    return (tar_eng_cost-eng_cost)/100
  }

  function getLoseAmountCurrentMonthAsPresentage() {
    let eng_cost = 0;
    let tar_eng_cost = 0;
    summaryRecords.forEach(obj => {
      if (dayjs(obj.key_as_string).format("MMM") === dayjs(summaryRecords[selectedDateIndex]?.key_as_string).format("MMM")) {
        if (obj.engagement_cost && obj.engagement_cost.sum !== undefined) {
          eng_cost += obj.engagement_cost.sum;
        }
        if (obj.target_engagement_cost && obj.target_engagement_cost.sum !== undefined) {
          tar_eng_cost += obj.target_engagement_cost.sum;
        }
      }
    });
    return ((((tar_eng_cost-eng_cost))/tar_eng_cost)*100).toFixed(2);
  }

  function calculateEngagementMetrics() {
    if (!summaryRecords.length) return null;

    const totalDays = summaryRecords.length;
    const completedDays = selectedDateIndex + 1;
    const remainingDays = totalDays - completedDays;

    // Calculate average engagement per day
    const totalCompletedEngagements = getActualUnitsAsAtDate(selectedDateIndex + 1, summaryRecords);
    const avgEngagementPerDay = totalCompletedEngagements / completedDays;

    // Get engagement cost per unit
    const engagementCostPerUnit = summaryRecords[0]?.engagement_cost?.sum ? summaryRecords[0].engagement_cost.sum / 100 : 0;

    // Calculate service amounts
    const completedServiceAmount = avgEngagementPerDay * completedDays * engagementCostPerUnit;
    const totalServiceAmount = summaryRecords[0]?.target_engagements?.sum * totalDays * engagementCostPerUnit;
    const goalAmount = summaryTotal?.target_engagement_cost?.sum - summaryTotal?.engagement_cost?.sum;
    const goalPerDay = remainingDays > 0 ? goalAmount / remainingDays : 0;

    return {
      avgEngagementPerDay: Math.round(avgEngagementPerDay),
      completedServiceAmount: Math.round(completedServiceAmount/100),
      totalServiceAmount: Math.round(totalServiceAmount/100),
      goalAmount: Math.round(goalAmount/100),
      goalPerDay: Math.round(goalPerDay/100),
      remainingDays
    };
  }

  function refreshUnitsCount(){
    plannedUnitsAtDate = getPlannedUnitsAsAtDate(selectedDateIndex, summaryRecords)
    actualUnitsAtDate = getActualUnitsAsAtDate(selectedDateIndex, summaryRecords);
    console.log("plannedUnitsAtDate", plannedUnitsAtDate)
    console.log("actualUnitsAtDate", actualUnitsAtDate)
    unitVarienceAtDate = plannedUnitsAtDate- actualUnitsAtDate;
  }

  function handleDateChange() {
    if (!summaryRecords.length) return;
    
    summaryRecords.forEach((record, index) => {
      if (dayjs(record.key_as_string).isSame(dayjs(selectedDate), 'day')) {
        selectedDateIndex = index;
        refreshUnitsCount();
      }
    });
  }
</script>

<svelte:head>
  <title>{$title}</title>
</svelte:head>

<section>
  <PageHeader>
    <div class="flex items-center space-x-4">
    </div>
  </PageHeader>
  <PageBody>
    {#if loading}
      <Loader loading={true} type="dataLoader" />
    {:else}
      <div class="w-full h-full mb-8 gap-4 grid grid-cols-3 ">
        <!-- Reveneue Component -->
        <div class="border rounded-md p-5 shadow-lg col-span-1">
          <div class=" w-full flex justify-between  items-start content-center gap-4">
            <div>
              <h2 class=" text-2xl font-medium dark:text-primary-dark-text">Engagements</h2>
              <p class=" text-sm text-gray-500">{dayjs(summaryRecords[0]?.key_as_string).format("MMM YYYY")}
                - {dayjs(summaryRecords[summaryRecords.length - 1]?.key_as_string).format("MMM YYYY")}</p>
            </div>
            <div class="flex flex-row w-full gap-2 py-2">

              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md dark:bg-dark-bg dark:text-primary-dark-text"
                      bind:value={engagementsType}>
                <option value="day">Daily</option>
                <option value="week">Weekly</option>
                <option value="month">Monthly</option>
              </select>
              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md dark:bg-dark-bg dark:text-primary-dark-text"
                      bind:value={selectedService}>
                <option value="">All Services</option>
                {#each services as service}
                  <option value={service.ID}>{service.ServiceName}</option>
                {/each}
              </select>


              <button
                class=" border  justify-center  w-1/3 px-1 py-2 text-sm  inline-flex gap-2 items-center rounded-md">
                <Icon icon="bx:calendar" width="18" />
              </button>


            </div>

          </div>

          <div>
            <div class="w-full grid grid-cols-2 justify-between gap-3 ">
              <ChartLabel
                color="black"
                key="Planned"
                value={isNaN(summaryTotal?.target_engagements?.sum) ? 0 : Number(summaryTotal?.target_engagements?.sum)}
              />
              <ChartLabel
                color="primary"
                key="Actual"
                value={isNaN(summaryTotal?.engagements?.sum) ? 0 : Number(summaryTotal?.engagements?.sum)} />
            </div>
            <div>
              <!-- <CommonChartSmall
                actualData={summaryRecords.map(o => o.engagements.sum )}
                plannedData={summaryRecords.map(o => o.target_engagements.sum )}
                labels={summaryRecords.map(o => dayjs(o.key_as_string).format('MMM YYYY'))} >
              </CommonChartSmall> -->

              <CommonChartSmall
                ID="1"
                chartType={engagementsType === 'day' || engagementsType === 'week' ? 'line' : 'bar'}
                actualData={summaryRecords.map(o => o.engagements.sum )}
                plannedData={summaryRecords.map(o => o.target_engagements.sum )}
                labels={summaryRecords.map(o => {
                    const format =  engagementsType === 'month' ? 'MMM': 'MMM DD'
                    return dayjs(o.key_as_string).format(format)
                  })}
                plannedColor='#000'
                actualColor='#FF914D'
              />

            </div>
          </div>


        </div>
        <!-- Reveneue Component -->


        <!-- Engagement Cost Component -->
        <div class=" border  rounded-md  col-span-1 p-5 shadow-lg">
          <div class=" w-full flex justify-between  items-start content-center gap-4">
            <div>
              <h2 class=" text-2xl font-medium dark:text-primary-dark-text">Engagement Cost</h2>
              <p class=" text-sm text-gray-500">{dayjs(summaryRecords[0]?.key_as_string).format("MMM YYYY")}
                - {dayjs(summaryRecords[summaryRecords.length - 1]?.key_as_string).format("MMM YYYY")}</p>
            </div>
            <div class="flex flex-row w-full gap-2 py-2">

              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md dark:bg-dark-bg dark:text-primary-dark-text"
                      bind:value={engagementsType}>
                <option value="day">Daily</option>
                <option value="week">Weekly</option>
                <option value="month">Monthly</option>
              </select>
              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md dark:bg-dark-bg dark:text-primary-dark-text"
                      bind:value={selectedService}>
                <option value="">All Services</option>
                {#each services as service}
                  <option value={service.ID}>{service.ServiceName}</option>
                {/each}
              </select>


              <button
                class=" border  justify-center  w-1/3 px-1 py-2 text-sm  inline-flex gap-2 items-center rounded-md">
                <Icon icon="bx:calendar" width="18" />
              </button>


            </div>

          </div>


          <div>
            <div class="w-full grid grid-cols-2 justify-between gap-3 ">
              <ChartLabel 
                color="black" 
                key="Planned" 
                value={Number(summaryTotal?.target_engagement_cost?.sum || 0)/100} 
              />
              <ChartLabel 
                color="primary" 
                key="Actual" 
                value={Number(summaryTotal?.engagement_cost?.sum || 0)/100} 
              />
            </div>
            <div>
              <CommonChartSmall
                ID="2"
                chartType={engagementsType === 'day' || engagementsType === 'week' ? 'line' : 'bar'}
                actualData={summaryRecords.map(o => o.engagement_cost.sum/100 )}
                plannedData={summaryRecords.map(o => o.target_engagement_cost.sum/100 )}
                labels={summaryRecords.map(o => {
                    const format =  engagementsType === 'month' ? 'MMM': 'MMM DD'
                    return dayjs(o.key_as_string).format(format)
                  })}
                plannedColor='#000'
                actualColor='#FF914D'
              />
            </div>
          </div>
        </div>



        <!-- Projected Variance Component -->
        <div class=" border rounded-md basis-full sm:basis-[48%] lg:basis-[32%] p-6 bg-green-50 shadow-lg dark:bg-dark-bg">
          <div class="  w-full  flex justify-between py-2 pb-5">
            <h2 class=" text-2xl font-medium mb-4 dark:text-primary-dark-text">Projected Variance</h2>
          </div>

          <div class="justify-center">
            <input
              type="date"
              class="p-2 rounded-lg bg-white border dark:bg-dark-bg dark:text-primary-dark-text"
              bind:value={selectedDate}
              min={dayjs(summaryRecords[0]?.key_as_string).format('YYYY-MM-DD')}
              max={dayjs(summaryRecords[summaryRecords.length-1]?.key_as_string).format('YYYY-MM-DD')}
              onchange={handleDateChange}
            />
            <!-- <div>
              <select class="p-2 rounded-lg bg-white border dark:bg-dark-bg dark:text-primary-dark-text" bind:value={selectedDateIndex} onchange={refreshUnitsCount}>
                {#each summaryRecords  as record , i}
                  <option value={i} selected={selectedDateIndex == i} disabled={dayjs(record.key_as_string).isBefore(dayjs("2024-01-31T00:00:00.000Z"))} >{dayjs(record.key_as_string).format('MMM D, YYYY')}</option>
                {/each}
                <option></option>
              </select>
            </div> -->
          <div class="flex h-full w-full gap-6 items-center justify-center py-5">
            <div class="h-fit flex-wrap justify-center">
              <div class="flex-col p-3 bg-black text-white rounded-2xl border  w-16 h-16 flex justify-center items-center ">
                <Icon icon="pepicons-pencil:file" width="32" />
              </div>
            </div>

            <div class="h-fit">
              <ul class="leading-loose list-disc marker:text-green-500 marker:text-xl text-sm ml-4 dark:text-primary-dark-text  ">
                  <li>
                    {projection1()}
                  </li>
                  <!-- <li>{Math.round(getEngagementVariance()/(summaryRecords.length-selectedDateIndex)) < 0 ? 'You have additional' : 'You need to add more'}
                    {Math.abs(Math.round(getEngagementVariance()/(summaryRecords.length-selectedDateIndex))).toLocaleString()}
                    engagements/day
                  </li> -->
                <!-- <li> You will lose 250$/month of $10,000 span</li>
<li>You will lose 0.25% per month</li> -->
                <!-- <li>You need add more {Math.round(getEngagementVariance()*summaryRecords.length/(summaryRecords.length-selectedDate))} units/day</li> -->
                  <li>
                    {getLoseAmountCurrentMonth() < 0 ? 'You will gain': 'You will lose'}
                    {getLoseAmountCurrentMonth() < 0 ? 
                      (Math.abs(getLoseAmountCurrentMonth())).toFixed(2) : 
                      getLoseAmountCurrentMonth().toFixed(2)}
                    $/month of 
                    {((summaryTotal?.target_engagement_cost?.sum || 0)/100).toLocaleString()} 
                    that is
                    {Number(getLoseAmountCurrentMonthAsPresentage()) < 0 ? 
                     Math.abs(Number(getLoseAmountCurrentMonthAsPresentage())) : 
                     Number(getLoseAmountCurrentMonthAsPresentage())} %
                  </li>
                  <li>
                    {projection3()}
                  </li>
                  {#if calculateEngagementMetrics()}
                    <li>Average engagement per day: {calculateEngagementMetrics().avgEngagementPerDay.toLocaleString()}</li>
                    <!-- <li>Completed service amount: ${calculateEngagementMetrics().completedServiceAmount.toLocaleString()}</li>
                    <li>Total service amount: ${calculateEngagementMetrics().totalServiceAmount.toLocaleString()}</li> -->
                    <li>Goal amount: ${calculateEngagementMetrics().goalAmount.toLocaleString()}</li>
                    <li>Goal per day: ${calculateEngagementMetrics().goalPerDay.toLocaleString()} (for {calculateEngagementMetrics().remainingDays.toLocaleString()} remaining days)</li>
                  {/if}
                <!-- <li>You need add more {Math.round(getEngagementVariance()/(summaryRecords.length-selectedDateIndex))} engagements/day</li> -->
                <!-- <li>You have additional {Math.round(getEngagementVariance()/(summaryRecords.length-selectedDateIndex))} engagements/day</li> -->

                <!-- = (Planned - Actual) / ([last_occurrence_of_the_month]-[today_date]) -->
                <!-- <li>You need to complete 50 units within this month</li> -->
              </ul>
            </div>
          </div>
          </div>
          <!-- Contract Forecasting Component -->
          <div
            class="rounded-md basis-full sm:basis-[48%] lg:basis-[32%] self-stretch justify-center items-center pt-6">
            <div class="  w-full  h-[60%] shadow-lg items-center justify-center border p-5 rounded-md">
              <h2 class=" text-2xl font-medium mb-4 dark:text-primary-dark-text">Contract Forecasting</h2>

              <div class=" flex items-center gap-3 my-6 ">
                <span
                  class=" bg-green-400 rounded-full  inline-flex gap-1 justify-center items-center  text-white w-8 h-8 p-1">
                  <Icon icon="mdi:arrow-up" width="30" />
                </span>
                <div>
                  <p class=" text-sm text-gray-400">Current Plan</p>
                  <p class=" font-bold text-lg dark:text-primary-dark-text">${((getSumOfObjectArray(summaryRecords, 'target_engagement_cost','sum')/100).toFixed(2)).toLocaleString()}</p>
                </div>
              </div>

              <div class=" flex items-center gap-3 my-6">
                <span
                  class="{getEngagementCostVariance() < 0 ? "bg-green-400" : "bg-red-400"} rounded-full  inline-flex gap-1 justify-center items-center  text-white w-8 h-8 p-1">
                  {#if getEngagementCostVariance() < 0}
                    <Icon icon="mdi:arrow-up" width="30" />
                  {:else}
                    <Icon icon="mdi:arrow-down" width="30" />
                  {/if}
                </span>
                <div>
                  <p class=" text-sm text-gray-400">Forecasting till end</p>
                  <p class=" font-bold text-lg dark:text-primary-dark-text">
                    ${Math.abs(Number(getEngagementCostVariance()/(summaryRecords.length-(selectedDateIndex+1)))).toFixed(2).toLocaleString()}
                  </p>
                  {#if getEngagementCostVariance() < 0}
                    <p class=" text-green-600 text-xs">You will gain of ${getEngagementCostVariance()*-1}</p>
                  {:else}
                    <p class=" text-red-600 text-xs">You will be loss of ${getEngagementCostVariance()}</p>
                  {/if}
                </div>
              </div>
            </div>
            <!-- <div class="flex flex-col justify-center items-center  h-[34%] gap-[6%] shadow-lg border p-6 rounded-md "> -->
            <!--   <PartnerComponent bind:partner={partner} /> -->
            <!-- </div> -->
          </div>
          <!-- Contract Forecasting Component -->
        </div>
        <!-- Projected Variance Component -->

        <!-- File Upload Component -->
        <div class="border rounded-md p-5 shadow-lg col-span-3">
          <h2 class="text-2xl font-medium mb-4 dark:text-primary-dark-text">Contract Files</h2>
          <ContractFileUpload {contractId} />
        </div>

      </div> <!--Component Container ends-->
    {/if}
  </PageBody>
</section>
