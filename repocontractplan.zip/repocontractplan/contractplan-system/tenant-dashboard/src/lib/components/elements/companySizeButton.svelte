<script lang="ts">

    interface companySizeButtonProps {
        regForm: any;
        setCompanySize: any;
        companySize?: number;
        text: string;
        errors: any;
    }
    
    let {regForm, setCompanySize, companySize, text, errors}: companySizeButtonProps = $props();
</script>

<button
    class="py-2 px-3 text-sm font-medium text-gray-900  rounded border {regForm.company.companySize === companySize ? ' bg-primary-extra-light' : 'bg-gray-50'} {errors.companySize ? 'border-red-500' : 'border-gray-300'} border-gray-300 dark:text-white focus:border-blue-500 focus:ring focus:outline-none"
    onclick={setCompanySize}>
    {text}
</button>
