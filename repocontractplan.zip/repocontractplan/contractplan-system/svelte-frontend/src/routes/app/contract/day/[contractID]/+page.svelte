<script lang="ts">
  export const prerender = false;
  import { onMount } from 'svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import confirmicon from '$lib/assets/svg/confirm.png';
  import { page } from '$app/stores';
  import Table from '$lib/components/table/table.svelte';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import type { ContractDayRecord, ContractDayRecordInput } from '$lib/generated/graphql';
  import { GetContractDayRecordsDoc, UpdateContractDayRecordDoc } from '$lib/generated/graphql';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import BulkDayRecord from '$lib/components/elements/BulkDayRecord.svelte';
  import { title } from '$lib/state/store';

  const contractId = $page.params.contractID;

  interface Row {
    checked: boolean;

    [key: string]: any;
  }

  let isLabel = true;
  let label = 'Columns';
  title.set('Records');

  const columns = [
    { key: 'Date', title: 'date ', sortable: true },
    { key: 'ContractID', title: 'Contract ID', sortable: true },
    { key: 'ContractName', title: 'Contract Name', sortable: true },
    { key: 'ServiceID', title: 'Service ID', sortable: true },
    { key: 'ServiceName', title: 'Service Name', sortable: true },
    { key: 'Engagements', title: 'Engagements', sortable: true }
  ];

  let queryRepository = new GraphQLQueryRepository<ContractDayRecord>();
  let tableDataSource = new DataSourceConnector<ContractDayRecord>(
    queryRepository,
    GetContractDayRecordsDoc,
    {
      contractId: contractId
    }
  );
  onMount(() => {
    console.log('onMount');
  });

  let searchableColumns = ['ContractName', 'ContractPartner', 'ContractAlias'];
  let availableColumns = [
    'Date',
    // 'ContractID',
    'ContractName',
    // 'ServiceID',
    'ServiceName',
    'Engagements'
  ];
  let currencyColumns = ['ContractValue'];
  let dateColumns = ['Date'];
  let actions = true;
  let actionList = [
    { name: 'Day Report', icon: confirmicon, function: updateDayRecord }
  ];
  let bulkActions = ['Activate', 'Deactivate', 'Delete', 'Export to CSV', 'Export to PDF'];
  let editableCell = ['Engagements'];
  let BulkRecordPop = $state(false);

  function updateDayRecord(item: any) {
    let queryRepository = new GraphQLQueryRepository<ContractDayRecordInput>();
    let ID = item.ID;
    delete item.ID;
    console.log(item);
    console.log('contract day record',ID);
    queryRepository.updateItem(UpdateContractDayRecordDoc, { id: ID, input: item }).then(() => {
      localStorage.removeItem('contract');
      console.log(item);
      item.ID = ID;
    });
  }

</script>

<BulkDayRecord pop={BulkRecordPop}/>
<PageHeader Title="Day Report">
  <div class="flex items-center justify-between w-full dark:text-white">
    <a class="flex px-2 py-1 border rounded text-white bg-primary" href="/app/contract">Back</a>
    <div>
      <AddNewButton btnText="Bulk Day Record" onclick={()=>{BulkRecordPop = !BulkRecordPop; console.log('pop',BulkRecordPop)}} openAsPopup={true} />
    </div>
  </div>
</PageHeader>
<PageBody>

  <section class="container mx-auto bg-white dark:bg-dark-bg">
    <div class="overflow-x-auto shadow-lg rounded-lg">
      <Table
        {actionList}
        {actions}
        {availableColumns}
        {bulkActions}
        {columns}
        {currencyColumns}
        {dateColumns}
        {editableCell}
        {isLabel}
        {label}
        rootAccessPath="data.getContractDayRecords.edges"
        {tableDataSource}
      />
    </div>
  </section>

</PageBody>
