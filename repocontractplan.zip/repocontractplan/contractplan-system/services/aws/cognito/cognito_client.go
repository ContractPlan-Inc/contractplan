package cognito

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"os"

	"cloudparallax.com/backend/models"
	"cloudparallax.com/backend/services/aws/config"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider/types"
)

var cognitoClient *cognitoidentityprovider.Client
var cognitoAppClientID = os.Getenv("USERPOOL_CLIENT_ID")
var clientSecret = os.Getenv("USERPOOL_CLIENT_SECRET")
var userpoolId = os.Getenv("USERPOOL_ID")

func init() {
	cognitoClient = cognitoidentityprovider.NewFromConfig(config.AWSConfig)
}

func calculateSecretHash(username, clientID string) string {
	message := username + clientID
	key := []byte(clientSecret)
	h := hmac.New(sha256.New, key)
	h.Write([]byte(message))
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

func SignUp(input models.SignUpInput, ulid string) (*cognitoidentityprovider.SignUpOutput, error) {
	secretHash := calculateSecretHash(input.Email, cognitoAppClientID)
	user := &cognitoidentityprovider.SignUpInput{
		Username:   aws.String(input.Email),
		Password:   aws.String(input.Password),
		ClientId:   aws.String(cognitoAppClientID),
		SecretHash: aws.String(secretHash),
		UserAttributes: []types.AttributeType{
			{
				Name:  aws.String("given_name"),
				Value: aws.String(input.FirstName),
			},
			{
				Name:  aws.String("middle_name"),
				Value: aws.String(input.MiddleName),
			},
			{
				Name:  aws.String("family_name"),
				Value: aws.String(input.LastName),
			},
			{
				Name:  aws.String("email"),
				Value: aws.String(input.Email),
			},
		},
	}

	result, err := cognitoClient.SignUp(context.TODO(), user)

	if err != nil {
		return nil, err
	}

	if input.Company != nil {
		_, err := CreateGroup(input, ulid)
		if err != nil {
			// If the group creation fails, delete the created user from the userpool
			deleteUserInput := &cognitoidentityprovider.AdminDeleteUserInput{
				Username:   aws.String(input.Email),
				UserPoolId: aws.String(userpoolId),
			}
			cognitoClient.AdminDeleteUser(context.Background(), deleteUserInput)
			return nil, err
		}
	}
	return result, nil
}

func CreateGroup(input models.SignUpInput, ulid string) (*cognitoidentityprovider.AdminAddUserToGroupOutput, error) {
	// create a group
	group := &cognitoidentityprovider.CreateGroupInput{
		GroupName:   aws.String(ulid), // tenantID UUID
		UserPoolId:  aws.String(userpoolId),
		Description: aws.String("Company group of " + input.Company.Name),
	}

	// groupOld := cognitoidentityprovider.GetGroupInput{
	// 	GroupName:   aws.String(ulid),
	// 	UserPoolId:  aws.String(userpoolId),
	// }

	_, err := cognitoClient.CreateGroup(context.Background(), group)
	if err != nil {
		return nil, err
	}
	// attach user to group
	attachAdminUserToGroup := cognitoidentityprovider.AdminAddUserToGroupInput{
		Username:   aws.String((input.Email)),
		UserPoolId: aws.String(userpoolId),
		GroupName:  aws.String(ulid),
		//GroupName: aws.String("dummy"),
	}
	addUserOutput, err := cognitoClient.AdminAddUserToGroup(context.Background(), &attachAdminUserToGroup)
	if err != nil {
		return nil, err
	}

	return addUserOutput, nil
}

func ConfirmSignUp(email string, code string) (*cognitoidentityprovider.ConfirmSignUpOutput, error) {
	secretHash := calculateSecretHash(email, cognitoAppClientID)
	confirmSignUpInput := &cognitoidentityprovider.ConfirmSignUpInput{
		Username:         aws.String(email),
		ConfirmationCode: aws.String(code),
		ClientId:         aws.String(cognitoAppClientID),
		SecretHash:       aws.String(secretHash),
	}

	result, err := cognitoClient.ConfirmSignUp(context.TODO(), confirmSignUpInput)

	if err != nil {
		return nil, err
	}

	return result, nil
}
