package config

import (
	"os"
)

var DDBTable = os.Getenv("MAIN_TABLE")
