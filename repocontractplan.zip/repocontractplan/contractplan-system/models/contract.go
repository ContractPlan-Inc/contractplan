package models

import (
	"context"
	"sync"
	"time"
)

type Contract struct {
	DynamoDBModel
	ID                string          `json:"ID" dynamodbav:"a"`
	Status            ContractStatus  `json:"Status"`
	ContractName      string          `json:"ContractName"`
	ContractPartnerID string          `json:"ContractPartnerID"`
	ContractAlias     *string         `json:"ContractAlias,omitempty"`
	StartDate         time.Time       `json:"StartDate"`
	EndDate           time.Time       `json:"EndDate"`
	ServiceDays       int             `json:"ServiceDays"`
	ServiceDates      []string        `json:"ServiceDates,omitempty"`
	ServicePeriod     string          `json:"ServicePeriod"`
	Weekdays          []*int          `json:"Weekdays,omitempty"`
	SelectedMonthDays []*int          `json:"SelectedMonthDays,omitempty"`
	EngagementsPerDay int             `json:"EngagementsPerDay"`
	ContractValue     *Money          `json:"ContractValue"`
	UnitDefinition    *UnitDefinition `json:"UnitDefinition"`
	Services          []*Service      `json:"Services,omitempty"`
	Archive           bool            `json:"Archive"`
	CreatedAt         time.Time       `json:"CreatedAt,omitempty"`
}

func (Contract) IsNode() {}
func (c Contract) GetID() string {
	return c.ID
}
func (Contract) IsServicePeriod()              {}
func (this Contract) GetServicePeriod() string { return this.ServicePeriod }
func (this Contract) GetStartDate() time.Time  { return this.StartDate }
func (this Contract) GetEndDate() time.Time    { return this.EndDate }
func (this Contract) GetServiceDays() int      { return this.ServiceDays }
func (this Contract) GetServiceDates() []string {
	if this.ServiceDates == nil {
		return nil
	}
	interfaceSlice := make([]string, 0, len(this.ServiceDates))
	for _, concrete := range this.ServiceDates {
		interfaceSlice = append(interfaceSlice, concrete)
	}
	return interfaceSlice
}
func (this Contract) GetEngagementsPerDay() int { return this.EngagementsPerDay }
func GetContractById(ctx context.Context, id string) (*Contract, error) {
	var contract Contract
	contract.ID = id
	return GetModelByIDFromDDB(ctx, contract, "CONTRACT", "PK")
}

func StoreContract(ctx context.Context, wg *sync.WaitGroup, contract_day_record *ContractDayRecord) {
	defer wg.Done()
	StoreItem(ctx, contract_day_record, "CONTRACT_DAY_RECORD")
}

type ContractReport struct {
	Contract
}
