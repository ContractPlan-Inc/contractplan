package models

import (
	"context"
	"crypto/sha256"
	"fmt"
	"os"
	"reflect"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/expression"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/beego/beego/v2/core/logs"
	"github.com/kr/pretty"

	"cloudparallax.com/backend/services/aws/config"
	dynamodb2 "cloudparallax.com/backend/services/aws/dynamodb"
)

type anyModel struct {
	DynamoDBModel
	Id string
}

func (a anyModel) GetID() string {
	return a.Id
}

type Model interface {
	BlankModel | Customer | User | any | Contract | ContractDayRecord
}
type SearchItem interface{}

type ModelConstraint interface {
	Model
	GetID() string
	GetPK() string
	GetSK() string
}

type BlankModel struct {
	Id string
}

func (t BlankModel) GetID() string {
	return t.Id
}

func (t BlankModel) GetTenant() string {
	return ""
}

func RetrieveMultipleItems[F ModelConstraint](ctx context.Context, recordType string, items []F) ([]*F, error) {
	PKMap := map[string]string{}
	PKMapSequence := map[string]int{}
	mapOutput := map[string]*F{}
	var slice []*F
	for seq, item := range items {
		// build gsi for each item
		BuildGSI(ctx, &item, recordType, "", false, true)
		pk := item.GetPK()
		sk := item.GetSK()
		PKMapSequence[pk+"#"+sk] = seq
		PKMap[sk] = pk
	}
	var retrivalMap []map[string]types.AttributeValue
	i := 0
	for SK, PK := range PKMap {
		retrivalItem := map[string]types.AttributeValue{}
		retrivalItem["PK"] = &types.AttributeValueMemberS{Value: PK}
		retrivalItem["SK"] = &types.AttributeValueMemberS{Value: SK}
		retrivalMap = append(retrivalMap, retrivalItem)
		i++
		if i >= 99 {
			mapOutput, _ = ReadBatchFromDDB(ctx, retrivalMap, recordType, mapOutput)
			retrivalMap = []map[string]types.AttributeValue{}
			i = 0
		}
	}
	if i > 0 {
		mapOutput, _ = ReadBatchFromDDB(ctx, retrivalMap, recordType, mapOutput)
	}
	slice = make([]*F, len(mapOutput))
	for key, item := range mapOutput {
		if keyindex, ok := PKMapSequence[key]; ok {
			slice[keyindex] = item
		}
	}
	// pretty.Println("SLICE", slice)
	return slice, nil

	// retrieve items from ddb
}

func RetrieveItemsUsingGSI[F Model](ctx context.Context, record F, recordType string, limit int32, count, partialFiltering, skipIncomplete, sortAsc bool, lastEvaluatedKey *DynamoLastEvaluatedKey, searchType string, gsiOverride ...string) ([]*F, *DynamoLastEvaluatedKey, error) {
	consumedUnits := 0.0
	_, validGSI, err := BuildGSI(ctx, &record, recordType, "", partialFiltering, skipIncomplete)
	pretty.Println("VALID GSI: ", validGSI)
	if len(gsiOverride) > 0 {
		validGSI = gsiOverride
	}
	pretty.Println("GSI OVERRIDES", validGSI)

	mapOutput := map[string]*F{}
	var slice []*F

	if err != nil {
		logs.Debug(err)
		return slice, lastEvaluatedKey, err
	}
	PKName := "PK"
	SKName := "SK"
	PKField := "PK"
	SKField := "SK"
	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug("SLICE INTERFACE", pretty.Sprint(record))
	}
	counts := make(map[string]int)
	PKMap := map[string]string{}
	PKMapSequence := map[string]int{}

	logs.Info("BEGIN SEARCH")
	for i, gsi := range validGSI {
		logs.Info("ITERATION", i)
		if gsi == "EntityFilter" {
			PKName, PKField = "EntityType", "EntityType"
			SKName, SKField = "EntitySK", "EntitySK"
		} else if gsi == "InvertedIndex" {
			PKName, PKField = "SK", "SK"
			SKName, SKField = "PK", "PK"
		} else if gsi == "IDFilter" {
			PKName, PKField = "EntityType", "EntityType"
			SKName, SKField = "ID", "a"
		} else if strings.HasPrefix(gsi, "GSI") {
			PKName, PKField = gsi+"PK", gsi+"PK"
			SKName, SKField = gsi+"SK", gsi+"SK"
		} else if gsi == "PK" {
			PKName, PKField = "PK", "PK"
			SKName, SKField = "SK", "SK"
			gsi = "PK"
		}

		pk := reflect.ValueOf(record).FieldByName(PKName).String()
		sk := reflect.ValueOf(record).FieldByName(SKName).String()
		expr := expression.Key(PKField).Equal(expression.Value(pk))

		switch searchType {
		case "beginswith":
			{
				expr = expr.And(expression.Key(SKField).BeginsWith(sk))
			}
		case "exact":
			{
				expr = expr.And(expression.Key(SKField).Equal(expression.Value(sk)))
			}
		case "lt":
			{
				expr = expr.And(expression.Key(SKField).LessThan(expression.Value(sk)))
			}
		case "lte":
			{
				expr = expr.And(expression.Key(SKField).LessThanEqual(expression.Value(sk)))
			}
		case "gt":
			{
				expr = expr.And(expression.Key(SKField).GreaterThan(expression.Value(sk)))
			}
		case "gte":
			{
				expr = expr.And(expression.Key(SKField).GreaterThanEqual(expression.Value(sk)))
			}
		default:
			{
				expr = expr.And(expression.Key(SKField).Equal(expression.Value(sk)))
			}
		}
		if sk != "" {
		}
		logs.Debug(pk, sk)
		if strings.Contains(sk, "<==^==>") {
			split := strings.Split(sk, "<==^==>")
			expr = expression.
				Key(PKName).Equal(expression.Value(pk)).And(expression.
				Key(SKName).Between(expression.Value(split[0]), expression.Value(split[1])))
		}
		// var exprBuilder expression.Builder
		exprBuilder, err := expression.NewBuilder().WithKeyCondition(expr).Build()
		if err != nil {
			return slice, lastEvaluatedKey, err
		}

		var startKey map[string]types.AttributeValue
		if lastEvaluatedKey != nil {
			if val, ok := lastEvaluatedKey.GsiKeyMap[gsi]; ok && val != nil && len(val) > 0 {
				startKey = val
			}
		}
		ddbQuery := retrieveDBValues(startKey, exprBuilder, limit, count, sortAsc)

		if gsi != "PK" {
			ddbQuery.IndexName = aws.String(gsi)
		}
		if os.Getenv("SHOWQUERY") == "1" {
			logs.Info("QUERY ", pretty.Sprint(ddbQuery))
		}
		output, err := dynamodb2.DDBClient.Query(ctx, ddbQuery)
		if lastEvaluatedKey != nil && output != nil {
			lastEvaluatedKey.GsiKeyMap[gsi] = output.LastEvaluatedKey
		}
		if err == nil {
			dynamodb2.DDBUsage.IncrementReadCount(*output.ConsumedCapacity.CapacityUnits)
		}
		if err != nil {
			logs.Error(err.Error())
			continue
		} else if count {
			consumedUnits += *output.ConsumedCapacity.CapacityUnits
			counts[gsi] = int(output.Count)
		} else if !count {
			if ok, _ := StringInSlice(gsi, "PK"); ok {
				for _, p := range output.Items {
					var resultMapD F
					err = attributevalue.UnmarshalMap(p, &resultMapD)
					pkVal := ""
					attributevalue.Unmarshal(p["PK"], &pkVal)
					skVal := ""
					attributevalue.Unmarshal(p["SK"], &skVal)
					slice = append(slice, &resultMapD)
				}
				if len(slice) > 0 {
					logs.Info("RETURN PREMATURE of Size : ", len(slice))
					return slice, lastEvaluatedKey, err
				}
			} else {
				var resultMap []map[string]interface{}
				err = attributevalue.UnmarshalListOfMaps(output.Items, &resultMap)
				if len(resultMap) > 0 {
					for i, val := range resultMap {
						PKMap[val["PK"].(string)+"`````"+val["SK"].(string)] = val["PK"].(string)
						PKMapSequence[val["PK"].(string)+"#"+val["SK"].(string)] = i
						// pretty.Println(val["PK"].(string)+"#"+val["SK"].(string), " =====>     ", i)
					}
					if err != nil {
						return slice, lastEvaluatedKey, err
					}
				}
			}
		}
	}
	var retrivalMap []map[string]types.AttributeValue
	i := 0
	for SK, PK := range PKMap {
		retrivalItem := map[string]types.AttributeValue{}
		retrivalItem["PK"] = &types.AttributeValueMemberS{Value: PK}
		retrivalItem["SK"] = &types.AttributeValueMemberS{Value: strings.Split(SK, "`````")[1]}
		retrivalMap = append(retrivalMap, retrivalItem)
		i++
		if i >= 99 {
			mapOutput, _ = ReadBatchFromDDB(ctx, retrivalMap, recordType, mapOutput)
			retrivalMap = []map[string]types.AttributeValue{}
			i = 0
		}
	}
	if i > 0 {
		mapOutput, _ = ReadBatchFromDDB(ctx, retrivalMap, recordType, mapOutput)
	}
	slice = make([]*F, len(mapOutput))
	for key, item := range mapOutput {
		if keyindex, ok := PKMapSequence[key]; ok {
			if os.Getenv("DEEP_OBJECT") == "1" {
				logs.Debug("ITEM:", pretty.Sprint(item))
			}
			slice[keyindex] = item
		}
	}
	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug("SLICE INTERFACE", pretty.Sprint(slice))
	}
	logs.Debug("total consumed units:", consumedUnits)
	// return records, nil
	logs.Info("RETRIEVAL FINISHED of Size : ", len(mapOutput))
	return slice, lastEvaluatedKey, err
}

func RetrieveItemCounts[F Model](ctx context.Context, record F, recordType string, limit int32, count, partialFiltering, skipIncomplete bool, lastEvaluatedKey *DynamoLastEvaluatedKey, gsiOverride ...string) (map[string]int, error) {
	consumedUnits := 0.0
	record, validGSI, err := BuildGSI(ctx, record, recordType, "", partialFiltering, skipIncomplete)
	if len(gsiOverride) > 0 {
		validGSI = gsiOverride
	}
	if err != nil {
		logs.Debug(err)
		return nil, err
	}
	PKName := "PK"
	SKName := "SK"
	PKField := "PK"
	SKField := "SK"

	counts := make(map[string]int)
	logs.Info("BEGIN SEARCH")
	for i, gsi := range validGSI {
		logs.Info("ITERATION", i)
		if gsi == "EntityFilter" {
			PKName, PKField = "EntityType", "EntityType"
			SKName, SKField = "EntitySK", "EntitySK"
		} else if gsi == "InvertedIndex" {
			PKName, PKField = "SK", "SK"
			SKName, SKField = "PK", "PK"
		} else if gsi == "IDFilter" {
			PKName, PKField = "EntityType", "EntityType"
			SKName, SKField = "Id", "a"
		} else if strings.HasPrefix(gsi, "GSI") {
			PKName, PKField = gsi+"PK", gsi+"PK"
			SKName, SKField = gsi+"SK", gsi+"SK"
		} else if gsi == "PK" {
			PKName, PKField = "PK", "PK"
			SKName, SKField = "SK", "SK"
			gsi = "PK"
		}

		pk := reflect.ValueOf(record).Elem().FieldByName(PKName).String()
		sk := reflect.ValueOf(record).Elem().FieldByName(SKName).String()

		expr := expression.Key(PKField).Equal(expression.Value(pk))
		if sk != "" {
			expr = expr.And(expression.Key(SKField).BeginsWith(sk))
		}
		logs.Debug(pk, sk)
		if strings.Contains(sk, "<==^==>") {
			split := strings.Split(sk, "<==^==>")
			expr = expression.
				Key(PKName).Equal(expression.Value(pk)).And(expression.
				Key(SKName).Between(expression.Value(split[0]), expression.Value(split[1])))
		}
		exprBuilder, err := expression.
			NewBuilder().
			WithKeyCondition(expr).
			Build()
		if err != nil {
			logs.Debug(err)
			return nil, err
		}
		var startKey map[string]types.AttributeValue
		if lastEvaluatedKey != nil {
			if val, ok := lastEvaluatedKey.GsiKeyMap[gsi]; ok && val != nil && len(val) > 0 {
				startKey = val
			}
		}
		ddbQuery := retrieveDBValues(startKey, exprBuilder, limit, true, true)
		if gsi != "PK" {
			ddbQuery.IndexName = aws.String(gsi)
		}
		if os.Getenv("SHOWQUERY") == "1" {
			logs.Debug("QUERY ", pretty.Sprint(ddbQuery))
		}
		output, err := dynamodb2.DDBClient.Query(ctx, ddbQuery)
		if lastEvaluatedKey != nil && output != nil {
			lastEvaluatedKey.GsiKeyMap[gsi] = output.LastEvaluatedKey
		}
		if err != nil {
			logs.Debug(err)
			continue
		} else {
			consumedUnits += *output.ConsumedCapacity.CapacityUnits
			counts[gsi] = int(output.Count)
		}
		dynamodb2.DDBUsage.IncrementReadCount(*output.ConsumedCapacity.CapacityUnits)
	}
	logs.Debug("total consumed units:", consumedUnits)
	return counts, nil
}

func ReadBatchFromDDB[F Model](ctx context.Context, retrivalMap []map[string]types.AttributeValue, recordType string, slice map[string]*F) (map[string]*F, error) {
rereadBatch:
	output, err := readBatchFromDynamoDB(ctx, retrivalMap)
	if err != nil {
		logs.Debug(err)
		return slice, err
	}
	for _, p := range output.Responses[config.DDBTable] {
		logs.Debug("ITEM:", pretty.Sprint(p))
		var resultMapD F
		err = attributevalue.UnmarshalMap(p, &resultMapD)
		logs.Debug("ITEM MODEL:", pretty.Sprint(resultMapD))
		pkVal := ""
		err = attributevalue.Unmarshal(p["PK"], &pkVal)
		skVal := ""
		err = attributevalue.Unmarshal(p["SK"], &skVal)
		combVal := pkVal + "#" + skVal
		if _, ok := slice[combVal]; ok {
			logs.Debug("Duplicate found", combVal)
			continue
		}
		logs.Debug("COMBVAL: ", combVal)
		slice[combVal] = &resultMapD
	}
	for _, p := range output.ConsumedCapacity {
		dynamodb2.DDBUsage.IncrementReadCount(*p.CapacityUnits)
	}
	if len(output.UnprocessedKeys[config.DDBTable].Keys) > 0 {
		retrivalMap = output.UnprocessedKeys[config.DDBTable].Keys
		goto rereadBatch
	} else {
		retrivalMap = []map[string]types.AttributeValue{}
	}
	return slice, nil
}

func readBatchFromDynamoDB(ctx context.Context, batchKeys []map[string]types.AttributeValue) (*dynamodb.BatchGetItemOutput, error) {
	requestItems := map[string]types.KeysAndAttributes{}
	requestItems[config.DDBTable] = types.KeysAndAttributes{
		Keys: batchKeys,
	}
	ddbBatchRead := &dynamodb.BatchGetItemInput{
		RequestItems:           requestItems,
		ReturnConsumedCapacity: "TOTAL",
	}
	if os.Getenv("SHOWQUERY") == "1" {
		logs.Debug("QUERY :", pretty.Sprint(ddbBatchRead))
	}
	return dynamodb2.DDBClient.BatchGetItem(ctx, ddbBatchRead)
}

func expressionBuilder(conditionBuilder expression.ConditionBuilder, parent string, destructuredMap map[string]interface{}) expression.ConditionBuilder {
	for field, item := range destructuredMap {
		typeOfItem := reflect.TypeOf(item)
		fieldName := field
		if parent != "" {
			fieldName = strings.Join([]string{parent, fieldName}, ".")
		}
		if typeOfItem.Kind().String() == "map" {
			conditionBuilder = expressionBuilder(conditionBuilder, fieldName, item.(map[string]interface{}))
		} else if typeOfItem.Kind().String() != "slice" {
			// logs.Debug(conditionBuilder)
			if val, ok := destructuredMap[field+"Array"]; ok {
				valMap := val.([]interface{})
				if !conditionBuilder.IsSet() {
					conditionBuilder = expression.AttributeNotExists(expression.Name(fieldName)).Or(expression.AttributeExists(expression.Name(fieldName)).And(expression.Name(fieldName).Between(expression.Value(valMap[0].(string)), expression.Value(valMap[1].(string)))))
				} else {
					conditionBuilder = conditionBuilder.And(expression.AttributeNotExists(expression.Name(fieldName)).Or(expression.AttributeExists(expression.Name(fieldName)).And(expression.Name(fieldName).Between(expression.Value(valMap[0].(string)), expression.Value(valMap[1].(string))))))
				}
			} else {
				if !conditionBuilder.IsSet() {
					conditionBuilder = expression.AttributeNotExists(expression.Name(fieldName)).Or(expression.AttributeExists(expression.Name(fieldName)).And(expression.Name(fieldName).Contains(item.(string))))
				} else {
					conditionBuilder = conditionBuilder.And(expression.AttributeNotExists(expression.Name(fieldName)).Or(expression.AttributeExists(expression.Name(fieldName)).And(expression.Name(fieldName).Contains(item.(string)))))
				}
			}
		}
	}
	return conditionBuilder
}

func destructureInterface(record interface{}) map[string]interface{} {
	values := make(map[string]interface{})
	v := reflect.ValueOf(record)
	f := reflect.TypeOf(record)
	if v.Kind().String() == "ptr" {
		v = v.Elem()
		f = f.Elem()
	}
	for i := 0; i < v.NumField(); i++ {
		if f.Field(i).Name == "DynamoDBModel" {
			continue
		}
		if !v.Field(i).IsZero() && v.Field(i).Kind().String() != "ptr" {
			if v.Field(i).Kind().String() == "struct" {
				values[f.Field(i).Name] = v.Field(i).Interface()
			} else {
				values[f.Field(i).Name] = v.Field(i).Interface()
			}
		} else if !v.Field(i).IsZero() && v.Field(i).Kind().String() == "ptr" {
			values[f.Field(i).Name] = destructureInterface(v.Field(i).Elem().Interface())
		}
	}
	return values
}

func retrieveDBValues(startKey map[string]types.AttributeValue, exprBuilder expression.Expression, limit int32, count bool, sortAsc bool) *dynamodb.QueryInput {
	// exprBuilder = exprBuilder.WithKeyCondition("Archived = :archivedFalse")
	// exprBuilder = exprBuilder.WithValue(":archivedFalse", &types.AttributeValueMemberBOOL{Value: false})

	ddbQuery := &dynamodb.QueryInput{
		TableName:                 aws.String(config.DDBTable),
		ExclusiveStartKey:         startKey,
		KeyConditionExpression:    exprBuilder.KeyCondition(),
		ExpressionAttributeNames:  exprBuilder.Names(),
		ExpressionAttributeValues: exprBuilder.Values(),
		FilterExpression:          exprBuilder.Condition(),
		Limit:                     aws.Int32(limit),
		ReturnConsumedCapacity:    types.ReturnConsumedCapacityTotal,
		ScanIndexForward:          aws.Bool(sortAsc),
	}
	if count {
		ddbQuery.Select = types.SelectCount
	}

	return ddbQuery
}

func reverseString(input string) string {
	// Get Unicode code points.
	n := 0
	runeList := make([]rune, len(input))
	for _, r := range input {
		runeList[n] = r
		n++
	}
	runeList = runeList[0:n]
	// Reverse
	for i := 0; i < n/2; i++ {
		runeList[i], runeList[n-1-i] = runeList[n-1-i], runeList[i]
	}
	// Convert back to UTF-8.
	output := string(runeList)
	return output
}

func asSha256(o interface{}) string {
	h := sha256.New()
	h.Write([]byte(fmt.Sprintf("%v", o)))
	return fmt.Sprintf("%x", h.Sum(nil))
}
