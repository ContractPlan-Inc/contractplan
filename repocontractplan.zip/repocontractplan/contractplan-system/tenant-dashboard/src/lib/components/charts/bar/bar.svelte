<script lang="ts">
  import Chart from "chart.js/auto";
  import { onMount } from "svelte";
  import plannedRevenue from "$lib/mock/plannedRevenue.json";
  import actalRevenue from "$lib/mock/actualRevenue.json";

  let chart;
  let chartCanvas;

  onMount(() => {
    const chartData = {
      labels: [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ],
      datasets: [
        {
          label: "Planned",
          data: plannedRevenue.map((o) => o.value),
          backgroundColor: "#000",
          borderColor: "#fff",
          borderWidth: 4,
          barThickness: 20,
        },
        {
          label: "Actual",
          data: actalRevenue.map((o) => o.value),
          backgroundColor: "#FF914D",
          borderColor: "#fff",
          borderWidth: 4,
          barThickness: 20,
        },
      ],
    };

    const ctx = document.getElementById("myChart").getContext("2d");
    chart = new Chart(ctx, {
      type: "bar",
      data: chartData,
      options: {
        plugins: {
          legend: {
            display: false,
          },
        },
        layout: {},
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            max: 1000000,
            min: 0,
            beginAtZero: false,
            grace: "20%",
            type: "linear",
            ticks: {},
          },
          x: {},
        },
      },
    });
  });
</script>

<div style="position: relative; height:40vh; width:100%; margin:0 auto;  ">
  <canvas id="myChart"></canvas>
</div>
