package utils

import (
	"crypto/rand"
	"regexp"
	"time"

	"github.com/oklog/ulid/v2"
)

func ExtractErrorMessage(input string) string {
	regexPattern := `.*: (.*)$`
	re := regexp.MustCompile(regexPattern)
	match := re.FindStringSubmatch(input)
	return match[1]
}
func GenerateULID() string {
	entropy := ulid.Monotonic(rand.Reader, 0)
	return ulid.MustNew(ulid.Now(), entropy).String()
}

func GetCurrentTimestamp() string {
	currentTime := time.Now()
	return currentTime.Format("2006-01-02 15:04:05")
}
