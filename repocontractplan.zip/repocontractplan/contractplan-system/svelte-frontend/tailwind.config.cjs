/** @type {import("tailwindcss").Config} */
module.exports = {
  content: [
    "./src/**/*.{html,js,svelte,ts}"
  ],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["Georama", "sans-serif"],
        poppins: ["Poppins", "Helvetica", "sans-serif"]
      },
      colors: {
        primary: 'var(--primary)',
        'primary-light': 'var(--primary-light)',
        'primary-extra-light': 'var(--primary-extra-light)',
        'primary-dark': 'var(--primary-dark)',
        'primary-extra-dark': 'var(--primary-extra-dark)',
        'primary-orange': 'var(--primary-orange)',
        'dark-bg': '#1f3548',
        'primary-dark-text':'white',
        'secondary-dark-text': '#808080'
      }
    }
  }
};
