<script lang="ts">
  import Chart from 'chart.js/auto';
  import { onMount } from 'svelte';

  let chart;
  let { ID, plannedData, actualData, labels, plannedColor, actualColor, chartType} = $props();
  let max = 0;
  let min = 1000;

  // Get primary color from localStorage
  let primaryColor = $state(localStorage.getItem('primary-color') || 'orange');
  
  // Map color names to hex values
  const colorMap = {
    'orange': '#FF914D',
    'blue': '#3B82F6',
    'red': '#FF69B4',
    'green': '#10B981'
  };

  // Update chart when primary color changes
  $effect(() => {
    if (chart) {
      chart.data.datasets[1].backgroundColor = colorMap[primaryColor];
      chart.data.datasets[1].borderColor = colorMap[primaryColor];
      chart.update();
    }
  });

  // Listen for color change events
  onMount(() => {
    window.addEventListener('primary-color-changed', (event: CustomEvent) => {
      primaryColor = event.detail.color;
    });
    return () => {
      window.removeEventListener('primary-color-changed', () => {});
    };
  });

  $effect(async () => {
    console.log("CommonChartinside:",plannedData)
    const chartData = {
      labels: labels,
      datasets: [{
        label: 'Planned',
        data: plannedData.map(o => {
          if (o > max) {
            max = o;
          }
          if (o < min) {
            min = o;
          }
          return o
        }),
        backgroundColor: plannedColor,
        borderColor: plannedColor,
        borderWidth: 2,
        barThickness: 20,
        pointRadius: 3,
        tension: 0.5
      },
        {
          label: 'Actual',
          data: actualData.map(o => {
          if (o > max) {
            max = o;
          }
          if (o < min) {
            min = o;
          }
          return o
        }),
          backgroundColor: colorMap[primaryColor],
          borderColor: colorMap[primaryColor],
          borderWidth: 1,
          barThickness: 20,
          pointRadius: 3,
          tension: 0.5
        }]
    };

    const ctx = document.getElementById(ID).getContext('2d');

    if (chart) {
      chart.destroy();
    }
    chart = new Chart(ctx, {
      type: chartType,
      data: chartData,
      options: {
        plugins: {
          legend: {
            display: false
          }
        },
        layout: {},
        responsive: true,
        aspectRatio: 5 / 1,
        scales: {
          y: {
            max: max + 1000,
            min: 0,
            beginAtZero: true,
            grace: '50%',
            type: 'linear',
            ticks: {
              //   fill -> avg & target
            }
          },
          x: {}
        }
      }
    });
  });

</script>
<div class=" w-[90%]  m-auto relative    ">
  <canvas class=" w-full" id={ID}></canvas>
</div>
