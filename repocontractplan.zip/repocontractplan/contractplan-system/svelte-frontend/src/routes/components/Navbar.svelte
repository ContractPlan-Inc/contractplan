<script lang="ts">
    import Icon from "@iconify/svelte";
    import logo from "../../lib/assets/svg/logo-icon.svg";

    let innerWidth = $state(0);
    let mobileMenu = $state(false);

</script>

<svelte:window bind:innerWidth />
<div class="  relative">
    <div class="flex flex-col md:flex-row    content-center w-full md:relative    absolute container mx-auto z-50">
        <button onclick={() => mobileMenu = false} class=" absolute  md:hidden right-0 top-0 w-10 h-10 round-full bg-white text-black flex  justify-center items-center ">
            <Icon icon="ic:baseline-close" width="26" height="26" />
        </button>
        <div class=" m-0 p-0  lg:w-1/2 md:w-[30%] md:self-center flex  items-center">
            <img src={logo} alt="">
            <h1 class="text-white font-bold text-lg ">ContractPlan</h1>
        </div>
        {#if mobileMenu || innerWidth >= 768}
            <ul class=" text-white mt-4 md:mt-0 bg-black md:bg-transparent flex flex-col md:flex-row text-center leading-[4]  md:w-2/3 lg:w-1/2 divide-y md:divide-none justify-between divide-slate-700 w-full rounded-xl  shadow-2xl md:shadow-none shadow-black border md:border-none border-white">
                <li><a href="/#pricing" class=" hover:text-gray-400">Pricing</a></li>
                <li><a href="/#features" class=" hover:text-gray-400">Features</a></li>
                <li><a href="/#industries" class=" hover:text-gray-400">Industries</a></li>
                <li><a href="/#faq" class=" hover:text-gray-400">FAQ</a></li>
                <li><a href="/company" class=" hover:text-gray-400">Company</a></li>
                <li><a href="/auth/signin" class="py-2 px-6 border text-white bg-orange-700 rounded-lg hover:text-white hover:bg-black border-black hover:border-white">Login</a></li>
            </ul>
            {:else}
            <button onclick={() => mobileMenu = true} class=" absolute flex  justify-center items-center   md:hidden right-0 top-0 w-10 h-10 round-full bg-white text-black">
                <Icon icon="iconamoon:menu-burger-horizontal" width="30px" height="30px" /></button>
        {/if}
    </div>
</div>
