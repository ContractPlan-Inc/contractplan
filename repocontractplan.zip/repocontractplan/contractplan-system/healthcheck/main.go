package main

import (
	"crypto/tls"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
)

func main() {

	const host = "127.0.0.1" // default host
	usedPort := "8443"       // default port
	path := "/"              // default path
	protocol := "https://"   // default protocol
	for _, envParts := range os.Environ() {
		// env = "HEALTH_CHECK_PORT=8443"
		env := strings.Split(envParts, "=")[0]
		if env == "HEALTH_CHECK_PORT" {
			usedPort = os.Getenv("HEALTH_CHECK_PORT")
		}
		if env == "HEALTH_CHECK_PATH" {
			path = os.Getenv("HEALTH_CHECK_PATH")
		}
		if env == "HEALTH_CHECK_PROTOCOL" {
			protocol = os.Getenv("HEALTH_CHECK_PROTOCOL")
		}
	}

	status, healthCheckError := executeHealthCheck(protocol, host, usedPort, path)

	if healthCheckError != nil {
		log.Fatalf(healthCheckError.Error())
	}

	log.Printf("%s", status)

}

func executeHealthCheck(protocol, host string, port string, path string) (string, error) {
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	resp, err := http.Get(fmt.Sprint(protocol, host, ":", port, path))
	if err != nil {
		return "", fmt.Errorf("unable to retrieve health status: %s", err.Error())
	}
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("STATUS: %d", resp.StatusCode)
	}
	return fmt.Sprintf("STATUS: %d", resp.StatusCode), nil
}

// validatePort checks if the port configuration is valid
func validatePort(port string) error {

	portInt, err := strconv.Atoi(port)
	if err != nil {
		return fmt.Errorf("invalid port: %w", err)
	}
	if portInt < 1 || portInt > 65535 {
		return fmt.Errorf("port outside of range [1:65535]: %d", portInt)
	}
	return nil

}
