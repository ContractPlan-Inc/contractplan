<script lang="ts">
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import {
    type Contract,
    type ContractDayRecordInput, GetContractDayRecordsDoc, type GetContractDayRecordsQuery,
    GetContractDayRecordsbyDateDoc,
    type GetContractDayRecordsByDateQuery,
    UpdateContractDayRecordsDoc
  } from '$lib/generated/graphql';
  import dayjs from 'dayjs';
  import Loader from "$lib/components/elements/loader.svelte";

  let { pop, contract } = $props();
  let errors: { [key: string]: string } = {};
  let searchTerm = $state("");
  let allContracts = $state<Contract[]>([]);
  let selectedContract = $state<Contract | null>(null);
  let selectedService = $state<any | null>(null);
  let contractDayRecords = $state([]);
  let date1 = $state(dayjs().format('YYYY-MM-DD'));
  let count1 = $state(0); // For Engagements
  let count2 = $state(0); // For Expected Eng
  let isLoading = $state(false);

  $effect(() => {
    pop
    console.log("fetching contracts");
    fetchContracts();
  });

  async function fetchContracts  () {

    try {
      const queryRepository = new GraphQLQueryRepository<GetContractDayRecordsByDateQuery>();
      const contractQuery = await queryRepository.getItems(
              GetContractDayRecordsbyDateDoc,
              { date: dayjs(date1).toISOString() },
              0,
              100
      );
      const ctrs = contractQuery?.data?.getContractdayRecordsByDate?.edges?.reduce(
              (acc, contract) => {
                acc.push(contract?.node as Contract);
                return acc;
              },
              [] as Contract[]
      );
      allContracts = ctrs as Contract[];
      console.log("all contracts", allContracts);
    } catch (error) {
      console.error("Error fetching contracts:", error);
    }
  }

</script>

{#if pop}
<div class="absolute top-0 left-0 flex items-center justify-center z-50">
  <div
    tabindex="0"
    class="flex items-center justify-center w-full h-full top-0 left-0 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow"
    style="position: fixed;"
    role="button"
    onclick={() => { pop = false; }}
  >
    <div
      class="w-full max-w-md max-h-full z-50 bg-white rounded-lg shadow border border-black"
      style="left: 150px;"
      onclick={(event) => { event.stopPropagation() }}
    >
      <div class="flex w-full justify-center items-center px-5">
        <div class="flex-wrap w-fit px-4 text-xl font-bold">Today Records</div>
      </div>

      <div class="w-full px-5 my-5">
        <div class="flex items-center space-x-2 mb-2">
          <label class="text-sm font-semibold w-1/4">Date</label>
          <input
            bind:value={date1}
            onchange={(e) => {
                fetchContracts();
            }}
            class="p-2 w-3/4 h-10 bg-gray-50 rounded-lg border border-gray-200"
            type="date"
          />
        </div>
        {#if errors.Date}
          <div class="text-xs text-red-500">{errors.Date}</div>
        {/if}
      </div>

      <div class="w-full px-5 my-5">
        <div class="flex items-center space-x-2 mb-2">
          <label class="text-sm font-semibold w-1/4">Contract</label>
          <div class="relative w-3/4">
            <input
              bind:value={searchTerm}
              class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200"
              type="text"
            />
            {#if allContracts !== undefined && allContracts.length !== 0}
              <div class="absolute z-10 w-full mt-1 bg-white border border-gray-200 shadow-lg rounded-lg">
                {#each allContracts as ctr}
                  {#if ctr.ContractName !== ""}
                    <div
                      onclick={() => selectContract(ctr)}
                      class="px-4 py-2 text-sm text-gray-800 cursor-pointer hover:bg-gray-100"
                    >
                      {ctr.ContractName}
                    </div>
                  {/if}
                {/each}
              </div>
            {/if}
          </div>
        </div>
        {#if errors.ContractID}
          <div class="text-xs text-red-500">{errors.ContractID}</div>
        {/if}
      </div>

      {#if selectedContract !== null}
        <div class="w-full px-5 my-5">
          <div class="flex items-center space-x-2 mb-2">
            <label class="text-sm font-semibold w-1/4">Service</label>
            <select
              bind:value={selectedService}
              class="p-2 w-3/4 h-10 bg-gray-50 rounded-lg border border-gray-200"
            >
              {#each selectedContract?.Services as service}
                <option value={service.ID}>{service.ServiceName}</option>
              {/each}
            </select>
          </div>
          {#if errors.ServiceID}
            <div class="text-xs text-red-500">{errors.ServiceID}</div>
          {/if}
        </div>
      {/if}

      <div class="w-full px-5 my-5">
        <div class="flex items-center space-x-2 mb-2">
          <label class="text-sm font-semibold w-1/4">Engagements</label>
          <input
            class="p-2 w-3/4 h-10 bg-gray-50 rounded-lg border border-gray-200"
            type="number"
            bind:value={count1}
          />
        </div>
        {#if errors.Count1}
          <div class="text-xs text-red-500">{errors.Count1}</div>
        {/if}
      </div>

      <div class="w-full px-5 my-5">
        <div class="flex items-center space-x-2 mb-2">
          <label class="text-sm font-semibold w-1/4">Expected Eng</label>
          <input
            class="p-2 w-3/4 h-10 bg-gray-50 rounded-lg border border-gray-200"
            type="number"
            bind:value={count2}
          />
        </div>
        {#if errors.Count2}
          <div class="text-xs text-red-500">{errors.Count2}</div>
        {/if}
      </div>

      <div class="w-full flex justify-center">
        <button
          class="p-2 px-4 w-fit m-2 h-10 bg-gray-50 rounded-lg border border-gray-200"
          onclick={() => updateDayRecord()}
          disabled={isLoading}
        >
          Submit
        </button>
      </div>
      {#if isLoading}
        <div class="w-full flex justify-center">
          <Loader loading={true} type="dataLoader" />
        </div>
      {/if}
    </div>
  </div>
</div>

{/if}

<style>
  .dropdown-container {
    position: relative;
    display: inline-block;
  }

  .dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    border: 1px solid #ccc;
    background: white;
    z-index: 1000;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }

  .dropdown-item {
    padding: 8px 12px;
    cursor: pointer;
  }

  .dropdown-item:hover {
    background-color: #f0f0f0;
  }

</style>
