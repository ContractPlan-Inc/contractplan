import * as cdk from 'aws-cdk-lib';
import {aws_kms, aws_logs} from 'aws-cdk-lib';
import * as autoscaling from 'aws-cdk-lib/aws-autoscaling';
import {OnDemandAllocationStrategy, SpotAllocationStrategy} from 'aws-cdk-lib/aws-autoscaling';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import {IVpc, SecurityGroup} from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import {AmiHardwareType, FargateService} from 'aws-cdk-lib/aws-ecs';
import * as iam from 'aws-cdk-lib/aws-iam';
import {LogGroup} from 'aws-cdk-lib/aws-logs';
import {Construct} from 'constructs';

export interface ClusterStackProps extends cdk.StackProps {
  environment: string;
}

export class ClusterCdkStack extends cdk.Stack {
  public readonly vpc: IVpc;
  public readonly ecsSG: SecurityGroup;
  public readonly service: FargateService;
  public readonly cluster: ecs.Cluster;
  public capacityProvider: string;
  public readonly logGroup: LogGroup;

  constructor(scope: Construct, id: string, props: ClusterStackProps) {
    super(scope, id, props);

    this.vpc = ec2.Vpc.fromVpcAttributes(this, 'vpc', {
      vpcId: cdk.Fn.importValue('VPC-vpc-id'),
      availabilityZones: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-azs`)),
      publicSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-public-subnets`)),
      privateSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-private-subnets`)),
    })
    const albStackSecurityGroupId = cdk.Fn.importValue('ApplicationLoadBalancerV2-security-group-id');//ApplicationLoadBalancerV2 ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbSecurityGroupId', '/alb-stack/security-group-id').stringValue;
    const albSG = ec2.SecurityGroup.fromSecurityGroupId(this, 'alb-security-group', albStackSecurityGroupId);
    this.cluster = new ecs.Cluster(this, 'application-cluster', {
      clusterName: 'application-cluster',
      vpc: this.vpc,
      containerInsights: true,
    });


    // Security groups to allow connections from the application load balancer to the fargate containers
    this.ecsSG = new ec2.SecurityGroup(this, 'ecsSG', {
      vpc: this.vpc,
      allowAllOutbound: true,
    });
    this.ecsSG.connections.allowFrom(
      albSG,
      ec2.Port.allTcp(),
      'Application load balancer'
    );
    // const instanceClasses = [ec2.InstanceClass.T4G,
      // ec2.InstanceClass.C6G,
      // ec2.InstanceClass.M6G,
      // ec2.InstanceClass.R6G,
    // ]
    const instanceFactor = 1;


    // const instanceSizes = [
    //   {capacity: 32, class: ec2.InstanceSize.XLARGE2},
    //   {capacity: 16, class: ec2.InstanceSize.XLARGE},
    //   {capacity: 8, class: ec2.InstanceSize.LARGE},
    //   {capacity: 4, class: ec2.InstanceSize.MEDIUM},
    // ]
    const weightedCapacity: autoscaling.LaunchTemplateOverrides[] = [];
    // for (const instanceSize of instanceSizes) {
    //   for (const instanceClass of instanceClasses) {
    //     weightedCapacity.push({
    //       instanceType: ec2.InstanceType.of(instanceClass, instanceSize.class),
    //       weightedCapacity: instanceSize.capacity * instanceFactor
    //     })
    //   }
    // }

    // weightedCapacity.push({
    //   instanceType: ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.SMALL),
    //   weightedCapacity: 2 * instanceFactor
    // })
    weightedCapacity.push({
      instanceType: ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.MICRO),
      weightedCapacity: instanceFactor
    })
    const role = new iam.Role(this, 'MyRole', {
      assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromManagedPolicyArn(this, 'managedPolicy', 'arn:aws:iam::aws:policy/service-role/AmazonEC2ContainerServiceforEC2Role')
      ]
    });

    const launchTemplate = new ec2.LaunchTemplate(this, 'LaunchTemplate', {
      detailedMonitoring: true,
      machineImage: ecs.EcsOptimizedImage.amazonLinux2023(AmiHardwareType.ARM),
      securityGroup: this.ecsSG,
      userData: ec2.UserData.forLinux({}),
      role: role,
    })
    // launchTemplate.addSecurityGroup(
    //   ec2.SecurityGroup.fromSecurityGroupId(
    //     this,
    //     "RedisClientSecurityGroup",
    //     cdk.Fn.importValue("Redis-client-security-group"),
    //   ),
    // );
    const autoScalingGroup = new autoscaling.AutoScalingGroup(this, `AutoScalingGroup`, {
      vpc: this.vpc,
      vpcSubnets: {subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS},
      mixedInstancesPolicy: {
        instancesDistribution: {
          onDemandAllocationStrategy: OnDemandAllocationStrategy.LOWEST_PRICE,
          onDemandBaseCapacity: 3,
          onDemandPercentageAboveBaseCapacity: props.environment === 'sandbox' ? 0 : 100,
          spotAllocationStrategy: SpotAllocationStrategy.LOWEST_PRICE,
          spotInstancePools: props.environment === 'sandbox' ? 1 : 3,
        },
        launchTemplate: launchTemplate,
        launchTemplateOverrides: weightedCapacity,
      },
      minCapacity: 0,
      maxCapacity: 500,
      capacityRebalance:true,
      terminationPolicies: [
        autoscaling.TerminationPolicy.OLDEST_INSTANCE,
        autoscaling.TerminationPolicy.OLDEST_LAUNCH_CONFIGURATION,
        autoscaling.TerminationPolicy.CLOSEST_TO_NEXT_INSTANCE_HOUR,
        autoscaling.TerminationPolicy.NEWEST_INSTANCE,
      ]

    });
    const capacityProvider = new ecs.AsgCapacityProvider(this, `ASG-CapacityProvider`, {
      autoScalingGroup,
      enableManagedScaling: true,
      enableManagedTerminationProtection: true,
      enableManagedDraining: true,
    });
    this.cluster.addAsgCapacityProvider(capacityProvider, {});
    this.capacityProvider = capacityProvider.capacityProviderName;
    const kmsKey = aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));

    this.logGroup = new aws_logs.LogGroup(
      this,
      'ecs-stack-log-group', {
        removalPolicy: cdk.RemovalPolicy.DESTROY,
        retention: aws_logs.RetentionDays.ONE_WEEK,
        logGroupName: '/system/ecs',
        encryptionKey: kmsKey,
      }
    )

  }
}
