<script>

  import Icon from "@iconify/svelte";


  export let profilePicture = "https://cdn.cloudflare.steamstatic.com/steamcommunity/public/images/avatars/00/00411ecc969f4fd6116d5115a0438a337d23cfd2.jpg";
  export let name = "John Doe";
  export let phoneNumber = "+618923979";
  export let isOnline = false;
</script>
<div class=" flex  items-center justify-between my-6 ">
  <div class=" flex items-center gap-3">
    <img alt="" class="w-10 rounded-full" src={profilePicture}>
    <div>
      <p class=" font-semibold">{name}</p>
      <p class=" text-sm text-gray-500">{phoneNumber}</p>
    </div>
  </div>
  <div class=" text-gray-500 relative">
    <Icon icon="lucide:message-circle" width="28" />
    <span
      class=" {!isOnline ? ' hidden' :''} w-3 h-3 bg-green-400 rounded-full absolute top-0 right-0  border border-white "></span>
  </div>
</div>
