# Backend

Backend for the System


## Built With

Backend is built with

* Go
* TypeScript
* AWS-CLI


## Prerequisites

### Go
1. To Install GoLang: [https://go.dev/doc/install]()


### AWS-CLI
#### Install AWS-CLI
1. Documentation [https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html]()
#### Configure a profile
1. Run
   ```sh
   aws configure sso
   ```
3. Enter a profile name ( Example: ``contractplan`` )
4. Enter Start URL: ``https://contractplan.awsapps.com/start/``
5. Enter Region: ``us-west-1``, Output Format: ``json``

### AWS CodeCommit
1. You need pip to install code commmit. To Install pip: [https://pip.pypa.io/en/stable/installation/]()
2. Install CodeCommit
   ```sh
   pip install git-remote-codecommit
   ```

## Getting Started
### Cloning Repository
1. Run
   ```sh
   git clone codecommit://contractplan@system
   ```
2. Move to backend
   ```sh
   cd backend
   ```
3. Install dependencies
   ```sh
   npm install
   ```
### Running the Backend
#### Login to SSO
You have to do these steps each time you got logged out.
1. Run the command using the profile name
   ```sh
   aws sso login --profile contractplan
   ```
2. Login to AWS and allow the authorization in the opened browser window.

#### Run Backend
1. Run
   ```sh
   make run
   ```




## Authors

Gnanakeethan - gnanakeethan@cloudparallax.com

