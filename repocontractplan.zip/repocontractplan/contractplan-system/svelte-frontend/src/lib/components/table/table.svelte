<script module lang="ts">
  export interface Column {
    value?: any;
    key: string;
    title: string;
    sortable?: boolean;
  }

  export interface Action {
    name: string; // name of the function
    icon: string; // icon of the action
    function: any; // execute after click the action
  }
</script>

<script generics="T" lang="ts">
  import pkg from 'lodash';
  import { createEventDispatcher, onMount } from 'svelte';
  import type { DataSource } from '$lib/interfaces/datasource';
  import dayjs from 'dayjs';
  import { title } from '$lib/state/store';

  const { orderBy } = pkg;

  interface Row {
    node: { [key: string]: any };
    checked: boolean;
  }


  interface Props {
    tabletitle?: string;
    rows?: Row[];
    isLabel?: boolean;
    label?: string;
    columns?: Column[];
    availableColumns?: string[];
    currencyColumns?: string[];
    dateColumns?: string[];
    dateTimeColumns?: string[];
    actionList?: Action[];
    bulkActions?: string[];
    tableDataSource: DataSource<T>;
    rootAccessPath?: string;
    actions?: boolean;
    editableCell?: String[];
    isSearch?: boolean;
    buttons?: import('svelte').Snippet;
  }

  let {
    tabletitle = '',
    rows = $bindable([]),
    isLabel = false,
    label = '',
    columns = [],
    availableColumns = $bindable([]),
    currencyColumns = [],
    dateColumns = [],
    dateTimeColumns = [],
    actionList = [],
    bulkActions = [],
    tableDataSource,
    rootAccessPath = '',
    actions = false,
    editableCell = [],
    isSearch = false,
    buttons
  }: Props = $props();

  let isAction = $state(false);
  let masterToggle = $state(false);
  let masterIndeterminate = $state(false);
  let sortBy: string = $state('');
  let sortDirection: 'asc' | 'desc' = $state('asc');
  const dispatch = createEventDispatcher();
  let columnKeys: any;
  let selectedTitles: any;
  let searchTerm = $state('');
  let isOpen = $state(false);
  onMount(() => {
    console.log('onMount');
    // updateColumn();
    // getPageData();
    tableDataSource.loadCurrentPage({}).then((data) => {
      rootAccessPath.split('.').forEach((path) => {
        data = extractData(data, path);
      });
      if (data) {
        rows = data;
      }
      console.log('data', rows);
    });
  });

  function extractData(data: any, path: string) {
    console.log("extractData", data[path])
    return data[path];
  }

  function dayjsC(date: any) {
    return dayjs(date);
  }

  // trouggle section
  function toggleAll() {
    rows = rows.map((item) => ({
      ...item,
      checked: masterToggle
    }));
    masterIndeterminate = false;
  }

  function toggleRow(item: Row) {
    masterToggle = rows.every((item) => item.checked);
    masterIndeterminate = !masterToggle && rows.some((item) => item.checked);
  }

  let selectedRows = $derived(rows.filter((item) => item.checked));

  // sorting section
  function sortByColumn(columnKey: string) {
    if (sortBy === columnKey) {
      sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      sortBy = columnKey;
      sortDirection = 'asc';
    }
    const sortedRows = orderBy(rows, [columnKey], [sortDirection]);

    rows = [...sortedRows];
  }

  // search section
  let filteredRows = $derived(rows);
  //pagination section
  const options = columns.map((column) => ({
    title: column.title,
    value: column.key,
    checked: true
  }));
  let selectedOptions: Column[] = [];

  function handleSelectedOptionsChange(event: any) {
    selectedOptions = event.detail;

    console.log(selectedOptions);
    console.log(options);
    updateColumn();
  }

  function updateIsOpen(value: any) {
    isOpen = value;
  }

  function updateColumn() {
    columnKeys = columns.map((column) => column.title);
    selectedTitles = selectedOptions.map((option) => option.value);
    availableColumns = selectedOptions.map((option) => option.value);
    console.log('test');
    console.log('selectedOptions ' + JSON.stringify(selectedOptions));
    console.log('options ' + JSON.stringify(options));

    console.log('selectedTitles ' + selectedTitles);
    console.log('columnKeys ' + columnKeys);
  }

  function handleCellChange(item: Row, key: string): any {
    console.log('item:', item, 'key:', key);
  }
</script>

<!-- {JSON.stringify(selectedOptions)} -->
<!-- {JSON.stringify(selectedColumns)} -->

{#if isOpen || isAction}
  <div
    class="absolute w-full md:w-[calc(100%_-_180px)] z-10 h-full"
    onclick={() => {isOpen = false;isAction = false}}
  ></div>
  <div
    class="absolute w-full md:w-[calc(100%_-_180px)] z-10 h-full"
    onclick={() => {isOpen = false;isAction = false}}
  ></div>
{/if}

<section class="container mx-auto bg-white dark:bg-dark-bg">
  <div class="flex items-center justify-between w-full dark:text-white">
    <p>{rows.length} {tabletitle === '' ? $title : tabletitle}</p>
    <!--{#if Object.keys(addButton).length === 0}
      <AddNewButton btnText={addButton.text} path={addButton.path} />
    {/if}-->
    {@render buttons?.()}
  </div>
  <div class="overflow-x-auto rounded-lg">
    {#if isSearch}
      <div class="flex justify-between items-end p-6 border rounded-lg gap-6">
        <div class="flex gap-6">
          <div class="w-[35%]">
            <label for="search" class=" text-xs">Search</label>
            <input
              type="text"
              id="search"
              class=" border border-gray-300 outline-cyan-500 rounded-md px-3 w-full"
              bind:value={searchTerm}
            />
          </div>
          <div class="w-[35%]">
            <label for="partner" class=" text-xs">Name</label>
            <input
              type="text"
              id="partner"
              class="border border-gray-300 outline-cyan-500 rounded-md px-3 w-full"
              bind:value={searchTerm}
            />
          </div>
          <div class="w-[30%]">
            <label for="date" class=" text-xs">Date</label>
            <input
              type="text"
              id="date"
              class="border border-gray-300 outline-cyan-500 rounded-md px-3 w-full"
              bind:value={searchTerm}
            />
          </div>
        </div>
        <button class=" border border-gray-900 w-[15%] py-2 rounded-md"
        >Search
        </button
        >
      </div>
    {/if}

    <div class="border rounded-lg my-6">
      <table class="w-full table-auto">
        <thead>
        <tr class="text-gray-400 font-light text-xs leading-normal">
          <th class="py-2 px-3 text-left">
            <input
              bind:checked={masterToggle}
              bind:indeterminate={masterIndeterminate}
              class="h-4 w-4 rounded text-primary focus:ring-0 border-primary-extra-dark"
              onchange={toggleAll}
              type="checkbox"
            />
          </th>
          {#each columns as column}
            {#if availableColumns.includes(column.key)}
              <th
                class="py-2 cursor-pointer font-normal"
                onclick={() =>
                    column.sortable ? sortByColumn(column.key) : null}
              >
                <div
                  class="flex flex-row"
                  class:flex-row-reverse={currencyColumns.includes(
                      column.key
                    )}
                >
                  <span class="pr-[20px]">{column.title}</span>
                  {#if column.sortable}
                    {#if sortBy === column.key}
                      <span>{sortDirection === "asc" ? "▲" : "▼"}</span>
                    {/if}
                  {/if}
                </div>
              </th>
            {/if}
          {/each}
          {#if actions}
            <th class="py-2 px-3 font-normal">Action</th>
          {/if}
        </tr>
        </thead>
        <tbody class="text-gray-700 text-sm font-light dark:text-white">
        {#each rows as item}
          {#if "node" in item && item['node']['Archive']!==true}
            <tr
              class="{item.checked
                  ? 'bg-primary-extra-light'
                  : ''}     border-t"
            >
              <td class="py-2 px-3">
                <input
                  type="checkbox"
                  class=" h-4 w-4 rounded text-primary focus:ring-0 border-primary-extra-dark"
                  bind:checked={item.checked}
                  onchange={() => toggleRow(item)}
                />
              </td>
              {#each columns as column}
                {#if availableColumns.includes(column.key)}
                  {#if currencyColumns.includes(column.key)}
                    {#if editableCell.includes(column.key)}
                      <td
                        class="text-right pr-[20px]"
                        contenteditable="true"
                        bind:innerHTML={item["node"][column.key]}
                        oninput={() => handleCellChange(item, column.key)}
                      >
                        {#if column.key in item["node"]}
                          {Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: item["node"][column.key]["currency"],
                          }).format(
                            item["node"][column.key]["amount"] / 100.0
                          )}
                        {/if}
                      </td>
                    {:else}
                      <td class="text-right pr-[20px]">
                        {#if column.key in item["node"]}
                          {Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: item["node"][column.key]["currency"],
                          }).format(
                            item["node"][column.key]["amount"] / 100.0
                          )}
                        {/if}
                      </td>
                    {/if}
                  {:else if dateColumns.includes(column.key)}
                    {#if editableCell.includes(column.key)}
                      <td
                        class="text-left"
                        contenteditable="true"
                        bind:innerHTML={item["node"][column.key]}
                        oninput={() => handleCellChange(item, column.key)}
                      >
                        {#if column.key in item["node"]}
                          {dayjs(item["node"][column.key]).format(
                            "DD MMM YYYY"
                          )}
                        {/if}
                      </td>
                    {:else}
                      <td class="text-left">
                        {#if column.key in item["node"]}
                          {dayjs(item["node"][column.key]).format(
                            "DD MMM YYYY"
                          )}
                        {/if}
                      </td>
                    {/if}
                  {:else if dateTimeColumns.includes(column.key)}
                    {#if editableCell}
                      <td
                        class="text-right"
                        contenteditable="true"
                        bind:innerHTML={item["node"][column.key]}
                        oninput={() => handleCellChange(item, column.key)}
                      >
                        {#if column.key in item["node"]}
                          {item["node"][column.key]}
                        {/if}
                      </td>
                    {:else}
                      <td class="text-right" contenteditable="true">
                        {#if column.key in item["node"]}
                          {item["node"][column.key]}
                        {/if}
                      </td>
                    {/if}
                  {:else if editableCell.includes(column.key)}
                    <td
                      class="text-left"
                      contenteditable="true"
                      bind:innerHTML={item["node"][column.key]}
                      oninput={() => handleCellChange(item, column.key)}
                    >
                      {#if column.key in item["node"]}
                        {item["node"][column.key]}
                      {/if}
                    </td>
                  {:else}
                    <td class="text-left">
                      {#if column.key in item["node"]}
                        {item["node"][column.key]}
                      {/if}
                    </td>
                  {/if}
                {/if}
              {/each}
              {#if actions}
                <td class=" flex justify-center items py-2 px-3 space-x-2">
                  {#each actionList as action}
                    <button
                      class="border py-2 px-3 rounded"
                      onclick={() => {
                          action.function(item["node"]);
                        }}
                    >
                      <img src={action.icon} class="w-4" alt="" />
                    </button>
                  {/each}
                </td>
              {/if}
            </tr>
          {/if}
        {/each}
        </tbody>
      </table>
    </div>
  </div>
</section>
