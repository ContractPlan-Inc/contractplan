package models

type Customer struct {
	ID        string `json:"ID"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Email     string `json:"email"`
	Phone     string `json:"phone"`
	Status   string `json:"status"`
}

func (Customer) IsNode()            {}
func (this Customer) GetID() string { return this.ID }

type CustomerConnection struct {
	Edges            []*CustomerEdge         `json:"edges,omitempty"`
	Pagination       *Pagination             `json:"pagination,omitempty"`
	LastEvaluatedKey *DynamoLastEvaluatedKey `json:"lastEvaluatedKey,omitempty"`
}

func (CustomerConnection) IsConnection() {}
func (this CustomerConnection) GetEdges() []Edge {
	if this.Edges == nil {
		return nil
	}
	interfaceSlice := make([]Edge, 0, len(this.Edges))
	for _, concrete := range this.Edges {
		interfaceSlice = append(interfaceSlice, concrete)
	}
	return interfaceSlice
}
func (this CustomerConnection) GetPagination() *Pagination { return this.Pagination }
func (this CustomerConnection) GetLastEvaluatedKey() *DynamoLastEvaluatedKey {
	return this.LastEvaluatedKey
}

type CustomerEdge struct {
	Cursor *string `json:"Cursor,omitempty"`
	Node   Node    `json:"node,omitempty"`
}

func (CustomerEdge) IsEdge()            {}
func (this CustomerEdge) GetNode() Node { return this.Node }
