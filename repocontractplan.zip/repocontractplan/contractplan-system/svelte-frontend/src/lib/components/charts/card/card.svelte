<script lang="ts">
  interface Props {
    Title: string;
    Value: number;
    Icon: any;
    CurrencyPrefix?: boolean;
  }

  let {
    Title,
    Value,
    Icon,
    CurrencyPrefix = false
  }: Props = $props();
  // export let ColorFrom: string;
  // export let ColorTo: string;

  let USDollar = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  });


</script>
<div class=" h-auto w-full flex flex-col mx-auto shadow-sm border  rounded-md">
  <div class=" p-2 h-18 flex justify-between items-start">
    <div class=" p-2 h-18 space-y-1 ">
      <div class=" text-sm">{Title}</div>
      <div class=" text-2xl font-bold">
      {#if CurrencyPrefix}
        {USDollar.format(Value)}
      {:else}
      <input disabled class="bg-transparent" type="text" value={Value}/>
      {/if}
      </div>
    </div>
    <div class=" p-2 h-18 flex items-center justify-center">
    </div>
  </div>

</div>

<style>
  @media (max-width: 972px) {
    .flex-mb {
      display: flex;
      flex-direction: column-reverse;
    }
  }
</style>
