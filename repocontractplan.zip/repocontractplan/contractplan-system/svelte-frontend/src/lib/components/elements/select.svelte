<script>
  /**
   * @typedef {Object} Props
   * @property {string} [label]
   * @property {string} [value]
   * @property {string} [type]
   * @property {any} [options]
   */

  /** @type {Props} */
  let {
    label = "Text",
    value = $bindable(""),
    type = "text",
    options = [{ title: "option 1", value: "option 1" }, { title: "option 2", value: "option 2" }]
  } = $props();

  function ValueChange(e) {
    value = e.target.value;
    console.log(value);
  }


</script>


<div class="relative flex flex-col items-start w-full ">
  <label class="  text-sm  mb-2"
         for="{label}">
    {label}
  </label>
  <select
    class="focus:ring-white focus:border-teal-400 peer px-4 py-2 w-full border rounded-md bg-gray-50 border-gray-300 placeholder-transparent dark:bg-dark-bg"
    id='{label}'
    onchange={ValueChange}>
    {#each options as option}
      <option value={option.value}>{option.title}</option>
    {/each}
  </select>

</div>


