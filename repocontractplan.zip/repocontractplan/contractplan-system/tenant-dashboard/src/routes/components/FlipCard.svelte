<div class="card-body md:w-1/3 w-full ">
<div class="flip-card rounded-xl  lg:h-64    md:h-96 h-52">
  <div class="flip-card-inner ">
      <div class="flip-card-front">
        <slot name="front">
          <!-- <span class="missing">Unknown email</span> -->
        </slot>
    </div>
    <div class="flip-card-back">
        <slot name="back">
          <!-- <span class="missing">Unknown email</span> -->
        </slot>
    </div>
  </div>
</div>
</div>

<style>
  .card-body {
  font-family: Arial, Helvetica, sans-serif;

}

.flip-card {
  background-color: transparent;
  width: 100%;
  perspective: 1000px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}

.flip-card:hover .flip-card-inner {
  transform: rotateY(180deg);
}

.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;

  border: 1px solid rgb(215, 215, 215);
}

.flip-card-front {
  background-color: #ffffff;
  color: black;
  display: flex;
  justify-content: center;
  align-items: center;
}

.flip-card-back {
  transform: rotateY(180deg);
  display: flex;
  justify-content: center;
  padding: 30px;
}

</style>
