<script lang="ts">
  import {page} from '$app/stores';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GetCustomerByIdDoc, type CustomerExtended } from '$lib/generated/graphql';
  import { title } from '$lib/state/store';
  import { onMount } from 'svelte';
  import SubscriptionCard from './subscription.svelte';
  import Subscription from './subscription.svelte';
  
  const ID = $page.params.ID;
  let userData = {};
  let sub;
  let currentPlanStatus = '';

  onMount(async() => {
    $title = "Customer Details";

    let queryRepository = new GraphQLQueryRepository<CustomerExtended>();
    let tableDataSource = new DataSourceConnector<CustomerExtended>(
      queryRepository,
      GetCustomerByIdDoc,
    );
    
    await tableDataSource.loadCurrentPage({id: ID})
    .then((data) => {
      userData = data.data.getCustomer;
    })
    console.log('Table Data', userData);
    
  });

  function handlePlanStatusUpdate(event) {
    currentPlanStatus = event.detail.currentPlanStatus;
  }
</script>


<div class="m-5">

<div class="relative flex items-start  ">
  <label class="text-sm m-2 w-1/3" for="email">
    ID
  </label>
  <input bind:value={userData.ID}
    type="email"
    class="w-2/3bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    id="email"
    disabled
  />
</div>
<div class="relative flex items-start  ">
  <label class="text-sm m-2 w-1/3">
    First Name
  </label>
  <input bind:value={userData.FirstName}
    type="email"
    class="w-2/3bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    id="text"
    disabled
  />
</div>
<div class="relative flex items-start ">
  <label class="text-sm m-2 w-1/3">
    Last Name
  </label>
  <input bind:value={userData.LastName}
    type="text"
    class="w-2/3bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    id="email"
    disabled
  />
</div>
<div class="relative flex items-start">
  <label class="text-sm m-2 w-1/3">
    Email
  </label>
  <input bind:value={userData.Email}
    type="email"
    class="bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    id="email"
    disabled
  />
</div>
<div class="relative flex items-start  ">
  <label class="text-sm m-2 w-1/3">
    Phone
  </label>
  <input bind:value={userData.Phone}
    type="number"
    class="w-2/3bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    id="email"
    disabled
  />
</div>
<div class="mt-5">
  <SubscriptionCard bind:this={sub} on:planStatusUpdate={handlePlanStatusUpdate} />
</div>
<div class="mt-5 relative border rounded-lg border-gray-200 p-6">
  <p class=" text-xs text-gray-500 my-1">Payment</p>
  <div class=" border-b flex  items-center justify-between py-3">
    <p class=" font-medium">Card Nubmer</p>
    <p>{'XXXX XXXX XXXX ' + (userData.Card?.Last4 ? userData.Card?.Last4 : 'XXXX')}</p>
  </div>
  <div class=" border-b flex  items-center justify-between py-3">
    <p class=" font-medium">Next Payment</p>
    <p>$100.00</p>
  </div>
  <div class=" flex  items-center justify-between py-3">
    <p class=" font-medium">Payment Due</p>
    <p>12/12/2023</p>
  </div>
</div>
<div class="my-5 border w-fit p-2 rounded-xl bg-red-500">
  <button on:click={()=>{sub.cancelPlan();}} class=" text-white text-sm">Cancel Subscription</button>
</div>
</div>