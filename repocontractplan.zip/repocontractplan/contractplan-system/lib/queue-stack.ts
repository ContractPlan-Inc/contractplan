import * as cdk from "aws-cdk-lib";
import { Duration, PhysicalName } from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { IVpc } from "aws-cdk-lib/aws-ec2";
import * as sqs from "aws-cdk-lib/aws-sqs";
import { Queue } from "aws-cdk-lib/aws-sqs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";

// import * as sqs from 'aws-cdk-lib/aws-sqs';

export interface QueueStackProps extends cdk.StackProps {
    environment: string;
}


export class QueueStack extends cdk.Stack {
    public readonly machine: sfn.StateMachine;
    public readonly vpc: IVpc;
    public readonly email_queue: Queue;
    public readonly billing_queue: Queue;

    constructor(parent: Construct, id: string, props: QueueStackProps) {
        super(parent, id, props);
        this.vpc = ec2.Vpc.fromVpcAttributes(this, 'vpc', {
            vpcId: cdk.Fn.importValue('VPC-vpc-id'),
            availabilityZones: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-azs`)),
            publicSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-public-subnets`)),
            privateSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-private-subnets`)),
        })
        const kmsKey = cdk.aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));
        this.email_queue = new sqs.Queue(this, 'email-sqs-queue', {
            queueName: PhysicalName.GENERATE_IF_NEEDED,
            visibilityTimeout: Duration.seconds(1800),
        });
        this.billing_queue = new sqs.Queue(this, 'billing-queue', {
            queueName: PhysicalName.GENERATE_IF_NEEDED,
            visibilityTimeout: Duration.seconds(1800),
        });
        new cdk.CfnOutput(this, `Queue-emailoverdue-sqs-queue-url`, {
            description: "Email Overdue Queue URL",
            exportName: `Queue-email-sqs-queue-url`,
            value: this.email_queue.queueUrl,
        });
        new cdk.CfnOutput(this, `Queue-emailoverdue-sqs-queue-arn`, {
            description: "Email Overdue Queue Arn",
            exportName: `Queue-email-sqs-queue-arn`,
            value: this.email_queue.queueArn,

        });
        new cdk.CfnOutput(this, `Queue-billing-queue-url`, {
            description: "Billing Queue URL",
            exportName: `Queue-billing-queue-url`,
            value: this.billing_queue.queueUrl,
        });
        new cdk.CfnOutput(this, `Queue-billing-queue-arn`, {
            description: "Billing Queue Arn",
            exportName: `Queue-billing-queue-arn`,
            value: this.billing_queue.queueArn,
        });
    }

}
