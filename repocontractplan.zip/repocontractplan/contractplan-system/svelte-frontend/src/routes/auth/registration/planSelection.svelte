<script lang="ts">
  import {GraphQLQueryRepository} from '$lib/api/query-repository';
  import {
    GetPlansDoc,
    type GetPlansQuery,
    type Plan,
    type SignUpInput,
    type SubscribePlanMutation
  } from '$lib/generated/graphql';
  import { AuthenticationDetails, CognitoUser, CognitoUserPool } from 'amazon-cognito-identity-js';
  import { userPool } from '$lib/cognito/pool';
  import { auth, authState } from '$lib/state/auth';
  import {onMount} from 'svelte';
  import PlanEl from '$lib/components/elements/plan.svelte';
  import {type OperationResult} from '@urql/svelte';
  import Loader from '$lib/components/elements/loader.svelte';

  let plans: Plan[] = $state([]);

  let selectedPlan: string = $state('');
  let loading = $state(false);
  let loadingData = $state(false);


  interface RegFormProps {
    regForm: SignUpInput;
    status: string;
  }

  let {regForm = $bindable(), status = $bindable()}: RegFormProps = $props();


  async function fetchPlans() {
    try {
      const queryRepository = new GraphQLQueryRepository<GetPlansQuery>();
      const plansQuery = await queryRepository.getItems(GetPlansDoc, {}, 1, 10);

      plans = plansQuery?.data?.listPlans as Plan[];
      loadingData = false;

      console.log('PLANS:', plans);
    } catch (e) {
      console.log('ERROR:', e);
    }
  }

  async function login() {
    let authenticationDetails = new AuthenticationDetails({
      Username: regForm.email,
      Password: regForm.password
    });
    
    let userData = {
      Username: regForm.email,
      Pool: userPool
    };

    let cognitoUser = new CognitoUser(userData);
    
    return new Promise((resolve, reject) => {
      cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function(result) {
          auth.token = result.getAccessToken().getJwtToken();
          auth.refreshToken = result.getRefreshToken().getToken();
          auth.loggedIn = true;
          authState.set(auth);
          resolve(result);
        },
        onFailure: function(err) {
          console.error('Authentication failed:', err);
          reject(err);
        }
      });
    });
  }

  async function subscribePlan() {
    loading = true;
    try {
      await login();

      const queryRepository = new GraphQLQueryRepository<SubscribePlanMutation>();
      const res = await queryRepository.subscribePlan({
        PlanID: selectedPlan
      });

      if (res.data?.subscribePlan?.url) {
        window.location.href = res.data.subscribePlan.url;
      } else {
        console.error('No redirect URL received');
        loading = false;
      }
    } catch (e) {
      console.error('Error during plan subscription:', e);
      loading = false;
    }
  }

  onMount(async () => {
    loadingData = true;

    await fetchPlans();
  });

</script>

<div class="  space-y-6 p-9">
  <h1 class="mb-6 text-2xl font-bold">Select Plan</h1>
  <div class="mx-auto space-y-4 w-full">
    <Loader loading={loadingData} type="dataLoader"/>
    {#each plans as plan (plan.ID)}
      <PlanEl plan={plan} selected={selectedPlan == plan.ID} on:planSelected={() => {
          selectedPlan = plan.ID
      }}/>
    {/each}
  </div>

  <div class="w-full">
    <form onsubmit={(event)=>{event.preventDefault();subscribePlan()}}
    >
      <input hidden name="selectedPlan" type="text" value={selectedPlan}/>
      <button class="justify-center p-2.5 px-8 w-full text-white bg-black rounded-lg py-[11px]">Next
      </button>
    </form>
  </div>
</div>

<Loader {loading} type="pageLoader"/>



