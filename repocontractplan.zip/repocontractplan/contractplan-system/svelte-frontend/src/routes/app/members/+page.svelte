<script lang="ts">
  import { onMount } from 'svelte';
  import { goto, invalidate } from '$app/navigation';
  import Input from '$lib/components/elements/input.svelte';
  import Select from '$lib/components/elements/select.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Table from '$lib/components/table/table.svelte';
  import { editId, title } from '$lib/state/store';
  import editIcon from '$lib/assets/svg/edit.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { CreateMemberDoc, GetMembersDoc, type Member, type MemberInput, UpdateMemberDoc, DeleteMemberDoc } from '$lib/generated/graphql';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import * as yup from 'yup';
  import Confirmation from "../contract/delete/Confirmationl.svelte";

  title.set('Members');

  let showModal = $state(false);
  let memberToDelete: Member;
  let recordCount = 0;
  let errors = $state({});
  let successMessage = "";
  let errorMessage = "";

  let schema = yup.object().shape({
    FullName: yup.string().required('Full Name is required'),
    Email: yup
      .string()
      .email('Invalid email format')
      .required('Email is required')
    // Add other validations as needed
  });

  // table attributes
  let queryRepository = new GraphQLQueryRepository<Member>();
  let tableDataSource = new DataSourceConnector<Member>(
    queryRepository,
    GetMembersDoc
  );
  const columns = [
    { key: 'ID', title: 'ID', sortable: true },
    { key: 'FullName', title: 'Full Name', sortable: true },
    { key: 'Email', title: 'Email Address', sortable: true },
    { key: 'Status', title: 'Status', sortable: true }
  ];
  let isLabel = true;
  let label = 'Columns';
  let availableColumns = ['ID', 'FullName', 'Designation', 'Email', 'Status'];
  let searchableColumns = ['ID', 'FullName', 'Designation', 'Email', 'Status'];
  let actions = true;
  let actionList = [
    { name: 'Edit', icon: editIcon, function: editFunction },
    { name: 'Delete', icon: deleteIcon, function: deleteFunction }
  ];
  let bulckActions = [
    'Activate',
    'Deactivate',
    'Delete',
    'Export to CSV',
    'Export to PDF'
  ];

  let popupTitle = $state('Add New Member');
  let options = [
    { title: 'Manager', value: 'Manager' },
    { title: 'CEO', value: 'CEO' }
  ];
  let pop = $state(false);
  let member = $state({
    ID: '',
    FullName: '',
    Designation: '',
    Email: ''
  });



  editId.subscribe((value) => {
    console.log('val : ', value);
    if (value != 0) {
      popupTitle = 'Edit Member';
      edit(value);
      pop = true;
      // goto('/holidays/'+value);
    }
    // goto('editId');
  });

  function handleSubmit() {
  schema
    .validate(member, { abortEarly: false })
    .then(() => {
      // Validation passed, proceed with form submission
      let queryRepository = new GraphQLQueryRepository<MemberInput>();
      const { FullName, Email, Designation } = member;

      if (!member.ID) {
        queryRepository
          .updateItem(CreateMemberDoc, { input: { FullName, Email, Designation } })
          .then(() => {
            checked = false;
            pop = false;
          });
      } else {
        queryRepository
          .updateItem(UpdateMemberDoc, { id: member.ID, input: { FullName, Email, Designation } })
          .then(() => {
            checked = false;
            pop = false;
          });
      }
    })
    .catch((err) => {
      // Validation failed, handle errors
      console.error(err.errors);
    });
}
        function edit(id) {
    member = json.find((obj) => obj.id === id);
  }

  let checked = $state(false);

  function popup() {
    pop = !pop;
    editId.set(0);
    popupTitle = 'Add New Member ';
    member = {
      FullName: '',
      Designation: 'Manager',
      Email: ''
    };
  }

  function editFunction(memberData: Member) {
    popupTitle = 'Edit Member';
    pop = true;
    member.ID = memberData.ID;
    member.FullName = memberData.FullName;
    member.Email = memberData.Email;
    member.Designation = memberData.Designation;
  }


  function deleteFunction(node: Member) {
    memberToDelete = node;
    showModal = true;
  }
  async function handleConfirmDelete() {
    console.log("delete confirmation accepted")
    if (memberToDelete) {
      try {
        let queryRepository = new GraphQLQueryRepository();
        const response = await queryRepository.updateItem(DeleteMemberDoc, {
          id: memberToDelete.ID,
        });

        console.log("delete member response", response)
        if (response?.data?.deleteMember?.ID) {
          successMessage = "Member successfully deleted!";
          errorMessage = "";
          window.location.reload();
        } else {
          errorMessage = "Failed to delete member.";
          successMessage = "";
        }
      } catch (error) {
        errorMessage = "An error occurred during contract deletion.";
        successMessage = "";
        console.error("Error during contract deletion:", error);
      }
    }
    showModal = true;
  }
  function handleCancelDelete() {
    showModal = false;
  }

  onMount(async () => {
    if (tableDataSource) {
      const result = await tableDataSource.currentRows;
      recordCount = result.data ? result.data.length : 0;
    }
  });

  function validation() {
    errors = {};
    try {
      schema.validateSync(member, { abortEarly: false });
      console.log('Validation passed');
      handleSubmit();
    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      console.log(errors);
      console.log('Validation failed');
    }
}

</script>

<!--{JSON.stringify(holidays)}-->

{#if pop}
  <div
    class="w-full h-full !absolute top-0 left-0 z-30 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow"
    onclick={() => popup()}
    onkeydown={(event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        popup();
      }
    }}
    tabindex="0"
    role="button"
  ></div>

  <div
    class="absolute w-full h-full top-0 left-0 flex items-center justify-center shadow"
  >
    <div
      class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-lg shadow border border-black dark:bg-dark-bg dark:text-white"
    >
      <form onsubmit={validation} class="w-full px-5 my-5">
        <div class="w-full px-5 my-5 flex items-center justify-left">
          <h1 class="text-gray-800 text-[32px] font-bold font-poppins dark:text-primary-dark-text">
            {popupTitle}
          </h1>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Full Name</div>
          <Input
            type="text"
            {checked}
            bind:value={member.FullName}
          />
            <div class="text-red-500 text-xs mt-1">{errors.FullName}</div>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Email Address</div>
          <Input
            type="text"
            {checked}
            bind:value={member.Email}
          />
          <div class="text-red-500 text-xs mt-1">{errors.Email}</div>
        </div>
        <div class="pt-4 w-full px-5 my-5 flex items-center justify-left">
          <!-- Use onclick={handleSubmit} instead of onclick={()=>checked = true} -->
          <button
            type="submit"
            class="w-full border rounded p-3 text-white bg-[#343B4D]"
          >Add Member
          </button>
        </div>
      </form>
    </div>
  </div>
{/if}

<PageHeader Title="Member" />
<PageBody>
  <Table
    {actionList}
    {actions}
    {availableColumns}
    {bulckActions}
    {columns}
    {isLabel}
    {label}
    rootAccessPath="data.listMembers.edges"
    {searchableColumns}
    {tableDataSource}
  >
    {#snippet buttons()}
        <span >
        <AddNewButton
          btnText="New Member"
          on:message={popup}
          openAsPopup={true}
        />
      </span>
      {/snippet}
  </Table>
  <Confirmation
    visible={showModal}
    message="Are you sure you want to delete this contract?"
    on:confirm={handleConfirmDelete}
    on:cancel={handleCancelDelete}
  />
</PageBody>
