package models

import (
	"context"
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/beego/beego/v2/core/logs"
	"github.com/google/uuid"
	"github.com/kr/pretty"
	"github.com/uniplaces/carbon"
)

var OrderStatusMap = map[string]string{
	"DRAFT":                    "00",
	"READY":                    "01",
	"QUOTED":                   "02",
	"OPEN":                     "10",
	"BULK_ASSIGN":              "15",
	"AUTO_ASSIGN":              "16",
	"ASSIGNED":                 "17",
	"PICKED_UP":                "25",
	"PICKUP_WAREHOUSE":         "26",
	"RETURN":                   "35",
	"SECOND_ATTEMPT_RETURN":    "36",
	"SECOND_ATTEMPT":           "40",
	"SECOND_ATTEMPT_RETURNED":  "45",
	"SECOND_ATTEMPT_DELIVERED": "50",
	"SECOND_ATTEMPT_DROPBY":    "51",
	"DELIVERED":                "55",
	"DROPBY":                   "60",
	"RETURNED":                 "65",
	"DROPOFF_WAREHOUSE":        "70",
	"SHIPPER_UNAVAILABLE":      "90",
	"NOT_GIVEN":                "91",
	"CANCELLED":                "92",
	"REJECTED":                 "99",
}

func BuildGSI[F Model](ctx context.Context, record F, recordType string, reportType string, partialFiltering bool, skipIncomplete bool) (F, []string, error) {
	valKeyMap := map[string]string{}
	var validGSIs []string
	loadMap := GSIMap
	if reportType != "" {
		loadMap = ReportsGenMap[reportType]
	}
	DynamicSKFieldFound := map[string]bool{}
	if (ctx).Value("Tenant") != nil {
		pretty.Println("Tenant Found", (ctx).Value("Tenant"))
		reflectVal := reflect.ValueOf(record)
		if reflectVal.Kind().String() == "ptr" {
			reflectVal = reflectVal.Elem()
		}
		if reflectVal.FieldByName("Tenant").IsValid() {
			reflectVal.FieldByName("Tenant").SetString((ctx).Value("Tenant").(string))
		}
	}
	// refactor the following function to simplify it
	if values, ok := loadMap[recordType]; ok {
	valKeyBuilder:
		for valKey, valValues := range values {
			rrecordValKey := ""
			items := strings.Split(valKey, "ø")
			for i, val := range items {
				if i < 1 || strings.Contains(val, "$") {
					if rrecordValKey == "" {
						rrecordValKey = strings.ReplaceAll(val, "$", "")
					} else {
						rrecordValKey = fmt.Sprintf("%s.%s", rrecordValKey, strings.ReplaceAll(val, "$", ""))
					}
					continue
				}
				rVAL := ""
				recordSeek := strings.Split(strings.ReplaceAll(val, "-", ""), ".")
				reflectVal := reflect.ValueOf(record)
				reflectType := reflect.TypeOf(record)
				// //pretty.Println("PROCESSING RECORD : SEEKING", recordSeek)
				// //pretty.Println("PROCESSING RECORD : TYPED", recordType, reportType, record)
				if reflectVal.Kind().String() == "ptr" {
					reflectVal = reflectVal.Elem()
					reflectType = reflectType.Elem()
				}
				dateMode := ""
				timeZoneField := "UTC"
				for _, p := range recordSeek {
					splitDate := strings.Split(p, "/")
					p = splitDate[0]
					if len(splitDate) > 1 {
						dateMode = splitDate[1]
					}
					if len(splitDate) > 2 {
						timeZoneField = splitDate[2]
					}
					if _, ok := reflectType.FieldByName(p); ok {
						reflectValF := reflectVal.FieldByName(p)
						if reflectValF.Kind().String() == "ptr" {
							reflectValF = reflectValF.Elem()
						}
						if reflectValF.IsValid() {
							reflectType = reflect.Indirect(reflectValF).Type()
							reflectVal = reflectValF
						}
					}
				}
				fieldVal := reflectVal.Interface()
				switch fieldVal.(type) {
				case string:
					{
						if fieldVal.(string) != "" {
							rVAL = fieldVal.(string)
						}
					}
				case int, float64:
					{
						rVAL = fmt.Sprintf("%v", fieldVal)
					}
				case time.Time:
					{
						pretty.Println("TIMEZONE", timeZoneField)
						timezone, err := time.LoadLocation(timeZoneField)
						if err != nil {
							timezone, _ = time.LoadLocation("UTC")
						}
						if fieldVal.(time.Time).IsZero() {
							rVAL = ""
						} else {
							switch dateMode {
							case "DATETIME":
								rVAL = fieldVal.(time.Time).In(timezone).Format("2006-01-02T15:04:05")
							case "DATE":
								rVAL = fieldVal.(time.Time).In(timezone).Format("2006-01-02")
							case "MONTH":
								rVAL = fieldVal.(time.Time).In(timezone).Format("2006-01")
							case "YEAR":
								rVAL = fieldVal.(time.Time).In(timezone).Format("2006")
							default:
								rVAL = fieldVal.(time.Time).In(timezone).Format(time.RFC3339)
							}
						}
					}
				}
				if rVAL != "" {
					newVal := rVAL
					rrecordValKey = fmt.Sprintf("%v.%v", rrecordValKey, newVal)
					valKey = rrecordValKey
				}
			}

			// valKey=rrecordValKey
			for _, val := range valValues {
				recordVal := ""
				recordValKey := ""
				if val, ok := valKeyMap[valKey]; ok {
					recordValKey = val
				}
				if strings.Contains(val, "ø") {
					recordVal = val
				} else {
					recordSeek := strings.Split(strings.ReplaceAll(val, "-", ""), ".")
					reflectVal := reflect.ValueOf(record)
					baseValF := reflect.ValueOf(nil)
					reflectType := reflect.TypeOf(record)
					// //pretty.Println("PROCESSING RECORD : SEEKING", recordSeek)
					// //pretty.Println("PROCESSING RECORD : TYPED", recordType, reportType, record)
					if reflectVal.Kind().String() == "ptr" {
						reflectVal = reflectVal.Elem()
						reflectType = reflectType.Elem()
					}
					lastField := ""
					dateMode := ""
					timeZoneField := "UTC"
					for _, p := range recordSeek {
						splitDate := strings.Split(p, "/")
						p = splitDate[0]
						if len(splitDate) > 1 {
							dateMode = splitDate[1]
						}
						if len(splitDate) > 2 {
							timeZoneField = splitDate[2]
						}

						if _, ok := reflectType.FieldByName(p); ok {
							lastField = p
							reflectValF := reflectVal.FieldByName(p)
							if reflectValF.Kind().String() == "ptr" {
								reflectValF = reflectValF.Elem()
							}
							baseValFD := reflectVal.FieldByName(p + "Array")
							if baseValFD.IsValid() {
								baseValF = baseValFD
							}
							if reflectValF.IsValid() {
								reflectType = reflect.Indirect(reflectValF).Type()
								reflectVal = reflectValF
							} else {
								continue valKeyBuilder
							}
						}
					}
					if timeZoneField != "UTC" {
						timeVal := reflect.ValueOf(record)
						timeValType := reflect.TypeOf(record)
						if timeVal.Kind().String() == "ptr" {
							timeVal = timeVal.Elem()
							timeValType = timeValType.Elem()
						}

						timeZoneSeek := strings.Split(strings.ReplaceAll(timeZoneField, "-", ""), ",")
						// //pretty.Println("TIMEZONE SEEK", timeZoneSeek)
						for _, p := range timeZoneSeek {
							if _, ok := timeValType.FieldByName(p); ok {
								lastField = p
								timeValF := timeVal.FieldByName(p)
								if timeValF.Kind().String() == "ptr" {
									timeValF = timeValF.Elem()
								}
								if timeValF.IsValid() {
									timeValType = reflect.Indirect(timeValF).Type()
									timeVal = timeValF
								}
							}
						}
						fieldVal := timeVal.Interface()
						switch fieldVal.(type) {
						case string:
							timeZoneField = fieldVal.(string)
						}

					}
					fieldVal := reflectVal.Interface()
					// pretty.Println("recordVal", recordVal, "recordValKey", recordValKey, "fieldVal", fieldVal)
					switch fieldVal.(type) {
					case bool:
						{
							if fieldVal.(bool) {
								recordVal = "1"
							} else {
								recordVal = "0"
							}
						}
					case string:
						{
							if fieldVal.(string) != "" {
								recordVal = fieldVal.(string)
							}
							if ok, _ := StringInSlice(lastField, "OrderStatus", "Activity"); ok && recordVal != "" {
								recordVal = OrderStatusMap[recordVal]
							}
							if baseValF.IsValid() {
								var stringArray []string
								for i := 0; i < baseValF.Len(); i++ {
									if ok, _ := StringInSlice(lastField, "OrderStatus", "Activity"); ok && recordVal != "" {
										stringArray = append(stringArray, OrderStatusMap[baseValF.Index(i).Interface().(string)])
									}
								}
								// OrderStatusArray = []{"PICKED_UP","DELIVERED"}
								// StringArray = []{"PICKED_UP","DELIVERED"}
								if len(stringArray) > 0 {
									recordVal = strings.Join(stringArray, "<==^==>")
								}
								// recordVal result = "PICKED_UP<==^==>DELIVERED"
							}
						}
					case int, float64:
						{
							recordVal = fmt.Sprintf("%v", fieldVal)
						}
					case time.Time:
						{
							timezone, err := time.LoadLocation(timeZoneField)
							if err != nil {
								timezone, _ = time.LoadLocation("UTC")
							}
							if fieldVal.(time.Time).IsZero() {
								recordVal = ""
							} else {
								switch dateMode {
								case "DATETIME":
									recordVal = fieldVal.(time.Time).In(timezone).Format("2006-01-02T15:04:05")
								case "DATE":
									recordVal = fieldVal.(time.Time).In(timezone).Format("2006-01-02")
								case "MONTH":
									recordVal = fieldVal.(time.Time).In(timezone).Format("2006-01")
								case "WEEK":
									recordVal = carbon.NewCarbon(fieldVal.(time.Time).In(timezone)).StartOfWeek().Format("2006-01-02")
								case "YEAR":
									recordVal = fieldVal.(time.Time).In(timezone).Format("2006")
								default:
									recordVal = fieldVal.(time.Time).In(timezone).Format(time.RFC3339)
								}
							}

							if baseValF.IsValid() {
								var timeArray []string
								for i := 0; i < baseValF.Len(); i++ {
									timeOut := baseValF.Index(i).Interface().(time.Time)
									switch dateMode {
									case "DATETIME":
										timeArray = append(timeArray, timeOut.In(timezone).Format("2006-01-02T15:04:05"))
									case "DATE":
										timeArray = append(timeArray, timeOut.In(timezone).Format("2006-01-02"))
									case "MONTH":
										timeArray = append(timeArray, timeOut.In(timezone).Format("2006-01"))
									case "YEAR":
										timeArray = append(timeArray, timeOut.In(timezone).Format("2006"))
									default:
										timeArray = append(timeArray, timeOut.In(timezone).Format(time.RFC3339))
									}
								}
								if len(timeArray) > 0 {
									recordVal = strings.Join(timeArray, "<==^==>")
								}
							}
						}
					}
				}
				if recordVal != "" {
					newVal := recordVal
					resultString := recordValKey
					if recordValKey != "" && newVal != "" && !strings.Contains(newVal, "ø") {
						if newVal == val && skipIncomplete && valKey != "EntitySK" {
							valKeyMap[valKey] = ""
							continue valKeyBuilder
						}
						if newVal == val && partialFiltering {
							valKeyMap[valKey] = resultString
							continue valKeyBuilder
						}
						if strings.Contains(newVal, "<==^==>") || strings.Contains(recordValKey, "<==^==>") {
							split := strings.Split(newVal, "<==^==>")
							valkeySplit := strings.Split(recordValKey, "<==^==>")
							maxLen := len(split)
							if len(valkeySplit) > maxLen {
								maxLen = len(valkeySplit)
							}
							splitList := make([]string, maxLen)
							for i := range valkeySplit {
								for p, vv := range split {
									if i < p {
										splitList[p] = fmt.Sprintf("%v#%v", valkeySplit[i], vv)
									} else {
										splitList[i] = fmt.Sprintf("%v#%v", valkeySplit[i], vv)
									}
									logs.Debug("valkeySplit: %v", valkeySplit)
								}
							}
							resultString = strings.Join(splitList, "<==^==>")
						} else {
							resultString = fmt.Sprintf("%v#%v", recordValKey, newVal)
						}
						if strings.Contains(valKey, "SK") {
							gsi := strings.ReplaceAll(valKey, "EntitySK", "EntityFilter")
							if gsi != "SK" {
								gsi = strings.ReplaceAll(gsi, "SK", "")
							}
							DynamicSKFieldFound[gsi] = true
						}
					} else if recordValKey == "" && newVal != "" && !strings.Contains(newVal, "ø") {
						if newVal == val && skipIncomplete && valKey != "EntitySK" {
							valKeyMap[valKey] = ""
							continue valKeyBuilder
						}
						if newVal == val && partialFiltering {
							valKeyMap[valKey] = resultString
							continue valKeyBuilder
						} else {
							if resultString != "" {
								resultString = fmt.Sprintf("%v#%v", resultString, newVal)
							} else {
								resultString = fmt.Sprintf("%v", newVal)
							}
						}
					} else {
						if newVal == val && skipIncomplete && !strings.Contains(newVal, "ø") {
							valKeyMap[valKey] = ""
							continue valKeyBuilder
						}
						if newVal == val && partialFiltering && !strings.Contains(newVal, "ø") {
							valKeyMap[valKey] = resultString
							continue valKeyBuilder
						} else if resultString != "" {
							resultString = fmt.Sprintf("%v#%v", resultString, strings.ReplaceAll(val, "ø", ""))
						} else {
							if resultString == "" {
								resultString = fmt.Sprintf("%v%v", resultString, strings.ReplaceAll(val, "ø", ""))
							} else {
								resultString = fmt.Sprintf("%v#%v", resultString, strings.ReplaceAll(val, "ø", ""))
							}
						}
					}
					valKeyMap[valKey] = resultString
				} else if skipIncomplete && valKey != "EntitySK" {
					valKeyMap[valKey] = ""
					continue valKeyBuilder
				}
			}
			if (strings.Contains(valKey, "PK")) || valKey == "EntityType" {
				valKey = strings.ReplaceAll(valKey, "EntityType", "EntityFilter")
				if valKey != "PK" {
					validGSIs = append(validGSIs, strings.ReplaceAll(valKey, "PK", ""))
				} else {
					validGSIs = append(validGSIs, valKey)
				}
			}
		}
	}
	if !partialFiltering {
		copyGSI := validGSIs
		validGSIs = []string{}
		for _, gsi := range copyGSI {
			if val, ok := DynamicSKFieldFound[gsi]; ok && val {
				validGSIs = append(validGSIs, gsi)
			}
		}
	}
	for fieldPath, value := range valKeyMap {
		reflectField := reflect.ValueOf(record)
		fieldSplit := strings.Split(fieldPath, ".")
		for _, field := range fieldSplit {
			if reflectField.Kind() == reflect.Ptr {
				if reflectField.IsNil() {
					t := reflectField.Type().Elem()
					reflectField.Set(reflect.New(t))
				}
				if reflectField.Kind() == reflect.Ptr {
					reflectField = reflectField.Elem()
				}
			}
			if reflectField.Kind() == reflect.Struct {
				reflectField = reflectField.FieldByName(field)
			}
		}
		if reflectField.IsValid() {
			switch reflectField.Kind() {
			case reflect.String:
				reflectField.SetString(value)
			case reflect.Int:
				intVal, _ := strconv.ParseInt(value, 10, 64)
				reflectField.SetInt(intVal)
			case reflect.Bool:
				boolVal, _ := strconv.ParseBool(value)
				reflectField.SetBool(boolVal)
			case reflect.Float64:
				floatVal, _ := strconv.ParseFloat(value, 64)
				reflectField.SetFloat(floatVal)
			case reflect.Slice:
				if reflectField.Type().Elem().Kind().String() == "string" {
					reflectField.Set(reflect.ValueOf(strings.Split(value, "#")))
				}
			}
		}
	}
	// compiute if there is ID index search
	reflectVal := reflect.ValueOf(record)
	reflectType := reflect.TypeOf(record)
	if reflectVal.Kind().String() == "ptr" {
		reflectVal = reflectVal.Elem()
		reflectType = reflectType.Elem()
	}
	if reflectVal.FieldByName("Id").IsValid() {
		fieldVal := reflectVal.FieldByName("Id").Interface()
		switch fieldVal.(type) {
		case string:
			{
				if fieldVal.(string) != "" && len(fieldVal.(string)) == 36 {
					if _, err := uuid.Parse(fieldVal.(string)); err == nil {
						validGSIs = append(validGSIs, "IDFilter")
					}
				}
			}
		}
	}
	return record, validGSIs, nil
}
