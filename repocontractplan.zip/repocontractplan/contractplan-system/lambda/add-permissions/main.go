package main

import (
	"context"
	
	"github.com/aws/aws-lambda-go/lambda"
	
	"bitbucket.org/onroutedrivers/backend/models"
	"bitbucket.org/onroutedrivers/backend/utils"
)

type PermRole struct {
	Roles      []string
	Permission models.Permission
}

func handler(ctx context.Context, request map[string]string) error {
	ctx = utils.TenantWithContext(ctx, request["tenant"])
	var err error
	permRoles := []PermRole{}
	for _, permRole := range permRoles {
		models.AddPermission(ctx, &permRole.Permission)
		for _, role := range permRole.Roles {
			var fetchedRole []*models.Roles
			err, fetchedRole, _ = models.SearchQuery(ctx, models.Roles{}, "roles", map[string]interface{}{"Name__exact": role}, nil, 1, 0, nil)
			_, err = models.AddPermissionRole(ctx, &models.PermissionRole{RoleId: fetchedRole[0].Id, PermissionId: permRole.Permission.Id})
		}
	}
	
	return err
}

func main() {
	lambda.Start(handler)
}
