package auth

import (
	"context"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"os"
	"strings"
	"time"

	"cloudparallax.com/backend/models"
	"cloudparallax.com/backend/services/cache"
	"cloudparallax.com/backend/utils"
	"github.com/beego/beego/v2/core/logs"
	"github.com/golang-jwt/jwt/v5"
	"github.com/kr/pretty"
)

var redisClient = cache.UniversalRedis()

type JWTClaim struct {
	Groups []string `json:"cognito:groups"`
	jwt.RegisteredClaims
}

func remove(s []string, i int) []string {
	s[i] = s[len(s)-1]
	return s[:len(s)-1]
}

func ValidateToken(token string) (*models.User, error) {

	// Example JWT token
	userPoolID := os.Getenv("USERPOOL_ID")

	// Validate JWT token
	jwtToken, err := validateJWT(token, userPoolID)
	if err != nil {
		fmt.Println("JWT validation failed:", err)
		return nil, err
	}

	// Handle the validated token
	fmt.Println("JWT validation successful")
	fmt.Println("Token claims:", jwtToken.Claims.(*JWTClaim).Groups)
	tenants := jwtToken.Claims.(*JWTClaim).Groups
	for i, tenant := range tenants {
		if !strings.HasPrefix(tenant, "01") {
			tenants = remove(tenants, i)
		}
	}
	if len(tenants) == 0 {
		return nil, errors.New("no tenants found")
	}
	if len(tenants) > 1 {
		return nil, errors.New("multiple tenants found")
	}
	sub, err := jwtToken.Claims.GetSubject()
	user, _, _ := models.GetModelsFromDDB(context.Background(), models.User{CognitoID: sub}, "USERS", 1, nil, "beginswith", false, "GSI1")
	pretty.Println("USER:", user, tenants)
	if err != nil {
		return nil, err
	}
	if len(user) == 0 {
		return nil, errors.New("user not found")
	}
	if ok, _ := utils.StringInSlice(user[0].Tenant, tenants...); !ok {
		return nil, errors.New("tenant not found")
	}
	return user[0], nil
}

var keyMap = make(map[string]rsa.PublicKey)

// Get JWT signing key from Redis cache
func getSigningKeyFromCache(keyID string) (interface{}, error) {
	logs.Info("Getting Key from Cache", keyID)
	if key, ok := keyMap[keyID]; ok {
		logs.Debug("Key from cache", &key)
		return &key, nil
	}
	return nil, errors.New("key not found")
}

// Cache JWT signing key in Redis
func cacheSigningKey(keyID string, key []byte, expiration time.Duration) error {
	err := redisClient.Set(context.Background(), keyID, key, expiration).Err()
	if err != nil {
		// Handle Redis connection error
		return err
	}
	return nil
}

// Retrieve signing key from Cognito JWKS file
func retrieveSigningKeyFromCognito(keyID string, userPoolID string) (interface{}, error) {
	// Fetch the JWKS file from Cognito
	logs.Info("Fetching JWKS file from Cognito", "userPoolID", userPoolID)
	logs.Info("Fetching JWKS file from Cognito", "AWS_REGION", os.Getenv("AWS_REGION"))
	url := fmt.Sprintf("https://cognito-idp.%s.amazonaws.com/%s/.well-known/jwks.json", os.Getenv("AWS_REGION"), userPoolID)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// Read the response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	// Parse the JWKS file
	var jwks struct {
		Keys []struct {
			Kid string `json:"kid"`
			Alg string `json:"alg"`
			Kty string `json:"kty"`
			E   string `json:"e"`
			N   string `json:"n"`
			Use string `json:"use"`
		} `json:"keys"`
	}
	err = json.Unmarshal(body, &jwks)
	if err != nil {
		return nil, err
	}

	// Find the signing key based on the Key ID (kid)
	for _, key := range jwks.Keys {
		if key.Kid == keyID && key.Alg == "RS256" && key.Kty == "RSA" && key.Use == "sig" {
			// Decode the Base64urlUInt-encoded exponent and modulus values
			exponent, err := base64.RawURLEncoding.DecodeString(key.E)
			if err != nil {
				return nil, err
			}
			modulus, err := base64.RawURLEncoding.DecodeString(key.N)
			if err != nil {
				return nil, err
			}

			// Create the RSA public key using the exponent and modulus
			rsaPublicKey := &rsa.PublicKey{
				N: big.NewInt(0).SetBytes(modulus),
				E: int(big.NewInt(0).SetBytes(exponent).Uint64()),
			}

			// Convert the RSA public key to jwt.KeyFunc type
			return rsaPublicKey, nil
		}
	}

	return nil, errors.New("signing key not found")
}

// Validate JWT token
func validateJWT(tokenString string, userPoolID string) (*jwt.Token, error) {
	token, err := jwt.ParseWithClaims(tokenString, &JWTClaim{}, func(token *jwt.Token) (interface{}, error) {
		logs.Info("TOKEN:", token)
		keyID := token.Header["kid"].(string)
		logs.Info("Signing key from Cognito", "keyID", keyID)
		// Check if the signing key exists in Redis cache
		signingKey, err := getSigningKeyFromCache(keyID)
		if err == nil {
			// Return the signing key from cache
			return signingKey, nil
		}

		// Retrieve the signing key from Cognito
		signingKey, err = retrieveSigningKeyFromCognito(keyID, userPoolID)
		logs.Info("Signing key retrieved from Cognito", "keyID", keyID, signingKey)
		if err != nil {
			return nil, err
		}

		// Cache the signing key in Redis for future use
		keyMap[keyID] = *signingKey.(*rsa.PublicKey)
		return signingKey, nil
	}, jwt.WithIssuer(fmt.Sprintf("https://cognito-idp.%s.amazonaws.com/%s", os.Getenv("AWS_REGION"), userPoolID)))

	if err != nil {
		return nil, err
	}

	return token, nil
}
