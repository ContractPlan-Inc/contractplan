package models

import (
	"context"
	"reflect"
	"testing"

	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/expression"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

func TestBlankModel_GetID(t1 *testing.T) {
	type fields struct {
		Id string
	}
	tests := []struct {
		name   string
		fields fields
		want   string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t1.Run(tt.name, func(t1 *testing.T) {
			t := BlankModel{
				Id: tt.fields.Id,
			}
			if got := t.GetID(); got != tt.want {
				t1.Errorf("GetID() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBlankModel_GetTenant(t1 *testing.T) {
	type fields struct {
		Id string
	}
	tests := []struct {
		name   string
		fields fields
		want   string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t1.Run(tt.name, func(t1 *testing.T) {
			t := BlankModel{
				Id: tt.fields.Id,
			}
			if got := t.GetTenant(); got != tt.want {
				t1.Errorf("GetTenant() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestReadBatchFromDDB(t *testing.T) {
	type args[F Model] struct {
		ctx         context.Context
		retrivalMap []map[string]types.AttributeValue
		recordType  string
		slice       map[string]*F
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		want    map[string]*F
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ReadBatchFromDDB(tt.args.ctx, tt.args.retrivalMap, tt.args.recordType, tt.args.slice)
			if (err != nil) != tt.wantErr {
				t.Errorf("ReadBatchFromDDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ReadBatchFromDDB() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRetrieveItemCounts(t *testing.T) {
	type args[F Model] struct {
		ctx              context.Context
		record           F
		recordType       string
		limit            int32
		count            bool
		partialFiltering bool
		skipIncomplete   bool
		lastEvaluatedKey *DynamoLastEvaluatedKey
		gsiOverride      []string
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		want    map[string]int
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := RetrieveItemCounts(tt.args.ctx, tt.args.record, tt.args.recordType, tt.args.limit, tt.args.count, tt.args.partialFiltering, tt.args.skipIncomplete, tt.args.lastEvaluatedKey, tt.args.gsiOverride...)
			if (err != nil) != tt.wantErr {
				t.Errorf("RetrieveItemCounts() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("RetrieveItemCounts() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRetrieveItemsUsingGSI(t *testing.T) {
	type args[F Model] struct {
		ctx              context.Context
		record           F
		recordType       string
		limit            int32
		count            bool
		partialFiltering bool
		skipIncomplete   bool
		lastEvaluatedKey *DynamoLastEvaluatedKey
		searchType       string
		gsiOverride      []string
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		want    []*F
		want1   *DynamoLastEvaluatedKey
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, err := RetrieveItemsUsingGSI(tt.args.ctx, tt.args.record, tt.args.recordType, tt.args.limit, tt.args.count, tt.args.partialFiltering, tt.args.skipIncomplete, true, tt.args.lastEvaluatedKey, tt.args.searchType, tt.args.gsiOverride...)
			if (err != nil) != tt.wantErr {
				t.Errorf("RetrieveItemsUsingGSI() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("RetrieveItemsUsingGSI() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("RetrieveItemsUsingGSI() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestRetrieveMultipleItems(t *testing.T) {
	type args[F ModelConstraint] struct {
		ctx        context.Context
		recordType string
		items      []F
	}
	type testCase[F ModelConstraint] struct {
		name    string
		args    args[F]
		want    []*F
		wantErr bool
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := RetrieveMultipleItems(tt.args.ctx, tt.args.recordType, tt.args.items)
			if (err != nil) != tt.wantErr {
				t.Errorf("RetrieveMultipleItems() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("RetrieveMultipleItems() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_asSha256(t *testing.T) {
	type args struct {
		o interface{}
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := asSha256(tt.args.o); got != tt.want {
				t.Errorf("asSha256() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_destructureInterface(t *testing.T) {
	type args struct {
		record interface{}
	}
	tests := []struct {
		name string
		args args
		want map[string]interface{}
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := destructureInterface(tt.args.record); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("destructureInterface() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_expressionBuilder(t *testing.T) {
	type args struct {
		conditionBuilder expression.ConditionBuilder
		parent           string
		destructuredMap  map[string]interface{}
	}
	tests := []struct {
		name string
		args args
		want expression.ConditionBuilder
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := expressionBuilder(tt.args.conditionBuilder, tt.args.parent, tt.args.destructuredMap); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("expressionBuilder() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_readBatchFromDynamoDB(t *testing.T) {
	type args struct {
		ctx       context.Context
		batchKeys []map[string]types.AttributeValue
	}
	tests := []struct {
		name    string
		args    args
		want    *dynamodb.BatchGetItemOutput
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readBatchFromDynamoDB(tt.args.ctx, tt.args.batchKeys)
			if (err != nil) != tt.wantErr {
				t.Errorf("readBatchFromDynamoDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("readBatchFromDynamoDB() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_retrieveDBValues(t *testing.T) {
	type args struct {
		startKey    map[string]types.AttributeValue
		exprBuilder expression.Expression
		limit       int32
		count       bool
	}
	tests := []struct {
		name string
		args args
		want *dynamodb.QueryInput
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := retrieveDBValues(tt.args.startKey, tt.args.exprBuilder, tt.args.limit, tt.args.count, true); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("retrieveDBValues() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_reverseString(t *testing.T) {
	type args struct {
		input string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := reverseString(tt.args.input); got != tt.want {
				t.Errorf("reverseString() = %v, want %v", got, tt.want)
			}
		})
	}
}
