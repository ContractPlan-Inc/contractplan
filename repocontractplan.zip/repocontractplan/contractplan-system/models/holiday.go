package models

import "time"

type Holiday struct {
	DynamoDBModel
	ID        string    `json:"ID"`
	Date      time.Time `json:"Date"`
	Name      string    `json:"Name"`
	Category  string    `json:"Category"`
	CreatedAt time.Time `json:"CreatedAt"`
}

func (Holiday) IsNode()            {}
func (this Holiday) GetID() string { return this.ID }

type HolidayConnection struct {
	Edges            []*ContractEdge         `json:"edges,omitempty"`
	Pagination       *Pagination             `json:"pagination,omitempty"`
	LastEvaluatedKey *DynamoLastEvaluatedKey `json:"lastEvaluatedKey,omitempty"`
}

func (HolidayConnection) IsConnection() {}
func (this HolidayConnection) GetEdges() []Edge {
	if this.Edges == nil {
		return nil
	}
	interfaceSlice := make([]Edge, 0, len(this.Edges))
	for _, concrete := range this.Edges {
		interfaceSlice = append(interfaceSlice, concrete)
	}
	return interfaceSlice
}
func (this HolidayConnection) GetPagination() *Pagination { return this.Pagination }
func (this HolidayConnection) GetLastEvaluatedKey() *DynamoLastEvaluatedKey {
	return this.LastEvaluatedKey
}

type HolidayEdge struct {
	Cursor string `json:"Cursor"`
	Node   Node   `json:"node"`
}

func (HolidayEdge) IsEdge()            {}
func (this HolidayEdge) GetNode() Node { return this.Node }

type HolidayInput struct {
	Date     time.Time `json:"Date"`
	Name     string    `json:"Name"`
	Category string    `json:"Category"`
}
