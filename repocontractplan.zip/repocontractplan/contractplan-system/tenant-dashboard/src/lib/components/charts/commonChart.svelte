<script lang="ts">
  import Chart from 'chart.js/auto';
  import { onMount } from 'svelte';

  let chart;
  let { ID, plannedData, actualData, labels, plannedColor, actualColor, chartType} = $props();
  let max = 0;
  let min = 1000;

  // console.log("CommonChartinside:", ID )
  console.log("CommonChartinside:",plannedData )
  // console.log("CommonChartinside:",actualData)
  // console.log("CommonChartinside:", labels, plannedColor, actualColor, chartType )


  onMount(() => {
  
    const chartData = {
      labels: labels,
      datasets: [{

        label: 'Planned',
        data: plannedData.map(o => {
          if (o > max) {
            max = o;
          }
          if (o < min) {
            min = o;
          }
          return o
        }),
        backgroundColor: plannedColor,
        borderColor: plannedColor,
        borderWidth: 2,
        barThickness: 20,
        pointRadius: 3,
        tension: 0.5
      },
        {
          label: 'Actual',
          data: actualData.map(o => {
          if (o > max) {
            max = o;
          }
          if (o < min) {
            min = o;
          }
          return o
        }),
          backgroundColor: actualColor,
          borderColor: actualColor,
          borderWidth: 1,
          barThickness: 20,
          pointRadius: 3,
          tension: 0.5
        }]
    };

    const ctx = document.getElementById(ID).getContext('2d');

    chart = new Chart(ctx, {
      type: chartType,
      data: chartData,
      options: {
        plugins: {
          legend: {
            display: false
          }
        },
        layout: {},
        responsive: true,
        aspectRatio: 5 / 1,
        scales: {
          y: {
            max: max + 1000,
            min: 0,
            beginAtZero: true,
            grace: '50%',
            type: 'linear',
            ticks: {
              //   fill -> avg & target
            }
          },
          x: {}
        }
      }
    });
  });

</script>
<div class=" w-[90%]  m-auto relative    ">
  <canvas class=" w-full" id={ID}></canvas>
</div>
