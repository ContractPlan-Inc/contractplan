<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  const dispatch = createEventDispatcher();

  function handleClose() {
    dispatch('close');
  }

  function handleSubmit() {
    dispatch('submit');
  }

  interface PopupProps {
    popupTitle: String,
    buttonText: String,
  }

  let { children, popupTitle, buttonText, submitHandler } = $props();


</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div class=" w-full   h-full !fixed top-0 left-0 z-40 bg-white/50     backdrop-blur-sm" role="button" onclick={handleClose}></div>
<div class=" absolute w-full h-full top-0 left-0 flex items-center justify-center">

  <div class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-2xl shadow-xl border border-gray-300 dark:bg-dark-bg">
    <form class="w-full my-"  onsubmit={(event) => { event.preventDefault(); submitHandler(); }}>
      <div class=" p-5">
        <div class="w-full mb-3 flex    ">
          <h1 class=" text-[32px]  font-bold dark:text-primary-dark-text">{popupTitle}</h1>
        </div>

        <div class="  space-y-4">
          {@render children?.()}
          <div class="w-full my-5 flex items-center justify-center ">
            <button class=" w-full border rounded p-3 text-white bg-[#343B4D]"
                    type="submit">{buttonText}
            </button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
