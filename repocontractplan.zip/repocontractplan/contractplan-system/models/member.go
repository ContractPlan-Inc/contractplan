package models

import "context"

type Member struct {
	DynamoDBModel
	ID          string `json:"ID"`
	FullName    string `json:"FullName"`
	Email       string `json:"Email"`
	Designation string `json:"Designation"`
	Archive     bool   `json:"Archive"`
}

func (Member) IsNode()            {}
func (this Member) GetID() string { return this.ID }

type MemberConnection struct {
	Edges            []*MemberEdge           `json:"edges,omitempty"`
	Pagination       *Pagination             `json:"pagination,omitempty"`
	LastEvaluatedKey *DynamoLastEvaluatedKey `json:"lastEvaluatedKey,omitempty"`
}

func (MemberConnection) IsConnection() {}
func (this MemberConnection) GetEdges() []Edge {
	if this.Edges == nil {
		return nil
	}
	interfaceSlice := make([]Edge, 0, len(this.Edges))
	for _, concrete := range this.Edges {
		interfaceSlice = append(interfaceSlice, concrete)
	}
	return interfaceSlice
}
func (this MemberConnection) GetPagination() *Pagination { return this.Pagination }
func (this MemberConnection) GetLastEvaluatedKey() *DynamoLastEvaluatedKey {
	return this.LastEvaluatedKey
}

type MemberEdge struct {
	Cursor *string `json:"cursor,omitempty"`
	Node   Node    `json:"node,omitempty"`
}

func (MemberEdge) IsEdge()            {}
func (this MemberEdge) GetNode() Node { return this.Node }

func GetMemberById(ctx context.Context, id string) (*Member, error) {
	var member Member
	member.ID = id
	return GetModelByIDFromDDB(ctx, member, "MEMBER", "PK")
}

type MemberInput struct {
	FullName    string `json:"FullName"`
	Email       string `json:"Email"`
	Designation string `json:"Designation"`
}
