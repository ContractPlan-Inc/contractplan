import { goto } from "$app/navigation";
import { auth, authState } from "$lib/state/auth";

export const prerender = false;
export const trailingSlash = "always";

auth.viewLoaded = true;
authState.set(auth);

function logout() {
  auth.token = "";
  auth.loggedIn = false;
  auth.user = undefined;
  authState.set(auth);
  goto("/auth/signin");
}

export function load() {
  // if(auth.loggedIn === false && auth.token === ""){
  //   goto("/auth/signin");
  // }else{
  // }
}

//
