<script>
  import { createEventDispatcher } from "svelte";

  
  /**
   * @typedef {Object} Props
   * @property {any} btnText
   * @property {boolean} [openAsPopup]
   * @property {string} [path]
   * @property {any} [onclick]
   */

  /** @type {Props} */
  let {
    btnText,
    openAsPopup = false,
    path = "",
    onclick = () => {}
  } = $props();
  const dispatch = createEventDispatcher();

  function triggerClick() {
    dispatch("message");
    onclick();
  }


</script>

{#if openAsPopup}
  <button
    class="px-3 py-2 bg-white border flex flex-row gap-1 text-sm shadow-md  items-center justify-center rounded-md text-gray-900"
    onclick={(triggerClick)}>
    <span><svg class="  fill-gray-900 " width="17px" height="17px" viewBox="0 0 20 20"
               xmlns="http://www.w3.org/2000/svg" fill="none"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g
      id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path
      fill-rule="evenodd"
      d="M10 3a7 7 0 100 14 7 7 0 000-14zm-9 7a9 9 0 1118 0 9 9 0 01-18 0zm14 .069a1 1 0 01-1 1h-2.931V14a1 1 0 11-2 0v-2.931H6a1 1 0 110-2h3.069V6a1 1 0 112 0v3.069H14a1 1 0 011 1z"></path> </g></svg></span>
    {btnText}
  </button>
{:else}
  <a href={path}
     class="px-3 py-2 bg-white border flex flex-row gap-1 text-sm shadow-md items-center justify-center  rounded-md text-gray-900">
    <span><svg class="  fill-gray-900 " width="17px" height="17px" viewBox="0 0 20 20"
               xmlns="http://www.w3.org/2000/svg" fill="none"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g
      id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path
      fill-rule="evenodd"
      d="M10 3a7 7 0 100 14 7 7 0 000-14zm-9 7a9 9 0 1118 0 9 9 0 01-18 0zm14 .069a1 1 0 01-1 1h-2.931V14a1 1 0 11-2 0v-2.931H6a1 1 0 110-2h3.069V6a1 1 0 112 0v3.069H14a1 1 0 011 1z"></path> </g></svg></span>
    {btnText}
  </a>
{/if}


