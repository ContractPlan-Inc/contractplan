package models

type Tenant struct {
	DynamoDBModel
	ID        string      `json:"id"`
	Name      string      `json:"name"`
	Category  string      `json:"category"`
	Telephone string      `json:"telephone"`
	Address   string      `json:"address"`
	Contacts  []*Contacts `json:"contacts,omitempty"`
}

func (Tenant) IsNode() {}
func (m Tenant) GetPK() string {
	return m.PK
}
func (m Tenant) GetSK() string {
	return m.SK
}
func (m Tenant) GetID() string {
	return m.ID
}
