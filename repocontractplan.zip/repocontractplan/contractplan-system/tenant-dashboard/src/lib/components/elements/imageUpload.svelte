<script>
  let input;
  let container;
  let image;
  let placeholder;
  let showImage = false;
  export let value = "";

  function onChange() {
    const file = input.files[0];

    if (file) {
      showImage = true;

      const reader = new FileReader();
      reader.addEventListener("load", function() {
        image.setAttribute("src", reader.result);
      });
      reader.readAsDataURL(file);

      return;
    }
    showImage = false;
  }
</script>
<div class="w-full space-y-2">
  <input bind:this={input}
         class="w-full px-3 py-2 border border-black focus:file:bg-teal-500 hover:file:bg-teal-500 rounded-md file:py-2 file:px-4 file:rounded-full file:border-0"
         onchange={onChange} onclick={()=>value=''}
         type="file" />
  {#if value === ''}
    {#if showImage}
      <div class="flex items-center justify-center  mt-4 border-2 border-black w-full">
        <img class="w-full" bind:this={image} src="" alt="Preview" />
      </div>
    {/if}
  {:else}
    <div class="flex items-center justify-center  mt-4 border-2 border-black w-full">
      <img class="w-full" src="{value}" alt="Preview" />
    </div>
  {/if}

</div>

<!-- <div >
  <input class="peer px-4 py-2 w-96 border border-slate-600 placeholder-transparent"
    type={type}
    value={value}
    id={label}
  />
  <label class="ml-4 -mt-11 text-xs text-blue-600 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:-mt-8 peer-placeholder-shown:text-base duration-300"
   for={label}>
    {label}
  </label>
</div>
  -->
<!-- {#if value !== ''}
<img src="{value}" alt="" class=" w-full rounded-md">
{:else}
<label class="flex flex-col w-full h-32 border-4 hover:border-blue-200 border-dashed hover:bg-gray-100 border-gray-300">
    <div class="flex flex-col items-center justify-center pt-7">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-gray-400 group-hover:text-gray-600"
            fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <p class="pt-1 text-sm tracking-wider text-gray-400 group-hover:text-gray-600">
            Attach a file</p>
    </div>
    <input type="file" class="opacity-0" />
</label>
{/if}

   <button
   type="button"
    class="bg-[#FBC02D] h-[36px] w-[121px] rounded-[4px] tracking-[0.02px] text-[#00000099] text-center">Delete
    Image</button> -->


