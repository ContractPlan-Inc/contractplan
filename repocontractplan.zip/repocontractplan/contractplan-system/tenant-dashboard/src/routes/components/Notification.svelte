<script>
  import { notifications, removeNotification } from "./store.js";
  import { onDestroy } from "svelte";

  // Subscribe to the notifications store
  let notifs = [];
  const unsubscribe = notifications.subscribe(value => {
    notifs = value;
  });

  // Function to remove a notification
  const closeNotification = (notification) => {
    removeNotification(notification);
  };

  // Clean up the subscription when the component is destroyed
  onDestroy(() => unsubscribe());
</script>

{#each notifs as { message, type } (message)}
  <div class={`notification ${type}`}>
    <p>{message}</p>
    <button onclick={() => closeNotification({ message, type })}>Close</button>
  </div>
{/each}
