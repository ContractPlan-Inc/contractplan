<script lang="ts">
  export let key: string;
  export let value: number;
  export let color: string;
  export let pretext: string = "";
</script>

<div class=" w-full  bg-gray-100 rounded-lg py-1  px-4 my-6">
  <div class="relative ">
    <div class="py-1 px-4 ">
      <div class="flex  items-center">
        <span class="w-2 h-2 absolute left-0 rounded bg-{color}"></span>
        <p class=" text-sm text-gray-400">{key}</p>
      </div>
      <p class=" text-md font-bold">{pretext}{value}</p>
    </div>
  </div>
</div>
