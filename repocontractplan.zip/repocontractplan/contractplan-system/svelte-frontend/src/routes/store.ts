import { writable } from "svelte/store";

export let userdata = writable({
  ID: "",
  VisibleName: "",
  Email: "",
  Image: "",
});
