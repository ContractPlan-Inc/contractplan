<script lang="ts">
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import {
    CancelPlanDoc,
    type CancelPlanMutation,
    GetCurrentCustomer,
    GetCurrentCustomerDoc,
    GetCurrentUserDoc
  } from '$lib/generated/graphql';
  import Subscription from './subscription.svelte';
  import SubscriptionCard from './subscription.svelte';
  import { type CustomerExtended } from '$lib/generated/graphql';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { onMount } from 'svelte';
  import { userdata } from '../../store';


  interface Props {
    // let data: any = [{ planPrice:100, currentPlan:true },{ planPrice:200 },{ planPrice:300 }];
    data: any;
  }

  let { data }: Props = $props();
  let sub = $state();
  let currentPlanStatus = '';
  let userData;
  userdata.subscribe((value) => {
    userData = value;
  });
  let currentCustomer = $state();

  onMount(async() => {
    let queryRepository = new GraphQLQueryRepository<CustomerExtended>();
    await queryRepository.getItems(
            GetCurrentCustomerDoc,
            {},
            1,
            1
    ).then((data)=>{
      console.log("X data", data);
      currentCustomer = data.data.getCurrentCustomer;
    })

  });

  function handlePlanStatusUpdate(event) {
    currentPlanStatus = event.detail.currentPlanStatus;
  }

  console.log('Plans:', data);


</script>

<div class=" space-y-6 p-6 dark:bg-dark-bg dark:text-white">
  <div class="">
    <SubscriptionCard bind:this={sub} on:planStatusUpdate={handlePlanStatusUpdate} />
  </div>

  <div class="mt-5 relative border rounded-lg border-gray-200 p-6">
    <p class=" text-xs text-gray-500 my-1">Payment</p>
    <div class=" border-b flex  items-center justify-between py-3">
      <p class=" font-medium">Card Number</p>
      <p>{'XXXX XXXX XXXX ' + (currentCustomer?.Card?.Last4 ? currentCustomer?.Card?.Last4 : 'XXXX')}</p>
    </div>
    <div class=" border-b flex  items-center justify-between py-3">
      <p class=" font-medium">Next Payment</p>
      <p>$100.00</p>
    </div>
    <div class=" flex  items-center justify-between py-3">
      <p class=" font-medium">Payment Due</p>
      <p>12/12/2023</p>
    </div>
  </div>

  <!-- {#if currentPlanStatus == 'cancelled'} -->
    <!-- <button on:click={()=>{sub.enablePlan();}} class=" text-blue-500 text-sm">Enable Subscription</button> -->
  <!-- {:else} -->
    <button onclick={()=>{sub.cancelPlan();}} class=" text-red-500 text-sm">Cancel Subscription</button>
  <!-- {/if} -->

</div>



