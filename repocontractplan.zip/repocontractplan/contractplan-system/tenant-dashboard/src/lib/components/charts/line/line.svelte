<script lang="ts">
  import Chart from 'chart.js/auto';
  import { onMount } from 'svelte';
  import plannedRevenue from '$lib/mock/plannedRevenue.json';
  import actalRevenue from '$lib/mock/actualRevenue.json';


  let chart;

  const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    datasets: [
      {
        label: 'Planned',
        data: plannedRevenue.map(o => o.value),
        backgroundColor: 'rgba(0, 0, 0, 0.1)',
        borderColor: '#FF914D'
      },
      {
        label: 'Actual',
        data: actalRevenue.map(o => o.value),
        backgroundColor: 'rgba(0, 0, 0, 0.1)',
        borderColor: '#000'
      }
    ]
  };

  onMount(() => {
    const ctx = document.getElementById('mylineChart').getContext('2d');
    chart = new Chart(ctx, {
      type: 'line',
      data: data,
      options: {
        plugins: {
          legend: {
            display: false
          }
        },
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 4 / 1,
        scales: {
          y: {
            max: 1000000,
            min: 0,
            beginAtZero: false,
            grace: '20%',
            type: 'linear'
          }
        }
      }
    });
  });
</script>
<div class="w-full">
  <canvas id="mylineChart"></canvas>
</div>
