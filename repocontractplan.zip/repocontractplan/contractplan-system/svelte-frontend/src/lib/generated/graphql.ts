import { readable, derived, type Readable } from 'svelte/store'
import client from '../../client'
import { gql, queryStore, type AnyVariables, type QueryArgs, type OperationResultState } from '@urql/svelte'
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
type ReadableQueryOption<T, V extends AnyVariables> = Omit<QueryArgs<T, V>, 'query' | 'client'>
type ReadableQueryResult<T, V extends AnyVariables, K extends Exclude<keyof T, '__typename'>> = {
  readonly query: ReturnType<typeof queryStore<T, V>>
  readonly rawData: Readable<T[K] | null>
} & Required<{
  readonly [P in keyof OperationResultState<T, V>]: Readable<OperationResultState<T>[P]>
}>
function __buildReadableResult<
  T,
  V extends AnyVariables,
  K extends Exclude<keyof T, '__typename'> = Exclude<keyof T, '__typename'>
>(result: ReturnType<typeof queryStore<T, V>>): ReadableQueryResult<T, V, K> {
  const data = derived(result, r => r.data)
  const rawData = derived(result, r => {
    if (!r.data) return null
    const k = Object.keys(r.data).filter(z => z !== '__typename')[0] as K
    if (!k) return null
    return r.data[k]
  })
  const error = derived(result, r => r.error)
  const fetching = derived(result, r => r.fetching)
  const hasNext = derived(result, r => r.hasNext)
  const operation = derived(result, r => r.operation)
  const stale = derived(result, r => r.stale)
  return {
    query: result,
    data,
    error,
    fetching,
    hasNext,
    operation,
    stale,
    rawData,
    extensions: readable(),
  }
}
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  ElasticQueryRaw: { input: any; output: any; }
  EmailAddress: { input: any; output: any; }
  LastEvaluatedKey: { input: any; output: any; }
  SummaryCurrencyResult: { input: any; output: any; }
  Time: { input: any; output: any; }
};

export enum AccessType {
  Allow = 'ALLOW',
  Deny = 'DENY'
}

export enum ActionTypes {
  Create = 'CREATE',
  Delete = 'DELETE',
  Read = 'READ',
  Update = 'UPDATE'
}

export type Authentication = {
  error?: Maybe<Error>;
  token: Scalars['String']['output'];
};

export type Bucket = {
  doc_count: Scalars['Int']['output'];
  key?: Maybe<Scalars['Int']['output']>;
  key_as_string?: Maybe<Scalars['String']['output']>;
};

export type Card = {
  __typename?: 'Card';
  CardType: Scalars['String']['output'];
  ExpMonth: Scalars['Int']['output'];
  ExpYear: Scalars['Int']['output'];
  FundingType: Scalars['String']['output'];
  Last4: Scalars['String']['output'];
  MaskedNumber: Scalars['String']['output'];
  PaymentSourceId: Scalars['String']['output'];
  Status: Scalars['String']['output'];
};

export type ChangePlanInput = {
  PlanID: Scalars['String']['input'];
};

export type ChangePlanResult = {
  __typename?: 'ChangePlanResult';
  message: Scalars['String']['output'];
  success: Scalars['Boolean']['output'];
};

export type Company = {
  address: Scalars['String']['input'];
  category: Scalars['String']['input'];
  companySize: Scalars['Int']['input'];
  country: Scalars['String']['input'];
  name: Scalars['String']['input'];
  state: Scalars['String']['input'];
  telephone: Scalars['String']['input'];
};

export enum ComparisonType {
  Between = 'BETWEEN',
  EndsWith = 'ENDS_WITH',
  Equal = 'EQUAL',
  GreaterThan = 'GREATER_THAN',
  GreaterThanOrEqual = 'GREATER_THAN_OR_EQUAL',
  LessThan = 'LESS_THAN',
  LessThanOrEqual = 'LESS_THAN_OR_EQUAL',
  NotEqual = 'NOT_EQUAL',
  StartsWith = 'STARTS_WITH'
}

export type Connection = {
  edges?: Maybe<Array<Maybe<Edge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type Contact = {
  __typename?: 'Contact';
  address: Scalars['String']['output'];
  email: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  name: Scalars['String']['output'];
  phone: Scalars['String']['output'];
};

export type ContactInput = {
  address: Scalars['String']['input'];
  email: Scalars['String']['input'];
  name: Scalars['String']['input'];
  phone: Scalars['String']['input'];
};

export type Contacts = {
  __typename?: 'Contacts';
  billing?: Maybe<Array<Contact>>;
  operations?: Maybe<Array<Contact>>;
};

export type Contract = Node & ServicePeriod & {
  __typename?: 'Contract';
  Archive: Scalars['Boolean']['output'];
  ContractAlias?: Maybe<Scalars['String']['output']>;
  ContractName: Scalars['String']['output'];
  ContractPartner?: Maybe<ContractPartner>;
  ContractPartnerID: Scalars['ID']['output'];
  ContractValue: Money;
  CreatedAt: Scalars['Time']['output'];
  EndDate: Scalars['Time']['output'];
  EngagementsPerDay: Scalars['Int']['output'];
  ID: Scalars['ID']['output'];
  SelectedMonthDays?: Maybe<Array<Maybe<Scalars['Int']['output']>>>;
  ServiceDates?: Maybe<Array<Scalars['String']['output']>>;
  ServiceDays: Scalars['Int']['output'];
  ServicePeriod: Scalars['String']['output'];
  Services?: Maybe<Array<Service>>;
  StartDate: Scalars['Time']['output'];
  Status: ContractStatus;
  UnitDefinition: UnitDefinition;
  Weekdays?: Maybe<Array<Maybe<Scalars['Int']['output']>>>;
};

export type ContractConnection = Connection & {
  __typename?: 'ContractConnection';
  edges?: Maybe<Array<Maybe<ContractEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type ContractDayRecord = Node & {
  __typename?: 'ContractDayRecord';
  ContractID: Scalars['String']['output'];
  Date: Scalars['Time']['output'];
  EngagementCost?: Maybe<Money>;
  Engagements: Scalars['Int']['output'];
  ID: Scalars['ID']['output'];
  ServiceCost?: Maybe<Money>;
  ServiceID: Scalars['String']['output'];
  ServiceName: Scalars['String']['output'];
  TargetEngagementCost?: Maybe<Money>;
  TargetEngagements: Scalars['Int']['output'];
};

export type ContractDayRecordConnection = Connection & {
  __typename?: 'ContractDayRecordConnection';
  edges?: Maybe<Array<Maybe<ContractDayRecordEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type ContractDayRecordEdge = Edge & {
  __typename?: 'ContractDayRecordEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type ContractDayRecordInput = {
  ContractID: Scalars['String']['input'];
  Date: Scalars['Time']['input'];
  EngagementCost?: InputMaybe<MoneyInput>;
  Engagements: Scalars['Int']['input'];
  ServiceID: Scalars['String']['input'];
  ServiceName: Scalars['String']['input'];
};

export type ContractEdge = Edge & {
  __typename?: 'ContractEdge';
  Cursor: Scalars['String']['output'];
  node: Node;
};

export type ContractFile = {
  __typename?: 'ContractFile';
  ID?: Maybe<Scalars['String']['output']>;
  Name?: Maybe<Scalars['String']['output']>;
  SignedUrl?: Maybe<Scalars['String']['output']>;
  UploadedAt?: Maybe<Scalars['String']['output']>;
};

export type ContractFileInput = {
  ID?: InputMaybe<Scalars['String']['input']>;
  Name?: InputMaybe<Scalars['String']['input']>;
};

export type ContractInput = {
  ContractAlias?: InputMaybe<Scalars['String']['input']>;
  ContractName: Scalars['String']['input'];
  ContractPartnerID: Scalars['ID']['input'];
  ContractValue: MoneyInput;
  EndDate: Scalars['Time']['input'];
  EngagementsPerDay: Scalars['Int']['input'];
  SelectedDatesOfYear?: InputMaybe<Array<Scalars['String']['input']>>;
  SelectedMonthDays?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  ServiceDates?: InputMaybe<Array<Scalars['String']['input']>>;
  ServiceDays: Scalars['Int']['input'];
  ServicePeriod: Scalars['String']['input'];
  Services?: InputMaybe<Array<ServiceInput>>;
  StartDate: Scalars['Time']['input'];
  Status?: ContractStatus;
  UnitDefinition: UnitDefinitionInput;
  Weekdays?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
};

export type ContractPartner = Node & {
  __typename?: 'ContractPartner';
  Archive: Scalars['Boolean']['output'];
  CompanyName: Scalars['String']['output'];
  Contact: Scalars['String']['output'];
  ContractPartnerName: Scalars['String']['output'];
  Email: Scalars['String']['output'];
  ID: Scalars['ID']['output'];
};

export type ContractPartnerConnection = Connection & {
  __typename?: 'ContractPartnerConnection';
  edges?: Maybe<Array<Maybe<ContractPartnerEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type ContractPartnerEdge = Edge & {
  __typename?: 'ContractPartnerEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type ContractPartnerInput = {
  CompanyName?: InputMaybe<Scalars['String']['input']>;
  Contact?: InputMaybe<Scalars['String']['input']>;
  ContractPartnerName: Scalars['String']['input'];
  Email?: InputMaybe<Scalars['String']['input']>;
  ID?: InputMaybe<Scalars['ID']['input']>;
};

export enum ContractStatus {
  Completed = 'COMPLETED',
  Draft = 'DRAFT',
  InProgress = 'IN_PROGRESS',
  Ready = 'READY',
  Signed = 'SIGNED',
  Terminated = 'TERMINATED'
}

export type Customer = Node & {
  __typename?: 'Customer';
  Email: Scalars['String']['output'];
  FirstName: Scalars['String']['output'];
  ID: Scalars['ID']['output'];
  LastName: Scalars['String']['output'];
  Phone: Scalars['String']['output'];
  Status: Scalars['String']['output'];
};

export type CustomerConnection = Connection & {
  __typename?: 'CustomerConnection';
  edges?: Maybe<Array<Maybe<CustomerEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type CustomerEdge = Edge & {
  __typename?: 'CustomerEdge';
  Cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type CustomerExtended = {
  __typename?: 'CustomerExtended';
  Card: Card;
  Email: Scalars['String']['output'];
  FirstName: Scalars['String']['output'];
  ID: Scalars['ID']['output'];
  LastName: Scalars['String']['output'];
  Phone: Scalars['String']['output'];
};

export type Edge = {
  node?: Maybe<Node>;
};

export type Error = {
  __typename?: 'Error';
  S?: Maybe<Scalars['String']['output']>;
};

export type FloatFilter = {
  and?: InputMaybe<FloatFilter>;
  comparison: ComparisonType;
  or?: InputMaybe<FloatFilter>;
  value1?: InputMaybe<Scalars['Float']['input']>;
  value2?: InputMaybe<Scalars['Float']['input']>;
};

export type Holiday = Node & {
  __typename?: 'Holiday';
  Category: Scalars['String']['output'];
  CreatedAt: Scalars['Time']['output'];
  Date: Scalars['Time']['output'];
  ID: Scalars['ID']['output'];
  Name: Scalars['String']['output'];
};

export type HolidayConnection = Connection & {
  __typename?: 'HolidayConnection';
  edges?: Maybe<Array<Maybe<ContractEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type HolidayEdge = Edge & {
  __typename?: 'HolidayEdge';
  Cursor: Scalars['String']['output'];
  node: Node;
};

export type HolidayInput = {
  Category: Scalars['String']['input'];
  Date: Scalars['Time']['input'];
  Name: Scalars['String']['input'];
};

export type IntFilter = {
  and?: InputMaybe<IntFilter>;
  comparison: ComparisonType;
  or?: InputMaybe<IntFilter>;
  value1?: InputMaybe<Scalars['Int']['input']>;
  value2?: InputMaybe<Scalars['Int']['input']>;
};

export type Member = Node & {
  __typename?: 'Member';
  Designation: Scalars['String']['output'];
  Email: Scalars['String']['output'];
  FullName: Scalars['String']['output'];
  ID: Scalars['ID']['output'];
};

export type MemberConnection = Connection & {
  __typename?: 'MemberConnection';
  edges?: Maybe<Array<Maybe<MemberEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type MemberEdge = Edge & {
  __typename?: 'MemberEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type MemberInput = {
  Designation: Scalars['String']['input'];
  Email: Scalars['String']['input'];
  FullName: Scalars['String']['input'];
};

export type Money = {
  __typename?: 'Money';
  amount: Scalars['Int']['output'];
  currency: Scalars['String']['output'];
};

export type MoneyInput = {
  amount: Scalars['Int']['input'];
  currency: Scalars['String']['input'];
  majorUnits?: InputMaybe<Scalars['Float']['input']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  SignUp: SignUpResponse;
  Verification: VerificationResponse;
  cancelPlan: ChangePlanResult;
  changePlan: ChangePlanResult;
  contractFileUpload?: Maybe<ContractFile>;
  createContact: Contact;
  createContract: Contract;
  createContractDayRecord?: Maybe<ContractDayRecord>;
  createContractPartner: ContractPartner;
  createMember: Member;
  deleteContract: Contract;
  deleteContractPartner: ContractPartner;
  deleteHoliday: Holiday;
  deleteMember: Member;
  error?: Maybe<Error>;
  insertHoliday: Holiday;
  profileImageUrl?: Maybe<Scalars['String']['output']>;
  subscribePlan: SubscriptionResult;
  updateContact: Contact;
  updateContract: Contract;
  updateContractDayRecord?: Maybe<ContractDayRecord>;
  updateContractDayRecords: Array<Maybe<ContractDayRecord>>;
  updateContractPartner: ContractPartner;
  updateHoliday: Holiday;
  updateMember: Member;
  updateUser: User;
};


export type MutationSignUpArgs = {
  input: SignUpInput;
};


export type MutationVerificationArgs = {
  input: VerificationInput;
};


export type MutationCancelPlanArgs = {
  input: ChangePlanInput;
};


export type MutationChangePlanArgs = {
  input: ChangePlanInput;
};


export type MutationContractFileUploadArgs = {
  id: Scalars['ID']['input'];
  input: ContractFileInput;
};


export type MutationCreateContactArgs = {
  input: ContactInput;
};


export type MutationCreateContractArgs = {
  input: ContractInput;
};


export type MutationCreateContractDayRecordArgs = {
  input: ContractDayRecordInput;
};


export type MutationCreateContractPartnerArgs = {
  input: ContractPartnerInput;
};


export type MutationCreateMemberArgs = {
  input: MemberInput;
};


export type MutationDeleteContractArgs = {
  id: Scalars['ID']['input'];
};


export type MutationDeleteContractPartnerArgs = {
  id: Scalars['ID']['input'];
};


export type MutationDeleteHolidayArgs = {
  id: Scalars['ID']['input'];
};


export type MutationDeleteMemberArgs = {
  id: Scalars['ID']['input'];
};


export type MutationInsertHolidayArgs = {
  input: HolidayInput;
};


export type MutationSubscribePlanArgs = {
  input: SubscribePlanInput;
};


export type MutationUpdateContactArgs = {
  input: ContactInput;
};


export type MutationUpdateContractArgs = {
  id: Scalars['ID']['input'];
  input: ContractInput;
};


export type MutationUpdateContractDayRecordArgs = {
  id: Scalars['ID']['input'];
  input?: InputMaybe<ContractDayRecordInput>;
};


export type MutationUpdateContractDayRecordsArgs = {
  contractId: Scalars['ID']['input'];
  count: Scalars['Int']['input'];
  dateRange: Array<Scalars['Time']['input']>;
  serviceId: Scalars['ID']['input'];
};


export type MutationUpdateContractPartnerArgs = {
  id: Scalars['ID']['input'];
  input: ContractPartnerInput;
};


export type MutationUpdateHolidayArgs = {
  id: Scalars['ID']['input'];
  input: HolidayInput;
};


export type MutationUpdateMemberArgs = {
  id: Scalars['ID']['input'];
  input: MemberInput;
};


export type MutationUpdateUserArgs = {
  ID: Scalars['ID']['input'];
  input: UserInput;
};

export type Node = {
  ID: Scalars['ID']['output'];
};

export enum OrderBy {
  Asc = 'asc',
  Desc = 'desc'
}

export type Pagination = {
  __typename?: 'Pagination';
  currentPage: Scalars['Int']['output'];
  itemsPerPage: Scalars['Int']['output'];
  nextPage: Scalars['Int']['output'];
  prevPage: Scalars['Int']['output'];
  totalItems: Scalars['Int']['output'];
};

export type Plan = {
  __typename?: 'Plan';
  Features: Array<Maybe<Scalars['String']['output']>>;
  ID: Scalars['ID']['output'];
  Period: Scalars['String']['output'];
  Price: Scalars['String']['output'];
};

export type Policy = {
  __typename?: 'Policy';
  Actions?: Maybe<Array<ActionTypes>>;
  CreatedAt?: Maybe<Scalars['String']['output']>;
  Description?: Maybe<Scalars['String']['output']>;
  Effect: AccessType;
  For: Scalars['String']['output'];
  Grant: Scalars['String']['output'];
  ID: Scalars['ID']['output'];
  Name: Scalars['String']['output'];
  Resources?: Maybe<Array<ResourceTypes>>;
  UpdatedAt?: Maybe<Scalars['String']['output']>;
};

export type Query = {
  __typename?: 'Query';
  error?: Maybe<Error>;
  getAllSummary?: Maybe<SummaryRecordList>;
  getContract?: Maybe<Contract>;
  getContractDayRecord?: Maybe<ContractDayRecord>;
  getContractDayRecordByID?: Maybe<ContractDayRecord>;
  getContractDayRecords?: Maybe<ContractDayRecordConnection>;
  getContractFiles?: Maybe<Array<ContractFile>>;
  getContractPartner?: Maybe<ContractPartner>;
  getContractdayRecordsByDate?: Maybe<ContractDayRecordConnection>;
  getCurrentCustomer?: Maybe<CustomerExtended>;
  getCurrentPlan?: Maybe<Plan>;
  getCurrentPlanStatus?: Maybe<Scalars['String']['output']>;
  getCurrentTenant?: Maybe<Tenant>;
  getCurrentUser?: Maybe<User>;
  getCustomer?: Maybe<CustomerExtended>;
  getHoliday?: Maybe<Holiday>;
  getMember?: Maybe<Member>;
  getSummary?: Maybe<SummaryRecordList>;
  getTenant?: Maybe<Tenant>;
  getTenantContractSummary?: Maybe<SummaryRecordList>;
  listContractPartners?: Maybe<ContractPartnerConnection>;
  listContractPartnersDDB?: Maybe<ContractPartnerConnection>;
  listContracts?: Maybe<ContractConnection>;
  listCustomers?: Maybe<CustomerConnection>;
  listHolidays?: Maybe<HolidayConnection>;
  listMembers?: Maybe<MemberConnection>;
  listPlans?: Maybe<Array<Maybe<Plan>>>;
  listTenants?: Maybe<TenantConnection>;
  listUsers?: Maybe<UserConnection>;
};


export type QueryGetAllSummaryArgs = {
  endDate?: InputMaybe<Scalars['String']['input']>;
  startDate?: InputMaybe<Scalars['String']['input']>;
  type: Scalars['String']['input'];
};


export type QueryGetContractArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetContractDayRecordArgs = {
  Date: Scalars['Time']['input'];
};


export type QueryGetContractDayRecordByIdArgs = {
  ID: Scalars['ID']['input'];
};


export type QueryGetContractDayRecordsArgs = {
  ContractID: Scalars['ID']['input'];
  EndDate?: InputMaybe<Scalars['Time']['input']>;
  ServiceID?: InputMaybe<Scalars['ID']['input']>;
  StartDate?: InputMaybe<Scalars['Time']['input']>;
};


export type QueryGetContractFilesArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetContractPartnerArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetContractdayRecordsByDateArgs = {
  Date: Scalars['Time']['input'];
};


export type QueryGetCustomerArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetHolidayArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetMemberArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetSummaryArgs = {
  ID: Scalars['ID']['input'];
  ServiceID?: InputMaybe<Scalars['String']['input']>;
  type: Scalars['String']['input'];
};


export type QueryGetTenantArgs = {
  id: Scalars['ID']['input'];
};


export type QueryGetTenantContractSummaryArgs = {
  endDate?: InputMaybe<Scalars['String']['input']>;
  startDate?: InputMaybe<Scalars['String']['input']>;
  type: Scalars['String']['input'];
};


export type QueryListContractPartnersArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};


export type QueryListContractPartnersDdbArgs = {
  query?: InputMaybe<ContractPartnerInput>;
};


export type QueryListContractsArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};


export type QueryListCustomersArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};


export type QueryListHolidaysArgs = {
  query?: InputMaybe<HolidayInput>;
};


export type QueryListMembersArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};


export type QueryListTenantsArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};


export type QueryListUsersArgs = {
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
};

export enum ResourceTypes {
  Contract = 'CONTRACT',
  Engagement = 'ENGAGEMENT',
  Holiday = 'HOLIDAY'
}

export type Role = {
  __typename?: 'Role';
  CreatedAt?: Maybe<Scalars['String']['output']>;
  Description?: Maybe<Scalars['String']['output']>;
  ID: Scalars['ID']['output'];
  Name?: Maybe<Scalars['String']['output']>;
  UpdatedAt?: Maybe<Scalars['String']['output']>;
};

export type Service = ServicePeriod & {
  __typename?: 'Service';
  EndDate: Scalars['Time']['output'];
  EngagementCost: Money;
  EngagementsPerDay: Scalars['Int']['output'];
  ID: Scalars['ID']['output'];
  SelectedMonthDays?: Maybe<Array<Maybe<Scalars['Int']['output']>>>;
  ServiceDates?: Maybe<Array<Scalars['String']['output']>>;
  ServiceDays: Scalars['Int']['output'];
  ServiceName: Scalars['String']['output'];
  ServicePeriod: Scalars['String']['output'];
  ServiceTotal: Money;
  StartDate: Scalars['Time']['output'];
  UnitDefinition: UnitDefinition;
  Weekdays?: Maybe<Array<Maybe<Scalars['Int']['output']>>>;
};

export type ServiceInput = {
  EndDate: Scalars['Time']['input'];
  EngagementCost: MoneyInput;
  EngagementsPerDay: Scalars['Int']['input'];
  PerDayServiceCost?: InputMaybe<Scalars['Float']['input']>;
  SelectedDatesOfYear?: InputMaybe<Array<Scalars['String']['input']>>;
  SelectedMonthDays?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  SeparatePeriod?: InputMaybe<Scalars['Boolean']['input']>;
  ServiceDates?: InputMaybe<Array<Scalars['String']['input']>>;
  ServiceDays: Scalars['Int']['input'];
  ServiceName: Scalars['String']['input'];
  ServicePeriod: Scalars['String']['input'];
  ServiceTotal: MoneyInput;
  StartDate: Scalars['Time']['input'];
  UnitDefinition: UnitDefinitionInput;
  Weekdays?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
};

export type ServicePeriod = {
  EndDate: Scalars['Time']['output'];
  EngagementsPerDay: Scalars['Int']['output'];
  ServiceDates?: Maybe<Array<Scalars['String']['output']>>;
  ServiceDays: Scalars['Int']['output'];
  ServicePeriod: Scalars['String']['output'];
  StartDate: Scalars['Time']['output'];
};

export type SignInInput = {
  email: Scalars['String']['input'];
  password: Scalars['String']['input'];
};

export type SignUpInput = {
  address: Scalars['String']['input'];
  company?: InputMaybe<Company>;
  email: Scalars['String']['input'];
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  middleName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  telephone: Scalars['String']['input'];
};

export type SignUpResponse = {
  __typename?: 'SignUpResponse';
  error?: Maybe<Error>;
  success: Scalars['Boolean']['output'];
};

export type StdDeviationBounds = {
  __typename?: 'StdDeviationBounds';
  lower?: Maybe<Scalars['Float']['output']>;
  lower_population?: Maybe<Scalars['Float']['output']>;
  lower_sampling?: Maybe<Scalars['Float']['output']>;
  upper?: Maybe<Scalars['Float']['output']>;
  upper_population?: Maybe<Scalars['Float']['output']>;
  upper_sampling?: Maybe<Scalars['Float']['output']>;
};

export type StringFilter = {
  and?: InputMaybe<StringFilter>;
  comparison: ComparisonType;
  or?: InputMaybe<StringFilter>;
  value1?: InputMaybe<Scalars['String']['input']>;
  value2?: InputMaybe<Scalars['String']['input']>;
};

export type SubscribePlanInput = {
  PlanID: Scalars['String']['input'];
};

export type Subscription = {
  __typename?: 'Subscription';
  contractCreated?: Maybe<Contract>;
  contractDeleted?: Maybe<Contract>;
  contractUpdated?: Maybe<Contract>;
  currentTime: Scalars['Time']['output'];
  deleteHoliday?: Maybe<Holiday>;
  error: Error;
  insertHoliday?: Maybe<Holiday>;
  updateHoliday?: Maybe<Holiday>;
};

export type SubscriptionResult = {
  __typename?: 'SubscriptionResult';
  message: Scalars['String']['output'];
  success: Scalars['Boolean']['output'];
  url?: Maybe<Scalars['String']['output']>;
};

export type SummaryContractDayRecord = Bucket & {
  __typename?: 'SummaryContractDayRecord';
  currency?: Maybe<Scalars['SummaryCurrencyResult']['output']>;
  doc_count: Scalars['Int']['output'];
  engagement_cost?: Maybe<TargetValue>;
  engagements?: Maybe<TargetValue>;
  key: Scalars['Int']['output'];
  key_as_string: Scalars['String']['output'];
  target_engagement_cost?: Maybe<TargetValue>;
  target_engagements?: Maybe<TargetValue>;
};

export type SummaryRecordList = {
  __typename?: 'SummaryRecordList';
  Contract?: Maybe<Contract>;
  SummaryRecords: Array<SummaryContractDayRecord>;
  SummaryTotal: SummaryContractDayRecord;
  Window?: Maybe<Scalars['String']['output']>;
};

export type TargetValue = {
  __typename?: 'TargetValue';
  avg?: Maybe<Scalars['Float']['output']>;
  count?: Maybe<Scalars['Int']['output']>;
  max?: Maybe<Scalars['Float']['output']>;
  min?: Maybe<Scalars['Float']['output']>;
  std_deviation?: Maybe<Scalars['Float']['output']>;
  std_deviation_bounds?: Maybe<StdDeviationBounds>;
  std_deviation_population?: Maybe<Scalars['Float']['output']>;
  std_deviation_sampling?: Maybe<Scalars['Float']['output']>;
  sum?: Maybe<Scalars['Float']['output']>;
  sum_of_squares?: Maybe<Scalars['Float']['output']>;
  value?: Maybe<Scalars['Float']['output']>;
  variance?: Maybe<Scalars['Float']['output']>;
  variance_population?: Maybe<Scalars['Float']['output']>;
  variance_sampling?: Maybe<Scalars['Float']['output']>;
};

export type Tenant = Node & {
  __typename?: 'Tenant';
  Address: Scalars['String']['output'];
  Category: Scalars['String']['output'];
  Contacts?: Maybe<Array<Contacts>>;
  ID: Scalars['ID']['output'];
  Name: Scalars['String']['output'];
  Telephone: Scalars['String']['output'];
};

export type TenantConnection = Connection & {
  __typename?: 'TenantConnection';
  edges?: Maybe<Array<Maybe<TenantEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type TenantEdge = Edge & {
  __typename?: 'TenantEdge';
  Cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type TenantFilter = {
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type TenantInput = {
  Address: Scalars['String']['input'];
  Category: Scalars['String']['input'];
  Name: Scalars['String']['input'];
  Telephone: Scalars['String']['input'];
};

export type UnitDefinition = {
  __typename?: 'UnitDefinition';
  Description: Scalars['String']['output'];
  Name: Scalars['String']['output'];
};

export type UnitDefinitionInput = {
  Description: Scalars['String']['input'];
  Name: Scalars['String']['input'];
};

export type User = Node & {
  __typename?: 'User';
  AutoLogout?: Maybe<Scalars['Int']['output']>;
  Card: Card;
  CreatedAt?: Maybe<Scalars['String']['output']>;
  Email?: Maybe<Scalars['String']['output']>;
  ID: Scalars['ID']['output'];
  ProfileImageUrl?: Maybe<Scalars['String']['output']>;
  UpdatedAt?: Maybe<Scalars['String']['output']>;
  Username?: Maybe<Scalars['String']['output']>;
  VisibleName?: Maybe<Scalars['String']['output']>;
};

export type UserConnection = Connection & {
  __typename?: 'UserConnection';
  edges?: Maybe<Array<Maybe<UserEdge>>>;
  lastEvaluatedKey?: Maybe<Scalars['LastEvaluatedKey']['output']>;
  pagination?: Maybe<Pagination>;
};

export type UserEdge = Edge & {
  __typename?: 'UserEdge';
  Cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<Node>;
};

export type UserFilter = {
  ID?: InputMaybe<Scalars['ID']['input']>;
};

export type UserInput = {
  AutoLogout?: InputMaybe<Scalars['Int']['input']>;
  CreatedAt?: InputMaybe<Scalars['String']['input']>;
  Email: Scalars['String']['input'];
  UpdatedAt?: InputMaybe<Scalars['String']['input']>;
  Username: Scalars['String']['input'];
  VisibleName: Scalars['String']['input'];
};

export type UserList = {
  __typename?: 'UserList';
  items: Array<Maybe<User>>;
  pagination?: Maybe<Pagination>;
};

export type VerificationInput = {
  email: Scalars['String']['input'];
  token: Scalars['String']['input'];
};

export type VerificationResponse = {
  __typename?: 'VerificationResponse';
  message: Scalars['String']['output'];
  success: Scalars['Boolean']['output'];
};

export type GetContractsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetContractsQuery = { __typename?: 'Query', listContracts?: { __typename?: 'ContractConnection', edges?: Array<{ __typename?: 'ContractEdge', node: { __typename?: 'Contract', ID: string, Status: ContractStatus, ContractName: string, ContractPartnerID: string, ContractAlias?: string | null, StartDate: any, EndDate: any, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, Archive: boolean, ContractPartner?: { __typename?: 'ContractPartner', CompanyName: string, ContractPartnerName: string } | null, ContractValue: { __typename?: 'Money', amount: number, currency: string }, Services?: Array<{ __typename?: 'Service', ID: string, ServiceName: string, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, EngagementCost: { __typename?: 'Money', amount: number, currency: string }, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } }> | null, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } } | null> | null } | null };

export type GetContractQueryVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type GetContractQuery = { __typename?: 'Query', getContract?: { __typename?: 'Contract', ID: string, Status: ContractStatus, ContractName: string, ContractPartnerID: string, ContractAlias?: string | null, StartDate: any, EndDate: any, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, Archive: boolean, ContractPartner?: { __typename?: 'ContractPartner', CompanyName: string, ContractPartnerName: string } | null, ContractValue: { __typename?: 'Money', amount: number, currency: string }, Services?: Array<{ __typename?: 'Service', ID: string, ServiceName: string, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, EngagementCost: { __typename?: 'Money', amount: number, currency: string }, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } }> | null, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } } | null };

export type GetContractDayRecordsQueryVariables = Exact<{
  contractId: Scalars['ID']['input'];
  serviceId?: InputMaybe<Scalars['ID']['input']>;
  startDate?: InputMaybe<Scalars['Time']['input']>;
  endDate?: InputMaybe<Scalars['Time']['input']>;
}>;


export type GetContractDayRecordsQuery = { __typename?: 'Query', getContractDayRecords?: { __typename?: 'ContractDayRecordConnection', edges?: Array<{ __typename?: 'ContractDayRecordEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord', Date: any, ContractID: string, ID: string, ServiceID: string, ServiceName: string, Engagements: number } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type GetContractDayRecordsByDateQueryVariables = Exact<{
  date: Scalars['Time']['input'];
}>;


export type GetContractDayRecordsByDateQuery = { __typename?: 'Query', getContractdayRecordsByDate?: { __typename?: 'ContractDayRecordConnection', edges?: Array<{ __typename?: 'ContractDayRecordEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord', Date: any, ContractID: string, ID: string, ServiceID: string, ServiceName: string, Engagements: number } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type GetSummaryQueryVariables = Exact<{
  ID: Scalars['ID']['input'];
  Type: Scalars['String']['input'];
  ServiceID?: InputMaybe<Scalars['String']['input']>;
}>;


export type GetSummaryQuery = { __typename?: 'Query', getSummary?: { __typename?: 'SummaryRecordList', Window?: string | null, Contract?: { __typename?: 'Contract', ContractName: string, ServicePeriod: string, Services?: Array<{ __typename?: 'Service', ID: string, ServiceName: string }> | null, ContractPartner?: { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, Email: string, Contact: string } | null } | null, SummaryRecords: Array<{ __typename?: 'SummaryContractDayRecord', doc_count: number, key: number, key_as_string: string, currency?: any | null, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null }>, SummaryTotal: { __typename?: 'SummaryContractDayRecord', currency?: any | null, doc_count: number, key: number, key_as_string: string, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null } } | null };

export type GetAllSummaryQueryVariables = Exact<{
  Type: Scalars['String']['input'];
}>;


export type GetAllSummaryQuery = { __typename?: 'Query', getAllSummary?: { __typename?: 'SummaryRecordList', Window?: string | null, SummaryRecords: Array<{ __typename?: 'SummaryContractDayRecord', doc_count: number, key: number, key_as_string: string, currency?: any | null, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null }>, SummaryTotal: { __typename?: 'SummaryContractDayRecord', currency?: any | null, doc_count: number, key: number, key_as_string: string, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null } } | null };

export type GetTenantContractSummaryQueryVariables = Exact<{
  Type: Scalars['String']['input'];
  StartDate?: InputMaybe<Scalars['String']['input']>;
  EndDate?: InputMaybe<Scalars['String']['input']>;
}>;


export type GetTenantContractSummaryQuery = { __typename?: 'Query', getTenantContractSummary?: { __typename?: 'SummaryRecordList', Window?: string | null, Contract?: { __typename?: 'Contract', ContractName: string, Services?: Array<{ __typename?: 'Service', ID: string, ServiceName: string }> | null, ContractPartner?: { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, Email: string, Contact: string } | null } | null, SummaryRecords: Array<{ __typename?: 'SummaryContractDayRecord', doc_count: number, key: number, key_as_string: string, currency?: any | null, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null }>, SummaryTotal: { __typename?: 'SummaryContractDayRecord', currency?: any | null, doc_count: number, key: number, key_as_string: string, engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagements?: { __typename?: 'TargetValue', sum?: number | null } | null, target_engagement_cost?: { __typename?: 'TargetValue', sum?: number | null } | null } } | null };

export type PaginationFragment = { __typename?: 'Pagination', currentPage: number, prevPage: number, nextPage: number, totalItems: number, itemsPerPage: number };

export type ContractListFragment = { __typename?: 'Contract', ID: string, Status: ContractStatus, ContractName: string, ContractPartnerID: string, ContractAlias?: string | null, StartDate: any, EndDate: any, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, Archive: boolean, ContractPartner?: { __typename?: 'ContractPartner', CompanyName: string, ContractPartnerName: string } | null, ContractValue: { __typename?: 'Money', amount: number, currency: string }, Services?: Array<{ __typename?: 'Service', ID: string, ServiceName: string, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, EngagementCost: { __typename?: 'Money', amount: number, currency: string }, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } }> | null, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } };

export type ServiceFragment = { __typename?: 'Service', ID: string, ServiceName: string, ServiceDays: number, ServiceDates?: Array<string> | null, ServicePeriod: string, Weekdays?: Array<number | null> | null, SelectedMonthDays?: Array<number | null> | null, EngagementsPerDay: number, EngagementCost: { __typename?: 'Money', amount: number, currency: string }, UnitDefinition: { __typename?: 'UnitDefinition', Name: string, Description: string } };

export type MoneyFragment = { __typename?: 'Money', amount: number, currency: string };

export type UnitDefinitionFragment = { __typename?: 'UnitDefinition', Name: string, Description: string };

export type ContractDayRecordListFragment = { __typename?: 'ContractDayRecord', Date: any, ContractID: string, ID: string, ServiceID: string, ServiceName: string, Engagements: number };

export type UserSignUpFragment = { __typename?: 'User', ID: string, VisibleName?: string | null, Username?: string | null, Email?: string | null, CreatedAt?: string | null, UpdatedAt?: string | null, AutoLogout?: number | null };

export type HolidayListFragment = { __typename?: 'Holiday', ID: string, Date: any, Name: string, Category: string };

export type ContractPartnerListFragment = { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, CompanyName: string, Email: string, Contact: string, Archive: boolean };

export type MemberListFragment = { __typename?: 'Member', ID: string, FullName: string, Email: string, Designation: string };

export type PlansListFragment = { __typename?: 'Plan', ID: string, Price: string, Features: Array<string | null>, Period: string };

export type CurrentPlanFragment = { __typename?: 'Plan', ID: string, Price: string, Features: Array<string | null>, Period: string };

export type TenantListFragment = { __typename?: 'Tenant', ID: string, Name: string, Category: string, Telephone: string, Address: string };

export type UserListFragment = { __typename?: 'User', ID: string, Username?: string | null, VisibleName?: string | null, Email?: string | null, ProfileImageUrl?: string | null };

export type CustomerListFragment = { __typename?: 'Customer', ID: string, FirstName: string, LastName: string, Email: string, Phone: string };

export type CustomerExtendedFragment = { __typename?: 'CustomerExtended', ID: string, FirstName: string, LastName: string, Email: string, Phone: string, Card: { __typename?: 'Card', PaymentSourceId: string, Last4: string, Status: string, FundingType: string, ExpMonth: number, ExpYear: number, CardType: string, MaskedNumber: string } };

export type CreateContractMutationVariables = Exact<{
  input: ContractInput;
}>;


export type CreateContractMutation = { __typename?: 'Mutation', createContract: { __typename?: 'Contract', ContractName: string, ContractAlias?: string | null } };

export type UpdateContractMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input: ContractInput;
}>;


export type UpdateContractMutation = { __typename?: 'Mutation', updateContract: { __typename?: 'Contract', ID: string } };

export type DeleteContractMutationVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type DeleteContractMutation = { __typename?: 'Mutation', deleteContract: { __typename?: 'Contract', ID: string } };

export type SignUpMutationVariables = Exact<{
  input: SignUpInput;
}>;


export type SignUpMutation = { __typename?: 'Mutation', SignUp: { __typename?: 'SignUpResponse', success: boolean, error?: { __typename?: 'Error', S?: string | null } | null } };

export type UpdateContractDayRecordMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input?: InputMaybe<ContractDayRecordInput>;
}>;


export type UpdateContractDayRecordMutation = { __typename?: 'Mutation', updateContractDayRecord?: { __typename?: 'ContractDayRecord', ID: string, ContractID: string, ServiceID: string, ServiceName: string, Date: any } | null };

export type InsertHolidayMutationVariables = Exact<{
  input: HolidayInput;
}>;


export type InsertHolidayMutation = { __typename?: 'Mutation', insertHoliday: { __typename?: 'Holiday', ID: string, Name: string, Date: any, Category: string, CreatedAt: any } };

export type CreateMemberMutationVariables = Exact<{
  input: MemberInput;
}>;


export type CreateMemberMutation = { __typename?: 'Mutation', createMember: { __typename?: 'Member', ID: string, FullName: string, Email: string, Designation: string } };

export type UpdateMemberMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input: MemberInput;
}>;


export type UpdateMemberMutation = { __typename?: 'Mutation', updateMember: { __typename?: 'Member', ID: string, FullName: string, Email: string, Designation: string } };

export type DeleteMemberMutationVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type DeleteMemberMutation = { __typename?: 'Mutation', deleteMember: { __typename?: 'Member', ID: string } };

export type CreateContractPartnersMutationVariables = Exact<{
  input: ContractPartnerInput;
}>;


export type CreateContractPartnersMutation = { __typename?: 'Mutation', createContractPartner: { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, CompanyName: string, Email: string, Contact: string } };

export type UpdateContractPartnersMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input: ContractPartnerInput;
}>;


export type UpdateContractPartnersMutation = { __typename?: 'Mutation', updateContractPartner: { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, CompanyName: string, Email: string, Contact: string } };

export type DeleteContractPartnerMutationVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type DeleteContractPartnerMutation = { __typename?: 'Mutation', deleteContractPartner: { __typename?: 'ContractPartner', ID: string } };

export type VerificationMutationVariables = Exact<{
  input: VerificationInput;
}>;


export type VerificationMutation = { __typename?: 'Mutation', Verification: { __typename?: 'VerificationResponse', success: boolean, message: string } };

export type SubscribePlanMutationVariables = Exact<{
  input: SubscribePlanInput;
}>;


export type SubscribePlanMutation = { __typename?: 'Mutation', subscribePlan: { __typename?: 'SubscriptionResult', success: boolean, message: string, url?: string | null } };

export type ChangePlanMutationVariables = Exact<{
  input: ChangePlanInput;
}>;


export type ChangePlanMutation = { __typename?: 'Mutation', changePlan: { __typename?: 'ChangePlanResult', success: boolean, message: string } };

export type CancelPlanMutationVariables = Exact<{
  input: ChangePlanInput;
}>;


export type CancelPlanMutation = { __typename?: 'Mutation', cancelPlan: { __typename?: 'ChangePlanResult', success: boolean, message: string } };

export type UpdateContractDayRecordsMutationVariables = Exact<{
  contractId: Scalars['ID']['input'];
  serviceId: Scalars['ID']['input'];
  count: Scalars['Int']['input'];
  dateRange: Array<Scalars['Time']['input']> | Scalars['Time']['input'];
}>;


export type UpdateContractDayRecordsMutation = { __typename?: 'Mutation', updateContractDayRecords: Array<{ __typename?: 'ContractDayRecord', ContractID: string, ServiceID: string, Date: any } | null> };

export type UpdateUserMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input: UserInput;
}>;


export type UpdateUserMutation = { __typename?: 'Mutation', updateUser: { __typename?: 'User', ID: string, VisibleName?: string | null, Email?: string | null } };

export type ContractFileUploadMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  input: ContractFileInput;
}>;


export type ContractFileUploadMutation = { __typename?: 'Mutation', contractFileUpload?: { __typename?: 'ContractFile', ID?: string | null, Name?: string | null, UploadedAt?: string | null, SignedUrl?: string | null } | null };

export type ProfileImageUrlMutationVariables = Exact<{ [key: string]: never; }>;


export type ProfileImageUrlMutation = { __typename?: 'Mutation', profileImageUrl?: string | null };

export type GetCurrentUserQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCurrentUserQuery = { __typename?: 'Query', getCurrentUser?: { __typename?: 'User', ID: string, Username?: string | null, VisibleName?: string | null, Email?: string | null, ProfileImageUrl?: string | null } | null };

export type GetHolidaysQueryVariables = Exact<{ [key: string]: never; }>;


export type GetHolidaysQuery = { __typename?: 'Query', listHolidays?: { __typename?: 'HolidayConnection', edges?: Array<{ __typename?: 'ContractEdge', node: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday', ID: string, Date: any, Name: string, Category: string } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } } | null> | null } | null };

export type GetContractPartnersQueryVariables = Exact<{
  input?: InputMaybe<ContractPartnerInput>;
}>;


export type GetContractPartnersQuery = { __typename?: 'Query', listContractPartnersDDB?: { __typename?: 'ContractPartnerConnection', edges?: Array<{ __typename?: 'ContractPartnerEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner', ID: string, ContractPartnerName: string, CompanyName: string, Email: string, Contact: string, Archive: boolean } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type GetMembersQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMembersQuery = { __typename?: 'Query', listMembers?: { __typename?: 'MemberConnection', edges?: Array<{ __typename?: 'MemberEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member', ID: string, FullName: string, Email: string, Designation: string } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type GetMemberByIdQueryVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type GetMemberByIdQuery = { __typename?: 'Query', getMember?: { __typename?: 'Member', ID: string, FullName: string, Email: string, Designation: string } | null };

export type GetPlansQueryVariables = Exact<{ [key: string]: never; }>;


export type GetPlansQuery = { __typename?: 'Query', listPlans?: Array<{ __typename?: 'Plan', ID: string, Price: string, Features: Array<string | null>, Period: string } | null> | null };

export type GetCurrentPlanQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCurrentPlanQuery = { __typename?: 'Query', getCurrentPlan?: { __typename?: 'Plan', ID: string, Price: string, Features: Array<string | null>, Period: string } | null };

export type GetCurrentPlanStatusQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCurrentPlanStatusQuery = { __typename?: 'Query', getCurrentPlanStatus?: string | null };

export type GetContractDayRecordsbyDateQueryVariables = Exact<{
  date: Scalars['Time']['input'];
}>;


export type GetContractDayRecordsbyDateQuery = { __typename?: 'Query', getContractdayRecordsByDate?: { __typename?: 'ContractDayRecordConnection', edges?: Array<{ __typename?: 'ContractDayRecordEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord', Date: any, ContractID: string, ID: string, ServiceID: string, ServiceName: string, Engagements: number } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type ListTenantsQueryVariables = Exact<{
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
}>;


export type ListTenantsQuery = { __typename?: 'Query', listTenants?: { __typename?: 'TenantConnection', lastEvaluatedKey?: any | null, edges?: Array<{ __typename?: 'TenantEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant', ID: string, Name: string, Category: string, Telephone: string, Address: string } | { __typename?: 'User' } | null } | null> | null } | null };

export type ListUsersQueryVariables = Exact<{
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
}>;


export type ListUsersQuery = { __typename?: 'Query', listUsers?: { __typename?: 'UserConnection', lastEvaluatedKey?: any | null, edges?: Array<{ __typename?: 'UserEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer' } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User', ID: string, Username?: string | null, VisibleName?: string | null, Email?: string | null, ProfileImageUrl?: string | null } | null } | null> | null } | null };

export type ListCustomersQueryVariables = Exact<{
  query?: InputMaybe<Scalars['ElasticQueryRaw']['input']>;
}>;


export type ListCustomersQuery = { __typename?: 'Query', listCustomers?: { __typename?: 'CustomerConnection', lastEvaluatedKey?: any | null, edges?: Array<{ __typename?: 'CustomerEdge', node?: { __typename?: 'Contract' } | { __typename?: 'ContractDayRecord' } | { __typename?: 'ContractPartner' } | { __typename?: 'Customer', ID: string, FirstName: string, LastName: string, Email: string, Phone: string } | { __typename?: 'Holiday' } | { __typename?: 'Member' } | { __typename?: 'Tenant' } | { __typename?: 'User' } | null } | null> | null } | null };

export type GetCustomerByIdQueryVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type GetCustomerByIdQuery = { __typename?: 'Query', getCustomer?: { __typename?: 'CustomerExtended', ID: string, FirstName: string, LastName: string, Email: string, Phone: string, Card: { __typename?: 'Card', PaymentSourceId: string, Last4: string, Status: string, FundingType: string, ExpMonth: number, ExpYear: number, CardType: string, MaskedNumber: string } } | null };

export type GetCurrentCustomerQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCurrentCustomerQuery = { __typename?: 'Query', getCurrentCustomer?: { __typename?: 'CustomerExtended', ID: string, FirstName: string, LastName: string, Email: string, Phone: string, Card: { __typename?: 'Card', PaymentSourceId: string, Last4: string, Status: string, FundingType: string, ExpMonth: number, ExpYear: number, CardType: string, MaskedNumber: string } } | null };

export type GetContractFilesQueryVariables = Exact<{
  id: Scalars['ID']['input'];
}>;


export type GetContractFilesQuery = { __typename?: 'Query', getContractFiles?: Array<{ __typename?: 'ContractFile', ID?: string | null, Name?: string | null, UploadedAt?: string | null, SignedUrl?: string | null }> | null };

export const PaginationFragmentDoc = gql`
    fragment Pagination on Pagination {
  currentPage
  prevPage
  nextPage
  totalItems
  itemsPerPage
}
    `;
export const MoneyFragmentDoc = gql`
    fragment Money on Money {
  amount
  currency
}
    `;
export const UnitDefinitionFragmentDoc = gql`
    fragment UnitDefinition on UnitDefinition {
  Name
  Description
}
    `;
export const ServiceFragmentDoc = gql`
    fragment Service on Service {
  ID
  ServiceName
  ServiceDays
  ServiceDates
  ServicePeriod
  Weekdays
  SelectedMonthDays
  EngagementsPerDay
  EngagementCost {
    ...Money
  }
  UnitDefinition {
    ...UnitDefinition
  }
}
    ${MoneyFragmentDoc}
${UnitDefinitionFragmentDoc}`;
export const ContractListFragmentDoc = gql`
    fragment ContractList on Contract {
  ID
  Status
  ContractName
  ContractPartnerID
  ContractPartner {
    CompanyName
    ContractPartnerName
  }
  ContractAlias
  StartDate
  EndDate
  ServiceDays
  ServiceDates
  ServicePeriod
  Weekdays
  SelectedMonthDays
  EngagementsPerDay
  ContractValue {
    ...Money
  }
  Services {
    ...Service
  }
  UnitDefinition {
    ...UnitDefinition
  }
  Archive
}
    ${MoneyFragmentDoc}
${ServiceFragmentDoc}
${UnitDefinitionFragmentDoc}`;
export const ContractDayRecordListFragmentDoc = gql`
    fragment ContractDayRecordList on ContractDayRecord {
  Date
  ContractID
  ID
  ServiceID
  ServiceName
  Engagements
}
    `;
export const UserSignUpFragmentDoc = gql`
    fragment UserSignUp on User {
  ID
  VisibleName
  Username
  Email
  CreatedAt
  UpdatedAt
  AutoLogout
}
    `;
export const HolidayListFragmentDoc = gql`
    fragment holidayList on Holiday {
  ID
  Date
  Name
  Category
}
    `;
export const ContractPartnerListFragmentDoc = gql`
    fragment ContractPartnerList on ContractPartner {
  ID
  ContractPartnerName
  CompanyName
  Email
  Contact
  Archive
}
    `;
export const MemberListFragmentDoc = gql`
    fragment MemberList on Member {
  ID
  FullName
  Email
  Designation
}
    `;
export const PlansListFragmentDoc = gql`
    fragment PlansList on Plan {
  ID
  Price
  Features
  Period
}
    `;
export const CurrentPlanFragmentDoc = gql`
    fragment CurrentPlan on Plan {
  ID
  Price
  Features
  Period
}
    `;
export const TenantListFragmentDoc = gql`
    fragment TenantList on Tenant {
  ID
  Name
  Category
  Telephone
  Address
}
    `;
export const UserListFragmentDoc = gql`
    fragment UserList on User {
  ID
  Username
  VisibleName
  Email
  ProfileImageUrl
}
    `;
export const CustomerListFragmentDoc = gql`
    fragment CustomerList on Customer {
  ID
  FirstName
  LastName
  Email
  Phone
}
    `;
export const CustomerExtendedFragmentDoc = gql`
    fragment CustomerExtended on CustomerExtended {
  ID
  FirstName
  LastName
  Email
  Phone
  Card {
    PaymentSourceId
    Last4
    Status
    FundingType
    ExpMonth
    ExpYear
    CardType
    MaskedNumber
  }
}
    `;
export const GetContractsDoc = gql`
    query GetContracts {
  listContracts {
    edges {
      node {
        ...ContractList
      }
    }
  }
}
    ${ContractListFragmentDoc}`;
export const GetContractDoc = gql`
    query GetContract($id: ID!) {
  getContract(id: $id) {
    ...ContractList
  }
}
    ${ContractListFragmentDoc}`;
export const GetContractDayRecordsDoc = gql`
    query GetContractDayRecords($contractId: ID!, $serviceId: ID, $startDate: Time, $endDate: Time) {
  getContractDayRecords(
    ContractID: $contractId
    ServiceID: $serviceId
    StartDate: $startDate
    EndDate: $endDate
  ) {
    edges {
      node {
        ...ContractDayRecordList
      }
    }
  }
}
    ${ContractDayRecordListFragmentDoc}`;
export const GetContractDayRecordsByDateDoc = gql`
    query GetContractDayRecordsByDate($date: Time!) {
  getContractdayRecordsByDate(Date: $date) {
    edges {
      node {
        ...ContractDayRecordList
      }
    }
  }
}
    ${ContractDayRecordListFragmentDoc}`;
export const GetSummaryDoc = gql`
    query getSummary($ID: ID!, $Type: String!, $ServiceID: String) {
  getSummary(ID: $ID, type: $Type, ServiceID: $ServiceID) {
    Window
    Contract {
      ContractName
      Services {
        ID
        ServiceName
      }
      ServicePeriod
      ContractPartner {
        ID
        ContractPartnerName
        Email
        Contact
      }
    }
    SummaryRecords {
      doc_count
      key
      key_as_string
      currency
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
    SummaryTotal {
      currency
      doc_count
      key
      key_as_string
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
  }
}
    `;
export const GetAllSummaryDoc = gql`
    query getAllSummary($Type: String!) {
  getAllSummary(type: $Type) {
    Window
    SummaryRecords {
      doc_count
      key
      key_as_string
      currency
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
    SummaryTotal {
      currency
      doc_count
      key
      key_as_string
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
  }
}
    `;
export const GetTenantContractSummaryDoc = gql`
    query GetTenantContractSummary($Type: String!, $StartDate: String, $EndDate: String) {
  getTenantContractSummary(type: $Type, startDate: $StartDate, endDate: $EndDate) {
    Window
    Contract {
      ContractName
      Services {
        ID
        ServiceName
      }
      ContractPartner {
        ID
        ContractPartnerName
        Email
        Contact
      }
    }
    SummaryRecords {
      doc_count
      key
      key_as_string
      currency
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
    SummaryTotal {
      currency
      doc_count
      key
      key_as_string
      engagements {
        sum
      }
      engagement_cost {
        sum
      }
      target_engagements {
        sum
      }
      target_engagement_cost {
        sum
      }
    }
  }
}
    `;
export const CreateContractDoc = gql`
    mutation CreateContract($input: ContractInput!) {
  createContract(input: $input) {
    ContractName
    ContractAlias
  }
}
    `;
export const UpdateContractDoc = gql`
    mutation UpdateContract($id: ID!, $input: ContractInput!) {
  updateContract(id: $id, input: $input) {
    ID
  }
}
    `;
export const DeleteContractDoc = gql`
    mutation DeleteContract($id: ID!) {
  deleteContract(id: $id) {
    ID
  }
}
    `;
export const SignUpDoc = gql`
    mutation SignUp($input: SignUpInput!) {
  SignUp(input: $input) {
    error {
      S
    }
    success
  }
}
    `;
export const UpdateContractDayRecordDoc = gql`
    mutation UpdateContractDayRecord($id: ID!, $input: ContractDayRecordInput) {
  updateContractDayRecord(id: $id, input: $input) {
    ID
    ContractID
    ServiceID
    ServiceName
    Date
  }
}
    `;
export const InsertHolidayDoc = gql`
    mutation InsertHoliday($input: HolidayInput!) {
  insertHoliday(input: $input) {
    ID
    Name
    Date
    Category
    CreatedAt
  }
}
    `;
export const CreateMemberDoc = gql`
    mutation CreateMember($input: MemberInput!) {
  createMember(input: $input) {
    ID
    FullName
    Email
    Designation
  }
}
    `;
export const UpdateMemberDoc = gql`
    mutation UpdateMember($id: ID!, $input: MemberInput!) {
  updateMember(id: $id, input: $input) {
    ID
    FullName
    Email
    Designation
  }
}
    `;
export const DeleteMemberDoc = gql`
    mutation DeleteMember($id: ID!) {
  deleteMember(id: $id) {
    ID
  }
}
    `;
export const CreateContractPartnersDoc = gql`
    mutation CreateContractPartners($input: ContractPartnerInput!) {
  createContractPartner(input: $input) {
    ID
    ContractPartnerName
    CompanyName
    Email
    Contact
  }
}
    `;
export const UpdateContractPartnersDoc = gql`
    mutation UpdateContractPartners($id: ID!, $input: ContractPartnerInput!) {
  updateContractPartner(id: $id, input: $input) {
    ID
    ContractPartnerName
    CompanyName
    Email
    Contact
  }
}
    `;
export const DeleteContractPartnerDoc = gql`
    mutation DeleteContractPartner($id: ID!) {
  deleteContractPartner(id: $id) {
    ID
  }
}
    `;
export const VerificationDoc = gql`
    mutation Verification($input: VerificationInput!) {
  Verification(input: $input) {
    success
    message
  }
}
    `;
export const SubscribePlanDoc = gql`
    mutation SubscribePlan($input: SubscribePlanInput!) {
  subscribePlan(input: $input) {
    success
    message
    url
  }
}
    `;
export const ChangePlanDoc = gql`
    mutation ChangePlan($input: ChangePlanInput!) {
  changePlan(input: $input) {
    success
    message
  }
}
    `;
export const CancelPlanDoc = gql`
    mutation CancelPlan($input: ChangePlanInput!) {
  cancelPlan(input: $input) {
    success
    message
  }
}
    `;
export const UpdateContractDayRecordsDoc = gql`
    mutation UpdateContractDayRecords($contractId: ID!, $serviceId: ID!, $count: Int!, $dateRange: [Time!]!) {
  updateContractDayRecords(
    contractId: $contractId
    serviceId: $serviceId
    count: $count
    dateRange: $dateRange
  ) {
    ContractID
    ServiceID
    Date
  }
}
    `;
export const UpdateUserDoc = gql`
    mutation UpdateUser($id: ID!, $input: UserInput!) {
  updateUser(ID: $id, input: $input) {
    ID
    VisibleName
    Email
  }
}
    `;
export const ContractFileUploadDoc = gql`
    mutation ContractFileUpload($id: ID!, $input: ContractFileInput!) {
  contractFileUpload(id: $id, input: $input) {
    ID
    Name
    UploadedAt
    SignedUrl
  }
}
    `;
export const ProfileImageUrlDoc = gql`
    mutation ProfileImageURL {
  profileImageUrl
}
    `;
export const GetCurrentUserDoc = gql`
    query GetCurrentUser {
  getCurrentUser {
    ...UserList
  }
}
    ${UserListFragmentDoc}`;
export const GetHolidaysDoc = gql`
    query GetHolidays {
  listHolidays {
    edges {
      node {
        ...holidayList
      }
    }
  }
}
    ${HolidayListFragmentDoc}`;
export const GetContractPartnersDoc = gql`
    query GetContractPartners($input: ContractPartnerInput) {
  listContractPartnersDDB(query: $input) {
    edges {
      node {
        ...ContractPartnerList
      }
    }
  }
}
    ${ContractPartnerListFragmentDoc}`;
export const GetMembersDoc = gql`
    query GetMembers {
  listMembers {
    edges {
      node {
        ...MemberList
      }
    }
  }
}
    ${MemberListFragmentDoc}`;
export const GetMemberByIdDoc = gql`
    query GetMemberById($id: ID!) {
  getMember(id: $id) {
    ...MemberList
  }
}
    ${MemberListFragmentDoc}`;
export const GetPlansDoc = gql`
    query GetPlans {
  listPlans {
    ID
    Price
    Features
    Period
  }
}
    `;
export const GetCurrentPlanDoc = gql`
    query GetCurrentPlan {
  getCurrentPlan {
    ID
    Price
    Features
    Period
  }
}
    `;
export const GetCurrentPlanStatusDoc = gql`
    query GetCurrentPlanStatus {
  getCurrentPlanStatus
}
    `;
export const GetContractDayRecordsbyDateDoc = gql`
    query GetContractDayRecordsbyDate($date: Time!) {
  getContractdayRecordsByDate(Date: $date) {
    edges {
      node {
        ...ContractDayRecordList
      }
    }
  }
}
    ${ContractDayRecordListFragmentDoc}`;
export const ListTenantsDoc = gql`
    query ListTenants($query: ElasticQueryRaw) {
  listTenants(query: $query) {
    edges {
      node {
        ...TenantList
      }
    }
    lastEvaluatedKey
  }
}
    ${TenantListFragmentDoc}`;
export const ListUsersDoc = gql`
    query ListUsers($query: ElasticQueryRaw) {
  listUsers(query: $query) {
    edges {
      node {
        ...UserList
      }
    }
    lastEvaluatedKey
  }
}
    ${UserListFragmentDoc}`;
export const ListCustomersDoc = gql`
    query ListCustomers($query: ElasticQueryRaw) {
  listCustomers(query: $query) {
    edges {
      node {
        ...CustomerList
      }
    }
    lastEvaluatedKey
  }
}
    ${CustomerListFragmentDoc}`;
export const GetCustomerByIdDoc = gql`
    query GetCustomerById($id: ID!) {
  getCustomer(id: $id) {
    ...CustomerExtended
  }
}
    ${CustomerExtendedFragmentDoc}`;
export const GetCurrentCustomerDoc = gql`
    query GetCurrentCustomer {
  getCurrentCustomer {
    ...CustomerExtended
  }
}
    ${CustomerExtendedFragmentDoc}`;
export const GetContractFilesDoc = gql`
    query GetContractFiles($id: ID!) {
  getContractFiles(id: $id) {
    ID
    Name
    UploadedAt
    SignedUrl
  }
}
    `;

export const GetContracts = (
  options?: ReadableQueryOption<GetContractsQuery, GetContractsQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractsDoc, ...options } as QueryArgs<
      GetContractsQuery,
      GetContractsQueryVariables
    >)
  )

export const GetContract = (
  options?: ReadableQueryOption<GetContractQuery, GetContractQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractDoc, ...options } as QueryArgs<
      GetContractQuery,
      GetContractQueryVariables
    >)
  )

export const GetContractDayRecords = (
  options?: ReadableQueryOption<GetContractDayRecordsQuery, GetContractDayRecordsQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractDayRecordsDoc, ...options } as QueryArgs<
      GetContractDayRecordsQuery,
      GetContractDayRecordsQueryVariables
    >)
  )

export const GetContractDayRecordsByDate = (
  options?: ReadableQueryOption<GetContractDayRecordsByDateQuery, GetContractDayRecordsByDateQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractDayRecordsByDateDoc, ...options } as QueryArgs<
      GetContractDayRecordsByDateQuery,
      GetContractDayRecordsByDateQueryVariables
    >)
  )

export const getSummary = (
  options?: ReadableQueryOption<GetSummaryQuery, GetSummaryQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetSummaryDoc, ...options } as QueryArgs<
      GetSummaryQuery,
      GetSummaryQueryVariables
    >)
  )

export const getAllSummary = (
  options?: ReadableQueryOption<GetAllSummaryQuery, GetAllSummaryQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetAllSummaryDoc, ...options } as QueryArgs<
      GetAllSummaryQuery,
      GetAllSummaryQueryVariables
    >)
  )

export const GetTenantContractSummary = (
  options?: ReadableQueryOption<GetTenantContractSummaryQuery, GetTenantContractSummaryQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetTenantContractSummaryDoc, ...options } as QueryArgs<
      GetTenantContractSummaryQuery,
      GetTenantContractSummaryQueryVariables
    >)
  )

export const CreateContract = (variables: CreateContractMutationVariables) =>
  client.mutation<CreateContractMutation, CreateContractMutationVariables>(CreateContractDoc, variables)

export const UpdateContract = (variables: UpdateContractMutationVariables) =>
  client.mutation<UpdateContractMutation, UpdateContractMutationVariables>(UpdateContractDoc, variables)

export const DeleteContract = (variables: DeleteContractMutationVariables) =>
  client.mutation<DeleteContractMutation, DeleteContractMutationVariables>(DeleteContractDoc, variables)

export const SignUp = (variables: SignUpMutationVariables) =>
  client.mutation<SignUpMutation, SignUpMutationVariables>(SignUpDoc, variables)

export const UpdateContractDayRecord = (variables: UpdateContractDayRecordMutationVariables) =>
  client.mutation<UpdateContractDayRecordMutation, UpdateContractDayRecordMutationVariables>(UpdateContractDayRecordDoc, variables)

export const InsertHoliday = (variables: InsertHolidayMutationVariables) =>
  client.mutation<InsertHolidayMutation, InsertHolidayMutationVariables>(InsertHolidayDoc, variables)

export const CreateMember = (variables: CreateMemberMutationVariables) =>
  client.mutation<CreateMemberMutation, CreateMemberMutationVariables>(CreateMemberDoc, variables)

export const UpdateMember = (variables: UpdateMemberMutationVariables) =>
  client.mutation<UpdateMemberMutation, UpdateMemberMutationVariables>(UpdateMemberDoc, variables)

export const DeleteMember = (variables: DeleteMemberMutationVariables) =>
  client.mutation<DeleteMemberMutation, DeleteMemberMutationVariables>(DeleteMemberDoc, variables)

export const CreateContractPartners = (variables: CreateContractPartnersMutationVariables) =>
  client.mutation<CreateContractPartnersMutation, CreateContractPartnersMutationVariables>(CreateContractPartnersDoc, variables)

export const UpdateContractPartners = (variables: UpdateContractPartnersMutationVariables) =>
  client.mutation<UpdateContractPartnersMutation, UpdateContractPartnersMutationVariables>(UpdateContractPartnersDoc, variables)

export const DeleteContractPartner = (variables: DeleteContractPartnerMutationVariables) =>
  client.mutation<DeleteContractPartnerMutation, DeleteContractPartnerMutationVariables>(DeleteContractPartnerDoc, variables)

export const Verification = (variables: VerificationMutationVariables) =>
  client.mutation<VerificationMutation, VerificationMutationVariables>(VerificationDoc, variables)

export const SubscribePlan = (variables: SubscribePlanMutationVariables) =>
  client.mutation<SubscribePlanMutation, SubscribePlanMutationVariables>(SubscribePlanDoc, variables)

export const ChangePlan = (variables: ChangePlanMutationVariables) =>
  client.mutation<ChangePlanMutation, ChangePlanMutationVariables>(ChangePlanDoc, variables)

export const CancelPlan = (variables: CancelPlanMutationVariables) =>
  client.mutation<CancelPlanMutation, CancelPlanMutationVariables>(CancelPlanDoc, variables)

export const UpdateContractDayRecords = (variables: UpdateContractDayRecordsMutationVariables) =>
  client.mutation<UpdateContractDayRecordsMutation, UpdateContractDayRecordsMutationVariables>(UpdateContractDayRecordsDoc, variables)

export const UpdateUser = (variables: UpdateUserMutationVariables) =>
  client.mutation<UpdateUserMutation, UpdateUserMutationVariables>(UpdateUserDoc, variables)

export const ContractFileUpload = (variables: ContractFileUploadMutationVariables) =>
  client.mutation<ContractFileUploadMutation, ContractFileUploadMutationVariables>(ContractFileUploadDoc, variables)

export const ProfileImageURL = (variables: ProfileImageUrlMutationVariables) =>
  client.mutation<ProfileImageUrlMutation, ProfileImageUrlMutationVariables>(ProfileImageUrlDoc, variables)

export const GetCurrentUser = (
  options?: ReadableQueryOption<GetCurrentUserQuery, GetCurrentUserQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetCurrentUserDoc, ...options } as QueryArgs<
      GetCurrentUserQuery,
      GetCurrentUserQueryVariables
    >)
  )

export const GetHolidays = (
  options?: ReadableQueryOption<GetHolidaysQuery, GetHolidaysQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetHolidaysDoc, ...options } as QueryArgs<
      GetHolidaysQuery,
      GetHolidaysQueryVariables
    >)
  )

export const GetContractPartners = (
  options?: ReadableQueryOption<GetContractPartnersQuery, GetContractPartnersQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractPartnersDoc, ...options } as QueryArgs<
      GetContractPartnersQuery,
      GetContractPartnersQueryVariables
    >)
  )

export const GetMembers = (
  options?: ReadableQueryOption<GetMembersQuery, GetMembersQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetMembersDoc, ...options } as QueryArgs<
      GetMembersQuery,
      GetMembersQueryVariables
    >)
  )

export const GetMemberById = (
  options?: ReadableQueryOption<GetMemberByIdQuery, GetMemberByIdQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetMemberByIdDoc, ...options } as QueryArgs<
      GetMemberByIdQuery,
      GetMemberByIdQueryVariables
    >)
  )

export const GetPlans = (
  options?: ReadableQueryOption<GetPlansQuery, GetPlansQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetPlansDoc, ...options } as QueryArgs<
      GetPlansQuery,
      GetPlansQueryVariables
    >)
  )

export const GetCurrentPlan = (
  options?: ReadableQueryOption<GetCurrentPlanQuery, GetCurrentPlanQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetCurrentPlanDoc, ...options } as QueryArgs<
      GetCurrentPlanQuery,
      GetCurrentPlanQueryVariables
    >)
  )

export const GetCurrentPlanStatus = (
  options?: ReadableQueryOption<GetCurrentPlanStatusQuery, GetCurrentPlanStatusQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetCurrentPlanStatusDoc, ...options } as QueryArgs<
      GetCurrentPlanStatusQuery,
      GetCurrentPlanStatusQueryVariables
    >)
  )

export const GetContractDayRecordsbyDate = (
  options?: ReadableQueryOption<GetContractDayRecordsbyDateQuery, GetContractDayRecordsbyDateQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractDayRecordsbyDateDoc, ...options } as QueryArgs<
      GetContractDayRecordsbyDateQuery,
      GetContractDayRecordsbyDateQueryVariables
    >)
  )

export const ListTenants = (
  options?: ReadableQueryOption<ListTenantsQuery, ListTenantsQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: ListTenantsDoc, ...options } as QueryArgs<
      ListTenantsQuery,
      ListTenantsQueryVariables
    >)
  )

export const ListUsers = (
  options?: ReadableQueryOption<ListUsersQuery, ListUsersQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: ListUsersDoc, ...options } as QueryArgs<
      ListUsersQuery,
      ListUsersQueryVariables
    >)
  )

export const ListCustomers = (
  options?: ReadableQueryOption<ListCustomersQuery, ListCustomersQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: ListCustomersDoc, ...options } as QueryArgs<
      ListCustomersQuery,
      ListCustomersQueryVariables
    >)
  )

export const GetCustomerById = (
  options?: ReadableQueryOption<GetCustomerByIdQuery, GetCustomerByIdQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetCustomerByIdDoc, ...options } as QueryArgs<
      GetCustomerByIdQuery,
      GetCustomerByIdQueryVariables
    >)
  )

export const GetCurrentCustomer = (
  options?: ReadableQueryOption<GetCurrentCustomerQuery, GetCurrentCustomerQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetCurrentCustomerDoc, ...options } as QueryArgs<
      GetCurrentCustomerQuery,
      GetCurrentCustomerQueryVariables
    >)
  )

export const GetContractFiles = (
  options?: ReadableQueryOption<GetContractFilesQuery, GetContractFilesQueryVariables>
) =>
  __buildReadableResult(
    queryStore({ client: client, query: GetContractFilesDoc, ...options } as QueryArgs<
      GetContractFilesQuery,
      GetContractFilesQueryVariables
    >)
  )