<script>
  export let label = "";
  export let value = "";
  export let type = "";
  export let validationText = "this is validation text";
  export let required = false;
  export let checked = false;
  export let placeholder = "";

  export let disabled = false;

  export let styleClass = "";

  //export let required = false;
  function typeAction(node) {
    node.type = type;
  }

</script>
<div class="relative flex flex-col items-start w-full {styleClass}">
  <label class="text-sm my-2" for="{label}">
    {label}
  </label>
  <input bind:value="{value}"
         class="bg-gray-50 border {required ? 'border-red-500' : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
         {disabled} id="{label}"
         placeholder="{placeholder}"
         {required} use:typeAction />
  {#if required && validationText}
    <div class="text-red-500 text-xs mt-1">{validationText}</div>
  {/if}
</div>


