import type { CodegenConfig } from '@graphql-codegen/cli';

const config: CodegenConfig = {
  overwrite: true,
  schema: '../graph/schema/*.graphql',
  documents: '../graph/operations/*.graphql',
  generates: {
    'src/lib/generated/graphql.ts': {
      config: {
        gqlImport: '@urql/svelte#gql',
        clientPath: '../../client',
        clientType: 'urql',
        useTypeImports: true
      },
      plugins: ['typescript', 'typescript-operations', '@nerd-coder/graphql-codegen-svelte-queries']
    },
    './graphql.schema.json': {
      plugins: ['introspection']
    }
  }
};

export default config;
