<script>
  // @ts-nocheck

  
  /**
   * @typedef {Object} Props
   * @property {{ q: any; a: any;}} faq
   */

  /** @type {Props} */
  let { faq } = $props();
  let yes = $state(true);
</script>

<div class=" mb-3 transition-all">
  <label>
    <input bind:checked={yes} class=" hidden" type="checkbox" />
    <h2
      class="text-lg md:text-1xl border p-4 font-medium leading-5 md:leading-7  flex flex-row justify-between items-center tracking-normal "

    >
      {faq.q}

      {#if yes}
        <span class=" px-1 text-orange-500  text-3xl">&#43</span>
      {:else}
        <span class=" px-1  text-orange-500  text-3xl">&#8722</span>
      {/if}
    </h2>
  </label>
  <div class=" border p-4 text-base font-normal leading-6 " hidden={yes}>
    <p>
      {faq.a}


    </p>


  </div>
</div>
