package subscriptions

import (
	"time"
)

var TimeSubscription = make(chan *time.Time)
