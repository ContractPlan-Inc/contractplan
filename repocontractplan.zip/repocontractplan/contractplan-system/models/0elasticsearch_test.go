package models

import (
	"context"
	"reflect"
	"testing"
	"time"

	opensearch2 "github.com/opensearch-project/opensearch-go/v2"
)

func TestCountQuery(t *testing.T) {
	type args struct {
		ctx   context.Context
		index string
		query map[string]interface{}
	}
	tests := []struct {
		name    string
		args    args
		want    int
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := CountQuery(tt.args.ctx, tt.args.index, tt.args.query)
			if (err != nil) != tt.wantErr {
				t.Errorf("CountQuery() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("CountQuery() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestInsertIndexIntoOS(t *testing.T) {
	type args[F Model] struct {
		index            string
		modelId          string
		model            F
		openSearchClient *opensearch2.Client
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := InsertIndexIntoOS(tt.args.index, tt.args.modelId, tt.args.model, tt.args.openSearchClient, ""); (err != nil) != tt.wantErr {
				t.Errorf("InsertIndexIntoOS() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestIntToPointer(t *testing.T) {
	type args struct {
		i int
	}
	tests := []struct {
		name string
		args args
		want *int
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IntToPointer(tt.args.i); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("IntToPointer() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestSearchQuery(t *testing.T) {
	type args[F Model] struct {
		ctx        context.Context
		searchFor  F
		index      string
		query      map[string]interface{}
		sort       map[string]string
		size       int
		offset     int
		aggregates map[string]string
	}
	type testCase[F Model] struct {
		name  string
		args  args[F]
		want  error
		want1 []*F
		want2 map[string]interface{}
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//got, got1, got2 := SearchQuery(tt.args.ctx, tt.args.searchFor, tt.args.index, tt.args.query, tt.args.sort, tt.args.size, tt.args.offset, tt.args.aggregates)
			//if !reflect.DeepEqual(got, tt.want) {
			//	t.Errorf("SearchQuery() got = %v, want %v", got, tt.want)
			//}
			//if !reflect.DeepEqual(got1, tt.want1) {
			//	t.Errorf("SearchQuery() got1 = %v, want %v", got1, tt.want1)
			//}
			//if !reflect.DeepEqual(got2, tt.want2) {
			//	t.Errorf("SearchQuery() got2 = %v, want %v", got2, tt.want2)
			//}
		})
	}
}

func TestSearchQueryCached(t *testing.T) {
	type args[T Model] struct {
		ctx      context.Context
		cachedId string
		cacheKey string
		ttl      time.Duration
		v        T
		index    string
		query    map[string]interface{}
		sort     map[string]string
		size     int
		offset   int
	}
	type testCase[T Model] struct {
		name    string
		args    args[T]
		want    []T
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//got, err := SearchQueryCached(tt.args.ctx, tt.args.cachedId, tt.args.cacheKey, tt.args.ttl, tt.args.v, tt.args.index, tt.args.query, tt.args.sort, tt.args.size, tt.args.offset)
			//if (err != nil) != tt.wantErr {
			//	t.Errorf("SearchQueryCached() error = %v, wantErr %v", err, tt.wantErr)
			//	return
			//}
			//if !reflect.DeepEqual(got, tt.want) {
			//	t.Errorf("SearchQueryCached() got = %v, want %v", got, tt.want)
			//}
		})
	}
}

func Test_extractQuery(t *testing.T) {
	type args[F Model] struct {
		query      map[string]interface{}
		sortMap    map[string]string
		model      F
		aggregates map[string]string
	}
	type testCase[F Model] struct {
		name string
		args args[F]
		want []byte
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := extractQuery(tt.args.query, tt.args.sortMap, tt.args.model, tt.args.aggregates); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("extractQuery() = %v, want %v", got, tt.want)
			}
		})
	}
}
