/** @type {import("tailwindcss").Config} */
module.exports = {
  content: [
    "./src/**/*.{html,js,svelte,ts}"
  ],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["Georama", "sans-serif"],
        poppins: ["Poppins", "Helvetica", "sans-serif"]
      },
      colors: {
        primary: "rgb(255, 145, 77)",
        "primary-light": "rgba(255,145,77,0.75)",
        "primary-extra-light": "rgba(255,145,77,0.5)",
        "primary-dark": "rgb(255,120,43)",
        "primary-extra-dark": "rgb(215,85,2)",
        "primary-orange": "rgb(241,118,0)"
      }
    }
  }
};
