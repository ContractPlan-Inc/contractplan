<script>
  import menu from "$lib/assets/svg/menu-burger.svg";
  import logo from "$lib/assets/svg/logo.svg";
  import { onMount } from "svelte";
  import { title } from "$lib/state/store";
  import { auth, authState } from "$lib/state/auth";
  import { goto } from "$app/navigation";
  import { page } from "$app/stores";

  import IconDashboard from "~icons/material-symbols/team-dashboard-outline";
  import IconContract from "~icons/akar-icons/paper";
  import IconPartners from "~icons/simple-line-icons/people";
  import IconCalculator from "~icons/ph/brackets-round";
  import IconHoliday from "~icons/streamline/interface-logout-arrow-exit-frame-leave-logout-rectangle-right";
  import IconProfile from "$lib/assets/svg/profile.svg";
  import { cognitoUser } from "$lib/cognito/user";
  import { CognitoRefreshToken } from "amazon-cognito-identity-js";
  import { GetCurrentUserDoc} from '$lib/generated/graphql';
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import { userdata } from "../store.ts"
  import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
  import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
  import { env } from '$env/dynamic/public';

  let sidebar = false;
  let mobileView = false;
  let isMobileView = false;
  let showProfileDropdown = false;
  let currentPath = "";
  let VisibleName = "";
  $: currentPathName = currentPath;
  let ProfileImageUrl = ""
  console.log('Current Path:', currentPathName);

  let loading = true;
  let userData;
  userdata.subscribe((value) => {
    userData = value;
  });

  const s3Client = new S3Client({
    region: 'us-east-1',
    credentials: {
      accessKeyId: env.PUBLIC_AWS_ACCESS_KEY_ID,
      secretAccessKey: env.PUBLIC_AWS_SECRET_ACCESS_KEY,
    },
  });

  function redirectToLogin() {
    auth.token = "";
    auth.loggedIn = false;
    authState.set(auth);
    goto("/auth/signin");
  }

  onMount(() => {
    const savedPath = localStorage.getItem('currentPath');
    if (savedPath && auth.loggedIn) {
      currentPath = savedPath;
      window.history.replaceState(null, '', savedPath);
    } else if (!savedPath) {
      currentPath = "/app";
      window.history.replaceState(null, '', currentPath);
      localStorage.setItem('currentPath', currentPath);
    }

    const queryRepository = new GraphQLQueryRepository();
    const currentUserData = queryRepository.getItems(GetCurrentUserDoc);
    currentUserData.then((x) => {
      userdata.update((n) => x.data.getCurrentUser);
      console.log("($*$)", x.data.getCurrentUser);
      VisibleName = x.data.getCurrentUser.VisibleName;
      ProfileImageUrl = x.data.getCurrentUser.ProfileImageUrl
      console.log("Profile Image URL", ProfileImageUrl)
    })
      .then(async () => {
        userData.Image = await getSignedUrl(s3Client, new GetObjectCommand({
          Bucket: 'contractplan-profile-image',
          Key: `${userData.ID}`,
        }), { expiresIn: 90 });
      });

    if (auth.loggedIn === false && auth.token === "") {
      redirectToLogin();
    } else {
      loading = false;
      try {
        const jwtPayload = JSON.parse(window.atob(auth.token.split(".")[1]));
        const isExpired = Date.now() >= jwtPayload.exp * 1000;
        if (isExpired) {
          redirectToLogin();
        }
      } catch (error) {
        redirectToLogin();
      }
    }
    cognitoUser.refreshSession(new CognitoRefreshToken({ RefreshToken: auth.refreshToken }), (err, session) => {
      if (err) {
        console.log("error", err);
        redirectToLogin();
      }
      auth.token = session.getAccessToken().getJwtToken();
      auth.refreshToken = session.getRefreshToken().getToken();
      auth.loggedIn = true;
      authState.set(auth);

      if (!savedPath) {
        currentPath = "/app";
      }
    });

    const checkMobileView = () => {
      isMobileView = window.innerWidth <= 700;
    };

    checkMobileView();

    window.addEventListener('resize', checkMobileView);

    return () => {
      window.removeEventListener('resize', checkMobileView);
    };
  });

  function pathChanged(path) {
    currentPath = path;
    localStorage.setItem('currentPath', path);
    console.log("currentPath", currentPath);
  }

  function activeColor(path) {
    if (currentPathName === path) {
      return "bg-green-500";
    } else {
      return "bg-red-300";
    }
  }

  function signout() {
    localStorage.removeItem('currentPath');
    localStorage.clear();
    
    auth.token = "";
    auth.loggedIn = false;
    auth.refreshToken = "";
    authState.set(auth);

    sessionStorage.clear();
    
    window.location.replace("/auth/signin");
  }

  let showNotifications = false;
  let hasNewNotification = true; // Set this to true when a new notification arrives

  let notifications = [
    { id: 1, content: "Notification 1" },
    { id: 2, content: "Notification 2" }
    // Add more notifications as needed
  ];

  const sidebarGroups = [
    {
      title: "Admin Tools",
      items: [
        {
          title: "Dashboard",
          icon: IconDashboard,
          path: "/app"
        },
        {
          title: "Contract",
          icon: IconContract,
          path: "/app/contract"
        },
        {
          title: "Calculator",
          icon: IconCalculator,
          path: "/app/calculator"
        },
        {
          title: "Holidays",
          icon: IconHoliday,
          path: "/app/holidays"
        },
        {
          title: "Partners",
          icon: IconPartners,
          path: "/app/partners"
        }
      ]
    },
    {
      title: "Management",
      items: [
        {
          title: "Settings",
          icon: IconDashboard,
          path: "/app/setting"
        },
        {
          title: "Billing",
          icon: IconContract,
          path: "/app/billing"
        },
        // {
        //   title: "Members",
        //   icon: IconPartners,
        //   path: "/app/members"
        // }
      ]
    }
  ];

  function toggleNotifications() {
    showNotifications = !showNotifications;
    hasNewNotification = false; // Reset the new notification flag when the button is clicked
    console.log("showNotifications:", showNotifications);
  }

  function handleNotificationClick(notification) {
    // Handle the click event for the notification, e.g., open a modal, navigate to a page, etc.
    console.log(
      `Clicked on notification ${notification.id}: ${notification.content}`
    );
  }
</script>

<svelte:head>
  <title>ContractPlan</title>
</svelte:head>

{#if loading}
  <div class="fixed z-40 top-0 bottom-0 left-0 right-0 bg-black bg-opacity-50 flex items-center justify-center"
       style="display: {loading ? 'flex' : 'none'};">
    <div
      class="z-50 fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mx-auto flex justify-center items-center p-5 bg-white rounded-lg "
      role="alert">
      <div class="animate-spin rounded-full border-t-4 border-green-600 border-solid h-16 w-16"></div>
    </div>
  </div>
{:else}

  <div class="flex flex-wrap">
    {#if mobileView}
      <div class="relative z-40 md:hidden" role="dialog" aria-modal="true">
        <div
          role="button"
          onclick={() => {mobileView = false}}
          onkeydown={(e) => {e.key === 'Enter' || e.key === ' ' ? (mobileView = false) : null}}
          tabindex="0"
          class="fixed inset-0 bg-gray-600 bg-opacity-75"
        ></div>
        <div class="flex fixed z-40 w-1/2 h-full">
          <div class="flex relative flex-col pt-5 pb-4 w-full bg-white">
            <div class="overflow-y-auto mt-5 h-full">
              <nav class="flex flex-col px-2 space-y-4">
                <div
                  class="flex gap-1 items-center px-2 text-gray-500 focus:ring-2 focus:ring-inset focus:ring-indigo-500 focus:outline-none"
                >
                  <img src={logo} alt="Dashboard Logo" class="max-w-fit" />
                </div>

                {#each sidebarGroups as sidebarGroup}
                  <div class="item-group">
                    <p
                      class="px-2 py-2 text-sm text-gray-500 {sidebar
                        ? 'hidden'
                        : 'block'} "
                    >
                      {sidebarGroup.title}
                    </p>
                    {#each sidebarGroup.items as item}
                      <a
                        onclick={() => pathChanged(item.path)}
                        href={item.path}
                        class="text-gray-900 {activeColor(item.path)} border border-transparent group flex items-center rounded-md px-2 py-2 text-sm"
                      >
                        <!-- Icon with dynamic color based on active path -->
                        <svelte:component
                          this={item.icon}
                          class={`mr-3 h-4 w-4 flex-shrink-0 ${currentPathName === item.path ? "text-white" : "text-gray-600"}`}
                        />
                        <span class={sidebar ? "hidden" : "block"}>{item.title}</span>
                      </a>

                    {/each}
                  </div>
                {/each}
              </nav>
            </div>
          </div>
        </div>
      </div>
    {/if}
    <!-- Static sidebar for desktop -->
    <div
      class="hidden z-10 md:inset-y-0 md:flex   w-44 {sidebar
        ? 'w-12'
        : 'w-42'} md:flex-col transition-[width]"
    >
      <!-- Sidebar component, swap this element with another sidebar if you like -->
      <div
        class="flex overflow-y-auto flex-col flex-grow pt-5 bg-white border-r border-gray-200 min-h-svh dark:bg-dark-bg dark:text-white"
      >
        <div class="flex flex-col flex-grow h-full">
          <nav class="flex-1 px-2 pb-4 space-y-6">
            <div
              class="flex gap-1 items-center px-2 text-gray-500 focus:ring-2 focus:ring-inset focus:ring-indigo-500 focus:outline-none"
            >
              <img
                src={logo}
                alt="Dashboard Logo"
                class="w-max-[10px] w-[120px]"
              />
            </div>
            <!-- Current: "bg-gray-100 text-gray-900", Default: "text-gray-900 hover:bg-gray-50 hover:text-gray-900" -->
            {#each sidebarGroups as sidebarGroup}
              <div class="item-group">
                <p
                  class="px-2 py-2 text-sm text-gray-500 {sidebar
                    ? 'hidden'
                    : 'block'} "
                >
                  {sidebarGroup.title}
                </p>
                {#each sidebarGroup.items as item}
                  <a
                    onclick={() => pathChanged(item.path)}
                    href={item.path}
                    class="text-gray-900 dark:text-white {currentPathName === item.path
                      ? 'bg-primary text-white'
                      : 'hover:bg-primary-extra-light hover:border hover:border-primary-dark'} border border-transparent group flex items-center rounded-md px-2 py-2 text-sm"
                  >
                    <svelte:component
                      this={item.icon}
                      class={`mr-3 h-4 w-4 flex-shrink-0 h-5 w-5 ${
                        currentPathName === item.path
                          ? "text-white"
                          : "text-gray-500"
                      }`}
                    />
                    <span class={sidebar ? "hidden" : "block"}>{item.title}</span
                    ></a
                  >
                {/each}
              </div>
            {/each}
          </nav>
        </div>
      </div>
    </div>
    <div class="flex flex-col md:w-[calc(100%-176px)] w-full ">
      <div
        id="toolbar"
        class="flex justify-between items-center px-4 w-full h-16"
      >
      {#if isMobileView}
      <button
        tabindex="0"
        class="flex justify-between items-center px-4 w-full h-16"
        onclick={() => {mobileView = !mobileView}}
        onkeydown={(e) => {e.key === 'Enter' || e.key === ' ' ? (mobileView = !mobileView) : null }}
      >
        <img src={menu} alt="menu" class="w-6" />
      </button>
    {/if}
        <h1 class="px-4 text-2xl font-bold capitalize">{$title}</h1>
        <div class="flex-grow" ></div>
        <div class="flex justify-between px-4">
          <div class="flex items-center ml-4 md:ml-6">
            <div class="relative">
            <button
              type="button"
              onclick={()=>{showNotifications = !showNotifications}}
	            class="p-1 text-gray-400 bg-white rounded-full hover:text-gray-500 dark:bg-dark-bg"
            >
              <span class="sr-only">View notifications</span>
              <svg
                class="w-4 h-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"
                />
              </svg>
            </button>
            {#if (showNotifications)}
               <div
               role="button"
               tabindex="0"
               onclick={() => { showNotifications = false }}
               onkeydown={(e) => e.key === 'Enter' && (showNotifications = false)}
               class="fixed inset-0 z-20">
	               </div>
               <div class="absolute z-[100] rounded p-1 mt-1 w-60 -ml-10">
                 <div class="p-2 rounded border w-fit bg-white dark:bg-dark-bg dark:text-white">
                 Notification 1
                 </div>
                 <div class="p-2 rounded border w-fit bg-white dark:bg-dark-bg dark:text-white">
                 Notification 2
                 </div>
               </div>
               {/if}
             </div>
            <div class="relative ml-3">
              <div class="flex flex-row gap-4 justify-center items-center">
                <button
                  type="button"
                  onclick={() => {showProfileDropdown = !showProfileDropdown}}
                  class="flex items-center max-w-xs text-sm bg-white rounded-full focus:ring-2 focus:ring-offset-2 focus:outline-none focus:ring-primary dark:bg-dark-bg dark:text-white"
                  id="user-menu-button"
                  aria-expanded="false"
                  aria-haspopup="true"
                >
                  <span class="sr-only">Open user menu</span>
                  {#if userData.Image}
                  <img
                    class="w-8 h-8 rounded-full"
                    src={userData.Image}
                    alt=""
                  />
                  {:else}
                  <img
                    class="w-8 h-8 rounded-full"
                    src={ProfileImageUrl ? ProfileImageUrl : IconProfile}
                    alt=""
                  />
                  {/if}
                  <p class="pl-3 pr-2">{VisibleName}</p>
                </button>
              </div>
              {#if showProfileDropdown}
                <div
                  role="button"
                  aria-pressed={showProfileDropdown}
                  onclick={() => {showProfileDropdown = false}}
                  onkeydown={(e) => e.key === 'Enter' || e.key === ' ' ? (showProfileDropdown = false) : null}
                  tabindex="0"
                  class="fixed top-0 left-0 z-20 w-full h-full"
                ></div>
                <div
                  class="absolute right-0 z-10 z-30 py-1 mt-2 w-48 bg-white rounded-md ring-1 ring-black ring-opacity-5 shadow-lg origin-top-right focus:outline-none dark:bg-dark-bg"
                  role="menu"
                  aria-orientation="vertical"
                  aria-labelledby="user-menu-button"
                  tabindex="-1"
                >
                  <a
                    class="block py-2 px-4 text-sm text-gray-700 dark:text-white"
                    href="/app/profile"
                    role="menuitem"
                    tabindex="-1"
                    id="user-menu-item-0"
                  >
                    Your Profile
                  </a>
                  <a
                    class="block py-2 px-4 text-sm text-gray-700 dark:text-white"
                    role="menuitem"
                    tabindex="-1"
                    id="user-menu-item-1"
                  >
                    Settings
                  </a>
                  <div
                    class="block py-2 px-4 text-sm text-gray-700 dark:text-white"
                    role="menuitem"
                    onclick={signout}
                    onkeydown={(e) => e.key === 'Enter' || e.key === ' ' ? signout() : null}
                    tabindex="0"
                  >
                    Sign out
                  </div>
                </div>
              {/if}
            </div>
          </div>
        </div>
      </div>
      <div class="px-4 pt-4  ">
        <slot />
      </div>
    </div>
  </div>

{/if}

