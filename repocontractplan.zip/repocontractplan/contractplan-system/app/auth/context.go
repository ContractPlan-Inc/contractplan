package auth

import (
	"context"

	"github.com/gin-gonic/gin"
	"github.com/kr/pretty"

	"cloudparallax.com/backend/utils"
)

func GinContextToContextMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		ctx := context.WithValue(c.Request.Context(), "GinContextKey", c)
		authorization := c.GetHeader("Authorization")
		if authorization != "" {
			pretty.Println("AUTH:", authorization)
			// 	validate the authorization token
			user, err := ValidateToken(authorization[7:])
			pretty.Println("VALIDATE ERR:", user, err)
			if err == nil {
				ctx = utils.UserWithContext(ctx, user)
				if user.Tenant != "" {
					ctx = utils.TenantWithContext(ctx, user.Tenant)
				}
			}
		}
		c.Request = c.Request.WithContext(ctx)
		c.Next()
	}
}
