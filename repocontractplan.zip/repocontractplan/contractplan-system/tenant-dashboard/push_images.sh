#!/usr/bin/env bash
if [ -z $FRONTEND_REPOSITORY_URL ]; then
  echo "No frontend repository URL provided. Exiting build for Frontend."
  printf "[]" >imagedefinitions.json
  cat imagedefinitions.json
else
  docker image tag contractplan-frontend:latest $FRONTEND_REPOSITORY_URL:latest
  docker image tag contractplan-frontend:latest $FRONTEND_REPOSITORY_URL:$DATE

  echo image url = $FRONTEND_REPOSITORY_URL:latest
  docker push $FRONTEND_REPOSITORY_URL:latest
  docker push $FRONTEND_REPOSITORY_URL:$DATE
  echo Writing image definitions file...
  echo Build completed on
  printf "[{\"name\":\"frontend-service\",\"imageUri\":\"$FRONTEND_REPOSITORY_URL:$DATE\"}]" >frontend-service.imagedefinitions.json
  cat frontend-service.imagedefinitions.json
fi
