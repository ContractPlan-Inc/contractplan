<script lang="ts">
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { type ContractFile, ContractFileUploadDoc, GetContractFilesDoc, type GetContractFilesQuery } from '$lib/generated/graphql';
  import { onMount } from 'svelte';
  import Icon from '@iconify/svelte';
  import Loader from './loader.svelte';

  let {contractId} = $props();
  let fileInput: HTMLInputElement;
  let file: File | null = null;
  let loading = false;
  let error = '';
  let files: ContractFile[] = $state([]);

  async function loadFiles() {
    const queryRepository = new GraphQLQueryRepository<GetContractFilesQuery>();
    try {
      const response = await queryRepository.getItems(GetContractFilesDoc, { id: contractId }, 1, 1);
    //   if (response.error) {
    //     throw new Error(response.error.message);
    //   }
      files = response.data?.getContractFiles || [];
      console.log("files", files);
    } catch (err) {
      console.error("Error loading files:", err);
    }
  }

  // Load files when the component mounts
  onMount(() => {
    if (contractId) {
      loadFiles();
    console.log("contractId", contractId);
    }
  });

  async function handleFileUpload(event: Event) {
    const target = event.target as HTMLInputElement;
    const selectedFile = target?.files?.[0];
    if (!selectedFile) {
      error = "No file selected";
      return;
    }
    file = selectedFile;

    loading = true;
    error = '';

    const queryRepository = new GraphQLQueryRepository<{ contractFileUpload: ContractFile }>();
    try {
      // Get presigned URL from backend
      const response = await queryRepository.updateItem(ContractFileUploadDoc, {
        id: contractId,
        input: {
          Name: file.name,
        }
      });

    //   if (response.error) {
    //     throw new Error(response.error.message);
    //   }

      const presignedUrl = response.data?.contractFileUpload?.SignedUrl;
      if (!presignedUrl) {
        alert("Failed to get upload URL");
        return;
      }

      // Upload file using presigned URL
      const uploadResponse = await fetch(presignedUrl, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type
        }
      });

      if (!uploadResponse.ok) {
        throw new Error(`Upload failed: ${uploadResponse.statusText}`);
      }

      console.log("File uploaded successfully");

      // Clear the input and reload files
      if (fileInput) {
        fileInput.value = '';
      }
      file = null;
      await loadFiles();

    } catch (err) {
      error = err instanceof Error ? err.message : 'Failed to upload file';
      console.error("Error uploading file:", err);
    } finally {
      loading = false;
    }
  }

  function formatDate(dateString: string | null | undefined): string {
    if (!dateString) return '';
    return new Date(dateString).toLocaleString();
  }

  function formatFileSize(size: number): string {
    const units = ['B', 'KB', 'MB', 'GB'];
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  }
</script>

<div class="w-full space-y-4">
  <!-- File List -->
  {#if files.length > 0}
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
      <div class="p-4">
        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Contract Files</h3>
      </div>
      <div class="border-t border-gray-200 dark:border-gray-700">
        <ul class="divide-y divide-gray-200 dark:divide-gray-700">
          {#each files as file}
            <li class="p-4 hover:bg-gray-50 dark:hover:bg-gray-700">
              <div class="flex items-center justify-between">
                <div class="flex items-center min-w-0">
                  <Icon icon="heroicons:document" class="w-5 h-5 text-gray-400" />
                  <div class="ml-3">
                    <p class="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{file.Name}</p>
                    <p class="text-xs text-gray-500 dark:text-gray-400">
                      Uploaded {formatDate(file.UploadedAt)}
                    </p>
                  </div>
                </div>
                {#if file.SignedUrl}
                  <a
                    href={file.SignedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    class="ml-4 flex-shrink-0 text-sm font-medium text-primary-600 hover:text-primary-500"
                  >
                    Download
                  </a>
                {/if}
              </div>
            </li>
          {/each}
        </ul>
      </div>
    </div>
  {/if}

  <!-- Upload Section -->
  <div class="flex items-center justify-center w-full">
    <label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
      {#if loading}
        <Loader loading={true} type="dataLoader" />
      {:else}
        <div class="flex flex-col items-center justify-center pt-5 pb-6">
          <Icon icon="heroicons:cloud-arrow-up" class="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" />
          <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
            <span class="font-semibold">Click to upload</span> or drag and drop
          </p>
          <p class="text-xs text-gray-500 dark:text-gray-400">Any file type allowed</p>
        </div>
      {/if}
      <input 
        bind:this={fileInput}
        id="dropzone-file" 
        type="file" 
        class="hidden" 
        on:change={handleFileUpload}
      />
    </label>
  </div>
  {#if error}
    <p class="mt-2 text-sm text-red-600 dark:text-red-500">{error}</p>
  {/if}
</div> 