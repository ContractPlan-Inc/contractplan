<script lang="ts">
  import type { Plan } from '$lib/generated/graphql';
  import { createEventDispatcher } from 'svelte';


  function handleSelect() {
    console.log('clicked', plan.ID);
    dispatchEvent('planSelected', plan.ID);
  }

  const dispatchEvent = createEventDispatcher();

  interface PlanProps {
    plan: Plan;
    selected?: Boolean;
    isCurrentPlan?: Boolean;

  }

  let { plan, selected, isCurrentPlan } = $props<PlanProps>();

</script>

<div class=" border  bg-slate-50 rounded-md p-3 flex  justify-between ">
  <div>
    <p>Subscribe now for</p>
    <p class="  text-primary text-2xl font-bold">${+plan.Price / 100}<span
      class=" font-light text-gray-500 text-sm">/{plan.Period}</span></p>
    <ul>
      {#each plan.Features as feature }
        <li class=" text-sm text-gray-500">{feature}</li>
      {/each}
    </ul>
  </div>


  {#if isCurrentPlan}
    <div class=" flex items-start ">
      <span class="  bg-green-400 text-xs  px-2 py-1 rounded-md ">Current Plan</span>
    </div>
  {:else}
    <div class=" flex items-center">
      <button type="button"
              class=" {selected ? ' bg-primary border-primary' : 'border-gray-500'} text-sm border px-4 py-2 rounded-md"
              onclick={handleSelect}>{selected ? 'Selected' : 'Select'}</button>
    </div>
  {/if}


</div>
