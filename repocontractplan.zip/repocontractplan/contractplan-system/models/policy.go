package models

import "strings"

type Access bool
type Resource int
type Action int

const (
	DENY  Access = false
	ALLOW Access = true
)

const (
	CONTRACT Resource = iota
	HOLIDAY
	ENGAGEMENT
)

var (
	ResourceMap = map[string]Resource{
		"CONTRACT":   CONTRACT,
		"HOLIDAY":    HOLIDAY,
		"ENGAGEMENT": ENGAGEMENT,
	}
)

func GetResource(str string) (Resource, bool) {
	c, ok := ResourceMap[strings.ToLower(str)]
	return c, ok
}

const (
	CREATE Action = iota
	READ
	UPDATE
	DELETE
)

type Policy struct {
	DynamoDBModel
	ID          string `dynamodbav:"a, omitempty"`
	Name        string
	For         string
	Grant       string
	Resources   []Resource
	ResourceIDs []string
	Actions     []Action
	Effect      Access
	Description string
	CreatedAt   string
	UpdatedAt   string
}

func NewPolicy() Policy {
	return Policy{
		Effect: DENY, // Default to "Deny"
	}
}
