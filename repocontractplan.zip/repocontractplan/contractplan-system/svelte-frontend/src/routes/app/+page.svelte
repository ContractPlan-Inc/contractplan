<script lang="ts">
  import Card from "$lib/components/charts/card/card.svelte";
  import icon1 from "$lib/assets/svg/menu-burger.svg";
  import Bar from "$lib/components/charts/bar/bar.svelte";
  import Line from "$lib/components/charts/line/line.svelte";
  import {
    GetAllSummaryDoc,
    GetContractsDoc,
    GetTenantContractSummaryDoc,
    GetContractPartnersDoc,
    GetContracts,
    GetSummaryDoc,
    getAllSummary,
    type GetAllSummaryQuery,
    type GetContractPartnersQuery,
    type GetSummaryQuery, type GetTenantContractSummaryQuery, type ContractPartner, type Contract
  } from '$lib/generated/graphql';
  import Icon from "@iconify/svelte";
  import ChartLabel from "$lib/components/elements/chartLabel.svelte";
  import { authError, title } from "$lib/state/store";
  import { onMount } from "svelte";
  import { getCurrentPlan } from "../auth/signin/service";
  import { goto } from "$app/navigation";
  import CommonChart from "$lib/components/charts/commonChart.svelte";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import dayjs from "dayjs";
  import { load } from "./+layout";
  import Loader from "$lib/components/elements/loader.svelte";
  import TableComponent from "../../routes/app/contract/TableComponent.svelte";
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import { getContext } from "svelte";
  import BulkDayRecord from '$lib/components/elements/BulkDayRecord.svelte';

  // selected chart type for Revenue Overview
  let chartType = $state("bar");
  let loading = $state(false);
  let engagementsType = $state("month");
  let engagementsResult = $state();
  let summaryRecords = $state([]);
  let summaryTotal = $state([]);
  let contracts = $state([])
  let partners = $state([])
  let BulkRecordPop = $state(false);
  let selectedYear = $state(dayjs().year());
  let showYearDropdown = $state(false);
  let dropdownRef: HTMLDivElement;

  function handleClickOutside(event: MouseEvent) {
    if (dropdownRef && !dropdownRef.contains(event.target as Node)) {
      showYearDropdown = false;
    }
  }

  $effect(() => {
    if (showYearDropdown) {
      document.addEventListener('click', handleClickOutside);
    }
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  });

  // Get unique years from summary records
  let availableYears = $derived(
    [...new Set(summaryRecords.map(record => 
      dayjs(record.key_as_string).year()
    ))].sort((a, b) => b - a)
  );

  let contractQueryRepository = new GraphQLQueryRepository<Contract>();
  let partnersQueryRepository = new GraphQLQueryRepository<ContractPartner>();
  const queryRepository = new GraphQLQueryRepository<GetTenantContractSummaryQuery>();

  onMount(async () => {
    $title = "Dashboard";

    const currentPlan = await getCurrentPlan();
    if (currentPlan === null || currentPlan === undefined) {
      authError.set("PlanNotSelected");
      goto("/auth/registration");
    } else {
      goto("/app/");
    }
  });

  $effect(async () => {
    loading = true;
    engagementsResult = await queryRepository.getItems(
            GetTenantContractSummaryDoc,
            {
              Type: engagementsType,
              EndDate: dayjs().format('YYYY-MM-DD')
            }, 1, 1
    ).then((result) => {
      console.log("result", result);
      return result
    }).catch((e) => {
      console.log("Error", e);
    }).finally(() => {
      loading = false
    });

    summaryRecords = engagementsResult.data?.getTenantContractSummary
            ?.SummaryRecords;
    summaryTotal = engagementsResult.data?.getTenantContractSummary
            ?.SummaryTotal;
    console.log("Summary Records *", summaryRecords)
    console.log("Summary Total", summaryTotal)

    contracts = await (await contractQueryRepository.getItems(
            GetContractsDoc,
    )).data.listContracts.edges;

    partners = (await partnersQueryRepository.getItems(
            GetContractPartnersDoc,
    )).data.listContractPartnersDDB.edges

  });
</script>

<BulkDayRecord pop={BulkRecordPop}/>
<div
  class="gap-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 dark:text-white "
>
  <Card
    Icon={icon1}
    Title="Total Revenue"
    Value={isNaN(summaryTotal?.engagement_cost?.sum) ? 0 : summaryTotal?.engagement_cost?.sum/100.0}
    CurrencyPrefix=true
  />
  <Card
    Icon={icon1}
    Title="Total Contracts"
    Value={Object.keys(contracts).length ?? 0}
  />
  <Card
    Icon={icon1}
    Title="Total Partners"
    Value={Object.keys(partners).length ?? 0}
  />
</div>
<!------------- Revenue Overview Chart ------------->
<div class="flex justify-between pt-4">
  <div>
    <h2 class="text-xl dark:text-white">Revenue overview</h2>
    {#if summaryRecords.length > 0}
    <h3 class="text-gray-500 text-sm">{dayjs(summaryRecords[0].key_as_string).format('MMM YYYY')}- {dayjs(summaryRecords[summaryRecords.length-1].key_as_string).format('MMM YYYY')}</h3>
      {/if}
  </div>
  <div class=" inline-flex gap-6">
    <div class=" border p-1 rounded-md bg-gray-200 dark:bg-dark-bg">
      <button
        class="py-2 px-3 rounded-md {chartType === 'bar' ? 'bg-white shadow-md' : ''}"
        onclick={(event) => {
          event.preventDefault();
          chartType = "bar";
          console.log("chartType", chartType);
        }}
      >
        <Icon icon="humbleicons:chart" width="25" />
      </button>

      <button
        class="py-2 px-3 rounded-md {chartType === 'line' ? 'bg-white shadow-md' : ''}"
        onclick={(event) => {
          event.preventDefault();
          chartType = "line";
          console.log("chartType", chartType);
        }}
      >
        <Icon icon="bx:line-chart" width="25" />
      </button>
    </div>
    <button
      class="border py-2 px-4 text-sm inline-flex gap-2 items-center rounded-md dark:text-white relative"
      onclick={(event) => {
        event.stopPropagation();
        showYearDropdown = !showYearDropdown;
      }}
    >
      <Icon icon="bx:calendar" width="18" />
      {selectedYear}
      {#if showYearDropdown}
        <div 
          bind:this={dropdownRef}
          class="absolute top-full right-0 mt-1 bg-white dark:bg-dark-bg border rounded-md shadow-lg z-10"
          onclick={(event) => event.stopPropagation()}
        >
          {#each availableYears as year}
            <button
              class="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 {selectedYear === year ? 'bg-gray-100 dark:bg-gray-700' : ''}"
              onclick={(event) => {
                event.stopPropagation();
                selectedYear = year;
                showYearDropdown = false;
              }}
            >
              {year}
            </button>
          {/each}
        </div>
      {/if}
    </button>
  </div>
</div>
<div class=" flex gap-6 items-center">
  <ChartLabel
    color="black"
    key="Planned"
    pretext="$"
    value={isNaN(summaryTotal?.target_engagement_cost?.sum) ? 0 : (summaryTotal?.target_engagement_cost?.sum / 100.0).toFixed(2)}
  />
  <ChartLabel
    color="primary"
    key="Actual"
    pretext="$"
    value={isNaN(summaryTotal?.engagement_cost?.sum) ? 0 : (summaryTotal?.engagement_cost?.sum / 100.0).toFixed(2)}
  />
</div>
<!--
actualData={summaryRecords.map(o => o.engagement_cost?.sum )}
plannedData={summaryRecords.map(o => o.target_engagement_cost?.sum )} -->
<div class="">
  {#if loading}
    <Loader loading={true} type="dataLoader" />
  {:else}
    <CommonChart
      ID="1"
      chartType={chartType}
      actualData={summaryRecords
        .filter(o => dayjs(o.key_as_string).year() === selectedYear)
        .map(o => o.engagements.sum)}
      plannedData={summaryRecords
        .filter(o => dayjs(o.key_as_string).year() === selectedYear)
        .map(o => o.target_engagements.sum)}
      labels={summaryRecords
        .filter(o => dayjs(o.key_as_string).year() === selectedYear)
        .map(o => {
          const format = engagementsType === 'month' ? 'MMM' : 'MMM DD'
          return dayjs(o.key_as_string).format(format)
        })}
      plannedColor='#000'
      actualColor='#FF914D'
    />
  {/if}
  <div class="pt-10">
    <TableComponent>
      <!-- <AddNewButton btnText="Today Record" onclick={()=>{TodayRecordPop = !TodayRecordPop}} openAsPopup={true} /> -->
      <AddNewButton btnText="Bulk Day Record" onclick={()=>{BulkRecordPop = !BulkRecordPop; console.log('pop',BulkRecordPop)}} openAsPopup={true} />
    </TableComponent>
  </div>
</div>
