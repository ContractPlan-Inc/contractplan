package config

import (
	"os"
)

// gC grabs the application configuration using beego method
func GC(conf string, defaultString ...string) string {
	result := os.Getenv(conf)
	if len(result) <= 0 && len(defaultString) > 0 {
		return defaultString[0]
	}
	return result
}

func EnvVariable(conf string, defaultString ...string) string {
	if os.Getenv(conf) != "" {
		return os.Getenv(conf)
	}
	if len(defaultString) > 0 {
		return defaultString[0]
	}
	return ""
}
