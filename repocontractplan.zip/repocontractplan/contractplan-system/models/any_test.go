package models

import (
	"context"
	"reflect"
	"testing"
)

func TestGetAModelFromDDB(t *testing.T) {
	type args[F Model] struct {
		ctx          context.Context
		v            F
		recordType   string
		searchType   string
		GSIOverloads []string
	}
	type testCase[F Model] struct {
		name     string
		args     args[F]
		wantItem *F
		wantErr  bool
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotItem, err := GetAModelFromDDB(tt.args.ctx, tt.args.v, tt.args.recordType, tt.args.searchType, tt.args.GSIOverloads...)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetAModelFromDDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotItem, tt.wantItem) {
				t.Errorf("GetAModelFromDDB() gotItem = %v, want %v", gotItem, tt.wantItem)
			}
		})
	}
}

func TestGetControllerRecordsFromDDB(t *testing.T) {
	type args[F Model] struct {
		ctx        context.Context
		record     F
		recordType string
		query      map[string]interface{}
		pagination DynamoLastEvaluatedKey
		limit      int64
		index      string
		searchType string
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		want    []*F
		want1   *DynamoLastEvaluatedKey
		wantErr bool
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, err := GetControllerRecordsFromDDB(tt.args.ctx, tt.args.record, tt.args.recordType, tt.args.query, tt.args.pagination, tt.args.limit, tt.args.index, tt.args.searchType, true)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetControllerRecordsFromDDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetControllerRecordsFromDDB() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("GetControllerRecordsFromDDB() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestGetModelByIDFromDDB(t *testing.T) {
	type args[F ModelConstraint] struct {
		ctx        context.Context
		v          F
		recordType string
		index      []string
	}
	type testCase[F ModelConstraint] struct {
		name     string
		args     args[F]
		wantItem *F
		wantErr  bool
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotItem, err := GetModelByIDFromDDB(tt.args.ctx, tt.args.v, tt.args.recordType, tt.args.index...)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetModelByIDFromDDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotItem, tt.wantItem) {
				t.Errorf("GetModelByIDFromDDB() gotItem = %v, want %v", gotItem, tt.wantItem)
			}
		})
	}
}

func TestGetModelsFromDDB(t *testing.T) {
	type args[F Model] struct {
		ctx          context.Context
		v            F
		recordType   string
		limit        int
		pagination   *DynamoLastEvaluatedKey
		searchType   string
		gsiOverloads []string
	}
	type testCase[F Model] struct {
		name    string
		args    args[F]
		want    []*F
		want1   *DynamoLastEvaluatedKey
		wantErr bool
	}
	tests := []testCase[any]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, err := GetModelsFromDDB(tt.args.ctx, tt.args.v, tt.args.recordType, tt.args.limit, tt.args.pagination, tt.args.searchType, true, tt.args.gsiOverloads...)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetModelsFromDDB() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetModelsFromDDB() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("GetModelsFromDDB() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestGetMultipleModelPairs(t *testing.T) {
	type args[F ModelConstraint] struct {
		ctx        context.Context
		v          []F
		recordType string
	}
	type testCase[F ModelConstraint] struct {
		name      string
		args      args[F]
		wantItems []*F
		wantErr   bool
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotItems, err := GetMultipleModelPairs(tt.args.ctx, tt.args.v, tt.args.recordType)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetMultipleModelPairs() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotItems, tt.wantItems) {
				t.Errorf("GetMultipleModelPairs() gotItems = %v, want %v", gotItems, tt.wantItems)
			}
		})
	}
}

func TestQueryConverter(t *testing.T) {
	type args[F Model] struct {
		query        map[string]interface{}
		orderObjectF F
	}
	type testCase[F Model] struct {
		name string
		args args[F]
		want F
	}
	tests := []testCase[anyModel]{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := QueryConverter(tt.args.query, tt.args.orderObjectF); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("QueryConverter() = %v, want %v", got, tt.want)
			}
		})
	}
}
