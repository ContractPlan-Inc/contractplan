<script lang="ts">
  import DragAndDrop from '$lib/components/dragAndDrop/dragAndDrop.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import newContracts from '$lib/mock/newContracts.json';
  import type { Column } from '$lib/components/table/table.svelte';
  import Table from '$lib/components/table/table.svelte';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import type { Contract } from '$lib/generated/graphql';
  import { GetContractsDoc } from '$lib/generated/graphql';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import editIcon from '$lib/assets/svg/edit.svg';
  import dashboardIcon from '$lib/assets/svg/dashboard.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { goto } from '$app/navigation';
  import { title } from '$lib/state/store';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import TableComponent from './TableComponent.svelte'
  import PartnerComponent from '$lib/components/elements/PartnerComponent.svelte';
  import BulkDayRecord from '$lib/components/elements/BulkDayRecord.svelte';
  // import TodayRecord from '$lib/components/elements/TodayRecord.svelte';

  title.set('Contracts');

  let id = 0;
  let columnsData = $state(newContracts);
  let TodayRecordPop = $state(false);
  let BulkRecordPop = $state(false);

  function handleBoardUpdated(newColumnsData: any) {
    // if you wanted to update a database or a server, this is where you would do it
    // console.log("handleBoardUpdated from page")
    columnsData = newColumnsData;
  }

  let tableView = true;
  let handleContractStatus = false;
</script>

<!--{#if id !==  || newTask}-->
<!--    <div class="absolute w-full md:w-[calc(100%_-_280px)] z-20  h-[calc(100%_-_100px)] bg-black/20"-->
<!--         onclick={() => show = false} onclick={() => myStore.set(0)} onclick={() => newTask = false}></div>-->
<!--{/if}-->
<PageHeader />

<!-- <TodayRecord pop={TodayRecordPop}/> -->
<BulkDayRecord pop={BulkRecordPop}/>
<PageBody>
  {#if tableView}
    <TableComponent>
      <!-- <AddNewButton btnText="Today Record" onclick={()=>{TodayRecordPop = !TodayRecordPop}} openAsPopup={true} /> -->
      <AddNewButton btnText="Bulk Day Record" onclick={()=>{BulkRecordPop = !BulkRecordPop; console.log('pop',BulkRecordPop)}} openAsPopup={true} />
      <AddNewButton btnText="New Contract" path="/app/contract/create" />
    </TableComponent>
  {:else}
    <DragAndDrop
      columns={columnsData}
      onFinalUpdate={handleBoardUpdated}
      on:contractStatus={handleContractStatus}
    />
  {/if}
</PageBody>
