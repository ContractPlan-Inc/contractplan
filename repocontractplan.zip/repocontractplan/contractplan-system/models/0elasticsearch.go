package models

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"reflect"
	"strings"
	"time"

	"github.com/beego/beego/v2/core/logs"
	"github.com/kr/pretty"
	opensearch2 "github.com/opensearch-project/opensearch-go/v2"
	"github.com/opensearch-project/opensearch-go/v2/opensearchapi"
	"golang.org/x/text/cases"
	"golang.org/x/text/language"

	"cloudparallax.com/backend/services/aws/opensearch"
	"cloudparallax.com/backend/utils"
)

type OpenSearchCount struct {
	Count int `json:"count"`
}
type Aggregate[T Bucket] struct {
	Value        interface{}             `json:"value,omitempty"`
	Buckets      []*T                    `json:"buckets,omitempty"`
	Aggregations map[string]Aggregate[T] `json:"aggregations,omitempty"`
}

type OpenSearchResult[T Bucket] struct {
	Took         int                     `json:"took"`
	TimedOut     bool                    `json:"timed_out"`
	Shards       Shards                  `json:"_shards"`
	Hits         Hits                    `json:"hits"`
	Aggregations map[string]Aggregate[T] `json:"aggregations"`
}
type Shards struct {
	Total      int `json:"total"`
	Successful int `json:"successful"`
	Skipped    int `json:"skipped"`
	Failed     int `json:"failed"`
}
type Total struct {
	Value    int    `json:"value"`
	Relation string `json:"relation"`
}
type HitItem struct {
	Index  string                 `json:"_index"`
	Type   string                 `json:"_type"`
	ID     string                 `json:"_id"`
	Score  float64                `json:"_score"`
	Source map[string]interface{} `json:"_source"`
}
type Hits struct {
	Total    Total     `json:"total"`
	MaxScore float64   `json:"max_score"`
	Hits     []HitItem `json:"hits"`
}
type SortOrder struct {
	Order string `json:"order"`
}
type (
	Sort map[string]SortOrder
	Sum  struct {
		Field string `json:"field,omitempty"`
	}
	Stat struct {
		Field string `json:"field,omitempty"`
	}
)
type Avg struct {
	Field string `json:"field,omitempty"`
}
type AggregationsMap map[string]*Aggregation
type DateHistogram struct {
	Field    string `json:"field,omitempty"`
	Interval string `json:"interval,omitempty"`
}
type SummaryCurrencyResult struct {
	DocCountErrorUpperBound int `json:"doc_count_error_upper_bound"`
	SumOtherDocCount        int `json:"sum_other_doc_count"`
	Buckets                 []struct {
		Key      string `json:"key"`
		DocCount int    `json:"doc_count"`
	} `json:"buckets"`
}

// UnmarshalGQL implements the graphql.Unmarshaler interface
func (y SummaryCurrencyResult) UnmarshalGQL(v interface{}) error {
	if err := json.Unmarshal(v.([]byte), &y); err != nil {
		return err
	}
	return nil
}

// MarshalGQL implements the graphql.Marshaler interface
func (y SummaryCurrencyResult) MarshalGQL(w io.Writer) {
	actualCurrency := ""
	if len(y.Buckets) > 0 {
		actualCurrency = y.Buckets[0].Key
	}
	if out, err := json.Marshal(actualCurrency); err == nil {
		_, err := w.Write(out)
		if err != nil {
			panic(err)
		}
	} else {
		_, err := w.Write([]byte(``))
		panic(err)
	}
}

type Aggregation struct {
	Sum           *Sum             `json:"sum,omitempty"`
	Stats         *Stat            `json:"stats,omitempty"`
	ExtendedStats *Stat            `json:"extended_stats,omitempty"`
	Avg           *Avg             `json:"avg,omitempty"`
	Terms         *AggregateTerm   `json:"terms,omitempty"`
	Aggregations  *AggregationsMap `json:"aggs,omitempty"`
	DateHistogram *DateHistogram   `json:"date_histogram,omitempty"`
}
type ElasticQueryRaw map[string]interface{}

// UnmarshalGQL implements the graphql.Unmarshaler interface
func (y ElasticQueryRaw) UnmarshalGQL(v interface{}) error {
	if err := json.Unmarshal(v.([]byte), &y); err != nil {
		return err
	}
	return nil
}

// MarshalGQL implements the graphql.Marshaler interface
func (y ElasticQueryRaw) MarshalGQL(w io.Writer) {
	if out, err := json.Marshal(y); err == nil {
		_, err := w.Write(out)
		if err != nil {
			panic(err)
		}
	} else {
		_, err := w.Write([]byte(``))
		panic(err)
	}
}

type ElasticQuery struct {
	Query        *Query                  `json:"query,omitempty"`
	Sort         []Sort                  `json:"sort,omitempty"`
	Aggregations map[string]*Aggregation `json:"aggs,omitempty"`
}
type (
	Match       map[string]interface{}
	QueryString struct {
		Query        string   `json:"query,omitempty"`
		DefaultField string   `json:"default_field,omitempty"`
		Fields       []string `json:"fields,omitempty"`
	}
)
type Matcher struct {
	Match       Match            `json:"match,omitempty"`
	QueryString *QueryString     `json:"query_string,omitempty"`
	Range       map[string]Range `json:"range,omitempty"`
	Bool        *Bool            `json:"bool,omitempty"`
	MatchPhrase Match            `json:"match_phrase,omitempty"`
	Term        Term             `json:"term,omitempty"`
}
type (
	Term          map[string]string
	Terms         map[string][]string
	AggregateTerm struct {
		Field string `json:"field"`
	}
)
type Filter struct {
	Term  *Term  `json:"term,omitempty"`
	Terms *Terms `json:"terms,omitempty"`
	Match *Match `json:"match,omitempty"`
}
type Bool struct {
	Must               []Matcher `json:"must,omitempty"`
	Should             []Matcher `json:"should,omitempty"`
	MustNot            []Matcher `json:"must_not,omitempty"`
	Filter             *Filter   `json:"filter,omitempty"`
	MinimumShouldMatch int       `json:"minimum_should_match,omitempty"`
}
type Range struct {
	GreaterThanOrEqual string `json:"gte,omitempty"`
	LessThanOrEqual    string `json:"lte,omitempty"`
	LessThan           string `json:"lt,omitempty"`
	GreaterThan        string `json:"gt,omitempty"`
}
type Query struct {
	QueryString string            `json:"query_string,omitempty"`
	Match       *Match            `json:"match,omitempty"`
	Bool        *Bool             `json:"bool,omitempty"`
	Filter      *Filter           `json:"filter,omitempty"`
	Range       map[string]*Range `json:"range,omitempty"`
	Term        *Term             `json:"term,omitempty"`
}

//func SearchQueryCached[T Model](ctx context.Context, cachedId string, cacheKey string, ttl time.Duration, v T, index string, query map[string]interface{}, sort map[string]string, size, offset int) ([]T, error) {
//	redisLink := cache.UniversalRedis()
//	list := make([]T, 0)
//	if exists, errR := redisLink.Exists(ctx, cacheKey+cachedId).Result(); errR == nil && exists > 0 {
//		byteList, _ := redisLink.Get(ctx, cacheKey+cachedId).Bytes()
//		if err := json.Unmarshal(byteList, &list); err == nil {
//			redisLink.Expire(ctx, cacheKey+cachedId, ttl*time.Second)
//			return list, nil
//		} else {
//			redisLink.Expire(ctx, cacheKey+cachedId, 0)
//			return nil, err
//		}
//	} else {
//		logs.Debug(errR)
//	}
//	if err, vp, _ := SearchQuery(ctx, v, index, query, sort, size, offset, nil); err == nil {
//		if byteList, err := json.Marshal(vp); err == nil {
//			redisLink.Set(ctx, cacheKey+cachedId, byteList, ttl*time.Second)
//			if err = json.Unmarshal(byteList, &list); err == nil {
//				return list, nil
//			} else {
//				return nil, err
//			}
//		} else {
//			return nil, err
//		}
//	} else {
//		return nil, err
//	}
//}

type ContractResult struct {
	KeyAsString string `json:"key_as_string,omitempty"`
	Key         int    `json:"key,omitempty"`
	DocCount    int    `json:"doc_count,omitempty"`
	TargetSums  struct {
		Value float64 `json:"value"`
	} `json:"target_engagement_cost"`
}
type ContractResult2 struct {
	KeyAsString string `json:"key_as_string,omitempty"`
	Key         int    `json:"key,omitempty"`
	DocCount    int    `json:"doc_count,omitempty"`
	TargetSumsD struct {
		Value float64 `json:"value"`
	} `json:"target_engagement_cost"`
}

func (c ContractResult) GetKey() string {
	return c.KeyAsString
}
func (c ContractResult) GetDocCount() int {
	return c.DocCount
}
func (c ContractResult2) GetKey() string {
	return c.KeyAsString
}
func (c ContractResult2) GetDocCount() int {
	return c.DocCount
}

type AggregationResult interface {
	ContractResult
}

func SearchQuery[F Model, T Bucket](ctx context.Context, searchFor F, aggr T, index string, query map[string]interface{}, sort map[string]string, size, offset int, aggregates map[string]string) (error, []*F, map[string]interface{}) {
	searchQuery := extractQuery(query, sort, searchFor, aggregates)
	client, err := opensearch.NewClient()
	if err != nil {
		return err, nil, nil
	}
	if os.Getenv("SHOWQUERY") == "1" {
		fmt.Println(string(searchQuery))
		// pretty.Println("ERR", err)
	}
	pretty.Println("AGAINST: ", utils.GetTenant(ctx)+"-"+index+"*", "for", searchQuery)
	caser := cases.Lower(language.English)
	searchRequest := opensearchapi.SearchRequest{
		Index: []string{caser.String(index)},
		Body:  bytes.NewReader(searchQuery),
		Size:  IntToPointer(size),
		From:  IntToPointer(offset),
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println("SEARCH REQUEST", searchRequest)
	}
	timing := time.Now()
	searchResponse, err := searchRequest.Do(ctx, client)
	if err != nil {
		// pretty.Println("ELASTIC SEARCH ERROR:", err)
		return err, nil, nil
	}
	body, err := io.ReadAll(searchResponse.Body)
	resultMap := OpenSearchResult[T]{}
	json.Unmarshal(body, &resultMap)
	var results = make([]*F, len(resultMap.Hits.Hits))
	for i, hit := range resultMap.Hits.Hits {
		var result F
		item, err := json.Marshal(hit.Source)
		json.Unmarshal(item, &result)
		if os.Getenv("SHOWQUERY") == "1" {
			pretty.Println("ITEM", string(item))
			pretty.Println("RESULT", result)
		}
		if err != nil {
			pretty.Println("UNMARSHAL ERR", err)
		}
		results[i] = &result
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println("RESULT", len(results))
	}
	aggregatesResult := make(map[string]interface{})
	for key, agg := range resultMap.Aggregations {
		aggregatesResult[key] = agg
	}
	logs.Debug(pretty.Sprint("ELASTIC SEARCH TIME:", time.Since(timing).Milliseconds()))
	return err, results, aggregatesResult
}
func DeleteByRequestQuery[F Model](ctx context.Context, searchFor F, query map[string]interface{}) error {
	searchQuery := extractQuery(query, nil, searchFor, nil)
	client, err := opensearch.NewClient()
	if err != nil {
		return err
	}
	if os.Getenv("SHOWQUERY") == "1" {
		fmt.Println(string(searchQuery))
	}
	pretty.Println("AGAINST: ", utils.GetTenant(ctx), "for", searchQuery)
	caser := cases.Lower(language.English)
	deleteByQueryRequest := opensearchapi.DeleteByQueryRequest{
		Index: []string{caser.String(utils.GetTenant(ctx))},
		Body:  bytes.NewReader(searchQuery),
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println("SEARCH REQUEST", deleteByQueryRequest)
	}
	searchResponse, err := deleteByQueryRequest.Do(ctx, client)
	if err != nil {
		return err
	}
	if _, err := io.ReadAll(searchResponse.Body); err != nil {
		return err
	}
	return nil
}
func CountQuery(ctx context.Context, index string, query map[string]interface{}) (int, error) {
	searchQuery := extractQuery(query, nil, BlankModel{}, nil)
	client, err := opensearch.NewClient()
	if err != nil {
		return 0, err
	}
	searchRequest := opensearchapi.CountRequest{
		Index: []string{index},
		Body:  bytes.NewReader(searchQuery),
	}
	searchResponse, _ := searchRequest.Do(ctx, client)
	body, err := io.ReadAll(searchResponse.Body)
	resultMap := OpenSearchCount{}
	json.Unmarshal(body, &resultMap)
	return resultMap.Count, err
}

func extractQuery[F Model](query map[string]interface{}, sortMap map[string]string, model F, aggregates map[string]string) []byte {
	search := ""
	if _, ok := query["search"]; ok {
		search = query["search"].(string)
	}
	pretty.Println("QUERY", query)
	elasticQuery := ElasticQuery{}
	for k, v := range query {
		if k != "search" {
			k := strings.Replace(k, "Array", "", -1)
			k = strings.Replace(k, "Id.Id", "Id", -1)
			k = strings.Replace(k, ".Id", "Id", -1)
			switch v.(type) {
			case nil:
				elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{MatchPhrase: Match{k: "NULL"}})
			case string:
				if _, ok := query[k+"Array"]; ok {
					continue
				}
				if elasticQuery.Query == nil {
					elasticQuery.Query = &Query{}
				}
				if elasticQuery.Query.Bool == nil {
					elasticQuery.Query.Bool = &Bool{}
				}
				if elasticQuery.Query.Bool.Must == nil {
					elasticQuery.Query.Bool.Must = []Matcher{}
				}
				if elasticQuery.Query.Bool.Should == nil {
					elasticQuery.Query.Bool.Should = []Matcher{}
				}
				if strings.HasSuffix(k, "contains") {
					kSplit := strings.Split(k, "__")
					qS := &QueryString{
						Query:  "*" + v.(string) + "*",
						Fields: []string{kSplit[0]},
					}
					elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{QueryString: qS})
				} else if strings.HasSuffix(k, "exact") {
					kSplit := strings.Split(k, "__")
					elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{Term: Term{kSplit[0] + ".keyword": v.(string)}})
				} else if strings.HasSuffix(k, "gte") {
					kSplit := strings.Split(k, "__")
					elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{Range: map[string]Range{kSplit[0]: {GreaterThanOrEqual: v.(string)}}})
				} else if strings.HasSuffix(k, "lte") {
					kSplit := strings.Split(k, "__")
					elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{Range: map[string]Range{kSplit[0]: {LessThanOrEqual: v.(string)}}})
				} else {
					elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{MatchPhrase: Match{k: v.(string)}})
				}
			case []string:
				// append to should inside boolElastic inside must
				boolElastic := Bool{}
				boolElastic.Should = []Matcher{}
				boolElastic.Must = []Matcher{}
				arr_len := len(v.([]string))
				if strings.Contains(k, "Date") && arr_len >= 2 {
					lastV := v.([]string)[arr_len-1]
					// pretty.Println("DATE RANGE", v.([]string))
					boolElastic.Must = append(boolElastic.Must, Matcher{
						Range: map[string]Range{
							k: {
								GreaterThanOrEqual: v.([]string)[0],
								LessThanOrEqual:    lastV,
							},
						},
					})
					// boolElastic.Must = append(boolElastic.Must, Matcher{
					// 	Range: map[string]Range{
					// 		k: {
					// 			GreaterThanOrEqual: strings.Split(v.([]string)[0], "T")[0],
					// 			LessThanOrEqual:    strings.Split(lastV, "T")[0],
					// 		},
					// 	},
					// })
				} else {
					for _, v := range v.([]string) {
						boolElastic.Should = append(boolElastic.Should, Matcher{MatchPhrase: Match{k: v}})
					}
				}

				if elasticQuery.Query == nil {
					elasticQuery.Query = &Query{}
				}
				if elasticQuery.Query.Bool == nil {
					elasticQuery.Query.Bool = &Bool{}
				}
				if elasticQuery.Query.Bool.Must == nil {
					elasticQuery.Query.Bool.Must = []Matcher{}
				}
				elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{Bool: &boolElastic})
			}
		}
	}
	if search != "" {

		if elasticQuery.Query == nil {
			elasticQuery.Query = &Query{}
		}
		if elasticQuery.Query.Bool == nil {
			elasticQuery.Query.Bool = &Bool{}
		}
		if elasticQuery.Query.Bool.Must == nil {
			elasticQuery.Query.Bool.Must = []Matcher{}
		}
		elasticQuery.Query.Bool.Must = append(elasticQuery.Query.Bool.Must, Matcher{QueryString: &QueryString{Query: "*" + search + "*"}})
	}
	if sortMap != nil {
		if elasticQuery.Sort == nil {
			elasticQuery.Sort = []Sort{}
		}
	main:
		for k, v := range sortMap {
			splitK := strings.Split(k, ".")
			reflectVal := reflect.ValueOf(model)
			// pretty.Println(splitK)
			for _, v := range splitK {
				if !reflectVal.IsValid() {
					continue main
				}
				if reflectVal.Kind() == reflect.Ptr {

					// pretty.Println(reflectVal.Kind().String())
					// pretty.Println(reflectVal.IsValid())
					// pretty.Println(reflectVal.IsNil())
					// pretty.Println(reflectVal.IsZero())

					if reflectVal.IsNil() || reflectVal.IsZero() {
						reflectVal = reflect.New(reflectVal.Type().Elem())
					}
					reflectVal = reflectVal.Elem()
				}
				reflectVal = reflectVal.FieldByName(v)
			}
			if reflectVal.Kind() == reflect.String {
				elasticQuery.Sort = append(elasticQuery.Sort, Sort{k + ".keyword": SortOrder{Order: v}})
			} else if reflectVal.Type() == reflect.TypeOf(Money{}) {
				elasticQuery.Sort = append(elasticQuery.Sort, Sort{k + ".amount": SortOrder{Order: v}})
			} else {
				elasticQuery.Sort = append(elasticQuery.Sort, Sort{k: SortOrder{Order: v}})
			}
		}
	}
	for v, k := range aggregates {
		if elasticQuery.Aggregations == nil {
			elasticQuery.Aggregations = map[string]*Aggregation{}
		}
		aggregation := Aggregation{}
		switch k {
		case "sum":
			aggregation.Sum = &Sum{Field: v}
			break
		case "avg":
			aggregation.Avg = &Avg{Field: v}
			break
		case "bucket_count":
			aggregation.Terms = &AggregateTerm{Field: v + ".keyword"}
		}
		elasticQuery.Aggregations[v] = &aggregation
	}
	if os.Getenv("SHOWQUERY") == "1" {
		pretty.Println(elasticQuery)
	}
	searchQuery, _ := json.Marshal(elasticQuery)
	return searchQuery
}

func IntToPointer(i int) *int {
	return &i
}

func InsertIndexIntoOS[F Model](index, modelId string, model F, openSearchClient *opensearch2.Client, oldindex string) error {
	caser := cases.Lower(language.English)
	pretty.Println("INSERTING INDEX", caser.String(index), modelId)
	deleteRequest := opensearchapi.DeleteRequest{
		Index:      caser.String(oldindex),
		DocumentID: modelId,
	}
	res, err := deleteRequest.Do(context.Background(), openSearchClient)
	marshalledRecord, err := json.Marshal(model)
	if err != nil || res.IsError() {
		pretty.Println("MARSHALL ERR", err)
		pretty.Println("RESP", res)
	}
	req := opensearchapi.IndexRequest{
		Index:      caser.String(index),
		DocumentID: modelId,
		Body:       bytes.NewReader(marshalledRecord),
	}
	res, err = req.Do(context.Background(), openSearchClient)
	if err != nil || res.IsError() {
		pretty.Println("INSERT ERR", err)
		pretty.Println("RESP", res)
	}

	return err
}
