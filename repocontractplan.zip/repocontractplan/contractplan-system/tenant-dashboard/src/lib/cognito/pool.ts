import { PUBLIC_COGNITO_CLIENT_ID, PUBLIC_USERPOOL_ID } from '$env/static/public';
import { CognitoUserPool } from 'amazon-cognito-identity-js';

let poolData = {
  UserPoolId: PUBLIC_USERPOOL_ID,
  ClientId: PUBLIC_COGNITO_CLIENT_ID
};
export const userPool = new CognitoUserPool(poolData);
