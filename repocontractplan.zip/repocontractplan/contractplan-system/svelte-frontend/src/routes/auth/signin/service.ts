import { GraphQLQueryRepository } from '$lib/api/query-repository';
import { GetCurrentPlanDoc, type GetCurrentPlanQuery } from '$lib/generated/graphql';
import * as yup from 'yup';

//check already logged in with authState



export async function validation({email, password}, schema) {
    let errors;
    try {
      errors = {};
      await schema.validate({email, password}, { abortEarly: false });
      return null;
    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      return errors;
    }
  }

  export async function getCurrentPlan() {
    const queryRepository = new GraphQLQueryRepository<GetCurrentPlanQuery>();
    const currentPlanQuery = await queryRepository.getItem(GetCurrentPlanDoc);

    console.log('currentPlanQuery:', currentPlanQuery);
    if(currentPlanQuery.data?.getCurrentPlan === null || currentPlanQuery.data?.getCurrentPlan === undefined){
      return null;
    }
    return currentPlanQuery?.data?.getCurrentPlan?.ID;

  }