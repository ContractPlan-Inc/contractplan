<script lang="ts">
  import MultiSelect from '$lib/components/elements/multiSelect.svelte';
  import { onMount } from 'svelte';
  import { generateCronDates, type ServiceInterface } from './store';
  import { GetHolidaysDoc, type Holiday } from '$lib/generated/graphql';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { datePicker } from 'svelte-flatpickr-plus';

  const holidays: Date[] = [];
  const timezone = 'America/Toronto';
  const occurrence = 'every';
  $effect(() => {
    dateChanged();
  });

  //? declare any options you want to set in flatpickr

  let filteredDates = [];
  let correctfilteredDates = [];

  function dateChanged() {
    console.log('dateChanged');
    filteredDates = generateCronDates(
      new Date(service.StartDate),
      new Date(service.EndDate),
      service.ServicePeriod === 'weekly' ? service.Weekdays : service.ServicePeriod === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : [],
      service.ServicePeriod === 'monthly' ? service.SelectedMonthDays : [],
      service.ServicePeriod === 'yearly' ? service.SelectedDatesOfYear : [],
      occurrence,
      holidays,
      timezone
    );
    console.log('filteredDates', filteredDates);
    correctfilteredDates = filteredDates.filter(
      (date) =>
        date >= new Date(service.StartDate) &&
        date <= new Date(service.EndDate)
    );
    console.log('correctfilteredDates', correctfilteredDates);
    if (service.ServicePeriod === 'monthly') {
      correctfilteredDates = filterSpecificDays(
        correctfilteredDates,
        service.SelectedMonthDays
      );
    }
    console.log('correctfilteredDates', correctfilteredDates.length);
    service.ServiceDates = correctfilteredDates;
    service.ServiceDays = correctfilteredDates.length;
  }

  interface ServiceProps {
    service: ServiceInterface;
    separate: boolean;
  }

  let { service = $bindable(), separate }: ServiceProps = $props();

  const datePickerOptions = {
    minDate: service.StartDate,
    maxDate: service.EndDate,
    defaultDate: service.StartDate,
    altFormat: 'Y-m-d',
    altInput: true,
    conjunction: ', ',
    allowInput: true,
    mode: 'multiple',
    enableTime: false,
    onChange: function(selectedDates: Date[]) {
      let formattedDatesArray = selectedDates.map((dateStr) => {
        let date = new Date(dateStr);
        let year = date.getFullYear();
        let month = String(date.getMonth() + 1).padStart(2, '0'); // pad with leading zeros if necessary
        let day = String(date.getDate()).padStart(2, '0'); // pad with leading zeros if necessary
        return `${year}-${month}-${day}`;
      });
      console.log('formattedDatesArray', formattedDatesArray);
      service.SelectedDatesOfYear = formattedDatesArray;
    }
  };

  const options = [
    { title: 'Sunday', value: 0, checked: false },
    { title: 'Monday', value: 1, checked: false },
    { title: 'Tuesday', value: 2, checked: false },
    { title: 'Wednesday', value: 3, checked: false },
    { title: 'Thursday', value: 4, checked: false },
    { title: 'Friday', value: 5, checked: false },
    { title: 'Saturday', value: 6, checked: false }
  ];
  const daysOfMonth = Array.from({ length: 31 }, (_, index) => ({
    title: (index + 1).toString(),
    value: index,
    checked: false
  }));

  let queryRepository = new GraphQLQueryRepository<Holiday>();
  let tableDataSource = new DataSourceConnector<Holiday>(
    queryRepository,
    GetHolidaysDoc
  );

  onMount(() => {
    tableDataSource
      .loadCurrentPage({})
      .then((data: any) => {
      })
      .finally(() => {
        console.log('Holidays', holidays);
      });
  });

  // Common sub functions
  function filterSpecificDays(dates, days) {
    return dates.filter((date) => days.includes(date.getDate()));
  }

  // functions related to Service
  const serviceEngagementsChanged = (service: ServiceInterface) => {
    service.PerDayServiceCost = parseFloat(
      (service.EngagementCost.majorUnits * service.EngagementsPerDay).toFixed(
        2
      )
    );
    service.ServiceTotal.amount = parseFloat(
      (service.PerDayServiceCost * service.ServiceDays).toFixed(2)
    );
  };

  function updateSelectedDatesOfYear(e: Event) {
    const target = e.target as HTMLInputElement;
    console.log('target.value', target.value);
    console.log(
      'updateSelectedDatesOfYear---->>SelectedDatesOfYear',
      service.SelectedDatesOfYear
    );
    service.SelectedDatesOfYear.push(target.value);
    target.value = '';
  }
</script>

<svelte:head>
  <link
    href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css"
    rel="stylesheet"
  />
  <link
    href="https://npmcdn.com/flatpickr/dist/themes/material_orange.css"
    rel="stylesheet"
    type="text/css"
  />
</svelte:head>
<div class="grid grid-cols-2 gap-4 w-full dark:bg-dark-bg dark:text-white">
  <div class="items-center space-y-1 w-full">
    <div class="mt-2 w-full">Start Date</div>
    <input
      bind:value={service.StartDate}
      class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200 dark:bg-dark-bg dark:text-white"
      type="date"
    />
  </div>
  <div class="items-center space-y-1 w-full">
    <div class="mt-2 w-full">End Date</div>
    <input
      bind:value={service.EndDate}
      min={service.StartDate}
      max="2039-01-01"
      class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200 dark:bg-dark-bg dark:text-white"
      type="date"
    />
  </div>
  <div class="items-center space-y-1 w-full">
    <div class="w-full">Period</div>
    <select
      bind:value={service.ServicePeriod}
      class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200 dark:bg-dark-bg dark:text-white"
    >
      <option value="daily">Daily</option>
      <option value="weekly">Weekly</option>
      <option value="monthly">Monthly</option>
      <option value="yearly">Yearly</option>
    </select>
  </div>
  {#if service.ServicePeriod === "weekly"}
    <div class="items-center space-y-1 w-full">
      <div class="w-full">Weekdays</div>
      <div
        class="flex items-center p-2 h-10 w-full bg-gray-50 rounded border border-gray-200 dark:bg-dark-bg dark:text-white"
      >
        <MultiSelect {options} bind:selectedOptions={service.Weekdays} />
      </div>
    </div>
  {/if}
  {#if service.ServicePeriod === "monthly"}
    <div class=" items-center space-y-1 w-full">
      <div class="w-full">Days of Month</div>
      <div
        class="flex items-center h-10 w-full bg-gray-50 rounded border border-gray-200 dark:bg-dark-bg dark:text-white"
      >
        <MultiSelect
          options={daysOfMonth}
          bind:selectedOptions={service.SelectedMonthDays}
        />
      </div>
    </div>
  {/if}
  {#if service.ServicePeriod === "yearly"}
    <div class="items-center space-y-1 w-full">
      <div class="w-full">Days of Year</div>
      <div
        class="flex-wrap items-center w-full bg-gray-50 rounded border border-gray-200 dark:bg-dark-bg dark:text-white"
      >
        <div class="flex w-full">
          <!-- <Datepicker name="data.excludedDates.value" pickerRule="free"
          bind:selected={service.SelectedDatesOfYear}  disabled={holidays} /> -->
          <input
            class="p-2 w-full bg-gray-50 border-gray-200 rounded-lg dark:bg-dark-bg"
            name="input_datepicker"
            use:datePicker={datePickerOptions}
            readonly
            placeholder="please select date"
            onchange={updateSelectedDatesOfYear}
          />
        </div>
      </div>
    </div>
  {/if}
  <div class="items-center space-y-1 w-full">
    <div class="w-full">Service Days</div>
    <input
      bind:value={service.ServiceDays}
      class="p-2 w-full h-10 bg-gray-50 rounded border border-gray-200 dark:bg-dark-bg dark:text-white"
      disabled
      type="number"
    />
  </div>
  <div class="items-center mb-8 space-y-1 w-full">
    <div class="w-full">Engagements</div>
    <div
      class="flex w-full item-center justify-center border border-gray-200 rounded-lg"
    >
      <input
        bind:value={service.EngagementsPerDay}
        class="p-2 w-full h-10 bg-gray-50 rounded dark:bg-dark-bg dark:text-white"
        min="0"
        onchange={() => {
          serviceEngagementsChanged(service);
        }}
        onkeyup={() => {
          if (service.EngagementsPerDay < 0) {
            service.EngagementsPerDay = 0;
          } else {
            serviceEngagementsChanged(service);
          }
        }}
        type="number"
      />
      <div class="flex w-20 item-center">
        <input
          class="text-center justify-center w-20 inline-block align-middle"
          type="text"
          value="Per day"
          disabled
        />
      </div>
    </div>
  </div>
  {#if separate}
    <div class="relative items-center space-y-1 w-full">
      <div class="w-full">Cost</div>
      <div class="relative w-full">
        <input
          disabled
          class="pr-2 w-full h-10 bg-gray-50 rounded border-gray-200 focus:ring-0 focus:ring-offset-0 indent-6 focus:border-primary-orange border dark:bg-dark-bg"
          type="number"
          value={service.EngagementCost.amount.toFixed(2)}
        />
        <span class="absolute top-1.5 left-2 text-xl text-gray-500">$</span>
        <span class="absolute top-2.5 right-6 text-gray-600">Per day</span>
      </div>
    </div>
    <div class="items-center space-y-1 w-full">
      <div class="w-full">Service Cost</div>
      <div class="relative w-full dark:bg-dark-bg dark:text-white">
        <input
          disabled
          class="pr-2 w-full h-10 bg-gray-50 rounded border-gray-200 focus:ring-0 focus:ring-offset-0 indent-6 focus:border-primary-orange border dark:bg-dark-bg"
          type="number"
          value={service.ServiceTotal.majorUnits.toFixed(2)}
        />
        <span class="absolute top-1.5 left-2 text-xl text-gray-500">$</span>
      </div>
    </div>
  {/if}
</div>
