<script lang="ts">
  import BasicInfo from '$lib/components/calculator/form.svelte';
  import type { ContractInterface, ServiceInterface } from '$lib/components/calculator/store';
  import ServiceInfo from './serviceInfo.svelte';

  interface ContractProps {
    contract: ContractInterface;
  }

  let { contract = $bindable() }: ContractProps = $props();

  const handleNewService = () => {
    contract.Services.push({
      ServiceName: '',
      StartDate: '',
      EndDate: '',
      ServicePeriod: 'daily',
      ServiceDates: [],
      UnitDefinition: {
        Name: 'Day',
        Description: 'd'
      },
      Weekdays: [0, 1, 2, 3, 4, 5, 6],
      SelectedMonthDays: [],
      SelectedDatesOfYear: [],
      ServiceDays: 0,
      EngagementsPerDay: 1,
      EngagementCost: {
        amount: 0,
        currency: 'USD',
        majorUnits: 0
      },
      ServiceTotal: {
        amount: 0,
        currency: 'USD',
        majorUnits: 0
      },
      PerDayServiceCost: 0,
      SeparatePeriod: false
    });
    // console.log(contract.Services);
  };
  $effect(() => {
    console.log('services');
    contract.Services.forEach((service: ServiceInterface) => {
      console.log(service);
    });
  });
</script>

<div class="flex flex-col items-center px-8 w-full rounded-lg border">
  <div class="flex flex-col w-full">
    <div class="text-[#969CAA] py-4 text-lg">Services</div>
  </div>
  <div class="flex flex-col gap-y-4 mb-4 w-full text-sm text-black">
    {#each contract.Services as service, index}
      <div class="{service.SeparatePeriod ? ' bg-white' : ''} flex flex-col gap-y-4">
        <ServiceInfo bind:service={contract.Services[index]} />
        {#if service.SeparatePeriod}
          <label class="flex px-4 py-2 items-center border rounded-lg {service.SeparatePeriod
                                                ? 'bg-yellow-50 border-yellow-500'
                                                : ' bg-green-100 border-green-500'}">
            <input type="checkbox" id="ccbox" bind:checked={service.SeparatePeriod}
                   class="w-4 h-4 text-blue-600 bg-gray-100 rounded border-gray-300 dark:bg-gray-700 dark:border-gray-600 dark:ring-offset-gray-800 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600" />
            <span class="ml-4">Separate Time Period</span>
          </label>
        {/if}
        {#if service.SeparatePeriod}
          <BasicInfo bind:service={contract.Services[index]} separate={true} />
        {/if}
      </div>
    {/each}
  </div>
</div>
<div class="pt-4">
  <button class="py-3 px-8 mb-8 text-lg font-medium tracking-wider text-black bg-white rounded-lg border shadow-lg"
          onclick={() => handleNewService()}>
    Add New Service
  </button>
</div>
