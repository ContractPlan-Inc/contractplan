package models

import (
	"strings"
)

func StringInSlice(val string, array ...string) (ok bool, i int) {
	for i = range array {
		if ok = array[i] == val; ok {
			return
		}
	}
	return false, 0
}

func StringInSliceBeginsWith(val string, array ...string) (ok bool, i int) {
	for i = range array {
		if strings.HasPrefix(val, array[i]) {
			return true, i
		}
	}
	return false, 0
}
