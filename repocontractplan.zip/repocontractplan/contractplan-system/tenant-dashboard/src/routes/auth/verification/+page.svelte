<script lang="ts">
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { VerificationDoc, type VerificationInput } from '$lib/generated/graphql';
  import Input from '$lib/components/elements/input.svelte';
  import { goto } from '$app/navigation';

  let email = '';
  let verificationCode = '';

  let snackbarMessage = '';
  let snackbarTimeout: NodeJS.Timeout | undefined;

  async function handleSubmit() {
    console.log('triggered');

    const data = {
      email: email,
      token: verificationCode
    };

    console.log(data);

    let queryRepository = new GraphQLQueryRepository<VerificationInput>();
    let response: any = await queryRepository.Verification(VerificationDoc, {
      input: data
    });
    console.log('--------response----------');
    // console.log(response.data.SignUp.error.S);
    console.log(response.data.Verification);

    if (response.data.Verification.success === true) {
      snackbarMessage = response.data.Verification.message;
      goto('/auth/signin');
    }
    snackbarMessage = response.data.Verification.message;
    snackbarTimeout = setTimeout(() => {
      snackbarMessage = '';
    }, 4000);
  }
</script>

<div
  class="w-screen h-screen bg-gradient-to-b to-primary/20 from-primary flex items-center justify-center"
>
  <form
    class="flex flex-col items-center justify-center bg-white rounded p-5 space-y-5"
    onsubmit={(event)=>{event.preventDefault();handleSubmit()}}
  >
    <h1 class="text-2xl font-bold">Account Verification</h1>
    <Input bind:value={email} label="Email" />
    <Input bind:value={verificationCode} label="Verification Code" />
    <button class="bg-primary px-2 py-1 rounded w-full" type="submit"
    >Verify
    </button
    >
  </form>
  {#if snackbarMessage}
    <div
      id="toast-success"
      class="fixed top-10 left-50 right-50 flex items-center w-full max-w-xs p-4 mb-4 text-gray-500 bg-white rounded-lg shadow dark:text-gray-400 dark:bg-gray-800"
      role="alert"
    >
      <div class="ml-3 text-sm font-normal">{snackbarMessage}</div>
      <button
        type="button"
        class="ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex items-center justify-center h-8 w-8 dark:text-gray-500 dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700"
        data-dismiss-target="#toast-success"
        aria-label="Close"
        onclick={() => {
          snackbarMessage = "";
        }}
      >
        <span class="sr-only">Close</span>
        <svg
          class="w-3 h-3"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 14 14"
        >
          <path
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
          />
        </svg>
      </button>
    </div>
  {/if}
</div>
