import * as cdk from "aws-cdk-lib";
import { aws_kms, Duration, Fn, Stack, StackProps } from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { ISecurityGroup, IVpc } from "aws-cdk-lib/aws-ec2";
import { Platform } from "aws-cdk-lib/aws-ecr-assets";
import * as iam from "aws-cdk-lib/aws-iam";
import { PolicyDocument, Role } from "aws-cdk-lib/aws-iam";
import { IKey } from "aws-cdk-lib/aws-kms";
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { CfnEventSourceMapping, EventSourceMapping, IEventSource } from 'aws-cdk-lib/aws-lambda';
import { ISecret } from "aws-cdk-lib/aws-secretsmanager";
import { Construct } from "constructs";
import * as path from 'path';
import { SqsDlq } from "aws-cdk-lib/aws-lambda-event-sources";
import { Queue } from "aws-cdk-lib/aws-sqs";

export interface LambdaStackProps extends StackProps {
  environment: string;
  stripe_secret: ISecret;
}

export class LambdaCdkStack extends Stack {
  public readonly vpc: IVpc;

  constructor(parent: Construct, id: string, props: LambdaStackProps) {
    super(parent, id, props);
    // Create Billing Queue
    this.vpc = ec2.Vpc.fromVpcAttributes(this, 'vpc', {
      vpcId: cdk.Fn.importValue('VPC-vpc-id'),
      availabilityZones: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-azs`)),
      publicSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-public-subnets`)),
      privateSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-private-subnets`)),
    })
    const lambdaBuildProps = {
      file: 'Dockerfile',
      platform: Platform.LINUX_ARM64
    };
    const StandardProcessRole = new iam.Role(this, 'Role', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'DynamoDB Records Processing Role',
      roleName: 'StandardProcessRole',
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName("service-role/AWSLambdaRole")
      ],
      inlinePolicies: {
        "standardPolicy": new PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              resources: ['*'],
              actions: [
                'ec2:CreateNetworkInterface',
                'ec2:DescribeNetworkInterfaces',
                'ec2:DeleteNetworkInterface',
                'dynamodb:DescribeStream',
                'dynamodb:GetRecords',
                'dynamodb:GetShardIterator',
                'dynamodb:ListStreams',
                'logs:CreateLogGroup',
                'logs:CreateLogStream',
                'logs:PutLogEvents',
                'dynamodb:*',
                'sqs:*',
                'secretsmanager:*',
                'es:*',
                'kms:*',
                'states:*',
                's3:*'
              ],
            })
          ]
        })
      }
    });
    // const securityGroup = ec2.SecurityGroup.fromSecurityGroupId(this, "RedisClientSecurityGroup", cdk.Fn.importValue("Redis-client-security-group"))
    const securityGroup = new ec2.SecurityGroup(this, 'LambdaSecurityGroup', {
      vpc: this.vpc,
      allowAllOutbound: true,
      allowAllIpv6Outbound: true,
      securityGroupName: 'LambdaSecurityGroup',
    })
    const kmsKey = aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));

    const ProcessReportsFunction = this.getDockerImageFunction(
      'ProcessReportsFunction',
      '../lambda/process-reports/',
      lambdaBuildProps,
      StandardProcessRole,
      kmsKey,
      securityGroup,
      512,
      Duration.seconds(900),
    )
    const reportingDlq = new Queue(this, 'ReportingDlq', {
      retentionPeriod: Duration.days(14),
    });

    const sourceMapping = new EventSourceMapping(this, 'dynamoTableEventSourceMapping', {
      startingPosition: lambda.StartingPosition.TRIM_HORIZON,
      batchSize: 100,
      maxBatchingWindow: cdk.Duration.seconds(10),
      parallelizationFactor: 10,
      onFailure: new SqsDlq(reportingDlq),
      target: ProcessReportsFunction,
      eventSourceArn: Fn.importValue('DynamoDB-stream-arn'),
      bisectBatchOnError: true,
      retryAttempts: 3,
    })
    const cfnSourceMapping = sourceMapping.node.defaultChild as CfnEventSourceMapping
    const filterPattern = {
      "eventName": ["INSERT", "MODIFY"],
      "dynamodb": {
        "NewImage": {
          "¶": {
            "S": [
              "USERS",
              "ROLE",
              "USER_ROLE",
              "POLICY",
              "ROLE_POLICY",
              "CONTRACT",
              "CONTRACT_PARTNER",
              "CONTRACT_DAY_RECORD",
              "HOLIDAY",
              "ERROR"
            ]
          }
        }
      }
    };
    cfnSourceMapping.addPropertyOverride('FilterCriteria', {
      Filters: [
        {
          Pattern: JSON.stringify(filterPattern),
        },
      ],
    })
  }

  private getDockerImageFunction(
    name: string,
    lambdaPath: string,
    lambdaBuildProps: { file: string; platform: Platform },
    StandardProcessRole: Role,
    kmsKey: IKey,
    securityGroup: ISecurityGroup,
    memorySize: number,
    timeout: cdk.Duration,
    events: IEventSource[] = [])
  {
    return new lambda.DockerImageFunction(this, name, {
      code: lambda.DockerImageCode.fromImageAsset(path.join(__dirname, lambdaPath), {
        ...lambdaBuildProps,
      }),
      timeout: timeout,
      memorySize: memorySize,
      architecture: lambda.Architecture.ARM_64,
      tracing: lambda.Tracing.ACTIVE,
      role: StandardProcessRole,
      logRetention: 7,
      environmentEncryption: kmsKey,
      vpc: this.vpc,
      vpcSubnets: {subnets: this.vpc.privateSubnets},
      securityGroups: [securityGroup],
      environment: {
        DISABLE_ORM: "1",
        MAIN_TABLE: Fn.importValue('DynamoDB-table-name'),
        OPENSEARCH_ADDRESS: Fn.importValue('Elasticsearch-domain-endpoint'),
        OPENSEARCH_SECRET: Fn.importValue('Elasticsearch-secret-arn'),
        // REDIS_ENDPOINT: cdk.Fn.importValue('Redis-endpoint-address'),
        // REDIS_PORT: cdk.Fn.importValue('Redis-endpoint-port'),
        BUCKET_NAME: Fn.importValue('BaseInfrastructure-storage-bucket-name'),
      },
      events
    });
  }
}
