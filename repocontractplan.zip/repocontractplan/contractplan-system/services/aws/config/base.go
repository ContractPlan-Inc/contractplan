package config

import (
	"context"
	"log"
	"os"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

var AWSConfig aws.Config

func init() {
	var err error

	// Build configuration options
	opts := []func(*config.LoadOptions) error{
		config.WithRegion(os.Getenv("AWS_REGION")),
		config.WithDefaultRegion("us-east-1"), // Fallback region
	}

	// Add credentials if provided
	if os.Getenv("AWS_ACCESS_KEY_ID") != "" {
		opts = append(opts, config.WithCredentialsProvider(credentials.NewStaticCredentialsProvider(
			os.Getenv("AWS_ACCESS_KEY_ID"),
			os.Getenv("AWS_SECRET_ACCESS_KEY"),
			os.Getenv("AWS_SESSION_TOKEN"),
		)))
	}

	// Load the configuration
	AWSConfig, err = config.LoadDefaultConfig(context.TODO(), opts...)
	if err != nil {
		log.Fatalf("Unable to load AWS SDK config: %v", err)
	}

	// Test S3 client creation
	s3Client := s3.NewFromConfig(AWSConfig)
	_, err = s3Client.ListBuckets(context.TODO(), &s3.ListBucketsInput{})
	if err != nil {
		log.Printf("Warning: S3 connection test failed: %v", err)
	} else {
		log.Printf("Successfully connected to S3 in region: %s", AWSConfig.Region)
	}
}
