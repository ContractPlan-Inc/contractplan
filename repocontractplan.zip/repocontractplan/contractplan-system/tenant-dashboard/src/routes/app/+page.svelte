<script lang="ts">
  import Table, { type Column } from '$lib/components/table/table.svelte';
  import { DataSourceConnector } from "$lib/api/table-datasource";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import deleteIcon from "$lib/assets/svg/trash.svg";
  import editIcon from "$lib/assets/svg/edit.svg";
  import dashboardIcon from "$lib/assets/svg/dashboard.svg";
  import { goto } from "$app/navigation";
  import { type Contract, type Customer, ListCustomers, ListCustomersDoc, ListUsersDoc, type Tenant } from '$lib/generated/graphql';
  import {onMount} from 'svelte';
  import { title } from '$lib/state/store';
  let queryRepository = new GraphQLQueryRepository<Customer>();
  let tableDataSource = new DataSourceConnector<Customer>(
    queryRepository,
    ListCustomersDoc,
  );
  let addButton = { text: "New Contract", path: "/app/contract/create" };
  const isLabel = true;
  let label = "Columns";
  const columns = [
    { key: "ID", title: "ID", sortable: false },
    { key: "FirstName", title: "FirstName.", sortable: false },
    { key: "LastName", title: "LastName", sortable: false },
    { key: "Email", title: "Email", sortable: false },
    { key: "Phone", title: "Phone", sortable: false },
  ] as Column[];
  let availableColumns = [
    "ID",
    "Email",
    "FirstName",
    "LastName",
    "Phone",
  ];
  let dateColumns = ["StartDate", "EndDate"];
  let currencyColumns = ["ContractValue"];
  let actions = true;
  let actionList = [
    // { name: "Day Report", icon: editIcon, function: contractDay },
    {
      name: "View Customer",
      icon: dashboardIcon,
      iconColor: "text-gray-200",
      function: dashboardFunction,
    },
    // { name: "Edit", icon: editIcon, function: editFunction },
    { name: "Delete", icon: deleteIcon, function: deleteFunction },
  ];
  let bulkActions = [
    "Activate",
    "Deactivate",
    "Delete",
    "Export to CSV",
    "Export to PDF",
  ];

  onMount(()=>{
    $title = "Tenant Dashboard";

    console.log("Table Data Source", tableDataSource);
  })

  function dashboardFunction(node: Contract) {
    goto("/app/" + node.ID);
  }
  // function editFunction(node: Contract) {
  //   goto("/app/contract/edit/" + node.ID);
  // }
  function deleteFunction(node: Contract) {
    // console.log("/app/contract/delete/" + node.ID);
  }

</script>

<div>
  <Table
    tabletitle={"Tenants"}
    {tableDataSource}
    rootAccessPath="data.listCustomers.edges"
    {columns}
    {isLabel}
    {label}
    {availableColumns}
    {dateColumns}
    {currencyColumns}
    {actions}
    {actionList}
    {bulkActions}
  >
    <span slot="buttons" class="flex space-x-2">
      <slot/>
    </span>
  </Table>
</div>
