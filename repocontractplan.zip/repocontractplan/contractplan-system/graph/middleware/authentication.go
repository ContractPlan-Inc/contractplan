package middleware

import (
	"net/http"

	"github.com/kr/pretty"

	"cloudparallax.com/backend/utils"
)

// Middleware decodes the share session cookie and packs the session into context

func Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		pretty.Println(utils.GetTenant(r.Context()), "TENANT")
		authorization := r.Header.Get("Authorization")
		if len(authorization) < 9 {
			next.ServeHTTP(w, r.WithContext(r.Context()))
			return
		}
		authorization = authorization[7:]
		//user, err := auth.ValidateToken(authorization)
		//if err != nil {
		//	next.ServeHTTP(w, r.WithContext(r.Context()))
		//	return
		//}
		ctx := utils.TenantWithContext(r.Context(), "aaaaaa")
		//ctx = utils.UserWithContext(ctx, user)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
