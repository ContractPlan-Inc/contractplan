<script lang="ts">
  import {GraphQLQueryRepository} from '$lib/api/query-repository';
  import {
    type Contract, type ContractDayRecord,
    type ContractDayRecordInput, GetContractDayRecordsDoc, type GetContractDayRecordsQuery,
    GetContractsDoc,
    type GetContractsQuery,
    UpdateContractDayRecordsDoc
  } from '$lib/generated/graphql';
  import dayjs from 'dayjs';
  import Loader from "$lib/components/elements/loader.svelte";



  let {pop, contract} = $props();
  let errors: { [key: string]: string } = {};
  let searchTerm = $state("");
  let allContracts = $state<Contract[]>([]);
  let selectedContract = $state<Contract | null>(null);
  let selectedService = $state<any | null>(null);
  let contractDayRecords = $state([]);
  let date1 = $state(Date())
  let date2 = $state(Date())
  let count = $state(0)
  let isLoading = $state(false);

  async function fetchAndFilterContract(input: {}) {
    try {
      const queryRepository = new GraphQLQueryRepository<GetContractsQuery>();
      const contractQuery = await queryRepository.getItems(
        GetContractsDoc,
        {input: input},
        0,
        5,
      );
      const ctrs =
      contractQuery?.data?.listContracts?.edges?.reduce(
        (acc, contract) => {
          acc.push(contract?.node as Contract);
          return acc;
        },
        [] as Contract[],
      );
      allContracts = ctrs as Contract[];
    } catch (error) {
      console.error("Error fetching contracts:", error);
    }
  }

  async function loadDayRecords() {
    const queryRepository = new GraphQLQueryRepository<GetContractDayRecordsQuery>();
    const contractDayQuery = await queryRepository.getItems(
      GetContractDayRecordsDoc,
      {contractId: selectedContract.ID},
      0,
      5,
    );
    contractDayRecords = contractDayQuery?.data?.getContractDayRecords?.edges?.reduce(
      (acc, contractday) => {
        acc.push(contractday?.node as Contract);
        return acc;
      },
      [] as Contract[],
    );
    date1 = new Date(contractDayRecords[0].Date).toISOString().split('T')[0]
    date2 = new Date(contractDayRecords[contractDayRecords.length - 1].Date).toISOString().split('T')[0]
    console.log("contract day records", contractDayRecords)
  }

  function selectContract(contract: Contract) {
    searchTerm = contract.ContractName;
    console.log("contract", contract.ContractName, contract.Services);
    selectedContract = contract;
    allContracts = [];
    loadDayRecords();
  }

  async function updateDayRecord() {

     if (!validateForm()) {
      return;
    }

    isLoading = true;
    console.log('Updating day record with:', {
    contractId: selectedContract.ID,
    serviceId: selectedService.ID,
    count: count,
    dateRange: [
      dayjs(date1).format(),
      dayjs(date2).format()
    ]
  });

    try {
      const queryRepository = new GraphQLQueryRepository<ContractDayRecordInput>();
      await queryRepository.updateItem(UpdateContractDayRecordsDoc, {
        contractId: selectedContract.ID,
        serviceId: selectedService.ID,
        count: count,
        dateRange: [dayjs(date1, 'ddd MMM DD YYYY HH:mm:ss [GMT]ZZ'), dayjs(date2, 'ddd MMM DD YYYY HH:mm:ss [GMT]ZZ')]
      });
      console.log('Day record updated successfully');
      pop = false;
    } catch (error) {
      console.error("Error updating contract day records:", error);
    } finally {
      isLoading = false;
    }
  }

   function validateForm() {
    errors = {};

    if (!selectedContract) {
      errors.ContractID = "Please select a contract.";
    }
    if (!selectedService) {
      errors.ServiceID = "Please select a service.";
    }
    if (!count || count <= 0) {
      errors.Count = "Please enter a valid count.";
    }

    return Object.keys(errors).length === 0;
  }

</script>

{#if pop}
  <div class="absolute top-0 left-0 flex item-center justify-center z-50">
    <div
      tabindex="0"
      class="flex items-center justify-center w-full h-full  top-0 left-0 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow  "
      style="position: fixed;"
      role="button"
      onclick={() => {
        pop = false;
      }}
    >
      <div
        class="w-full max-w-md max-h-full z-50 bg-white rounded-lg shadow border border-black"
        style="left: 150px; "
        onclick={(event)=>{event.stopPropagation()}}>
        <div class="w-full flex space-x-2 justify-center rounded items-center px-5 my-5 ">
          <div class="mt-2 mr-12 w-fit">Contract
             {#if errors.ContractID}
              <div class="m-1 text-xs text-red-500">
                {errors.ContractID}
              </div>
            {/if}
          </div>
          <div class="relative inline-block gap-x-2 rounded-lg items-center my-3 border space-y-1 w-full">
            <input
              bind:value={searchTerm}
              class="class-set border-gray-200 bg-gray-50 w-full p-2 rounded-lg
              { errors.ContractID === '' || errors.ContractID === undefined
                ? 'border-gray-200 '
                : 'border-red-500'}"
              onkeyup={() =>
                fetchAndFilterContract({
                  ContractName: searchTerm,
                })}
              type="text"
            />
            {#if allContracts !== undefined && allContracts.length !== 0}
              <div
                class="hide-item absolute bg-gray-50 rounded-lg border-gray-200 peer-focus:block"
                style="position: absolute;top: 100%;left: 0; width: 100%;z-index: 1000;box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);box-sizing: border-box;"
              >
                <div class="inline-block bg-transparent z-40 rounded w-full p-1">
                  <div class="bg-gray-400 rounded p-1">
                    {#each allContracts as ctr}
                      {#if ctr.ContractName != "" && ctr.ContractName != null }
                        <div
                          onclick={() => selectContract(ctr)}
                          class="w-full py-2 px-4 text-sm mb-1 bg-gray-600 rounded-md text-white cursor-pointer first:border-t-0 hover:bg-gray-700 border-t-gray-400"
                        >
                          {ctr.ContractName}
                        </div>
                      {/if}
                    {/each}
                  </div>
                </div>
              </div>
            {/if}
          </div>
        </div>
        <div class="w-full flex space-x-2 px-5 my-5 ">
            <div class="mt-2 mr-14 w-fit">Service</div>
            <select id="country" name="country" autocomplete="country-name"
              bind:value={selectedService}
              class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200">
               {#each selectedContract?.Services as service}
                <option value={service} onclick={()=>{selectedService = service.ID}}>{service.ServiceName}</option>
              {/each}
            </select>
            {#if errors.ServiceID}
              <div class="m-1 text-xs text-red-500">
                {errors.ServiceID}
              </div>
            {/if}
        </div>
        <div class="w-full flex space-x-2 px-5 my-5 ">
          <div class="mt-2 mr-16 w-fit">Engagements</div>
          <input
            class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200"
            type="number"
            bind:value={count}
          />
           {#if errors.Count}
            <div class="m-1 text-xs text-red-500">
              {errors.Count}
            </div>
          {/if}
        </div>
        <div class="w-full flex space-x-2 px-5 my-5 ">
          <div class="mt-2 w-full">Date range</div>
          <div class="items-center space-y-1 w-full">
            <input
              bind:value={date1}
              class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200"
              type="date"
            />
          </div>
          <div class="items-center space-y-1 w-full">
            <input
              bind:value={date2}
              max="2039-01-01"
              class="p-2 w-full h-10 bg-gray-50 rounded-lg border border-gray-200"
              type="date"
            />
          </div>
        </div>
        <div class="w-full flex justify-center">
          <button
            class="p-2 px-4 w-fit m-2 h-10 bg-gray-50 rounded-lg border border-gray-200"
            onclick={() => updateDayRecord()}
            disabled={isLoading}
          >
            Submit
          </button>
        </div>
        {#if isLoading}
          <div class="w-full flex justify-center">
            <Loader loading={true} type="dataLoader" />
          </div>
        {/if}
      </div>
    </div>
  </div>
{/if}

<style>
  .dropdown-container {
    position: relative;
    display: inline-block;
  }

  .dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    border: 1px solid #ccc;
    background: white;
    z-index: 1000;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }

  .dropdown-item {
    padding: 8px 12px;
    cursor: pointer;
  }

  .dropdown-item:hover {
    background-color: #f0f0f0;
  }

</style>
