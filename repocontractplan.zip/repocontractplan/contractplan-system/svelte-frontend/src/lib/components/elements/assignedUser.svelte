<script>

  import Icon from "@iconify/svelte";


  /**
   * @typedef {Object} Props
   * @property {string} [profilePicture]
   * @property {string} [name]
   * @property {string} [phoneNumber]
   * @property {boolean} [isOnline]
   */

  /** @type {Props} */
  let {
    profilePicture = "https://cdn.cloudflare.steamstatic.com/steamcommunity/public/images/avatars/00/00411ecc969f4fd6116d5115a0438a337d23cfd2.jpg",
    name = "John Doe",
    phoneNumber = "+618923979",
    isOnline = false
  } = $props();
</script>
<div class=" flex  items-center justify-between my-6 ">
  <div class=" flex items-center gap-3">
    <img alt="" class="w-10 rounded-full" src={profilePicture}>
    <div>
      <p class=" font-semibold">{name}</p>
      <p class=" text-sm text-gray-500">{phoneNumber}</p>
    </div>
  </div>
  <div class=" text-gray-500 relative">
    <Icon icon="lucide:message-circle" width="28" />
    <span
      class=" {!isOnline ? ' hidden' :''} w-3 h-3 bg-green-400 rounded-full absolute top-0 right-0  border border-white "></span>
  </div>
</div>
