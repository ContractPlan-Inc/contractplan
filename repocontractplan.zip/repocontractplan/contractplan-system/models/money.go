package models

import (
	"encoding/json"
	"math"
	"strconv"

	"github.com/Rhymond/go-money"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type Money struct {
	Money    *money.Money `json:"–" dynamodbav:"-"`
	Amount   int64        `json:"amount" dynamodbav:"a"`
	Currency string       `json:"currency" dynamodbav:"b"`
}
type MoneyInput struct {
	Amount     int64    `json:"amount"`
	Currency   string   `json:"currency"`
	MajorUnits *float64 `json:"majorUnits"`
}

func (m *Money) UnmarshalDynamoDBAttributeValue(av types.AttributeValue) (err error) {
	amount := int64(0)
	currencyCode := ""
	if tv, ok := av.(*types.AttributeValueMemberM); ok {
		if val, ok := tv.Value["a"].(*types.AttributeValueMemberN); ok {
			if amountF, err := strconv.ParseInt(val.Value, 10, 0); err == nil {
				amount = amountF
				if valCur, ok := tv.Value["b"].(*types.AttributeValueMemberS); ok {
					currencyCode = valCur.Value
				}
			}
		}
	}
	if currencyCode == "" {
		m.Money = nil
		m.Amount = 0
		m.Currency = ""
		return
	}
	m.Money = money.New(amount, currencyCode)
	m.Amount = amount
	m.Currency = currencyCode
	return nil
}
func (m *Money) MarshalDynamoDBAttributeValue() (types.AttributeValue, error) {
	if m.Money == nil || m.Money.Currency() == nil {
		if m.Currency == "" {
			m.Currency = "CAD"
		}
		m.Money = money.New(m.Amount, m.Currency)
	}
	mapMoney := map[string]interface{}{
		"a": m.Money.Amount(),
		"b": m.Money.Currency().Code,
	}
	av, err := attributevalue.Marshal(mapMoney)
	return av, err
}
func (m *Money) MarshalJSON() ([]byte, error) {
	obj := struct {
		Amount   int64  `json:"amount"`
		Currency string `json:"currency"`
	}{
		Amount:   m.Amount,
		Currency: m.Currency,
	}
	return json.Marshal(obj)
}
func (m *Money) UnmarshalJSON(data []byte) error {
	var obj struct {
		Amount   int64  `json:"amount"`
		Currency string `json:"currency"`
	}
	var ddbMap struct {
		Amount   int64  `json:"a"`
		Currency string `json:"b"`
	}
	var amount float64
	if err := json.Unmarshal(data, &ddbMap); err == nil && ddbMap.Currency != "" {
		m.Money = money.New(ddbMap.Amount, ddbMap.Currency)
		m.Amount = ddbMap.Amount
		m.Currency = ddbMap.Currency
		return nil
	} else if err := json.Unmarshal(data, &obj); err == nil && obj.Currency != "" {
		m.Money = money.New(obj.Amount, obj.Currency)
		m.Amount = obj.Amount
		m.Currency = obj.Currency
		return nil
	} else if err := json.Unmarshal(data, &amount); err == nil {
		m.Money = money.New(int64(amount*100.0), "CAD")
		return nil
	}
	m.Money = money.New(int64(amount*100.0), "CAD")
	return nil
}
func (m *Money) Set(value string) {
	if moneyValue, err := strconv.ParseFloat(value, 64); err == nil {
		m.Money = money.New(int64(moneyValue*100.0), "CAD")
	} else {
		m.Money = money.New(0, "CAD")
	}
	m.Currency = "CAD"
	m.Amount = m.Money.Amount()
}
func (m *Money) SetRaw(value interface{}) error {
	switch value.(type) {
	case float64:
		m.Money = money.New(int64((value.(float64))*100.0), "CAD")
	case int64:
		m.Money = money.New(value.(int64), "CAD")
	case string:
		if moneyValue, err := strconv.ParseFloat(value.(string), 64); err == nil {
			// pretty.Println("CONVERTING", moneyValue)
			// pretty.Println("CONVERTED", moneyValue*100.0)
			// pretty.Println("CONVERTED", moneyValue*100)
			// pretty.Println("CONVERTED", math.Round(moneyValue*100.0))
			m.Money = money.New(int64(math.Round(moneyValue*100.0)), "CAD")
		} else {
			m.Money = money.New(0, "CAD")
		}
	default:
		m.Money = money.New(0, "CAD")
	}
	m.Currency = "CAD"
	m.Amount = m.Money.Amount()
	return nil
}
