package models

import "context"

type ContractPartner struct {
	DynamoDBModel
	ID                  string `json:"ID" dynamodbav:"a"`
	ContractPartnerName string
	CompanyName         string
	Email               string
	Contact             string
	Archive             bool `json:"Archive"`
}

func (ContractPartner) IsNode()            {}
func (this ContractPartner) GetID() string { return this.ID }

type ContractPartnerConnection struct {
	Edges            []*ContractPartnerEdge  `json:"edges,omitempty"`
	Pagination       *Pagination             `json:"pagination,omitempty"`
	LastEvaluatedKey *DynamoLastEvaluatedKey `json:"lastEvaluatedKey,omitempty"`
}

func GetContractPartnerById(ctx context.Context, id string) (*ContractPartner, error) {
	var partner ContractPartner
	partner.ID = id
	return GetModelByIDFromDDB(ctx, partner, "CONTRACT_PARTNER", "PK")
}

func (ContractPartnerConnection) IsConnection() {}
func (this ContractPartnerConnection) GetEdges() []Edge {
	if this.Edges == nil {
		return nil
	}
	interfaceSlice := make([]Edge, 0, len(this.Edges))
	for _, concrete := range this.Edges {
		interfaceSlice = append(interfaceSlice, concrete)
	}
	return interfaceSlice
}
func (this ContractPartnerConnection) GetPagination() *Pagination { return this.Pagination }
func (this ContractPartnerConnection) GetLastEvaluatedKey() *DynamoLastEvaluatedKey {
	return this.LastEvaluatedKey
}

type ContractPartnerEdge struct {
	Cursor *string `json:"cursor,omitempty"`
	Node   Node    `json:"node,omitempty"`
}

func (ContractPartnerEdge) IsEdge()            {}
func (this ContractPartnerEdge) GetNode() Node { return this.Node }

type ContractPartnerInput struct {
	ID                  string `json:"ID"`
	ContractPartnerName string `json:"ContractPartnerName"`
	CompanyName         string `json:"CompanyName"`
	Email               string `json:"Email"`
	Contact             string `json:"Contact"`
}
