import * as python from '@aws-cdk/aws-lambda-python-alpha';
import { PythonFunction } from '@aws-cdk/aws-lambda-python-alpha';
import * as cdk from 'aws-cdk-lib';
import { aws_secretsmanager, aws_ssm, CfnOutput, Duration, Fn, SecretValue } from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { ISecurityGroup, IVpc, SecurityGroup } from 'aws-cdk-lib/aws-ec2';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import { Ec2Service, ICluster, PlacementStrategy } from 'aws-cdk-lib/aws-ecs';
import * as elb from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as iam from 'aws-cdk-lib/aws-iam';
import { ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import * as fn from 'aws-cdk-lib/aws-lambda';
import { Architecture } from 'aws-cdk-lib/aws-lambda';
import { ILogGroup } from 'aws-cdk-lib/aws-logs';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { LoadBalancerTarget } from 'aws-cdk-lib/aws-route53-targets';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { IQueue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
import { DockerImageName, ECRDeployment } from 'cdk-ecr-deployment';
import { UserPool, UserPoolClient } from 'aws-cdk-lib/aws-cognito';
import { EcsDeployAction } from 'aws-cdk-lib/aws-codepipeline-actions';

export interface BackendStackProps extends cdk.StackProps {
  logGroup: ILogGroup;
  ecsSG: ISecurityGroup;
  cluster: ICluster;
  capacityProvider: string;
  environment: string;
  email_queue: IQueue;
  stripe_secret: secretsmanager.ISecret;
  userPool: UserPool;
  userPoolClient: UserPoolClient;
  backendImageUri: string;
  otelImageUri: string;
}

export class BackendCdkStack extends cdk.Stack {
  public readonly vpc: IVpc;
  public readonly ecsSG: SecurityGroup;
  public readonly Ec2Service: Ec2Service;
  private rotationFunction: PythonFunction;
  private opensearch_address: string;
  private opensearch_secret: string;
  private table_name: string;
  private chargebee_secret: string;
  private s3BucketName: string;

  constructor(scope: Construct, id: string, props: BackendStackProps) {
    super(scope, id, props);
    const cluster = props.cluster;

    const baseDomain = cdk.Fn.importValue('BaseInfrastructure-base-domain');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamDomain', '/infra-stack/base-domain').stringValue;
    const zone = cdk.Fn.importValue('BaseInfrastructure-zone');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamZone', '/infra-stack/zone-id').stringValue;
    const albStackSecurityGroupId = cdk.Fn.importValue('ApplicationLoadBalancerV2-security-group-id');//ApplicationLoadBalancerV2 ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbSecurityGroupId', '/alb-stack/security-group-id').stringValue;
    const albStackLoadbalancerArn = cdk.Fn.importValue('ApplicationLoadBalancerV2-loadbalancer-arn');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbLoadbalancerArn', '/alb-stack/loadbalancer-arn').stringValue;
    const albStackListenerArn = cdk.Fn.importValue('ApplicationLoadBalancerV2-listener-arn');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbListenerArn', '/alb-stack/listener-arn').stringValue;
    const albStackHostedZoneId = cdk.Fn.importValue('ApplicationLoadBalancerV2-alb-hosted-zone');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;
    const albStackDnsName = cdk.Fn.importValue('ApplicationLoadBalancerV2-alb-dns-name');//ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;
    // const userFrontendDomains = cdk.Fn.importValue('user-frontend-domains'); //ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;
    // const adminFrontendDomains = cdk.Fn.importValue('admin-frontend-domains'); //ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;
    this.opensearch_address = aws_ssm.StringParameter.fromStringParameterName(this, 'ElasticsearchDomainEndpoint', '/opensearch/domain-endpoint').stringValue;
    this.opensearch_secret = aws_ssm.StringParameter.fromStringParameterName(this, 'ElasticsearchDomainSecret', '/opensearch/secret').stringValue;
    this.table_name = aws_ssm.StringParameter.fromStringParameterName(this, 'DynamoDBTableName', '/dynamodb/table-name').stringValue;
    this.chargebee_secret = aws_ssm.StringParameter.fromStringParameterName(this, 'ChargebeeSecret', '/chargebee/secret').stringValue;
    this.s3BucketName = aws_ssm.StringParameter.fromStringParameterName(this, 'S3BucketName', '/s3/profile-image-bucket-name').stringValue;

    this.vpc = ec2.Vpc.fromLookup(this, 'PRIMARY_VPC', { vpcName: 'PRIMARY_VPC' });

    const hostedZone = route53.HostedZone.fromHostedZoneAttributes(this, 'HostedZone', {
      hostedZoneId: zone,
      zoneName: baseDomain
    });
    // -------------------------------------------------------------------
    // Application load balancer configuration for Messaging Service
    // -------------------------------------------------------------------
    const alb =
      elb.ApplicationLoadBalancer.fromApplicationLoadBalancerAttributes(
        this,
        `alb`,
        {
          loadBalancerArn: albStackLoadbalancerArn,
          securityGroupId: albStackSecurityGroupId,
          loadBalancerCanonicalHostedZoneId: albStackHostedZoneId,
          loadBalancerDnsName: albStackDnsName
        }
      );
    const albSG = ec2.SecurityGroup.fromSecurityGroupId(
      this,
      'alb-security-group',
      albStackSecurityGroupId
    );
    const listener = elb.ApplicationListener.fromApplicationListenerAttributes(
      this,
      `listener`,
      {
        listenerArn: albStackListenerArn,
        securityGroup: albSG
      }
    );

    const recordSet = new route53.RecordSet(this, 'RecordSet', {
      recordType: route53.RecordType.A,
      recordName: 'api.' + baseDomain,
      target: route53.RecordTarget.fromAlias(new LoadBalancerTarget(alb)),
      zone: hostedZone
    });
    const recordSet2 = new route53.RecordSet(this, 'RecordSet2', {
      recordType: route53.RecordType.AAAA,
      recordName: 'api.' + baseDomain,
      target: route53.RecordTarget.fromAlias(new LoadBalancerTarget(alb)),
      zone: hostedZone
    });

    // Target group to make resources containers discoverable by the application load balancer
    const targetGroupHttp = new elb.ApplicationTargetGroup(
      this,
      'ec2-target-group',
      {
        port: 443,
        vpc: this.vpc,
        protocol: elb.ApplicationProtocol.HTTPS,
        targetType: elb.TargetType.INSTANCE,
        deregistrationDelay: cdk.Duration.seconds(60)
      }
    );


    // Health check for containers to check they were deployed correctly
    targetGroupHttp.configureHealthCheck({
      path: '/status',
      protocol: elb.Protocol.HTTPS,
      healthyThresholdCount: 2,
      healthyHttpCodes: '200-499',
      unhealthyThresholdCount: 10,
      timeout: cdk.Duration.seconds(10),
      interval: cdk.Duration.seconds(30)
    });

    const listenerRule = new elb.ApplicationListenerRule(this, 'listenerRule', {
      action: undefined,
      conditions: [
        elb.ListenerCondition.hostHeaders([`api.${baseDomain}`, `app.${baseDomain}`, `admin.${baseDomain}`, baseDomain])
      ],
      listener: listener,
      priority: 3,
      targetGroups: [targetGroupHttp]
    });

    // the role assumed by the task and its containers
    const taskRole = new iam.Role(this, 'task-role', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      description: 'Role that the api task definitions use to run the api code'
    });

    taskRole.attachInlinePolicy(
      new iam.Policy(this, 'task-policy', {
        statements: [
          // policies to allow access to other AWS services from within the container e.g SES (Simple Email Service)
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ['SES:*', 'logs:*'],
            resources: ['*']
          }),
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: [
              'es:*',
              'dynamodb:*',
              'kms:*',
              'secretsmanager:*',
              'xray:*',
              'ssm:*',
              's3:*',
              'sqs:*',
              'cognito-idp:*',
            ],
            resources: ['*']
          })
        ]
      })
    );
    taskRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AmazonECSTaskExecutionRolePolicy'));
    taskRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('CloudWatchLogsFullAccess'));
    taskRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMReadOnlyAccess'));
    taskRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonS3ReadOnlyAccess'));

    // Security groups to allow connections from the application load balancer to the fargate containers
    this.ecsSG = new ec2.SecurityGroup(this, 'ecsSG', {
      vpc: this.vpc,
      allowAllOutbound: true
    });

    this.ecsSG.connections.allowFrom(
      albSG,
      ec2.Port.allTcp(),
      'Application load balancer'
    );
    // const secret = new aws_secretsmanager.Secret(this, 'Secret', {
    //   description: 'Secret for the api',
    //   secretObjectValue: {
    //     public_key: SecretValue.unsafePlainText('public_key'),
    //     private_key: SecretValue.unsafePlainText('private_key')
    //   }
    // });
    // this.rotationFunction = new python.PythonFunction(this, 'RotationFunction', {
    //   entry: 'lambda/rotation_function/',
    //   runtime: new fn.Runtime('python3.12', fn.RuntimeFamily.PYTHON, {
    //     supportsInlineCode: true,
    //     bundlingDockerImage: 'public.ecr.aws/sam/build-python3.12'
    //   }),
    //   architecture: Architecture.X86_64,
    //   timeout: cdk.Duration.seconds(900),
    //   handler: 'lambda_handler',
    //   environment: {
    //     'SECRETS_MANAGER_ENDPOINT': 'secretsmanager.ca-central-1.amazonaws.com'
    //   }
    // });
    // rotate permission to the rotation function
    // secret.grantRead(this.rotationFunction);
    // secret.grantWrite(this.rotationFunction);
    // secret.addRotationSchedule('RotationSchedule2', {
    //   rotationLambda: this.rotationFunction,
    //   automaticallyAfter: Duration.days(1)
    // });
    // this.rotationFunction.addPermission('allowInvocation', {
    //   principal: new ServicePrincipal('secretsmanager.amazonaws.com')
    // });
    const backendTaskDefinition = new ecs.TaskDefinition(
      this,
      'backend-task-definition',
      {
        taskRole: taskRole,
        compatibility: ecs.Compatibility.EC2,
        networkMode: ecs.NetworkMode.BRIDGE
      }
    );
    const log_driver = ecs.LogDriver.awsLogs({
      streamPrefix: '/backend',
      logGroup: props.logGroup
    });
    const collector_log_driver = ecs.LogDriver.awsLogs({
      streamPrefix: '/collector',
      logGroup: props.logGroup
    });
    const image = ecs.RepositoryImage.fromEcrRepository(
      ecr.Repository.fromRepositoryAttributes(this, 'Repository', {
        repositoryArn: aws_ssm.StringParameter.fromStringParameterName(this, 'backend-repository-arn', '/backend/repository/arn').stringValue,
        repositoryName: aws_ssm.StringParameter.fromStringParameterName(this, 'backend-repository-name', '/backend/repository/name').stringValue
      }),
      new Date().toISOString().substring(0, 10)
    );
    const otelImage = ecs.RepositoryImage.fromEcrRepository(
      ecr.Repository.fromRepositoryAttributes(this, 'OtelRepository', {
        repositoryArn: aws_ssm.StringParameter.fromStringParameterName(this, 'otel-repository-arn', '/backend/repository/arn').stringValue,
        repositoryName: aws_ssm.StringParameter.fromStringParameterName(this, 'otel-repository-name', '/backend/repository/name').stringValue
      }),
      'otel-collector'
    );
    const containerOtelService = backendTaskDefinition.addContainer(
      'containerOtelService',
      {
        image: otelImage,
        memoryReservationMiB: 64, // 32 MiB is the minimum memory reservation for a container
        essential: false,
        readonlyRootFilesystem: false,
        logging: collector_log_driver,
        containerName: 'aws-otel-collector',
        command: ['--config=/etc/ecs/otel.yaml'],
        environment: {
          ECS_FARGATE: 'false',
          AWS_REGION: this.region,
        },
        healthCheck: {
          command: ['CMD', '/healthcheck'],
          interval: cdk.Duration.seconds(5),
          timeout: cdk.Duration.seconds(3),
          retries: 3,
          startPeriod: cdk.Duration.seconds(60)
        }
      }
    );
    // const redis_endpoint = aws_ssm.StringParameter.fromStringParameterName(this, 'redis_endpoint', '/redis/endpoint').stringValue;
    // const redis_port = aws_ssm.StringParameter.fromStringParameterName(this, 'redis_port', '/redis/port').stringValue;

    // The docker container ec2 including the image to use
    const containerBackendEC2Service = backendTaskDefinition.addContainer(
      'container-backend-service',
      {
        image: image,
        memoryReservationMiB: 128 * 2,
        cpu: 2048,
        readonlyRootFilesystem: true,
        healthCheck: {
          command: ['CMD', '/healthcheck'],
          interval: cdk.Duration.seconds(5),
          timeout: cdk.Duration.seconds(3),
          retries: 3,
          startPeriod: cdk.Duration.seconds(60)
        },
        environment: {
          HEALTH_CHECK_PATH: '/status',
          HEALTH_CHECK_PORT: "8080",
          CORS_ORIGIN: '*',
          DISABLE_ORM: '1',
          BUCKET_NAME: this.s3BucketName,
          FRONTEND_DOMAINS: cdk.Fn.join(',', [baseDomain]),
          MAIN_TABLE: this.table_name,
          // REDIS_ENDPOINT: redis_endpoint,
          // REDIS_PORT: redis_port,
          OPENSEARCH_ADDRESS: this.opensearch_address,
          OPENSEARCH_SECRET: this.opensearch_secret,
          STRIPE_SECRET: props.stripe_secret.secretArn,
          // POSTMARK_SECRET: props.postmark_secret.secretArn,
          // SHOWQUERY: props.environment === 'production' ? "0" : "1",
          TRACING: props.environment === 'production' ? '0' : '1',
          EMAIL_QUEUE: props.email_queue.queueUrl,
          AWS_REGION: this.region,
          USERPOOL_ID: props.userPool.userPoolId,
          USERPOOL_CLIENT_ID: props.userPoolClient.userPoolClientId,
          USERPOOL_CLIENT_SECRET: props.userPoolClient.userPoolClientSecret.unsafeUnwrap(),
          CHARGEBEE_SECRET: this.chargebee_secret
        },
        containerName: 'backend-service',
        logging: log_driver
      }
    );
    // the docker container port mappings within the container
    containerBackendEC2Service.addPortMappings({ containerPort: 8080 });
    containerOtelService.addPortMappings({ containerPort: 4317 });
    containerBackendEC2Service.addContainerDependencies({
      container: containerOtelService,
      condition: ecs.ContainerDependencyCondition.START
    });
    containerBackendEC2Service.addLink(
      containerOtelService,
      'aws-otel-collector'
    );
    const backendImageDeployment = new ECRDeployment(this, 'DeployBackendImage', {
      src: new DockerImageName(props.backendImageUri),
      dest: new DockerImageName(`${image.imageName}`)
    });
    const otelImageDeployment = new ECRDeployment(this, 'DeployOtelImage', {
      src: new DockerImageName(props.otelImageUri),
      dest: new DockerImageName(`${otelImage.imageName}`)
    });
    // The ECS Service used for deploying Backend Service tasks
    // const securityGroup = ec2.SecurityGroup.fromSecurityGroupId(this, "RedisClientSecurityGroup", cdk.Fn.importValue("Redis-client-security-group"))
    this.Ec2Service = new ecs.Ec2Service(this, 'Ec2Service', {
      serviceName: 'backend-service',
      cluster,
      desiredCount: props.environment === 'production' ? 5 : 1,
      taskDefinition: backendTaskDefinition,
      placementStrategies: [PlacementStrategy.packedByMemory()],
      maxHealthyPercent: 300,
      minHealthyPercent: 100,
      healthCheckGracePeriod: cdk.Duration.seconds(120),
      capacityProviderStrategies: [
        {
          capacityProvider: props.capacityProvider,
          weight: 1,
          base: 1
        }
      ]
    });
    // add to a target group so make containers discoverable by the application load balancer
    this.Ec2Service.attachToApplicationTargetGroup(targetGroupHttp);
    this.Ec2Service.node.addDependency(backendImageDeployment);
    this.Ec2Service.node.addDependency(otelImageDeployment);
    const scalableTargetEc2 = this.Ec2Service.autoScaleTaskCount({
      minCapacity: props.environment === 'production' ? 3 : 1,
      maxCapacity: 10
    });

    scalableTargetEc2.scaleOnMemoryUtilization('ScaleUpMem2', {
      targetUtilizationPercent: 90
    });

    scalableTargetEc2.scaleOnCpuUtilization('ScaleUpCPU2', {
      targetUtilizationPercent: 80
    });

    // Add S3 bucket URL output
    new CfnOutput(this, "S3BucketURL", {
      description: "S3 Bucket URL for profile images",
      exportName: `backend-s3-bucket-url`,
      value: `https://${this.s3BucketName}.s3.${this.region}.amazonaws.com`,
    });
  }
}
