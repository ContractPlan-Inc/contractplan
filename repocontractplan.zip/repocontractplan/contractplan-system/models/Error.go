package models

import "fmt"

type Error struct {
	ID   string `dynamodbav:"a"`
	S    string `json:"S"`
	Data any
}

func (err *Error) Error() string {
	return fmt.Sprintf("Error: %s", err.S)
}

func (Error) NewError(message string) *Error {
	return &Error{S: message}
}
