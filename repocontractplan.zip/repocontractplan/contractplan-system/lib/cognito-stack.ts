import * as cdk from "aws-cdk-lib";
import {Construct} from "constructs";
import {ClientAttributes, UserPool, UserPoolClient, UserVerificationConfig, VerificationEmailStyle} from "aws-cdk-lib/aws-cognito";
import { CfnOutput } from "aws-cdk-lib";

// import * as sqs from 'aws-cdk-lib/aws-sqs';

export interface CognitoStackProps extends cdk.StackProps {
    environment: string;
}


export class CognitoStack extends cdk.Stack {
    public userPool: UserPool
    public userPoolClient: UserPoolClient
    constructor(parent: Construct, id: string, props: CognitoStackProps) {
        super(parent, id, props);
        const kmsKey = cdk.aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));
        const customAttributes = ['company', 'plan', 'role'];
        const userVerificationOptions: UserVerificationConfig = {
            emailStyle: VerificationEmailStyle.CODE, // Use verification code via email
          };
        this.userPool = new UserPool(this, 'UserPool', {
            userPoolName: 'ContractPlan',
            selfSignUpEnabled: true,
            deletionProtection: true,
            accountRecovery: cdk.aws_cognito.AccountRecovery.EMAIL_ONLY,
            removalPolicy: cdk.RemovalPolicy.RETAIN,
            passwordPolicy: {
                minLength: 8,
                requireDigits: true,
                requireUppercase: true,
                requireLowercase: true,
                requireSymbols: true,
                tempPasswordValidity: cdk.Duration.days(3),
            },
            mfa: cdk.aws_cognito.Mfa.OPTIONAL,
            mfaSecondFactor: {
                sms: false,
                otp: true,
            },
            customAttributes: Object.assign({},
                ...customAttributes.map(
                    (attr): { [key: string]: cdk.aws_cognito.ICustomAttribute } => (
                        {
                            [attr]: new cdk.aws_cognito.StringAttribute({mutable: true})
                        }
                    )
                )
            ),
            userVerification: userVerificationOptions,
        });
        const clientPoolAttributes = {
            refreshTokenValidity: cdk.Duration.days(30),
            idTokenValidity: cdk.Duration.minutes(60),
            accessTokenValidity: cdk.Duration.minutes(60),
            generateSecret: false,
            enableTokenRevocation: true,
            writeAttributes: new ClientAttributes().withStandardAttributes({
                email: true,
                givenName: true,
                middleName: true,
                familyName: true,
                fullname: true,
                profilePicture: true,
                locale: true,
                phoneNumber: true,
                timezone: true,
            }),
            readAttributes: new ClientAttributes().withStandardAttributes({
                email: true,
                givenName: true,
                middleName: true,
                familyName: true,
                fullname: true,
                profilePicture: true,
                locale: true,
                emailVerified: true,
                phoneNumber: true,
                phoneNumberVerified: true,
                timezone: true,
            }).withCustomAttributes(
                ...customAttributes
            ),
        }
// Create a user pool client
        new UserPoolClient(this, 'FrontendClient', {
            userPool: this.userPool,
            userPoolClientName: 'FrontendClient',
            ...clientPoolAttributes
        });
        this.userPoolClient = new UserPoolClient(this, 'BackendClient', {
            userPool: this.userPool,
            userPoolClientName: 'BackendClient',
            ...clientPoolAttributes,
            generateSecret: true,
            writeAttributes: new ClientAttributes().withStandardAttributes({
                email: true,
                givenName: true,
                middleName: true,
                familyName: true,
                fullname: true,
                profilePicture: true,
                locale: true,
                phoneNumber: true,
                timezone: true,
            }).withCustomAttributes(
                ...customAttributes
            ),
        })
        new CfnOutput(this, "UserPoolID", {
            description: "User Pool ID",
            exportName: `cognito-user-pool-id`,
            value: this.userPool.userPoolId,
        });
        new CfnOutput(this, "UserPoolClientID", {
            description: "User Pool Client ID",
            exportName: `cognito-user-pool-client-id`,
            value: this.userPoolClient.userPoolClientId,
        });
    }

}
