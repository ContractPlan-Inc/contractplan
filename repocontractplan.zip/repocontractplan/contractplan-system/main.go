package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"reflect"
	"strings"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/vektah/gqlparser/v2/ast"

	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler/extension"
	"github.com/99designs/gqlgen/graphql/handler/transport"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"

	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/99designs/gqlgen/graphql/playground"

	"cloudparallax.com/backend/app/auth"
	"cloudparallax.com/backend/graph/generated"
	"cloudparallax.com/backend/graph/resolvers"
	"cloudparallax.com/backend/models"
	"cloudparallax.com/backend/tracing"
	"cloudparallax.com/backend/utils"
)

// Defining the Graphql handler
func graphqlHandler() gin.HandlerFunc {
	// NewExecutableSchema and Config are in the generated.go file
	// Resolver is in the resolver.go file
	c := generated.Config{Resolvers: &resolvers.Resolver{}}
	c.Directives.HasPermission = func(ctx context.Context, obj interface{}, next graphql.Resolver, grantedFor, permission string) (interface{}, error) {
		userInterface := utils.UserForContext(ctx)
		if userInterface == nil {
			return nil, fmt.Errorf("not authenticated")
		}
		user := userInterface.(*models.User)
		var accessible models.Access
		resourceId := ""
		resourceType := ""
		value := reflect.ValueOf(obj)
		if obj != nil && !value.IsZero() && !value.IsNil() && value.IsValid() {
			if value.Kind() == reflect.Ptr {
				value = value.Elem()
			}
			if value.Kind() == reflect.Struct {
				if value.FieldByName("ID").IsValid() {
					resourceId = value.FieldByName("ID").String()
				}
				if value.FieldByName("EntityStream").IsValid() {
					resourceType = value.FieldByName("EntityStream").String()
				}
			}
		}
		for _, policy := range user.Policies {
			if policy.For == grantedFor && policy.Grant == permission {
				accessible = true
			}
			if resourceType != "" {
				for _, resource := range policy.Resources {
					if result, ok := models.GetResource(strings.ToUpper(resourceType)); ok == true && result == resource {
						accessible = policy.Effect
					}
				}
			}
			if resourceId != "" {
				for _, resource := range policy.ResourceIDs {
					if resource == resourceId {
						accessible = policy.Effect
					}
				}
			}
		}

		if accessible {
			return next(ctx)
		}
		return nil, fmt.Errorf("Access denied against %s for %s", grantedFor, permission)
	}
	cache := graphql.MapCache[*ast.QueryDocument]{}
	APQCache := graphql.MapCache[string]{}
	srv := handler.NewDefaultServer(generated.NewExecutableSchema(c))
	srv.AddTransport(transport.SSE{}) // <---- This is the important
	srv.AddTransport(transport.Options{})
	srv.AddTransport(transport.GET{})
	srv.AddTransport(transport.POST{})
	srv.AddTransport(transport.MultipartForm{})
	srv.SetQueryCache(cache)
	srv.Use(extension.Introspection{})
	srv.Use(extension.AutomaticPersistedQuery{
		Cache: APQCache,
	})
	srv.AddTransport(transport.Websocket{
		KeepAlivePingInterval: 10 * time.Millisecond,
		Upgrader: websocket.Upgrader{
			CheckOrigin: func(r *http.Request) bool {
				return true
			},
		},
	})

	srv.Use(tracing.Tracer{})
	return func(c *gin.Context) {
		srv.ServeHTTP(c.Writer, c.Request)
	}
}

// Defining the Playground handler
func playgroundHandler() gin.HandlerFunc {
	h := playground.Handler("GraphQL", "/query")

	return func(c *gin.Context) {
		h.ServeHTTP(c.Writer, c.Request)
	}
}

func main() {
	// Setting up Gin
	r := gin.New()
	r.Use(gin.Recovery())
	//r.Use(gin.Logger())
	r.Use(auth.GinContextToContextMiddleware())
	r.Use(cors.New(cors.Config{
		//AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"*"},
		AllowHeaders:     []string{"*"},
		ExposeHeaders:    []string{"*"},
		AllowCredentials: true,
		AllowAllOrigins:  true,
		AllowFiles:       true,
		MaxAge:           12 * time.Hour,
	}))
	r.POST("/query", graphqlHandler())
	r.GET("/query", graphqlHandler())
	r.GET("/", playgroundHandler())
	r.GET("/status", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"message": "pong",
		})
	})
	if os.Getenv("AWS_PROFILE") == "" {
		r.RunTLS(":8080", "/ssl-cert.pem", "/ssl-key.pem")
	} else if err := http.ListenAndServe(":8080", r); err != nil {
		panic(err)
	}
}
