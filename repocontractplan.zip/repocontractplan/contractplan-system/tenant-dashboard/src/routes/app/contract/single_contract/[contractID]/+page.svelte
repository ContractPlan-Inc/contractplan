<script lang="ts">
  import type { PageData } from './$types';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import CommonChartSmall from '$lib/components/charts/commonChartSmall.svelte';
  import ChartLabel from '$lib/components/elements/chartLabel.svelte';
  import Icon from '@iconify/svelte';
  import AssignedUser from '$lib/components/elements/assignedUser.svelte';
  import PartnerComponent from '$lib/components/elements/PartnerComponent.svelte';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { type ContractPartner, GetSummaryDoc, type GetSummaryQuery, type Service } from '$lib/generated/graphql';
  import Loader from '$lib/components/elements/loader.svelte';
  import { page } from '$app/stores';
  import { title } from '$lib/state/store';
  import dayjs from 'dayjs';

  const contractId = $page.params.contractID;
  let engagementsType = $state('day');

  let { data }: PageData = $props();

  let summaryRecords = $state([]);
  let summaryTotal = $state([]);
  let services = $state<Service[]>([]);
  let partner = $state<ContractPartner>();
  title.set('Contract Dashboard ' + contractId);
  let selectedService = $state('');
  let loading = $state(true);
  let formatter = $state(new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2,
    minimumFractionDigits: 2
  }))

  let selectedDate = $state(0);
  let actualUnitsAtDate = $state(0);
  let plannedUnitsAtDate = $state(0);
  let unitVarienceAtDate = $state(0);
  
  $effect(async () => {
// getActualEngagements()
    loading = true;
    const queryRepository = new GraphQLQueryRepository<GetSummaryQuery>();
    const engagementsResult = await queryRepository.getItems(GetSummaryDoc, {
      ID: contractId,
      Type: engagementsType,
      ServiceID: selectedService
    }, 1, 1);
    const engagementResult2 = await queryRepository.getItems(GetSummaryDoc, {}, 10, 10)
    console.log("RESULT2", engagementResult2)
    summaryRecords = engagementsResult.data?.getSummary?.SummaryRecords ?? [];
    summaryTotal = engagementsResult.data?.getSummary?.SummaryTotal ?? [];
    title.set(engagementsResult.data?.getSummary?.Contract?.ContractName);

    selectedDate = getTodayIndexOfDays(summaryRecords)

    refreshUnitsCount();

    console.log('summaryRecords', summaryRecords);
    console.log('summaryTotal', summaryTotal);
    console.log('RESULTS', engagementsResult);
    services = engagementsResult.data?.getSummary?.Contract?.Services;
    partner = engagementsResult.data?.getSummary?.Contract?.ContractPartner as ContractPartner;
    console.log('partner', engagementsResult.data?.getSummary?.SummaryRecords[0]?.currency);
    const currency = engagementsResult.data?.getSummary?.SummaryRecords[0]?.currency;

    formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      maximumFractionDigits: 2,
      minimumFractionDigits: 2
    });
    loading = false;
  });

  function getActualEngagements() {
    summaryRecords.forEach(element => {
      console.log("elements", element)
    });
  }
  function getPlannedEngagements() {

  }


function getTodayIndexOfDays(records){
  const today = dayjs("2024-01-31T00:00:00.000Z")
  console.log("today", today)
  let index = 0
  records.forEach((item, i) => {
    if(today.isSame(dayjs(item.key_as_string), 'day')){
      index = i
    }
  })

  return index;

}

function getPlannedUnitsAsAtDate(date: number, records ){
  return records.reduce((sum: number, record, i:number) => {
    if(i < date){
      return sum + record.target_engagements.sum;
    }
    return sum
  }, 0)
}

function getActualUnitsAsAtDate(date: number, records ){
  // if(records.length)
  return records.reduce((sum: number, record, i: number) => {
    if(i < date){
      return sum + record.engagements.sum;
    }
    return sum

  }, 0)
}

  function getSumOfObjectArray(array, attribute1, attribute2) {
    let tar = 0
    array.forEach(value => {
      tar += value[attribute1][attribute2];
    });
    return tar
  }

function getEngagementVariance(){
    let tar = getSumOfObjectArray(summaryRecords, 'target_engagements','sum')
    let act = 0
    summaryRecords.forEach(value => {
      act += value.engagements.sum;
    });
    console.log("getActualEngagementCost",tar)
    console.log("getPlannedEngagementCost",act)
    return tar-act;
}
function getEngagementCostVariance(){
    let tar = getSumOfObjectArray(summaryRecords, 'target_engagement_cost','sum')
    let act = 0
    summaryRecords.forEach(value => {
      act += value.engagement_cost.sum;
    });
    console.log("getActualEngagementCost",tar)
    console.log("getPlannedEngagementCost",act)
    return (tar-act)/100.00;
}

  function getLoseAmountCurrentMonth() {
    let eng_cost = 0;
    let tar_eng_cost = 0;
    summaryRecords.forEach(obj => {
      if (dayjs(obj.key_as_string).format("MMM") === dayjs(summaryRecords[selectedDate]?.key_as_string).format("MMM")) {
        eng_cost += obj.engagement_cost.sum
        tar_eng_cost += obj.target_engagement_cost.sum
      }
    });
    return (tar_eng_cost-eng_cost)/100
  }
  function getLoseAmountCurrentMonthAsPresentage() {
    let eng_cost = 0;
    let tar_eng_cost = 0;
    summaryRecords.forEach(obj => {
      if (dayjs(obj.key_as_string).format("MMM") === dayjs(summaryRecords[selectedDate]?.key_as_string).format("MMM")) {
        eng_cost += obj.engagement_cost.sum
        tar_eng_cost += obj.target_engagement_cost.sum
      }
    });
    return ((((tar_eng_cost-eng_cost))/tar_eng_cost)*100).toFixed(2);
    
  }

function refreshUnitsCount(){
    plannedUnitsAtDate = getPlannedUnitsAsAtDate(selectedDate, summaryRecords)
    actualUnitsAtDate = getActualUnitsAsAtDate(selectedDate, summaryRecords);
    console.log("plannedUnitsAtDate", plannedUnitsAtDate)
    console.log("actualUnitsAtDate", actualUnitsAtDate)
    unitVarienceAtDate = plannedUnitsAtDate- actualUnitsAtDate;
}


  // let componentMap: { [key: string]: any } = {
  //   'day': LineSmall,
  //   'week': LineSmall,
  //   'month': CommonChartSmall,

  // };

</script>
<svelte:head>
  <title>{$title}</title>
</svelte:head>

<section>
  <PageHeader>
    <div class="flex items-center space-x-4">

    </div>
  </PageHeader>
  <PageBody>
    {#if loading}
      <Loader loading={true} type="dataLoader" />
    {:else}
      <div class="w-full h-full mb-8 gap-4 grid grid-cols-3 ">
        <!-- Reveneue Component -->
        <div class="border rounded-md p-5 shadow-lg col-span-1">
          <div class=" w-full flex justify-between  items-start content-center gap-4">
            <div>
              <h2 class=" text-2xl font-medium">Engagements</h2>
              <p class=" text-sm text-gray-500">{dayjs(summaryRecords[0]?.key_as_string).format("MMM YYYY")}
                - {dayjs(summaryRecords[summaryRecords.length - 1]?.key_as_string).format("MMM YYYY")}</p>
            </div>
            <div class="flex flex-row w-full gap-2 py-2">

              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md"
                      bind:value={engagementsType}>
                <option value="day">Daily</option>
                <option value="week">Weekly</option>
                <option value="month">Monthly</option>
              </select>
              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md"
                      bind:value={selectedService}>
                <option value="">All Services</option>
                {#each services as service}
                  <option value={service.ID}>{service.ServiceName}</option>
                {/each}
              </select>


              <button
                class=" border  justify-center  w-1/3 px-1 py-2 text-sm  inline-flex gap-2 items-center rounded-md">
                <Icon icon="bx:calendar" width="18" />
              </button>


            </div>

          </div>

          <div>
            <div class="w-full grid grid-cols-2 justify-between gap-3 ">
              <ChartLabel
                color="black"
                key="Planned"
                value={isNaN(summaryTotal?.target_engagements?.sum) ? 0 : summaryTotal?.target_engagements?.sum}
              />
              <ChartLabel
                color="primary"
                key="Actual"
                value={isNaN(summaryTotal?.engagements?.sum) ? 0 : summaryTotal?.engagements?.sum} />
            </div>
            <div>
              <!-- <CommonChartSmall
                actualData={summaryRecords.map(o => o.engagements.sum )}
                plannedData={summaryRecords.map(o => o.target_engagements.sum )}
                labels={summaryRecords.map(o => dayjs(o.key_as_string).format('MMM YYYY'))} >
              </CommonChartSmall> -->

              <CommonChartSmall
                ID="1"
                chartType={engagementsType === 'day' || engagementsType === 'week' ? 'line' : 'bar'}
                actualData={summaryRecords.map(o => o.target_engagements.sum )}
                plannedData={summaryRecords.map(o => o.engagements.sum )}
                labels={summaryRecords.map(o => {
                    const format =  engagementsType === 'month' ? 'MMM': 'MMM DD'
                    return dayjs(o.key_as_string).format(format)
                  })}
                plannedColor='#FF914D'
                actualColor='#000'
              />
                                                              
            </div>
          </div>


        </div>
        <!-- Reveneue Component -->


        <!-- Engagement Cost Component -->
        <div class=" border  rounded-md  col-span-1 p-5 shadow-lg">
          <div class=" w-full flex justify-between  items-start content-center gap-4">
            <div>
              <h2 class=" text-2xl font-medium">Engagement Cost</h2>
              <p class=" text-sm text-gray-500">{dayjs(summaryRecords[0]?.key_as_string).format("MMM YYYY")}
                - {dayjs(summaryRecords[summaryRecords.length - 1]?.key_as_string).format("MMM YYYY")}</p>
            </div>
            <div class="flex flex-row w-full gap-2 py-2">

              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md"
                      bind:value={engagementsType}>
                <option value="day">Daily</option>
                <option value="week">Weekly</option>
                <option value="month">Monthly</option>
              </select>
              <select name="" id="" class=" bg-white border border-gray-400  w-2/3 px-1 py-2 text-sm rounded-md"
                      bind:value={selectedService}>
                <option value="">All Services</option>
                {#each services as service}
                  <option value={service.ID}>{service.ServiceName}</option>
                {/each}
              </select>


              <button
                class=" border  justify-center  w-1/3 px-1 py-2 text-sm  inline-flex gap-2 items-center rounded-md">
                <Icon icon="bx:calendar" width="18" />
              </button>


            </div>

          </div>

          <div>
            <div class="w-full grid grid-cols-2 justify-between gap-3 ">
              <ChartLabel color="black" key="Planned" value={formatter.format(summaryTotal?.target_engagement_cost?.sum/100.0)} />
              <ChartLabel color="primary" key="Actual" value={formatter.format(summaryTotal?.engagement_cost?.sum/100.0)} />
            </div>
            <div>
              <CommonChartSmall
                ID="2"
                chartType={engagementsType === 'day' || engagementsType === 'week' ? 'line' : 'bar'}
                actualData={summaryRecords.map(o => o.target_engagement_cost.sum )}
                plannedData={summaryRecords.map(o => o.engagement_cost.sum )}
                labels={summaryRecords.map(o => {
                    const format =  engagementsType === 'month' ? 'MMM': 'MMM DD'
                    return dayjs(o.key_as_string).format(format)
                  })}
                plannedColor='#FF914D'
                actualColor='#000'
              />
            </div>
          </div>
        </div>
      


        <!-- Projected Variance Component -->
        <div class=" border rounded-md basis-full sm:basis-[48%] lg:basis-[32%] p-6 bg-green-50 shadow-lg">
          <div class="  w-full  flex justify-between py-2 pb-5">
            <h2 class=" text-2xl font-medium mb-4">Projected Variance</h2>
          </div>

          <div class="justify-center">
            <div>
              <select class="p-2 rounded-lg bg-white border" bind:value={selectedDate} onchange={refreshUnitsCount}>
                {#each summaryRecords  as record , i}
                  <option value={i} selected={selectedDate == i} disabled={dayjs(record.key_as_string).isBefore(dayjs("2024-01-31T00:00:00.000Z"))} >{dayjs(record.key_as_string).format('MMM D, YYYY')}</option>
                {/each}
                <option></option>  
              </select> 
            </div>
          <div class="flex h-full w-full gap-6 items-center justify-center py-5">
            <div class="h-fit flex-wrap justify-center">
              <div class="flex-col p-3 bg-black text-white rounded-2xl border  w-16 h-16 flex justify-center items-center ">
                <Icon icon="pepicons-pencil:file" width="32" />
              </div>
            </div>

            <div class="h-fit">
              <ul class="leading-loose list-disc marker:text-green-500 marker:text-xl text-sm ml-4   ">
                <!-- <li> You will lose 250$/month of $10,000 span</li>
<li>You will lose 0.25% per month</li> -->
                <!-- <li>You need add more {Math.round(getEngagementVariance()*summaryRecords.length/(summaryRecords.length-selectedDate))} units/day</li> -->
                <li>You will lose {(getLoseAmountCurrentMonth()).toFixed(2)}$/month of ${summaryTotal.target_engagement_cost.sum/100}</li>
                <li>You will lose {getLoseAmountCurrentMonthAsPresentage()}% per month</li>
                <li>You need add more {Math.round(getEngagementVariance()/(summaryRecords.length-selectedDate))} engagements/day</li>

                <!-- = (Planned - Actual) / ([last_occurrence_of_the_month]-[today_date]) -->
                <!-- <li>You need to complete 50 units within this month</li> -->
              </ul>
            </div>
          </div>
          </div>
          <!-- Contract Forecasting Component -->
          <div
            class="rounded-md basis-full sm:basis-[48%] lg:basis-[32%] self-stretch justify-center items-center pt-6">
            <div class="  w-full  h-[60%] shadow-lg items-center justify-center border p-5 rounded-md">
              <h2 class=" text-2xl font-medium mb-4">Contract Forecasting</h2>

              <div class=" flex items-center gap-3 my-6 ">
                <span
                  class=" bg-green-400 rounded-full  inline-flex gap-1 justify-center items-center  text-white w-8 h-8 p-1">
                  <Icon icon="mdi:arrow-up" width="30" />
                </span>
                <div>
                  <p class=" text-sm text-gray-400">Current Plan</p>
                  <p class=" font-bold text-lg">${(getSumOfObjectArray(summaryRecords, 'target_engagement_cost','sum')/100).toFixed(2)}</p>
                </div>
              </div>

              <div class=" flex items-center gap-3 my-6">
                <span
                  class=" bg-red-400 rounded-full  inline-flex gap-1 justify-center items-center  text-white w-8 h-8 p-1">
                  <Icon icon="mdi:arrow-down" width="30" />
                </span>
                <div>
                  <p class=" text-sm text-gray-400">Forecasting till end</p>
                  <p class=" font-bold text-lg">${(getEngagementCostVariance()/(summaryRecords.length-selectedDate)).toFixed(2)}</p>
                  <p class=" text-red-600 text-xs">You will be loss of ${getEngagementCostVariance()}</p>
                </div>
              </div>
            </div>
            <!-- <div class="flex flex-col justify-center items-center  h-[34%] gap-[6%] shadow-lg border p-6 rounded-md "> -->
            <!--   <PartnerComponent bind:partner={partner} /> -->
            <!-- </div> -->
          </div>
          <!-- Contract Forecasting Component -->
        </div>
        <!-- Projected Variance Component -->






        <!-- Assigned Users Component -->
        <div class=" border rounded-md basis-full sm:basis-[48%] lg:basis-[32%] p-6 shadow-lg">
          <div>
            <h2 class=" text-2xl font-medium mb-4">Assigned Users</h2>
            <AssignedUser isOnline />
            <AssignedUser />
            <AssignedUser isOnline />
            <AssignedUser />
            <AssignedUser isOnline />
          </div>
        </div>
        <!-- Assigned Users Component -->

      </div> <!--Component Container ends-->
    {/if}
  </PageBody>
</section>
