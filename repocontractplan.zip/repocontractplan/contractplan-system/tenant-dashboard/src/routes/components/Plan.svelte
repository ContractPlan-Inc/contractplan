<script>
  /**
   * @type {any}
   */
  export let plan;
  let buttonText = "Select";

  let subscribed = false;

  function subscribe(e) {
    if (subscribed) {
      buttonText = "Select";
    } else {
      buttonText = `Current Plan`;
    }

    // Toggle the subscription status
    subscribed = !subscribed;

    // Stop the propagation of the click event to prevent the popup from closing
    e.stopPropagation();
  }
</script>

<div
  class=" rounded-xl lg:w-2/3 w-full text-center lg:text-left   border border-orange-200 hover:border-orange-500 shadow-md shadow-orange-100 p-8 flex flex-col gap-2 transition-all">
  <div class="flex flex-col gap-6">
    <div class="flex items-center justify-between">
      <h3 class="text-zinc-900 text-2xl font-medium">Subscribe Now for</h3>
      <button
        class="px-6 font-medium py-3 border border-black rounded-lg hover:bg-orange-500 hover:text-white hover:border-orange-500 transition-all"
        onclick={subscribe}
      >
        {buttonText}
      </button>
    </div>
    <h2 class="text-orange-500 text-4xl font-semibold">${plan.planPrice / 100}<span class="text-lg">/month</span></h2>
  </div>

  <ul class=" list-inside lg:list-outside" style="list-style-type:disc;">
    <li>1 user account per month.</li>
  </ul>

  <!--    <button class="px-6 font-medium py-3 border border-black rounded-lg hover:bg-orange-500 hover:text-white hover:border-orange-500 transition-all">-->
  <!--        Subscribe-->
  <!--    </button>-->

</div>

