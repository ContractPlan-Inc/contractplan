<script lang="ts">
  import posthog from "posthog-js";
  import { browser } from "$app/environment";
  import { onMount } from "svelte";

  onMount(() => {
    if (browser) {
      posthog.init("phc_u4RqrKDciNDJeWwb8G83QyuvQTojC8CRg7at6srVSVQ", {
        api_host: "https://us.i.posthog.com",
        person_profiles: "identified_only", // or 'always' to create profiles for anonymous users as well
      });
    }
  });
  import "../app.css";
  import Analytics from "$lib/components/analytics.svelte";
  interface Props {
    children?: import("svelte").Snippet;
  }

  let { children }: Props = $props();

  function applyTheme(selectedColor: string) {
    document.documentElement.classList.remove(
      "blue-theme",
      "red-theme",
      "green-theme",
      "orange-theme",
    );

    if (selectedColor === "blue") {
      document.documentElement.classList.add("blue-theme");
    } else if (selectedColor === "red") {
      document.documentElement.classList.add("red-theme");
    } else if (selectedColor === "green") {
      document.documentElement.classList.add("green-theme");
    } else {
      document.documentElement.classList.add("orange-theme");
    }
  }

  let isDarkMode = false;
  let selectedColor = "orange";

  if (typeof window !== "undefined") {
    isDarkMode = localStorage.getItem("dark-mode") === "true";
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      document.body.style.backgroundColor = "#1f3548";
    } else {
      document.documentElement.classList.remove("dark");
      document.body.style.backgroundColor = "";
    }

    selectedColor = localStorage.getItem("primary-color") || "orange";

    applyTheme(selectedColor);
  }
</script>

<Analytics />
{@render children?.()}
