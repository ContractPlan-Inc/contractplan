import type { Client, OperationResult } from '@urql/svelte';
import type { DocumentNode } from 'graphql';

export interface QueryRepository<T> {
  client: Client;

  getItems(
    query: DocumentNode,
    filter: object,
    page: number,
    perPage: number
  ): Promise<OperationResult<T>>;
}
