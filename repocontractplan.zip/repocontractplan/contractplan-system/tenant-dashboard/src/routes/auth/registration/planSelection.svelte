<script lang="ts">
  import {GraphQLQueryRepository} from '$lib/api/query-repository';
  import {
    GetPlansDoc,
    type GetPlansQuery,
    type Plan,
    type SignUpInput,
    type SubscribePlanMutation
  } from '$lib/generated/graphql';
  import {onMount} from 'svelte';
  import PlanEl from '$lib/components/elements/plan.svelte';
  import {type OperationResult} from '@urql/svelte';
  import Loader from '$lib/components/elements/loader.svelte';

  let plans: Plan[] = $state([]);

  let selectedPlan: string = $state('');
  let loading = $state(false);
  let loadingData = $state(false);


  interface RegFormProps {
    regForm: SignUpInput;
    status: string;
  }

  let {regForm = $bindable(), status = $bindable()}: RegFormProps = $props();


  async function fetchPlans() {
    try {
      const queryRepository = new GraphQLQueryRepository<GetPlansQuery>();
      const plansQuery = await queryRepository.getItems(GetPlansDoc, {}, 1, 10);

      plans = plansQuery?.data?.listPlans as Plan[];
      loadingData = false;

      console.log('PLANS:', plans);
    } catch (e) {
      console.log('ERROR:', e);
    }
  }

  async function subscribePlan() {
    loading = true;
    try {
      const queryRepository = new GraphQLQueryRepository<SubscribePlanMutation>();

      await queryRepository.subscribePlan(
        {
          PlanID: selectedPlan
        }
      ).then((res) => {
        if (res.data) {
          const subscribePlanData = res.data;

          if (subscribePlanData.subscribePlan.success) {
            loading = false;
            window.location.href = subscribePlanData.subscribePlan.url as string;
          }
        } else if (res.error) {
          console.log('errorr', res.error.message);
        }
      }).catch((err) => {
        loadingData = false;
        console.log('err', err);
      });

    } catch (e) {
      console.log('e', e);
    }
  }

  onMount(async () => {
    loadingData = true;

    await fetchPlans();
  });

</script>

<div class="  space-y-6 p-9">
  <h1 class="mb-6 text-2xl font-bold">Select Plan</h1>
  <div class="mx-auto space-y-4 w-full">
    <Loader loading={loadingData} type="dataLoader"/>
    {#each plans as plan (plan.ID)}
      <PlanEl plan={plan} selected={selectedPlan == plan.ID} on:planSelected={() => {
          selectedPlan = plan.ID

      }}/>
    {/each}
  </div>

  <div class="w-full">
    <form action="?/login" method="post" onsubmit={(event)=>{event.preventDefault();subscribePlan()}}
    >
      <input hidden name="selectedPlan" type="text" value={selectedPlan}/>
      <button class="justify-center p-2.5 px-8 w-full text-white bg-black rounded-lg py-[11px]">Next
      </button>
    </form>
  </div>
</div>

<Loader {loading} type="pageLoader"/>



