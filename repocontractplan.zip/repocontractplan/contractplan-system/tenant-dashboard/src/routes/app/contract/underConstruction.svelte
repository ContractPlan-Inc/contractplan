<script>
  import SideOver from "$lib/components/side-over.svelte";
  import Input from "$lib/components/elements/input.svelte";
  import Select from "$lib/components/elements/select.svelte";


  let project = {
    id: 0,
    contract_name: "",
    contract_partner: "",
    contract_alias: "",
    start_date: "",
    end_date: "",
    dollar_amount: 0.00,
    resource_identifier: "",
    service_info: [
      {
        service_frequency: 0,
        service_period: "daily",
        service_days: []
      }
    ],
    service: [
      {
        name: "",
        description: "",
        service_total_price: 0,
        service_engagement: 1,
        unit: [
          {
            definition: "",
            price: 0.00
          }
        ]
      }
    ]
  };

  let filteredData;
  let servicePeriods = [
    { title: "Daily", value: "daily" },
    { title: "Weekly", value: "weekly" },
    { title: "Monthly", value: "monthly" }
    // { title: "Yearly", value: "yearly" }
  ];
</script>

<SideOver {show} {title}>
  <form class="mt-2 overflow-auto">
    <div class="flex flex-col space-y-5 p-2 ">
      <h1 class="text-lg font-semibold">Basic Info</h1>
      <Input label="Contract Name" value={project.contract_name} />
      <Input label="Contract Partner" value={project.contract_partner} />
      <Input label="Contract Alias" value={project.contract_alias} />
      <Input label="Start Date" type="date" value={project.start_date} />
      <Input label="End Date" type="date" value={project.end_date} />
      <Input label="Dollar amount" type="number" value={project.dollar_amount} />
      <h1 class="text-lg font-semibold">Service Info</h1>
      <div class="flex flex-col space-y-5 p-2 border">
        <Select label="Period" options={servicePeriods} value={project.service_info.service_period} />
        {#if project.service_info.service_period === "weekly"}
          <Input label="Service Days" value={project.service_info.service_days} />

          <!--            <Select label="Weekdays" value={project.service_info.service_weekdays} options={weekdays} />-->
        {/if}
        {#if project.service_info.service_period === "monthly"}
          <!--            <Datepicker pickerRule="free"-->
          <!--                        reSelected-->
          <!--                        viewDate={selected[0]}-->
          <!--                        bind:selected-->
          <!--            />-->
        {/if}
        {#if project.service_info.service_period === "yearly"}
          <!--            <Select label="Months" value={project.service_info.service_months} options={months} multiple />-->
          <!--            <Select label="Days of Month" value={project.service_info.service_days_of_month} options={daysOfMonth} multiple />-->
        {/if}

      </div>
      <h1 class="text-lg font-semibold">Services</h1>
      {#each project.service as service}
        <div class="flex flex-col space-y-5 p-2 border">
          <Input label="Name" value={service.name} />
          <Input label="Description" value={service.description} />
          <Input label="Engagement" value={service.service_engagement} />
          {#each service.unit as unit}
            <Input label="Unit Definition" value={unit.definition} />
            <Input label="Unit Price" value={unit.price} />
          {/each}
        </div>
      {/each}
      <Input label="Resource Identifier" value={project.resource_identifier} />
      <!-- <ImageUpload value={project.imageUrl}/>
      <Input label="Name" value={project.name}/>
      <TextArea label="Description" value={project.task}/>
      <Select label="Category" value={project.category} options={categories}/> -->
      <button class="px-2 py-1 border rounded text-white bg-[#62CDFF]" type="submit">Save</button>
    </div>

  </form>
  <div>
    <!-- {#each filteredData as item}
      {item.name}
      {#each item.items as tas}
        {tas.name}
      {/each}
    {/each} -->
  </div>
</SideOver>
