<script lang="ts">
  import { onMount } from 'svelte';
  import Input from '$lib/components/elements/input.svelte';
  import { PUBLIC_COGNITO_CLIENT_ID, PUBLIC_USERPOOL_ID } from '$env/static/public';
  import { CognitoIdentityClient } from '@aws-sdk/client-cognito-identity';
  import { AuthenticationDetails, CognitoUser, CognitoUserPool } from 'amazon-cognito-identity-js';
  import * as yup from 'yup';
  import { auth, authState } from '$lib/state/auth';
  import { goto } from '$app/navigation';
  import { userPool } from '$lib/cognito/pool';
  import { getCurrentPlan, validation } from './service';
  import { error } from '@sveltejs/kit';
  import {authError, authUser } from '$lib/state/store';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { GetCurrentPlanDoc, type GetCurrentPlanQuery } from '$lib/generated/graphql';

  // Import required AWS SDK clients and command for Node.js


  let loginSchema = yup.object().shape({
    email: yup.string().email('Invalid email').required('Email is required'),
    password: yup.string().required('Password is required')
  });

  const REGION = 'us-east-1';

  let region = 'us-east-1';
  let email: string = $state('');
  let password: string = $state('');
  let loading = $state(false);
  let errors: { [key: string]: string } = $state({});


  onMount(() => {
  });


  const client = new CognitoIdentityClient({ region: 'us-east-1' });

  async function validateUserInfo() {
    let returnedErrors = await validation({email, password}, loginSchema);

    if (returnedErrors != null) {
      errors = returnedErrors;
      console.log('errors', returnedErrors);
    } else {
      console.log('validated');
      errors = {};
      handleSubmit();
    }
  }

   function handleSubmit() {

    loading = true;

    let authenticationData = {
      Username: email,
      Password: password
    };
    let authenticationDetails = new AuthenticationDetails(
      authenticationData
    );
    let userData = {
      Username: email,
      Pool: userPool
    };
    let cognitoUser = new CognitoUser(userData);
    console.log(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: async function(result) {
        loading = false;
        auth.token = result.getAccessToken().getJwtToken();
        auth.refreshToken = result.getRefreshToken().getToken();
        auth.loggedIn = true;
        authState.set(auth);

        const currentPlan = await getCurrentPlan();

        if(currentPlan === null || currentPlan === undefined){
          authError.set('PlanNotSelected');
          goto('/auth/registration')
        }else{
          goto('/app/');
        }

      },
      onFailure: function(err) {
        console.error('Login failed:', err);

        if (err.code === 'UserNotConfirmedException') {
          errors.authentication = 'Account not confirmed. Please check your email for confirmation.';

          authError.set('UserNotConfirmed');
          authUser.set({email: email, password: password});
          goto('/auth/registration')

        } else if (err.code === 'PasswordResetRequiredException') {
          errors.authentication = 'Password reset required. Please reset your password.';

        } else if(err.code === 'UserNotFoundException'){
            errors.authentication = 'User not found. Please check your email and password.';
        } else if(err.code === 'NotAuthorizedException'){
            errors.authentication = 'Invalid email or password. Please check your email and password.';
        }
        else {
        // Log the unknown error code and exception
        console.error('Unknown error code:', err.code, 'Exception:', err);
        }

        loading = false;
      },
      totpRequired: function(secretCode) {
        var challengeAnswer = prompt('Please input the TOTP code.', '');
        cognitoUser.sendMFACode(challengeAnswer, this, 'SOFTWARE_TOKEN_MFA');

        loading = false;
      }
    });

    // console.log('Email:', email);
    // console.log('Password:', password);
  }

</script>
<form class="w-1/2 p-9 flex-grow  min-w-[450px]" onsubmit={()=>{validateUserInfo()}}>
  <div class="mb-1 justify-start text-gray-800 text-2xl font-bold ">Sign In</div>

  <div class="space-y-2 my-4">
    <div class="relative flex flex-col items-start w-full ">
      <label class="text-sm my-2" for="email">
        Email
      </label>
      <input bind:value={email}
        type="email"
        class="bg-gray-50 border mb-1 {errors.email || errors.authentication ? 'border-red-500' : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
        id="email"
        placeholder="joshndoe@example.com"
      />
        <div class=" h-2">
          {#if errors.email}
          <p class="text-xs text-red-500 ">{errors.email}</p>
          {/if}
        </div>
    </div>

    <div class="relative flex flex-col items-start w-full ">
      <label class="text-sm my-2" for="password">
        Password
      </label>
      <input bind:value={password}
        type="password"
        class="bg-gray-50 border mb-1 {errors.password || errors.authentication ? 'border-red-500' : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
        id="password"
        placeholder="********"
      />
        <div class=" h-2">
          {#if errors.password}
          <p class="text-xs text-red-500 ">{errors.password}</p>
          {/if}
        </div>
    </div>
 </div>

  <div class="right-0 my-4 space-y-5">
    <a href="/auth/reset">
      <span class="text-gray-800 text-sm font-medium font-sans">Forget Password? </span>
      <span class="text-gray-800 text-sm font-medium font-sans underline">Reset</span>
    </a>
    <button

    class="w-full p-2.5 px-8 py-[11px] bg-black rounded-lg text-center text-white text-lg font-bold justify-center items-center gap-2 inline-flex hover:bg-black hover:text-white"
    type="submit">
    Log In
    </button>
  </div>


  <div class="h-2">
    {#if errors.authentication}
      <p class="text-xs text-red-500 "> {errors.authentication}</p>
    {/if}
  </div>

  <div class="fixed z-40 top-0 bottom-0 left-0 right-0 bg-black bg-opacity-50 flex items-center justify-center"
       style="display: {loading ? 'flex' : 'none'};">
    <div
      class="z-50 fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mx-auto flex justify-center items-center p-5 bg-white rounded-lg "
      role="alert">
      <div class="animate-spin rounded-full border-t-4 border-green-600 border-solid h-16 w-16"></div>
    </div>
  </div>
</form>
