<script lang="ts">
  import type { ServiceInterface } from "./store";

  interface ServiceProps {
    service: ServiceInterface;
  }

  let { service = $bindable() }: ServiceProps = $props();

  $effect(() => {
    console.log("service:", service);
    service.EngagementCost.amount = service.EngagementCost.majorUnits * 100;
    service.ServiceTotal = {
      majorUnits:
        service.EngagementCost.majorUnits *
        service.ServiceDays *
        service.EngagementsPerDay,
      amount: Math.trunc(
        service.EngagementCost.majorUnits *
          service.ServiceDays *
          100 *
          service.EngagementsPerDay,
      ),
      currency: service.EngagementCost.currency,
    };
    service.PerDayServiceCost = parseFloat(
      (service.EngagementCost.majorUnits * service.EngagementsPerDay).toFixed(
        2,
      ),
    );
  });
</script>

<div class="flex items-end space-x-2 w-full">
  <div class="flex flex-col gap-y-2 w-2/3">
    <label for="serviceName"> Service Name </label>
    <input
      bind:value={service.ServiceName}
      class="pl-4 w-full h-12 bg-gray-50 rounded-lg border focus:ring-0 focus:ring-offset-0 focus:border-primary-orange"
      id="serviceName"
    />
  </div>
  <div class="flex flex-col gap-y-2 w-1/3">
    <label for="servicePrice">Amount</label>
    <div class="flex relative items-center">
      <input
        bind:value={service.EngagementCost.majorUnits}
        class="pl-6 w-full h-12 bg-gray-50 rounded-lg border border-gray-200 focus:ring-0 focus:ring-offset-0 focus:border-primary-orange"
        disabled={service.ServiceName === ""}
        id="servicePrice"
        min="0"
        step="0.01"
        type="number"
      />
      <div class="flex absolute inset-y-0 left-0 items-center pl-2">
        <span class="text-xl text-gray-500">$</span>
      </div>
    </div>
  </div>
  <div
    class="flex flex-row items-center h-12 bg-gray-50 rounded-lg border border-gray-300 shadow button-group-container border-y"
  >
    <button class="p-3 bg-transparent border-r border-r-gray-300">
      <svg
        fill="none"
        height="20"
        viewBox="0 0 20 20"
        width="20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M14.1667 9.99984H5.83337"
          stroke="#2A303F"
          stroke-linecap="round"
        />
        <path
          clip-rule="evenodd"
          d="M9.99996 18.3332C14.6023 18.3332 18.3333 14.6022 18.3333 9.99984C18.3333 5.39746 14.6023 1.6665 9.99996 1.6665C5.39759 1.6665 1.66663 5.39746 1.66663 9.99984C1.66663 14.6022 5.39759 18.3332 9.99996 18.3332Z"
          fill-rule="evenodd"
          stroke="#2A303F"
        />
      </svg>
    </button>
    <button
      class="p-3 bg-transparent"
      onclick={() => {
        service.SeparatePeriod = !service.SeparatePeriod;
      }}
    >
      <svg
        class={!service.separatePeriod ? "transform rotate-180" : ""}
        fill="none"
        height="20"
        style="z-index: 100;"
        viewBox="0 0 20 20"
        width="20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M9.99996 18.3332C14.6023 18.3332 18.3333 14.6022 18.3333 9.99984C18.3333 5.39746 14.6023 1.6665 9.99996 1.6665C5.39759 1.6665 1.66663 5.39746 1.66663 9.99984C1.66663 14.6022 5.39759 18.3332 9.99996 18.3332Z"
          stroke="#2D3544"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-miterlimit="10"
        />
        <path
          d="M7.05835 11.05L10 8.1167L12.9417 11.05"
          stroke="#2D3544"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </button>
  </div>
</div>
