<script>
  /**
   * @typedef {Object} Props
   * @property {string} [label]
   * @property {string} [value]
   * @property {string} [type]
   * @property {string} [placeholder]
   */

  /** @type {Props} */
  let {
    label = "Text",
    value = $bindable(""),
    type = "text",
    placeholder = "placeholder"
  } = $props();

</script>

<!-- <div >
  <input class="peer px-4 py-2 w-96 border border-slate-600 placeholder-transparent"
    type={type}
    value={value}
    id={label}
  />
  <label class="ml-4 -mt-11 text-xs text-blue-600 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:-mt-8 peer-placeholder-shown:text-base duration-300"
   for={label}>
    {label}
  </label>
</div>
  -->
<div class="relative flex flex-col  items-start w-full">
      <textarea
        bind:value={value}
        class="peer h-20 px-4 py-2 w-full focus:ring-white focus:border-teal-400 border rounded-md border-slate-600 placeholder-transparent peer-placeholder-shown:border-blue-600 peer-placeholder-shown:text-base peer-focus:border-blue-600 peer-focus:focus:ring-0 focus:ring-offset-0 focus:ring-2   transition-all duration-300"
        id={label}
        placeholder=" "
      ></textarea>
  <label
    class="absolute bg-white left-2 -top-2  px-2  text-gray-600 text-xs pointer-events-none transition-all duration-100 peer-placeholder-shown:text-base peer-placeholder-shown:bg-transparent peer-placeholder-shown:text-gray-400 peer-placeholder-shown:mt-5   "
    for={label}
  >
    {label}
  </label>
</div>

