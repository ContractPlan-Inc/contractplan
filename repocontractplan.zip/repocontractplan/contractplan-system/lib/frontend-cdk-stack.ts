import * as cdk from 'aws-cdk-lib';
import { aws_s3, aws_s3_deployment, CfnOutput, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Bucket, BucketEncryption, StorageClass } from 'aws-cdk-lib/aws-s3';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as cloudfront_origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { OriginProtocolPolicy } from 'aws-cdk-lib/aws-cloudfront';
import * as targets from 'aws-cdk-lib/aws-route53-targets';
import * as elb from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import { TriggerInvalidation } from 'aws-cdk-lib/triggers';


export interface FrontendStackProps extends cdk.StackProps {
  path: string;
  src: string;
  subdomain: string;
}

export class FrontendCdkStack extends cdk.Stack {
  private bucket: Bucket;
  constructor(scope: Construct, id: string, props: FrontendStackProps) {
    super(scope, id, props);
    this.bucket = new Bucket(this, 'WebsiteBucket', {
      encryption: BucketEncryption.S3_MANAGED,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      versioned: false,
      intelligentTieringConfigurations: [
        {
          name: 'all',
          archiveAccessTierTime: cdk.Duration.days(90),
          deepArchiveAccessTierTime: cdk.Duration.days(180)
        }
      ],
      lifecycleRules: [
        {
          id: 'intelligent_tiering_all',
          enabled: true,
          abortIncompleteMultipartUploadAfter: cdk.Duration.days(7),
          noncurrentVersionExpiration: cdk.Duration.days(7),
          noncurrentVersionsToRetain: 1,
          expiration: cdk.Duration.days(30),
          transitions: [
            {
              storageClass: StorageClass.INTELLIGENT_TIERING,
              transitionAfter: cdk.Duration.days(0)
            }
          ]
        }
      ],
      publicReadAccess: true,
      blockPublicAccess: new aws_s3.BlockPublicAccess({
        blockPublicAcls: false,
        blockPublicPolicy: false,
        ignorePublicAcls: false,
        restrictPublicBuckets: false
      }),
      websiteIndexDocument: 'index.html',
      websiteErrorDocument: 'index.html',
    });
    // TLS certificate
    const baseDomain = cdk.Fn.importValue('BaseInfrastructure-base-domain');
    let appDomain = `${baseDomain}`;
    if (props.subdomain) {
      appDomain = `${props.subdomain}.${baseDomain}`;
    }
    const zone = cdk.Fn.importValue('BaseInfrastructure-zone');
    const hostedZone = route53.HostedZone.fromHostedZoneAttributes(this, 'HostedZone', {
      hostedZoneId: zone,
      zoneName: baseDomain
    });
    const certificate = new acm.DnsValidatedCertificate(this, 'CrossRegionCertificate2', {
      domainName: appDomain,
      hostedZone: hostedZone,
      region: 'us-east-1'
    });
    const cloudfrontOAI = cloudfront.OriginAccessIdentity.fromOriginAccessIdentityId(
      this,
      'originAccessIdentity',
      cdk.Fn.importValue('BaseInfrastructure-origin-access-identity-id'));
    const albStackSecurityGroupId = cdk.Fn.importValue('ApplicationLoadBalancerV2-security-group-id'); // ApplicationLoadBalancerV2 ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbSecurityGroupId', '/alb-stack/security-group-id').stringValue;
    const albStackLoadbalancerArn = cdk.Fn.importValue('ApplicationLoadBalancerV2-loadbalancer-arn'); // ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbLoadbalancerArn', '/alb-stack/loadbalancer-arn').stringValue;
    const albStackHostedZoneId = cdk.Fn.importValue('ApplicationLoadBalancerV2-alb-hosted-zone'); // ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;
    const albStackDnsName = cdk.Fn.importValue('ApplicationLoadBalancerV2-alb-dns-name'); // ssm.StringParameter.fromStringParameterName(this, 'vpcNameParamAlbHostedZoneId', '/alb-stack/hosted-zone-id').stringValue;

    const alb = elb.ApplicationLoadBalancer.fromApplicationLoadBalancerAttributes(this, `alb`, {
      loadBalancerArn: albStackLoadbalancerArn,
      securityGroupId: albStackSecurityGroupId,
      loadBalancerCanonicalHostedZoneId: albStackHostedZoneId,
      loadBalancerDnsName: albStackDnsName
    });

    const distribution = new cloudfront.Distribution(this, 'FullDistro', {
      certificate: certificate,
      defaultRootObject: 'index.html',
      domainNames: [appDomain],
      minimumProtocolVersion: cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021,
      httpVersion: cloudfront.HttpVersion.HTTP2_AND_3,
      errorResponses: [
        {
          httpStatus: 403,
          responseHttpStatus: 200,
          responsePagePath: '/index.html',
          ttl: Duration.minutes(30)
        },
        {
          httpStatus: 404,
          responseHttpStatus: 200,
          responsePagePath: '/index.html',
          ttl: Duration.minutes(30)
        }
      ],
      defaultBehavior: {
        origin: new cloudfront_origins.S3Origin(this.bucket, {
          originAccessIdentity: cloudfrontOAI
        }),
        cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        compress: true,
        allowedMethods: cloudfront.AllowedMethods.ALLOW_GET_HEAD_OPTIONS,
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS
      }
    });
    distribution.addBehavior('/query', new cloudfront_origins.LoadBalancerV2Origin(
      alb,
      {
        originSslProtocols: [cloudfront.OriginSslPolicy.TLS_V1_2],
        protocolPolicy: OriginProtocolPolicy.HTTPS_ONLY
      }
    ), {
      allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
      cachedMethods: cloudfront.CachedMethods.CACHE_GET_HEAD_OPTIONS,
      cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
      originRequestPolicy: cloudfront.OriginRequestPolicy.ALL_VIEWER,
      responseHeadersPolicy: cloudfront.ResponseHeadersPolicy.SECURITY_HEADERS
    });
    const distributionId = new CfnOutput(this, 'Distribution2Id', { value: distribution.distributionId });

    // Route53 alias record for the CloudFront distribution
    const Arecord = new route53.ARecord(this, 'App2AliasRecord', {
      recordName: appDomain,
      target: route53.RecordTarget.fromAlias(new targets.CloudFrontTarget(distribution)),
      zone: hostedZone
    });
    new aws_s3_deployment.BucketDeployment(this, 'DeployWebsite', {
      sources: [aws_s3_deployment.Source.asset(props.src)],
      destinationBucket: this.bucket,
      destinationKeyPrefix: props.path,
      cacheControl: [aws_s3_deployment.CacheControl.setPublic(), aws_s3_deployment.CacheControl.maxAge(Duration.days(30))],
      distribution: distribution,
    });
  }
}
