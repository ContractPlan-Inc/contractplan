#!/usr/bin/env bash
redis-server --daemonize yes
mkdir -pv cdk.out
if [ -z $BACKEND_REPOSITORY_URL ]; then
	echo "No backend repository URL provided. Exiting build for Backend."
	printf "[]" >imagedefinitions.json
	cat imagedefinitions.json
else
	echo Build completed on
	printf "[{\"name\":\"backend-service\",\"imageUri\":\"$BACKEND_REPOSITORY_URL:$DATE\"}]" >cdk.out/backend-service.imagedefinitions.json
	printf "[{\"name\":\"backend-ec2-service\",\"imageUri\":\"$BACKEND_REPOSITORY_URL:$DATE\"}]" >cdk.out/backend-ec2-service.imagedefinitions.json
fi
