package models

import "time"

type ContractDayRecordInput struct {
	Date            time.Time   `json:"Date"`
	ContractID      string      `json:"ContractID"`
	ContractName    string      `json:"ContractName"`
	ContractPartner string      `json:"ContractPartner"`
	ContractAlias   *string     `json:"ContractAlias,omitempty"`
	ContractValue   *MoneyInput `json:"ContractValue"`
	ServiceID       string      `json:"ServiceID"`
	ServiceName     string      `json:"ServiceName"`
	Engagements     int         `json:"Engagements"`
	EngagementCost  *MoneyInput `json:"EngagementCost,omitempty"`
}
type ContractDayRecord struct {
	DynamoDBModel
	ID                   string      `json:"ID" dynamodbav:"a"`
	Date                 time.Time   `json:"Date"`
	DateArray            []time.Time `json:"-"`
	ContractID           string      `json:"ContractID"`
	ContractName         string      `json:"ContractName"`
	ContractPartner      string      `json:"ContractPartner"`
	ContractAlias        *string     `json:"ContractAlias,omitempty"`
	ContractValue        *Money      `json:"ContractValue"`
	ServiceID            string      `json:"ServiceID"`
	ServiceName          string      `json:"ServiceName"`
	ServiceCost          *Money      `json:"ServiceCost"`
	Engagements          int         `json:"Engagements"`
	EngagementCost       *Money      `json:"EngagementCost"`
	TargetEngagements    int         `json:"TargetEngagements"`
	TargetEngagementCost *Money      `json:"TargetEngagementCost"`
}

func (ContractDayRecord) IsNode() {}
func (c ContractDayRecord) GetID() string {
	return c.ID
}
