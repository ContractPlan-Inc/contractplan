<script lang="ts">
  interface Props {
    key: string;
    value: number;
    color: string;
    pretext?: string;
  }

  let {
    key,
    value,
    color,
    pretext = ""
  }: Props = $props();
</script>

<div class=" w-full  bg-gray-100 rounded-lg py-1  px-4 my-6 dark:bg-dark-bg border">
  <div class="relative ">
    <div class="py-1 px-4 ">
      <div class="flex  items-center">
        <span class="w-2 h-2 absolute left-0 rounded bg-{color}"></span>
        <p class=" text-sm text-gray-400">{key}</p>
      </div>
      <p class=" text-md font-bold dark:text-white">{pretext}{value}</p>
    </div>
  </div>
</div>
