package utils

func StringInSlice(val string, array ...string) (ok bool, i int) {
	for i = range array {
		if ok = array[i] == val; ok {
			return
		}
	}
	return false, 0
}
