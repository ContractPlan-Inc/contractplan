import type {
  ContractInterface,
  MoneyInterface,
  ServiceInterface,
  UnitDefinitionInteface
} from '$lib/components/calculator/store';
import dayjs from 'dayjs';

export class Contract implements ContractInterface {
  PerDayServiceCost = $state<number>(0);
  ServiceName = $state('');
  EngagementCost = $state({
    amount: 0,
    currency: 'USD'
  });
  ServiceTotal = $state({
    amount: 0,
    currency: 'USD'
  });
  SeparatePeriod = $state<boolean>(false);
  ContractName = $state('');
  ContractPartnerID = $state<string>('');
  ContractPartner= $state('');
  ContractAlias = $state('');
  StartDate = $state(dayjs().format('YYYY-MM-DD'))
  EndDate = $state<string>(dayjs().endOf('year').format('YYYY-MM-DD'));
  ServiceDays = $state<number>(0);
  ServiceDates = $state<string[]>([]);
  ServicePeriod = $state<string>('daily');
  Weekdays = $state<number[]>([0, 1, 2, 3, 4, 5, 6]);
  SelectedMonthDays = $state<number[]>([]);
  SelectedDatesOfYear = $state<string[]>([]);
  ContractValue = $state<MoneyInterface>({
    amount: 0,
    currency: 'USD',
    majorUnits: 0
  });
  EngagementsPerDay = $state<number>(1);
  UnitDefinition = $state<UnitDefinitionInteface>({
    Name: 'Unit 1',
    Description: 'Description for Unit 1'
  });
  Services = $state<ServiceInterface[]>([
    {
      ServiceName: '',
      UnitDefinition: {
        Name: 'Unit 1',
        Description: 'Description for Unit 1'
      },
      StartDate: dayjs().format(),
      EndDate: dayjs().add(1, 'month').format(),
      ServicePeriod: 'daily',
      ServiceDates: [],
      Weekdays: [0, 1, 2, 3, 4, 5, 6],
      SelectedMonthDays: [],
      SelectedDatesOfYear: [],
      ServiceDays: 31,
      EngagementsPerDay: 1,
      EngagementCost: {
        amount: 0,
        currency: 'USD',
        majorUnits: 0
      } as MoneyInterface,
      ServiceTotal: {
        amount: 0,
        currency: 'USD',
        majorUnits: 0
      } as MoneyInterface,
      PerDayServiceCost: 0,
      SeparatePeriod: false
    }
  ]);
}

export const contract = new Contract();
