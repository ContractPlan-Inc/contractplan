<script lang="ts">
</script>
<script module lang="ts">
  import * as yup from 'yup';
  import { PUBLIC_COGNITO_CLIENT_ID, PUBLIC_USERPOOL_ID } from '$env/static/public';
  import { auth, authState } from '$lib/state/auth';
  import { AuthenticationDetails, CognitoUser, CognitoUserPool } from 'amazon-cognito-identity-js';

  export async function validation(regForm, schema) {
    let errors;
    try {
      console.log('service', regForm);
      errors = {};
      await schema.validate(regForm, { abortEarly: false });
      return null;
    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      return errors;
    }
  }

  export const registrationSchema = yup.object().shape({
    firstName: yup.string().required('First name is required'),
    middleName: yup.string(),
telephone: yup.string().required('Telephone is required').matches(/^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s-]?[0-9]{3}[\s-]?[0-9]{4}$/, 'Telephone must be in the correct format'),    email: yup.string().email('Invalid email').required('Email is required'),
    password: yup
      .string()
      .required('Password is required')
      .min(8, 'Password is too short - should be 8 chars minimum.')
      .test(
        'password-validation',
        'Password must have at least one uppercase letter, one lowercase letter, one number, and one special character',
        (value) => {
          if (!value) {
            return true;
          }

          const hasUppercase = /[A-Z]/.test(value);
          const hasLowercase = /[a-z]/.test(value);
          const hasNumber = /[0-9]/.test(value);
          const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(
            value
          );

          return hasUppercase && hasLowercase && hasNumber && hasSpecialChar;
        }
      )
  });

  export const companySchema = yup.object().shape({
    address: yup.string(),
    name: yup.string().required('Company name is required'),
    telephone: yup.string(),
    companySize: yup.number().moreThan(0, 'Company size is required'),
    category: yup.string(),
    state: yup.string().required('State is required'),
    country: yup.string().required('Country is required')
  });


  export async function autoLogin(email: string, password: string) {
    console.log('sign in triggered');

    let authenticationData = {
      Username: email,
      Password: password
    };
    let authenticationDetails = new AuthenticationDetails(
      authenticationData
    );
    let poolData = {
      UserPoolId: PUBLIC_USERPOOL_ID,
      ClientId: PUBLIC_COGNITO_CLIENT_ID
    };
    let userPool = new CognitoUserPool(poolData);
    let userData = {
      Username: email,
      Pool: userPool
    };
    let cognitoUser = new CognitoUser(userData);
    console.log(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: function(result) {
        auth.token = result.getAccessToken().getJwtToken();
        auth.loggedIn = true;
        authState.set(auth);
        return null;
      },
      onFailure: function(err) {
        console.error('Something went wrong:', err);
        return err;

      }
    });
  }

</script>

