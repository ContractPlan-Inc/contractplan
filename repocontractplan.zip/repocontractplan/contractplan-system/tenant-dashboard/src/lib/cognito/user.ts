import { userPool } from '$lib/cognito/pool';

export const cognitoUser = userPool.getCurrentUser();
