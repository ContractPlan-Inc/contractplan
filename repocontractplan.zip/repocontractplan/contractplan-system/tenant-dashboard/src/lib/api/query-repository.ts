import type { Client, OperationResult } from '@urql/svelte';
import type { DocumentNode } from 'graphql';
import type { QueryRepository } from '$lib/interfaces/query-repository';
import client from '../../client';
import { SubscribePlanDoc } from '$lib/generated/graphql';

interface FilterContext {
  ID: string;
}

export class GraphQLQueryRepository<T> implements QueryRepository<T> {
  client: Client;

  constructor() {
    this.client = client;
  }

  getItems(
    queryString: DocumentNode,
    filter: { [key: string]: any },
    page: number,
    perPage: number
  ): Promise<OperationResult<T>> {
    const finalVar: { [key: string]: any } = { page: page, limit: perPage };
    for (const filterKey in filter) {
      finalVar[filterKey] = filter[filterKey];
    }
    console.log('FINAL VARIABLES', finalVar);
    return this.client.query(queryString, finalVar).toPromise();
  }

  getItemById(
    queryString: DocumentNode,
    id: string)
    : Promise<OperationResult<T>> {
    return this.client.query(queryString, { id: id }).toPromise();
  }

  getItem(
    queryString: DocumentNode
  ): Promise<OperationResult<T>> {
    return this.client.query(queryString, {}).toPromise();

  }


  updateItem(
    queryString: DocumentNode,
    item: { [key: string]: any }
  ): Promise<OperationResult<T>> {
    return this.client.mutation(queryString, item).toPromise();
  }

  Signup(
    queryString: DocumentNode,
    item: { [key: string]: any }
  ): Promise<OperationResult<T>> {
    return this.client.mutation(queryString, item).toPromise();
  }

  Verification(
    queryString: DocumentNode,
    item: { [key: string]: any }
  ): Promise<OperationResult<T>> {
    return this.client.mutation(queryString, item).toPromise();
  }

  subscribePlan(
    input: { [key: string]: any }
  ): Promise<OperationResult<T>> {
    const queryString = SubscribePlanDoc;
    return this.client.mutation(queryString, { input }).toPromise();
  }

  changePlan(
    queryString: DocumentNode,
    input: { [key: string]: any }
  ): Promise<OperationResult<T>> {
    return this.client.mutation(queryString, input).toPromise();
  }
}
