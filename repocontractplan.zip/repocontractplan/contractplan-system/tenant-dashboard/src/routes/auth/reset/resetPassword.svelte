<script lang="ts">

  import * as yup from "yup";
  import {validateResetPasswordForm} from './service';
  import {userPool} from '$lib/cognito/pool';
  import {CognitoUser} from 'amazon-cognito-identity-js';

  interface ResetPasswordProps {
    email: string;
    step: string;

  }

  let { email = $bindable(), step = $bindable() }: ResetPasswordProps = $props();


  let emailSchema = yup.object().shape({
    email: yup.string().email('Invalid email').required('Email is required'),
  });

  let errors: { [key: string]: string } = $state({});
  let loading:boolean = $state(false);

  async function validateResetPassword(){

    let returnedError = await validateResetPasswordForm({email}, emailSchema);
    console.log("validateEmail error", returnedError)
    if (returnedError != null){
      errors = returnedError
    }else{
      errors = {};
      resetPassword();
    }
  }

  function resetPassword(){
    loading = true;
    let userData = {
      Username: email,
      Pool: userPool
    };

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.forgotPassword({
      onSuccess: (result) => {
        console.log("result", result)
        step = "ConfirmNewPassword";
        loading = false;
      },
      onFailure: (err) => {
        //console.log(err.name)
        if (err.name == 'UserNotConfirmedException') {
          errors.email   = 'Account not confirmed. Please check your email for confirmation.';
        } else if(err.name == 'UserNotFoundException'){
          errors.email = 'User not found. Please check your credentials and try again.';
        }
        else {
          console.error('Unknown error verificationCode:', err.name, 'Exception:', err);
        }

        loading = false;

      }
    })
  }

</script>

<form class="w-1/2 p-9 flex-grow  min-w-[450px]"  onsubmit={(event)=>{event.preventDefault; validateResetPassword()}}>
  <div class="mb-1 justify-start text-gray-800 text-2xl font-bold ">Forgot your password?</div>
  <p>Enter your Email below and we will send a message to reset your password</p>
  <div class="space-y-5 my-4">
    <div class="relative flex flex-col items-start w-full ">
      <label class="text-sm my-2" for="email">
        Email
      </label>
      <input bind:value={email}
             type="text"
             class="bg-gray-50 border mb-1 text-gray-900 text-sm rounded-lg {errors.email ? 'border-red-500' : 'border-gray-300'} focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
             id="email"
             placeholder="joshndoe@example.com"
      />
      <div class=" h-2">
        {#if errors.email}
          <p class="text-xs text-red-500 ">{errors.email}</p>
        {/if}
      </div>
    </div>

    <button class="bg-black text-white px-3 py-2 rounded-lg w-full"  type="submit"  >Reset my password</button>
  </div>
</form>

<div class="fixed z-40 top-0 bottom-0 left-0 right-0 bg-black bg-opacity-50 flex items-center justify-center"
     style="display: {loading ? 'flex' : 'none'};">
  <div
    class="z-50 fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mx-auto flex justify-center items-center p-5 bg-white rounded-lg "
    role="alert">
    <div class="animate-spin rounded-full border-t-4 border-green-600 border-solid h-16 w-16"></div>
  </div>
</div>
