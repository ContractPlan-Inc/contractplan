<!-- Card.svelte -->
<script>
  import Plan from "./Plan.svelte"; // Adjust the path as needed
  
  /**
   * @typedef {Object} Props
   * @property {any} plan
   */

  /** @type {Props} */
  let { plan } = $props();
</script>

<div class="mb-6 flex justify-center">
  <Plan {plan} />
</div>

