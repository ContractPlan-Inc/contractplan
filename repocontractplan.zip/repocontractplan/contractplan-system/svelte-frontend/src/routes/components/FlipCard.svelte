<script>
  /**
   * @typedef {Object} Props
   * @property {import('svelte').Snippet} [front]
   * @property {import('svelte').Snippet} [back]
   */

  /** @type {Props} */
  let { front, back } = $props();
</script>

<div class="card-body lg:w-1/3 w-full ">
<div class="flip-card rounded-xl sm:h-64 md:h-96 lg:h-80 h-80">
  <div class="flip-card-inner ">
      <div class="flip-card-front">
        {#if front}{@render front()}{:else}
          <!-- <span class="missing">Unknown email</span> -->
        {/if}
    </div>
    <div class="flip-card-back">
        {#if back}{@render back()}{:else}
          <!-- <span class="missing">Unknown email</span> -->
        {/if}
    </div>
  </div>
</div>
</div>

<style>
  .card-body {
  font-family: Arial, Helvetica, sans-serif;

}

.flip-card {
  background-color: transparent;
  width: 100%;
  perspective: 1000px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}

.flip-card:hover .flip-card-inner {
  transform: rotateY(180deg);
}

.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;

  border: 1px solid rgb(215, 215, 215);
}

.flip-card-front {
  background-color: #ffffff;
  color: black;
  display: flex;
  justify-content: center;
  align-items: center;
  transform: rotateY(0deg);
}

.flip-card-back {
  transform: rotateY(180deg);
  display: flex;
  justify-content: center;
  padding: 30px;
}

</style>
