<script lang="ts">
  import type { Company, SignUpInput } from '$lib/generated/graphql';
  import { SignUpDoc } from '$lib/generated/graphql';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import Input from '$lib/components/elements/input.svelte';
  import * as yup from 'yup';
  import { goto } from '$app/navigation';

  const signUpSchema = yup.object().shape({
    firstName: yup.string().required('First name is required'),
    middleName: yup.string(),
    lastName: yup.string().required('Last name is required'),
    telephone: yup.string().required('Telephone is required'),
    address: yup.string().required('Address is required'),
    email: yup.string().email('Invalid email').required('Email is required'),
    password: yup
      .string()
      .required('Password is required')
      .test(
        'password-validation',
        'Password must have at least one uppercase letter, one lowercase letter, one number, and one special character',
        (value) => {
          if (!value) {
            return true;
          }

          const hasUppercase = /[A-Z]/.test(value);
          const hasLowercase = /[a-z]/.test(value);
          const hasNumber = /[0-9]/.test(value);
          const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(
            value
          );

          return hasUppercase && hasLowercase && hasNumber && hasSpecialChar;
        }
      ),
    company: yup.lazy((value) =>
      showCompanyDetails
        ? companySchema.required('Company details are required')
        : yup.mixed().notRequired()
    )
  });

  const companySchema = yup.object().shape({
    name: yup.string().required('Company name is required'),
    category: yup.string().required('Company category is required'),
    telephone: yup.string().required('Company telephone is required'),
    address: yup.string().required('Company address is required')
  });

  let signupFormData: SignUpInput = {
    firstName: '',
    middleName: '',
    lastName: '',
    telephone: '',
    address: '',
    email: '',
    password: ''
  };

  let companyData: Company = {
    name: '',
    telephone: '',
    address: '',
    category: '',
    companySize: 0
  };

  let errors: { [key: string]: string } = {};

  let showCompanyDetails = false;
  let snackbarMessage = '';
  let snackbarTimeout: NodeJS.Timeout | undefined;

  async function handleSubmit() {
    try {
      errors = {};
      if (showCompanyDetails) {
        signupFormData.company = companyData;
      }

      await signUpSchema.validate(signupFormData, { abortEarly: false });
      // console.log("Form data submitted:", signupFormData);

      let queryRepository = new GraphQLQueryRepository<SignUpInput>();
      let response: any = await queryRepository.Signup(SignUpDoc, {
        input: signupFormData
      });
      console.log('--------response----------');
      // console.log(response.data.SignUp.error.S);
      console.log(response.data.SignUp);
      if (response.data.SignUp.success == false) {
        snackbarMessage = response.data.SignUp.error.S;
      } else if (response.data.SignUp.success == true) {
        snackbarMessage = 'Signup Successful!';
        signupFormData = {
          firstName: '',
          middleName: '',
          lastName: '',
          telephone: '',
          address: '',
          email: '',
          password: '',
          company: showCompanyDetails ? companyData : null
        };
        companyData = {
          name: '',
          telephone: '',
          address: '',
          category: ''
        };
        showCompanyDetails = false;
        goto('/app/verification');
      }
      snackbarTimeout = setTimeout(() => {
        snackbarMessage = '';
      }, 4000);

    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      console.error('Validation error:', validationErrors);
      console.log(errors);
    }
  }

  $: {
    if (!snackbarMessage) {
      if (snackbarTimeout !== undefined) {
        clearTimeout(snackbarTimeout);
      }
    }
  }
</script>

<div
  class="flex justify-center items-center w-screen min-h-screen bg-gradient-to-b max-h-auto to-primary/20 from-primary"
>
  <form
    class="flex flex-col justify-center items-center p-5 space-y-5 bg-white rounded"
    onsubmit={(event)=>{handleSubmit(); event.preventDefault();}}
  >
    <h1 class="text-2xl font-bold">SignUp</h1>
    <Input
      bind:value={signupFormData.firstName}
      label="First Name"
      type="text"
    />
    {#if errors.firstName}
      <div class="text-xs text-red-500">{errors.firstName}</div>
    {/if}
    <Input
      bind:value={signupFormData.middleName}
      label="Middle Name"
      type="text"
    />
    <Input bind:value={signupFormData.lastName} label="Last Name" type="text" />
    {#if errors.lastName}
      <p class="text-xs text-red-500">{errors.lastName}</p>
    {/if}
    <Input bind:value={signupFormData.telephone} label="Telephone" type="tel" />
    {#if errors.telephone}
      <p class="text-xs text-red-500">{errors.telephone}</p>
    {/if}
    <Input bind:value={signupFormData.address} label="Address" type="text" />
    {#if errors.address}
      <p class="text-xs text-red-500">{errors.address}</p>
    {/if}
    <Input bind:value={signupFormData.email} label="Email" type="email" />
    {#if errors.email}
      <p class="text-xs text-red-500">{errors.email}</p>
    {/if}
    <Input
      bind:value={signupFormData.password}
      label="Password"
      type="password"
    />
    {#if errors.password}
      <p class="text-xs text-red-500">{errors.password}</p>
    {/if}
    <div class="flex items-center w-full">
      <input
        bind:checked={showCompanyDetails}
        class="mr-1"
        id="companyCheckbox"
        type="checkbox"
      />
      <label class="ml-1" for="companyCheckbox"
      >Create an organization account</label
      >
    </div>
    {#if showCompanyDetails}
      <Input label="Company Name" type="text" bind:value={companyData.name} />
      {#if errors["company.name"]}
        <p class="text-xs text-red-500">{errors["company.name"]}</p>
      {/if}
      <Input
        label="Company Category"
        type="text"
        bind:value={companyData.category}
      />
      {#if errors["company.category"]}
        <p class="text-xs text-red-500">{errors["company.category"]}</p>
      {/if}
      <Input
        label="Company Telephone"
        type="tel"
        bind:value={companyData.telephone}
      />
      {#if errors["company.telephone"]}
        <p class="text-xs text-red-500">{errors["company.telephone"]}</p>
      {/if}
      <Input
        label="Company Address"
        type="text"
        bind:value={companyData.address}
      />
      {#if errors["company.address"]}
        <p class="text-xs text-red-500">{errors["company.address"]}</p>
      {/if}
    {/if}
    <button class="py-1 px-2 w-full rounded bg-primary" type="submit"
    >Sign Up
    </button
    >
    <div>
      I already have an account. <a class="hover:text-blue-600" href="/auth/signin"
    >Sign In</a
    >
    </div>
  </form>

  {#if snackbarMessage}
    <div id="toast-success"
         class="flex fixed top-10 items-center p-4 mb-4 w-full max-w-xs text-gray-500 bg-white rounded-lg shadow dark:text-gray-400 dark:bg-gray-800 left-50 right-50"
         role="alert">
      <div class="ml-3 text-sm font-normal">{snackbarMessage}</div>
      <button type="button"
              class="inline-flex justify-center items-center p-1.5 -my-1.5 -mx-1.5 ml-auto w-8 h-8 text-gray-400 bg-white rounded-lg dark:text-gray-500 dark:bg-gray-800 hover:text-gray-900 hover:bg-gray-100 focus:ring-2 focus:ring-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
              data-dismiss-target="#toast-success" aria-label="Close" onclick={() => { snackbarMessage = ""; }}>
        <span class="sr-only">Close</span>
        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
             viewBox="0 0 14 14">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
        </svg>
      </button>
    </div>
  {/if}

</div>
