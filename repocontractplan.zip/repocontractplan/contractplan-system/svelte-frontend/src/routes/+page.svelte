<script lang="ts">
  import Navbar from "./components/Navbar.svelte";
  import Accordion from "./components/Accordion.svelte";
  import "@splidejs/svelte-splide/css";
  import { goto } from "$app/navigation";
  import FlipCard from "./components/FlipCard.svelte";

  import PageIcon from "$lib/assets/svg/icon_page.svg";
  import SecurityIcon from "$lib/assets/svg/icon_security.svg";
  import DashboardIcon from "$lib/assets/svg/icon_dashboard.svg";
  import {
    GetPlansDoc,
    type GetPlansQuery,
    type Plan,
  } from "$lib/generated/graphql";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import { onMount } from "svelte";

  import screenshot1 from "$lib/assets/home/screenshot6.png";
  import screenshot2 from "$lib/assets/home/screenshot7.png";

  import Icon from "@iconify/svelte";

  export const prerender = true;
  let show = false;
  let plans: Plan[] = $state([]);
  let showLogo = false;

  async function fetchPlans() {
    try {
      const queryRepository = new GraphQLQueryRepository<GetPlansQuery>();
      const plansQuery = await queryRepository.getItems(GetPlansDoc, {}, 1, 10);

      plans = plansQuery?.data?.listPlans as Plan[];

      console.log("PLANS:", plans);
    } catch (e) {
      console.log("ERROR:", e);
    }
  }

  const faqs = [
    {
      q: "What is contract utilization? ",
      a: "Contract utilization refers to the effective use and execution of a contract's terms and conditions by involved parties. It measures how well resources, services, or benefits outlined in the contract are utilized within a specific timeframe. At 92% utilization of a $250,000 service contract, $20,000 is left unutilized, and a portion of the population remains unserved. Optimize your performance with ContractPlan.",
    },
    {
      q: "Why does managing contract utilization matter?",
      a: "Managing contract utilization is crucial for ensuring the full implementation of contract terms, maximizing benefits, and allocated resources. It enables the identification of underutilization or non-compliance issues, facilitating timely corrective actions to prevent financial losses, legal disputes, or operational challenges. Moreover, it strengthens relationships with contracting parties by demonstrating a commitment to honoring the agreement terms.",
    },
    {
      q: 'What is "client census"?',
      a: "Client census measures the number of clients receiving cyclical services that can be supported over the contract's lifespan by available funding sources.",
    },
    {
      q: 'What is an "engagement" in ContractPlan? ',
      a: 'An "engagement" in ContractPlan refers to each episode of service delivery, synonymous with "client census.',
    },
    {
      q: "Why is it important to have a contract model? ",
      a: "Contract models help reduce volatility in service provision by providing contractors with information on necessary actions over time to ensure full contract utilization.	",
    },
    {
      q: "Why strive to understand and reduce volatility in service provision?",
      a: "Unrecognized variance trends can compound over the contract term, leading to significant over- or under-provision and billing scenarios. ContractPlan was specifically designed to prevent such worst-case operational scenarios.",
    },
    {
      q: "How does ContractPlan improve contract monitoring? ",
      a: "ContractPlan enables users to store, access, and share documents in the cloud. It facilitates easy access and review of bulk compliance documentation, photos, and contract documents within a single application, with partners, or via the mobile app on the go.",
    },
    {
      q: "Who was ContractPlan designed for?",
      a: "ContractPlan was designed for individuals and organizations engaged in service provision,offering a low-effort, high-impact business tool.",
    },
    {
      q: "What new Features are in development?",
      a: "Automated sales input via QuickBooks integration, API development, AI support, OCR contract facts capture, and more. Send requests and recommendations to contact@contractplan.com.",
    },
  ];

  onMount(() => {
    fetchPlans();

    const handleScroll = () => {
      // Check if we're near the bottom of the page
      const bottomThreshold = 100; // pixels from bottom
      const isAtBottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - bottomThreshold;
      showLogo = isAtBottom;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  });
</script>

<svelte:head>
  <title>ContractPlan: Model, Monitor, Maximize Contract Utilization</title>
</svelte:head>

<div
  class="bg-gradient-to-br from-zinc-900 via-zinc-800 to-orange-900/20 min-h-screen w-full mx-auto flex flex-col"
>
  <div class="px-6 pt-6 font-poppins w-full mx-auto">
    <Navbar />
  </div>

  <div class="flex-grow flex items-center justify-center w-full text-center font-poppins">
    <div class="container px-6 mx-auto">
      <h1
        class="mb-6 text-5xl font-bold text-white md:text-6xl md:leading-tight animate-slide-up"
      >
        Model, Monitor, Maximize <br />
        Your Contract Utilization
      </h1>

      <p class="mx-auto mb-12 font-normal md:w-3/5 text-zinc-300/75 text-lg animate-slide-up delay-100">
        Businesses, local governments, and
        nonprofits trust ContractPlan to improve service
        contract administration and maximize contract utilization with its
        intuitive <br />cloud-based tools and dashboards
      </p>

      <button
        class="py-4 px-8 text-white bg-orange-700 rounded-lg hover:text-white hover:bg-black text-lg"
        onclick={() => {
          goto("/auth/registration");
        }}
      >
        Sign Up Now
      </button>
    </div>
  </div>
</div>

<div class="overflow-hidden bg-white py-24 sm:py-32" id="features">
  <div class="mx-auto max-w-7xl md:px-6 lg:px-8">
    <div
      class="grid grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:grid-cols-2 lg:items-start"
    >
      <div class="px-6 lg:px-0 lg:pr-4 lg:pt-4 order-1 lg:order-1">
        <div class="mx-auto max-w-2xl lg:mx-0 lg:max-w-lg">
          <h2 class="text-base font-semibold leading-7 text-orange-500">
            Model, Monitor, Maximize
          </h2>
          <p
            class="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"
          >
            ContractPlan
          </p>
          <p class="mt-6 text-lg leading-8 text-gray-600">
            ContractPlan makes it easy to plan, monitor, and adjust output to
            succeed in the purchase or provision of contract services.
          </p>
          <dl
            class="mt-10 max-w-xl space-y-8 text-base leading-7 text-gray-600 lg:max-w-none"
          >
            <div class="relative pl-9">
              <dt class="inline font-semibold text-gray-900">
                <svg
                  class="absolute left-1 top-1 h-5 w-5 text-orange-500"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5.5 17a4.5 4.5 0 01-1.44-8.765 4.5 4.5 0 018.302-3.046 3.5 3.5 0 014.504 4.272A4 4 0 0115 17H5.5zm3.75-2.75a.75.75 0 001.5 0V9.66l1.95 2.1a.75.75 0 101.1-1.02l-3.25-3.5a.75.75 0 00-1.1 0l-3.25 3.5a.75.75 0 101.1 1.02l1.95-2.1v4.59z"
                    clip-rule="evenodd"
                  />
                </svg>
                Take Charge of Your Contracts
              </dt>
              <dd class="inline">
                Organize your contract facts to simplify administration and
                visualize your contract portfolio – never miss another deadline,
                know where you stand, achieve compliance.
              </dd>
            </div>
            <div class="relative pl-9">
              <dt class="inline font-semibold text-gray-900">
                <svg
                  class="absolute left-1 top-1 h-5 w-5 text-orange-500"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z"
                    clip-rule="evenodd"
                  />
                </svg>
                Get Perspective
              </dt>
              <dd class="inline">
                Build and track single and multi-unit service contract schedules
                and revenue plans to master each revenue stream and react to
                actual utilization patterns with informed recommendations for
                action.
              </dd>
            </div>
            <div class="relative pl-9">
              <dt class="inline font-semibold text-gray-900">
                <svg
                  class="absolute left-1 top-1 h-5 w-5 text-orange-500"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    d="M4.632 3.533A2 2 0 016.577 2h6.846a2 2 0 011.945 1.533l1.976 8.234A3.489 3.489 0 0016 11.5H4c-.476 0-.93.095-1.344.267l1.976-8.234z"
                  />
                  <path
                    fill-rule="evenodd"
                    d="M4 13a2 2 0 100 4h12a2 2 0 100-4H4zm11.24 2a.75.75 0 01.75-.75H16a.75.75 0 01.75.75v.01a.75.75 0 01-.75.75h-.01a.75.75 0 01-.75-.75V15zm-2.25-.75a.75.75 0 00-.75.75v.01c0 .414.336.75.75.75H13a.75.75 0 00.75-.75V15a.75.75 0 00-.75-.75h-.01z"
                    clip-rule="evenodd"
                  />
                </svg>
                Evaluate Early & Often
              </dt>
              <dd class="inline">
                Recognize and respond to contract utilization variance early and
                often with intuitive analytics and dashboards that prevent
                costly surprises and reduce abrupt changes in service delivery
              </dd>
            </div>
          </dl>
        </div>
      </div>
      <div class="sm:px-6 lg:px-0 order-2 lg:order-2 ">
        <div
          class="relative isolate overflow-hidden bg-orange-500 lg:px-6 lg:pt-8 sm:mx-auto sm:max-w-2xl sm:rounded-lg sm:pl-16 sm:pr-0 sm:pt-16 lg:mx-0 lg:max-w-none"
        >
          <div
            class="absolute -inset-y-px -left-3 -z-10 w-full origin-bottom-left skew-x-[-30deg] bg-orange-100 opacity-20 ring-1 ring-inset ring-white"
            aria-hidden="true"
          ></div>
          <div class="mx-auto max-w-2xl sm:mx-10 sm:max-w-none p-4 sm:p-6">
            <img
              src={screenshot1}
              alt="Product screenshot"
              width="2432"
              height="1442"
              class="-mb-12 w-[57rem] max-w-none rounded-tl-xl bg-gray-800 ring-1 ring-white/10 object-cover object-top"
              style="aspect-ratio: 16/9"
            />
          </div>
          <div
            class="pointer-events-none absolute inset-0 ring-1 ring-inset ring-black/10 sm:rounded-lg"
            aria-hidden="true"
          ></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container py-12 px-6 mx-auto font-poppins" id="industries">
  <div class="mb-4 text-4xl font-bold text-center">Industries</div>
  <p
    class="mx-auto mb-12 font-normal text-center md:w-3/5 text-zinc-800 text-md"
  >
    ContractPlan.com delivers a package of cloud-based contract management tools
  </p>
  <div class="flex flex-col justify-center w-full gap-6 md:flex-row">
    <FlipCard>
      {#snippet front()}
            <span >
          <img
            alt="Page Icon"
            class="relative mb-6 mx-auto w-[60px] h-[60px]"
            src={PageIcon}
          />
          <h3 class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-orange-800">Small Business</h3>
        </span>
          {/snippet}
      {#snippet back()}
            <span  class="overflow-hidden">
          <h3 class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-orange-800 text-left mb-3">
            Small Business
          </h3>

          <p class="text-sm sm:text-base md:text-lg text-justify">
            Model and track contract performance to maximize sales and simplify
            business intelligence. From catering to transportation, ContractPlan
            will visualize actual performance to plan and make recommendations to
            ensure no sales opportunity is missed.
          </p>
        </span>
          {/snippet}
    </FlipCard>
    <FlipCard>
      {#snippet front()}
            <span >
          <img
            alt="Security Icon"
            class="relative mt-1 mb-6 mx-auto w-[60px] h-[60px]"
            src={SecurityIcon}
          />
          <h3 class="text-xl sm:text-xl md:text-2xl lg:text-3xl font-semibold text-orange-800">
            Local Government
          </h3>
        </span>
          {/snippet}
      {#snippet back()}
            <span >
          <h3 class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-orange-800 text-left mb-3">
            Local Government
          </h3>

          <p class="text-sm sm:text-base md:text-lg text-justify">
            Local Government: Manage and visualize contract portfolios at micro
            and macro level. Share and collaborate with colleagues and
            contractors. Centralize monitoring documentation collection and
            storage. Generate actionable data about emerging utilization trends
            for reporting and public accountability.
          </p>
        </span>
          {/snippet}
    </FlipCard>
    <FlipCard>
      {#snippet front()}
            <span >
          <img
            alt="Dashboard Icon"
            class="relative mt-1 mb-6 mx-auto w-[60px] h-[60px]"
            src={DashboardIcon}
          />
          <h3 class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-orange-800">Nonprofit</h3>
        </span>
          {/snippet}
      {#snippet back()}
            <span >
          <h3 class="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-orange-800 text-left mb-3">
            Nonprofit
          </h3>

          <p class="text-sm sm:text-base md:text-lg text-justify">
            Affordable. Accessible. Ideal for grant and social services contract
            administration. Size target client census to available funding
            sources. Track actual services billed versus plan and adjust to ensure
            maximum utilization for maximum impact.
          </p>
        </span>
          {/snippet}
    </FlipCard>
    <!-- <div
      class="p-12 mx-auto rounded-lg border border-orange-100 shadow-lg shadow-orange-50"
    >
      <img
        alt="Page Icon"
        class="relative mb-6 w-[60px] h-[60px]"
        src={PageIcon}
      />
      <div class="flex flex-col gap-3 justify-start items-start">
        <div class="text-base font-semibold text-orange-800">
          Small Business
        </div>
        <p
          class="text-base font-normal text-justify leading-normal text-zinc-900 h-[180px]"
        >
          Model and track contract performance to maximize sales and simplify
          business intelligence. From catering to transportation, ContractPlan
          will visualize actual performance to plan and make recommendations to
          ensure no sales opportunity is missed.
        </p>
      </div>
    </div> -->
    <!-- <div
      class="p-12 mx-auto rounded-lg border border-orange-100 shadow-lg shadow-orange-50"
    >
      <img
        alt="Security Icon"
        class="relative mt-1 mb-6 ml-1 w-[60px] h-[60px]"
        src={SecurityIcon}
      />
      <div class="flex flex-col gap-3 justify-start items-start">
        <div class="text-base font-semibold text-orange-800">
          Local Government
        </div>
        <p
          class="text-base font-normal text-justify leading-normal text-zinc-900 h-[180px]"
        >
          Local Government: Manage and visualize contract portfolios at micro
          and macro level. Share and collaborate with colleagues and
          contractors. Centralize monitoring documentation collection and
          storage. Generate actionable data about emerging utilization trends
          for reporting and public accountability.
        </p>
      </div>
    </div> -->
    <!-- <div
      class="p-12 mx-auto rounded-lg border border-orange-100 shadow-lg shadow-orange-50"
    >
      <img
        alt="Dashboard Icon"
        class="relative mt-1 mb-6 ml-1 w-[60px] h-[60px]"
        src={DashboardIcon}
      />
      <div class="flex flex-col gap-3 justify-start items-start">
        <div class="text-base font-semibold text-orange-800">Nonprofit</div>
        <p
          class="text-base font-normal text-justify leading-normal text-zinc-900 h-[180px]"
        >
          Affordable. Accessible. Ideal for grant and social services contract
          administration. Size target client census to available funding
          sources. Track actual services billed versus plan and adjust to ensure
          maximum utilization for maximum impact.
        </p>
      </div>
    </div> -->
  </div>
</div>

<div class="container py-12 px-6 mx-auto font-poppins" id="pricing">
  <div class="mb-4 text-4xl font-bold text-center">Our Pricing Plans</div>
  <p
    class="mx-auto mb-12 font-normal text-center md:w-3/5 text-zinc-800 text-md"
  >
    ContractPlan.com delivers a package of cloud-based contract management tools
  </p>

  <div class=" md:flex flex-row justify-center gap-10">
    {#each plans as plan}
      <div
        class=" border border-white rounded-lg bg-white drop-shadow-lg md:w-1/3 transition-all xl:max-w-xl p-9 flex flex-col gap-6 hover:border-primary-dark text-center"
      >
        <p class=" text-lg font-bold">Subscribe now for</p>
        <div class=" text-primary-dark text-center">
          <div class="  text-3xl font-bold">
            ${Math.round(Number(plan.Price) / 100)}
          {#if plan.ID.includes("Monthly")}/month
          {:else}/year
          {/if}
          </div>
        </div>
        <ul class="  list-disc list-inside">
          {#each plan.Features as feature}
            <li>{feature}</li>
          {/each}
        </ul>
        <button
          class=" hover:bg-primary-dark hover:border-primary-dark hover:text-white border border-black transition-all p-2 rounded-md"
          onclick={() => {
            goto("/auth/registration");
          }}
        >
          Subscribe
        </button>
      </div>
    {/each}
  </div>
</div>

<div class="container py-12 px-6 mx-auto font-poppins" id="faq">
  <div class="mb-8 text-4xl font-bold text-center">
    Frequently Asked Questions
  </div>
  <p
    class="mx-auto mb-12 font-normal text-center md:w-3/5 text-zinc-800 text-md"
  >
    ContractPlan.com delivers a package of cloud-based contract management tools
  </p>
  <div class="mx-auto w-3/4">
    <!-- Display each faq of faqs -->
    {#each faqs as question}
      <Accordion faq={question} />
    {/each}
  </div>
</div>

<!--<div class="bg-neutral-200/50" id="resources">-->
<!--  <div class="container py-12 px-6 mx-auto font-poppins">-->
<!--    <div class="mb-4 text-4xl font-bold text-center">Resources</div>-->
<!--    <p-->
<!--      class="mx-auto mb-12 font-normal text-center md:w-3/5 text-zinc-800 text-md"-->
<!--    >-->
<!--      ContractPlan.com delivers a package of cloud-based contract management-->
<!--      tools-->
<!--    </p>-->

<!--    <div class="container flex flex-col gap-6 mx-auto md:flex-row">-->
<!--      <div class="flex flex-col rounded-lg shadow-lg md:w-1/3">-->
<!--        <div class="h-56 bg-gray-500"></div>-->
<!--        <div class="p-3">-->
<!--          <div>Curabitur in efficitur velit.</div>-->
<!--          <p>20 mins</p>-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="flex flex-col rounded-lg shadow-lg md:w-1/3">-->
<!--        <div class="h-56 bg-gray-500"></div>-->
<!--        <div class="p-3">-->
<!--          <div>Curabitur in efficitur velit.</div>-->
<!--          <p>20 mins</p>-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="flex flex-col rounded-lg shadow-lg md:w-1/3">-->
<!--        <div class="h-56 bg-gray-500"></div>-->
<!--        <div class="p-3">-->
<!--          <div>Curabitur in efficitur velit.</div>-->
<!--          <p>20 mins</p>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<div class="relative bg-white">
  <!-- Protective overlay to prevent clicks -->
  <div class="fixed bottom-0 right-0 w-48 h-32 z-[9998] {showLogo ? 'pointer-events-none' : 'pointer-events-auto'}"></div>
  
  {#if showLogo}
    <div class="logo-wrapper fixed bottom-0 right-0 w-48 flex flex-col items-center p-4 z-[9999] mb-20 mr-4">
      <span class="built-by text-base font-medium text-white leading-none mb-2">Built by</span>
      <a href="https://cloudparallax.com/" 
         target="_blank" 
         rel="noopener noreferrer" 
         onclick={(e) => {
           if (!showLogo) {
             e.preventDefault();
             return false;
           }
         }}>
        <img 
          src="/company-logo.svg" 
          alt="Company Logo" 
          class="corner-logo w-48 h-10 object-contain"
        />
      </a>
    </div>
  {/if}
</div>

<div class="bg-orange-700" id="company">
  <div
    class="container flex flex-wrap gap-6 justify-between p-12 mx-auto text-white font-poppins"
  >
    <div class="flex flex-col gap-3 w-full md:w-2/6">
      <div class="text-2xl font-bold">ContractPlan</div>
      <div>
        Helping small businesses, local govt., and nonprofits model, manage, and
        maximize service contracts @ contractplan.com
      </div>
    </div>

    <ul
      class="flex flex-wrap gap-3 justify-between items-center w-full md:w-3/6"
    >
      <li class="w-full md:w-auto">
        <a href="#pricing">Pricing</a>
      </li>
      <li class="w-full md:w-auto">
        <a href="#features">Features</a>
      </li>
      <li class="w-full md:w-auto">
        <a href="#industries">Industries</a>
      </li>
      <li class="w-full md:w-auto">
        <a href="#faq">FAQ</a>
      </li>
      <li class="w-full md:w-auto">
        <a href="/auth/signin">Login</a>
      </li>
    </ul>
  </div>
</div>

<style>
  .corner-logo {
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    filter: brightness(0) invert(1);
  }

  .logo-wrapper {
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
    background: rgba(0, 0, 0, 0.9);
    border-radius: 8px;
    animation: fadeIn 0.3s ease forwards;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  .logo-wrapper:hover .corner-logo {
    opacity: 1;
    transform: translateY(0);
  }

  .built-by {
    opacity: 0;
    transform: translateY(5px);
    transition: all 0.2s ease-in-out;
  }

  .logo-wrapper:hover .built-by {
    opacity: 1;
    transform: translateY(0);
  }
</style>
