package models

import (
	"time"
)

type DynamoDBInterface interface {
	DynamoDB() string
}

//	type PivotIDField struct {
//		ID string `dynamodbav:"a,omitempty" orm:"column(id);pk"`
//	}
type MigrationDetail struct {
	// KSUID      string     `dynamodbav:"ksuid,omitempty" json:"-" orm:"column(ksuid);null"`
	SHAHash    string    `dynamodbav:"msha,omitempty" json:"-" orm:"column(migration_hash);null"`
	MigratedAt time.Time `dynamodbav:"mat,omitempty" json:"-" orm:"column(migrated_at);type(TIMESTAMP);null"`
	LastUpdate time.Time `dynamodbav:"-" json:"-" orm:"column(last_update);auto_now;type(TIMESTAMP);null"`
}
type DynamoDBModel struct {
	DynamoDBBaseModel
	GSIs
}

type DynamoDBBaseModel struct {
	Tenant       string `dynamodbav:"•,omitempty" json:"" orm:"-"`
	PK           string `dynamodbav:",omitempty" json:"-" orm:"-"`
	SK           string `dynamodbav:",omitempty" json:"-" orm:"-"`
	EntityName   string `dynamodbav:"-" json:"-" orm:"-"`
	EntityType   string `dynamodbav:",omitempty" json:"-" orm:"-"`
	EntitySK     string `dynamodbav:",omitempty" json:"-" orm:"-"`
	DDBAddFields string `dynamodbav:"-" json:"ddb_add_fields,omitempty" orm:"-"`
	EntityStream string `dynamodbav:"¶,omitempty" json:"" orm:"-"` // used in filtering the stream output
}

func (model DynamoDBBaseModel) GetPK() string {
	return model.PK
}
func (model DynamoDBBaseModel) GetSK() string {
	return model.SK
}

type DynamoDBBaseModelIncl struct {
	Tenant     string `dynamodbav:"•,omitempty" orm:"-"`
	PK         string `dynamodbav:",omitempty" orm:"-"`
	SK         string `dynamodbav:",omitempty" orm:"-"`
	EntityName string `dynamodbav:",omitempty" orm:"-"`
	EntityType string `dynamodbav:",omitempty" orm:"-"`
	EntitySK   string `dynamodbav:",omitempty" orm:"-"`
}
type GSIs struct {
	GSI1PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI1SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI2PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI2SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI3PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI3SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI4PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI4SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI5PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI5SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI6PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI6SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI7PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI7SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI8PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI8SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI9PK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI9SK  string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI10PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI10SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI11PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI11SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI12PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI12SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI13PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI13SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI14PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI14SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI15PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI15SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI16PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI16SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI17PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI17SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI18PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI18SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI19PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI19SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI20PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI20SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI21PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI21SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI22PK string `dynamodbav:",omitempty" json:"-" orm:"-"`
	GSI22SK string `dynamodbav:",omitempty" json:"-" orm:"-"`
}

func (*DynamoDBModel) DynamoDB() string {
	return ""
}
