package models

type UserRole struct {
	DynamoDBBaseModel
	ID          string `dynamodbav:"a,omitempty"`
	RoleID      string
	UserID      string
	Description string
	IsActive    bool
	CreatedAt   string
	UpdatedAt   string
}
