package models

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/kr/pretty"
	"github.com/opensearch-project/opensearch-go/v2/opensearchapi"

	"cloudparallax.com/backend/services/aws/config"
	dynamodb2 "cloudparallax.com/backend/services/aws/dynamodb"
	opensearch2 "cloudparallax.com/backend/services/aws/opensearch"
	"cloudparallax.com/backend/utils"
)

func DeleteItem[F ModelConstraint](ctx context.Context, record F, recordType string, openSearchDocumentId ...string) (*dynamodb.DeleteItemOutput, error) {
	_, _, err := BuildGSI(ctx, &record, recordType, "", false, true)
	if err != nil {
		return nil, err
	}
	marshalledRecord, err := attributevalue.MarshalMap(record)
	for i := range marshalledRecord {
		if ok, _ := utils.StringInSlice(i, "PK", "SK"); !ok {
			delete(marshalledRecord, i)
		}
	}
	pretty.Println("Deleting from DynamoDB", record)
	openSearchClient, err := opensearch2.NewClient()
	if err != nil {
		return nil, err
	}

	if openSearchDocumentId != nil && len(openSearchDocumentId) > 1 {
		pretty.Println("Deleting from OpenSearch", openSearchDocumentId[0], openSearchDocumentId[1])
		deleteRequest := opensearchapi.DeleteRequest{
			Index:      ctx.Value("Tenant").(string) + "-" + openSearchDocumentId[0],
			DocumentID: openSearchDocumentId[1],
		}
		resp, err := deleteRequest.Do(context.Background(), openSearchClient)
		if err != nil {
			pretty.Println(resp)
			panic(err)
		}
	}
	deleteItem := &dynamodb.DeleteItemInput{
		Key:                         marshalledRecord,
		TableName:                   aws.String(config.DDBTable),
		ReturnConsumedCapacity:      types.ReturnConsumedCapacityTotal,
		ReturnItemCollectionMetrics: types.ReturnItemCollectionMetricsSize,
		ReturnValues:                "ALL_OLD",
	}
	put, err := dynamodb2.DDBClient.DeleteItem(ctx, deleteItem, func(options *dynamodb.Options) {})
	if put != nil && put.ConsumedCapacity != nil && put.ConsumedCapacity.CapacityUnits != nil {
		dynamodb2.DDBUsage.IncrementWriteCount(*put.ConsumedCapacity.CapacityUnits)
	}

	return put, err
}
