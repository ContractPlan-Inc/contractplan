package models

import (
	"context"
	"errors"
	"os"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/kr/pretty"
)

func GetMultipleModelPairs[F ModelConstraint](ctx context.Context, v []F, recordType string) (items []*F, err error) {
	items, err = RetrieveMultipleItems(ctx, recordType, v)
	return
}

// GetItemByID retrieves an Item by Id. Returns error if
// Id doesn't exist
func GetModelByIDFromDDB[F ModelConstraint](ctx context.Context, v F, recordType string, index ...string) (item *F, err error) {
	//if !(len(v.GetID()) == 36 || len(v.GetID()) == 27 || len(v.GetID()) == 26) {
	//	return nil, errors.New("ID is not valid , len" + strconv.Itoa(len(v.GetID())))
	//}
	itemsInterface, _, err := RetrieveItemsUsingGSI(ctx, v, recordType, int32(1), false, false, true, true, nil, "", index...)
	if err == nil {
		for _, item := range itemsInterface {
			return item, nil
		}
		return nil, errors.New(recordType + " item not found")
	} else {
		panic(err)
	}
}

// GetItem retrieves an Item by most matched conditions. Returns nil if it doesnt exist
func GetAModelFromDDB[F Model](ctx context.Context, v F, recordType string, searchType string, GSIOverloads ...string) (item *F, err error) {
	itemsInterface, _, err := RetrieveItemsUsingGSI(ctx, v, recordType, int32(1), false, true, false, true, nil, searchType, GSIOverloads...)
	if err == nil {
		for _, item := range itemsInterface {
			return item, nil
		}
		return nil, errors.New(recordType + " item not found")
	} else {
		panic(err)
	}
}

func GetModelsFromDDB[F Model](ctx context.Context, v F, recordType string, limit int, pagination *DynamoLastEvaluatedKey, searchType string, sortAsc bool, gsiOverloads ...string) ([]*F, *DynamoLastEvaluatedKey, error) {
	return RetrieveItemsUsingGSI(ctx, v, recordType, int32(limit), false, true, false, sortAsc, pagination, searchType, gsiOverloads...)
}

// GetAllOrders retrieves all Orders matches certain condition. Returns empty list if
// no records exist
// withColorAndDelay -- includes the Delay Time if the completed time is greater than "expected delivery time"
func GetControllerRecordsFromDDB[F Model](ctx context.Context, record F, recordType string, query map[string]interface{}, pagination DynamoLastEvaluatedKey, limit int64, index string, searchType string, sortAsc bool) ([]*F, *DynamoLastEvaluatedKey, error) {
	timer := time.Now()
	record = QueryConverter(query, record)
	var records []*F
	var overloads []string
	if index != "" {
		overloads = append(overloads, index)
	}
	records, lastEvaluatedKey, err := GetModelsFromDDB(ctx, record, recordType, int(limit), &pagination, searchType, sortAsc, overloads...)
	// trim unused fields
	timeDiff := time.Since(timer)
	pretty.Println("TIME TAKEN FOR DYNAMODB:", timeDiff.Milliseconds())
	return records, lastEvaluatedKey, err
}

func QueryConverter[F Model](query map[string]interface{}, orderObjectF F) F {
	orderObject := &orderObjectF
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		searchSplit := []string{}
		searchSplitF := strings.Split(k, "__")
		for _, vv := range searchSplitF {
			searchSplit = append(searchSplit, strings.Split(vv, ".")...)
		}
		// lastItemIndex := len(searchSplit) - 1
		cloneVal := reflect.ValueOf(orderObject).Elem()
		for _, field := range searchSplit {
			if ok, _ := StringInSlice(field, "icontains", "contains", "startswith", "endswith", "exact", "in", "lt", "gt", "gte", "lte"); ok {
				continue
			}
			cloneVal = cloneVal.FieldByName(field)
			if cloneVal.Kind() == reflect.Ptr {
				if cloneVal.IsNil() {
					cloneVal.Set(reflect.New(cloneVal.Type().Elem()))
				}
				cloneVal = cloneVal.Elem()
			}
		}
		if cloneVal.Kind() == reflect.Ptr {
			cloneVal = cloneVal.Elem()
		}
		if cloneVal.Kind() == reflect.Ptr || cloneVal.Kind() == reflect.Struct {
			if cloneVal.FieldByName(k).IsValid() {
				cloneVal = cloneVal.FieldByName(k)
			}
		}
		fieldVal := cloneVal.Interface()
		switch fieldVal.(type) {
		case string, []string:
			{
				cloneVal.Set(reflect.ValueOf(v))
			}
		case int, int32, int64:
			{
				v2, _ := strconv.Atoi(v.(string))
				cloneVal.Set(reflect.ValueOf(v2))
			}
		case float64, float32:
			{
				v2, _ := strconv.ParseFloat(v.(string), 64)
				cloneVal.Set(reflect.ValueOf(v2))
			}
		case time.Time:
			{
				v2, _ := time.Parse(time.RFC3339, v.(string))
				cloneVal.Set(reflect.ValueOf(v2))
			}
		case bool:
			{
				v2, _ := v.(bool)
				cloneVal.Set(reflect.ValueOf(v2))
			}
		case []time.Time:
			{
				var v2 []time.Time
				for _, vv := range v.([]string) {
					timer, _ := time.Parse(time.RFC3339, vv)
					v2 = append(v2, timer)
				}
				cloneVal.Set(reflect.ValueOf(v2))
			}
		}
	}
	if os.Getenv("SHOWQUERY") != "" {
		pretty.Println("QUERY", query)
		pretty.Println("ORDER OBJECT", orderObject)
	}
	return orderObjectF
}
