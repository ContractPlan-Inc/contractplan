<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  interface Props {
    visible?: boolean;
    message?: string;
  }

  let { visible = $bindable(false), message = "Are you sure you want to delete this contract?" }: Props = $props();
  const dispatch = createEventDispatcher();

  function confirm() {
      dispatch('confirm');
      visible = false;
  }

  function cancel() {
      dispatch('cancel');
      visible = false;
  }
</script>

{#if visible}
  <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md mx-4 md:mx-0 dark:bg-dark-bg">
      <p class="text-lg text-gray-800 mb-4 dark:text-white">{message}</p>
      <div class="flex justify-end space-x-3">
        <button
          onclick={cancel}
          class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-gray-400">
          No
        </button>
        <button
          onclick={confirm}
          class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-red-400">
          Yes
        </button>
      </div>
    </div>
  </div>
{/if}

