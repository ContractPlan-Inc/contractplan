<script lang="ts">
  import Table from "$lib/components/table/table.svelte";
  import { DataSourceConnector } from "$lib/api/table-datasource";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import AddNewButton from "$lib/components/elements/AddNewButton.svelte";
  import deleteIcon from "$lib/assets/svg/trash.svg";
  import editIcon from "$lib/assets/svg/edit.svg";
  import { GetContractsDoc, DeleteContractDoc } from "$lib/generated/graphql";
  import dashboardIcon from "$lib/assets/svg/dashboard.svg";
  import { goto } from "$app/navigation";
  import Confirmation from "./delete/Confirmationl.svelte";
  interface Props {
    children?: import('svelte').Snippet;
  }

  let { children }: Props = $props();

  let queryRepository = new GraphQLQueryRepository<Contract>();
  let tableDataSource = new DataSourceConnector<Contract>(
    queryRepository,
    GetContractsDoc,
  );
  let addButton = { text: "New Contract", path: "/app/contract/create" };
  const isLabel = true;
  let label = "Columns";
  const columns = [
    { key: "ID", title: "ID", sortable: false },
    { key: "ContractAlias", title: "Contract No.", sortable: false },
    { key: "ContractName", title: "Contract Name", sortable: false },
    { key: "ContractPartner.Company", title: "Partner Name", sortable: true },
    { key: "StartDate", title: "Start Date", sortable: false },
    { key: "EndDate", title: "End Date", sortable: false },
    { key: "ServiceDays", title: "Service Days", sortable: false },
    { key: "ContractValue", title: "Contract Value", sortable: false },
    { key: "Units", title: "Units ", sortable: false },
    { key: "plannedAmount", title: "Planned Amount", sortable: false },
    { key: "Status", title: "Status", sortable: false },
  ] as Column[];
  let availableColumns = [
    "ContractAlias",
    "Date",
    "StartDate",
    "EndDate",
    "ServiceDays",
    "ContractValue",
    // "Units",
    // "Status",
  ];
  let dateColumns = ["StartDate", "EndDate"];
  let currencyColumns = ["ContractValue"];
  let actions = true;
  let actionList = [
    { name: "Day Report", icon: editIcon, function: contractDay },
    {
      name: "Dashboard",
      icon: dashboardIcon,
      iconColor: "text-gray-200",
      function: dashboardFunction,
    },
    { name: "Edit", icon: editIcon, function: editFunction },
    { name: "Delete", icon: deleteIcon, function: deleteFunction },
  ];
  let bulkActions = [
    "Activate",
    "Deactivate",
    "Delete",
    "Export to CSV",
    "Export to PDF",
  ];

  let showModal = $state(false);
  let contractToDelete: Contract;
  let successMessage = "";
  let errorMessage = "";

  function contractDay(node: Contract) {
    goto("/app/contract/day/" + node.ID);
  }
  function dashboardFunction(node: Contract) {
    goto("/app/contract/single_contract/" + node.ID);
  }
  function editFunction(node: Contract) {
    goto("/app/contract/edit/" + node.ID);
  }
  function deleteFunction(node: Contract) {
    contractToDelete = node;
    showModal = true;
  }

  async function handleConfirmDelete() {
    console.log("delete confirmation accepted")
    if (contractToDelete) {
      try {
        let queryRepository = new GraphQLQueryRepository();
        const response = await queryRepository.updateItem(DeleteContractDoc, {
          id: contractToDelete.ID,
        });

        if (response?.data?.deleteContract?.ID) {
          successMessage = "Contract successfully deleted!";
          errorMessage = "";
          window.location.reload();
        } else {
          errorMessage = "Failed to delete contract.";
          successMessage = "";
        }
      } catch (error) {
        errorMessage = "An error occurred during contract deletion.";
        successMessage = "";
        console.error("Error during contract deletion:", error);
      }
    }
        showModal = false;
    }

    function handleCancelDelete() {
        showModal = false;
    }

</script>

<div>
  <Table
    tabletitle={"Contracts"}
    {tableDataSource}
    rootAccessPath="data.listContracts.edges"
    {columns}
    {isLabel}
    {label}
    {availableColumns}
    {dateColumns}
    {currencyColumns}
    {actions}
    {actionList}
    {bulkActions}
  >
    {#snippet buttons()}
        <span  class="flex space-x-2">
        {@render children?.()}
      </span>
      {/snippet}
  </Table>
  <Confirmation
  visible={showModal}
  message="Are you sure you want to delete this contract?"
  on:confirm={handleConfirmDelete}
  on:cancel={handleCancelDelete}
/>
</div>
