package dynamodb

import (
	"context"
	"encoding/json"
	"sync"
	"time"
	
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/beego/beego/v2/core/logs"
	beego "github.com/beego/beego/v2/server/web"
	
	"cloudparallax.com/backend/services/aws/config"
	"cloudparallax.com/backend/services/cache"
)

var DDBClient = &dynamodb.Client{}
var DDBUsage = &DDBUsageMetric{}

type DDBUsageMetric struct {
	mu            sync.Mutex
	ConsumedWrite float64
	ConsumedRead  float64
}

func init() {
	DDBClient = dynamodb.NewFromConfig(config.AWSConfig)
	CaptureInfo()
	go CacheInfo()
}
func CaptureInfo() *DDBUsageMetric {
	client := cache.UniversalRedis()
	if result, err := client.Get(context.Background(), "ddb_usage_"+beego.BConfig.AppName+"_"+time.Now().Format("2006-01-02")).Bytes(); err == nil {
		usageStruct := &DDBUsageMetric{}
		if err = json.Unmarshal(result, usageStruct); err == nil {
			return usageStruct
		}
	}
	return &DDBUsageMetric{}
}
func CacheInfo() {
	client := cache.UniversalRedis()
	time.Sleep(10 * time.Second)
	for true {
		timeFormat := time.Now().Format("2006-01-02")
		if res, _ := client.Exists(context.Background(), "ddb_usage_lock_"+beego.BConfig.AppName+"_"+timeFormat).Result(); res > 0 {
			time.Sleep(10 * time.Second)
			continue
		}
		_ = client.Set(context.Background(), "ddb_usage_lock_"+beego.BConfig.AppName+"_"+timeFormat, "1", 0)
		usage := CaptureInfo()
		flushedUsage := DDBUsage.GetValueAndFlush()
		usage.IncrementReadCount(flushedUsage.ConsumedRead)
		usage.IncrementWriteCount(flushedUsage.ConsumedWrite)
		if usage.ConsumedWrite > 0 || usage.ConsumedRead > 0 {
			logs.Info("Consumed Writes: ", usage.ConsumedWrite, " Consumed Reads: ", usage.ConsumedRead)
		}
		if out, err := json.Marshal(usage); err == nil {
			_ = client.Set(context.Background(), "ddb_usage_"+beego.BConfig.AppName+"_"+timeFormat, string(out), 0)
		}
		_ = client.Del(context.Background(), "ddb_usage_lock_"+beego.BConfig.AppName+"_"+timeFormat)
		time.Sleep(10 * time.Second)
	}
}

// SetNil Inc increments the counter for the given key.
func (c *DDBUsageMetric) SetNil() {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.ConsumedWrite = 0
	c.ConsumedRead = 0
	c.mu.Unlock()
}

// IncrementWriteCount increments the counter for the given key.
func (c *DDBUsageMetric) IncrementWriteCount(value float64) {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.ConsumedWrite += value
	c.mu.Unlock()
}
func (c *DDBUsageMetric) IncrementReadCount(value float64) {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.ConsumedRead += value
	c.mu.Unlock()
}

// Value returns the current value of the counter for the given key.
func (c *DDBUsageMetric) GetValue() *DDBUsageMetric {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	defer c.mu.Unlock()
	return c
}
func (c *DDBUsageMetric) GetValueAndFlush() *DDBUsageMetric {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	defer c.mu.Unlock()
	inst := &DDBUsageMetric{}
	inst.ConsumedRead = c.ConsumedRead
	inst.ConsumedWrite = c.ConsumedWrite
	c.ConsumedRead = 0
	c.ConsumedWrite = 0
	return inst
}
