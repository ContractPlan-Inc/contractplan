package models

type Role struct {
	DynamoDBBaseModel
	ID          string `dynamodbav:"a,omitempty"`
	Name        string
	Description string
	CreatedAt   string
	UpdatedAt   string
}
