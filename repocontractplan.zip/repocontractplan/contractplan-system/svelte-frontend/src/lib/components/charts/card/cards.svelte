<script lang="ts">
  interface Props {
    children?: import('svelte').Snippet;
  }

  let { children }: Props = $props();

</script>
<main class="flex items-center justify-between w-full bg-white p-2 rounded-md ">
  {@render children?.()}
</main>
