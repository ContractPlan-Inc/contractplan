<!-- Card.svelte -->
<script>
  import Plan from "./Plan.svelte"; // Adjust the path as needed
  /** @type {any} */
  export let plan;
</script>

<div class="mb-6 flex justify-center">
  <Plan {plan} />
</div>

