<script lang="ts">
  import GrandTotal from '$lib/components/calculator/grandTotal.svelte';
  import Services from '$lib/components/calculator/services.svelte';
  import BasicInfo from '$lib/components/calculator/form.svelte';
  import { type ContractInterface, type ServiceInterface } from './store';

  interface ServiceProps {
    contract: ContractInterface;
  }

  let perDay: number;

  let { contract }: ServiceProps = $props();

  $effect(() => {
    let amount = 0;
    let majorUnits = 0;
    contract.Services.forEach((service: ServiceInterface) => {
      amount += service.ServiceTotal.amount;
      majorUnits += service.ServiceTotal.majorUnits;
    });
    console.log('contract', contract);
    console.log('contract', amount);
    contract.ContractValue.amount = amount;
    contract.ContractValue.majorUnits = majorUnits;
  });
  $effect(() => {
    console.log('start', contract.ServiceDates, contract.ServiceDays);
    if (contract.ServiceDates.length > 0 && contract.ServiceDays > 0) {
      for (let i = 0; contract.Services.length > i; i++) {
        let service = contract.Services[i];
        if (!service.SeparatePeriod) {
          service.ServiceDates = contract.ServiceDates;
          service.ServiceDays = contract.ServiceDays;
          service.StartDate = contract.StartDate;
          service.EndDate = contract.EndDate;
          service.EngagementsPerDay = contract.EngagementsPerDay;
        }
        console.log('service', service);
      }
    }
  });
</script>

<div class="flex flex-col w-full lg:flex-row ">
  <div class="flex-col items-center space-y-2 w-full rounded-xl lg:w-2/3">
    <div class="flex flex-col px-8 pt-4 mb-8 space-y-2 w-full text-sm rounded-xl border">
      <div class="py-3 text-lg text-gray-900 mb-[-15px]">Contract Basic Information</div>
      <div class="items-center space-y-1 w-full text-sm text-gray-600">
        <slot name="fields" />
      </div>
      <BasicInfo separate={false} service={contract} />
    </div>
    <Services contract={contract} />
  </div>

  <div class="flex flex-col justify-items-center mr-8 mb-3 space-y-2 w-full lg:w-1/3">
    <GrandTotal bind:contract={contract} />
    <div class="px-2 pt-1">
      <slot name="button" />
    </div>
  </div>
</div>
