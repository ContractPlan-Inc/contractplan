<script lang="ts">
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Calculator from '$lib/components/calculator/calculator.svelte';
  import { title } from '$lib/state/store';
  import { contract } from '$lib/state/calculator-store.svelte';

  title.set('Calculator');

</script>

<PageHeader>
</PageHeader>
<PageBody>
  <Calculator {contract} />
</PageBody>
