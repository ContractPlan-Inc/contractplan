<script lang="ts">
  import { createEventDispatcher, onMount } from 'svelte';




  interface Props {
    updateIsOpen?: any;
    options?: any[];
    label?: string;
    isLabel: boolean;
    availableColumns?: string[];
    selectedOptions?: any[];
    change: any;
    isOpen?: boolean;
  }

  let {
    updateIsOpen = () => {
  },
    options = $bindable([]),
    label = 'Select the service Days',
    isLabel,
    availableColumns = [],
    selectedOptions = $bindable([]),
    change,
    isOpen = $bindable(false)
  }: Props = $props();
  const dispatch = createEventDispatcher();
  const onchange = createEventDispatcher();

  onMount(() => {
    // set the "checked" property for each option to false initially
    options = options.map(option => ({
      ...option,
      checked: availableColumns.includes(option.value)
    }));
  });

  function toggleDropdown() {
    isOpen = !isOpen;
    console.log(isOpen);
    // updateIsOpen(isOpen);

  }

  function handleOptionClick(option: any) {

    option.checked = !option.checked;

    selectedOptions = options.filter((option) => option.checked).map(option => option.value);

    dispatch('selectedOptionsChange', selectedOptions);
    onchange('change', selectedOptions);

  }
</script>
<div class="relative z-30 w-full">
  <button
    class="flex w-full flex-wrap gap-2 py-1 px-2 {isLabel ? 'border' : ''}  rounded cursor-pointer"
    onclick={toggleDropdown}
  >
    <span class="">
      {#if options.filter(option => option.checked).length === 0}
        <div class="w-full">{label}</div>
      {:else}
        <div class="flex space-x-1 w-full">
          {#each options.filter(option => option.checked) as option}
          <div class="flex items-center px-1 space-x-1 h-6 text-sm rounded-3xl bg-primary-light"><div>{option.title}</div></div>
          {/each}
        </div>
      {/if}
    </span>

  </button>

  {#if isOpen}
    <div onclick={()=>isOpen = !isOpen} class="top-0 left-0 z-10 w-full h-full"></div>
    <div
      class="absolute z-30 {isLabel ? '-left-40':''} w-60  mt-1 overflow-y-auto bg-white border border-gray-400 rounded shadow-lg max-h-72">
      {#each options as option}
        <div
          class="flex items-center px-4 py-2 dark:bg-dark-bg {option.checked ? 'bg-primary-extra-light ':''} hover:bg-primary-light ">
          <input
            type="checkbox"
            id={option.title}
            class="mr-2 leading-tight"
            bind:checked={option.checked}
            onclick={() => handleOptionClick(option)}
          />
          <label class="w-full" for={option.title}>{option.title}</label>
        </div>
      {/each}
    </div>
  {/if}
</div>
