<script lang="ts">
  import { onMount } from 'svelte';

  import Input from '$lib/components/elements/input.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Table from '$lib/components/table/table.svelte';
  import json from '$lib/mock/holidays.json';
  import { editId, title } from '$lib/state/store';
  import editIcon from '$lib/assets/svg/edit.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import Confirmation from "../contract/delete/Confirmationl.svelte";
  import * as yup from 'yup';

  import {
    type ContractPartner,
    type ContractPartnerInput,
    CreateContractPartnersDoc,
    GetContractPartnersDoc,
    DeleteContractPartnerDoc,
    UpdateContractPartnersDoc
  } from '$lib/generated/graphql';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import PartnerComponent from "$lib/components/elements/PartnerComponent.svelte";

  title.set('Partners');
  let recordCount = 0;

  let partner = {
    ID: '',
    ContractPartnerName: '',
    CompanyName: '',
    Email: '',
    Contact: ''
    // Status: ""
  };
  let PartnerPop = $state(false);

  let checked = false;
  let pop = $state(false);
  let popupTitle = 'Add New Partner';
  let errors = $state({});
  let showModal = $state(false);
  let PartnerToDelete: Contract;
  let errorMessage = "";
  let successMessage = "";


  let queryRepository = new GraphQLQueryRepository<ContractPartner>();
  let tableDataSource = new DataSourceConnector<ContractPartner>(
    queryRepository,
    GetContractPartnersDoc
  );

  const columns = [
    { key: 'ID', title: 'ID', sortable: true },
    { key: 'ContractPartnerName', title: 'Partner Name', sortable: true },
    { key: 'CompanyName', title: 'Company', sortable: false },
    { key: 'Email', title: 'Email Address', sortable: true },
    { key: 'Contact', title: 'Contact', sortable: true },
    { key: 'Status', title: 'Status', sortable: true }
  ];

  let isLabel = true;
  let label = 'Columns';
  let availableColumns = [
    'ID',
    'ContractPartnerName',
    'CompanyName',
    'Email',
    'Contact',
    'Status'
  ];
  let searchableColumns = ['ID', 'Status', 'CompanyName', 'Email', 'Contact'];

  let actions = true;
  let actionList = [
    { name: 'Edit', icon: editIcon, function: editFunction },
    { name: 'Delete', icon: deleteIcon, function: deleteFunction }
  ];

  let bulkActions = [
    'Activate',
    'Deactivate',
    'Delete',
    'Export to CSV',
    'Export to PDF'
  ];

  let options = [
    { title: 'Active', value: 'active' },
    { title: 'Inactive', value: 'inactive' }
  ];

  editId.subscribe((value) => {
    console.log('val : ', value);
    if (value != 0) {
      popupTitle = 'Edit Partner';
      edit(value);
      pop = true;
    }
  });

  async function fetchPartners() {
    queryRepository = new GraphQLQueryRepository<ContractPartner>();
    tableDataSource = new DataSourceConnector<ContractPartner>(
      queryRepository,
      GetContractPartnersDoc
    );
    if (tableDataSource) {
      const result = await tableDataSource.currentRows;
      recordCount = result.data ? result.data.length : 0;
    }
  }

  function handleSubmit() {
    let queryRepository = new GraphQLQueryRepository<ContractPartnerInput>();
      if (partner.ID) {
      queryRepository
        .updateItem(UpdateContractPartnersDoc, { id: partner.ID, input: partner })
        .then(() => {
          console.log('Partner updated:', partner);
          checked = false;
          pop = false;
        });
    } else {
      queryRepository
        .updateItem(CreateContractParternsDoc, { input: partner })
        .then(() => {
          console.log('New partner added:', partner);
          checked = false;
          pop = false;
        });
    }
    fetchPartners();
  }

  function edit(id) {
    partner = json.find((obj) => obj.id === id);
  }

  function popup() {
    pop = !pop;
    editId.set(0);
    popupTitle = 'Add New Partner';
    partner = {
      ContractPartnerName: '',
      CompanyName: '',
      Email: '',
      Contact: ''
    };
  }

  function editFunction(partnerData:ContractPartner) {
    popupTitle = 'Edit Partner';
    pop = true;
    partner.ID = partnerData.ID
    partner.ContractPartnerName = partnerData.ContractPartnerName;
    partner.CompanyName= partnerData.CompanyName
    partner.Email = partnerData.Email;
    partner.Contact = partnerData.Contact;
  }

  function deleteFunction(node: ContractPartner) {
    PartnerToDelete = node;
    showModal = true;
  }

  const schema = yup.object().shape({
    ContractPartnerName: yup.string().required('Name is required'),
    CompanyName: yup.string().required('Company Name is required'),
    Email: yup.string().email('Invalid Email format').required('Email is required'),
    Contact: yup.string().required('Contact is required'),
  });

  function validation() {
    errors = {};
    try {
      schema.validateSync(partner, { abortEarly: false });
      console.log('Validation passed');
      handleSubmit();
    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      console.log(errors);
      console.log('Validation failed');
    }
  }

  async function handleConfirmDelete() {
    console.log("delete confirmation accepted", PartnerToDelete)
    showModal = false;
    console.log("delete confirmation accepted")
    if (PartnerToDelete) {
      try {
        let queryRepository = new GraphQLQueryRepository();
        const response = await queryRepository.updateItem(DeleteContractPartnerDoc, {
          id: PartnerToDelete.ID,
        });

        if (response?.data?.deleteContractPartner?.ID) {
          successMessage = "Partner successfully deleted!";
          errorMessage = "";
          window.location.reload();
        } else {
          errorMessage = "Failed to delete partner.";
          successMessage = "";
        }
      } catch (error) {
        errorMessage = "An error occurred during partner deletion.";
        successMessage = "";
        console.error("Error during partner deletion:", error);
      }
    }
    showModal = false;
  }

  function handleCancelDelete() {
    showModal = false;
  }

  onMount(async () => {
    fetchPartners();
  });

</script>

{#if pop}
  <div
    class="w-full h-full !absolute top-0 left-0 z-30 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow"
    onclick={() => popup()}
    onkeydown={(event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        popup();
      }
    }}
    tabindex="0"
    role="button"
  ></div>

  <div
    class="absolute w-full h-full top-0 left-0 flex items-center justify-center shadow"
  >
    <div
      class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-lg shadow border border-black dark:bg-dark-bg dark:text-white"
    >
      <form onsubmit={validation} class="w-full px-5 my-5">
        <div class="w-full px-5 my-5 flex items-center justify-left">
          <h1 class="text-gray-800 text-[32px] font-bold font-poppins dark:text-primary-dark-text">
            {popupTitle}
          </h1>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Name</div>
          <Input
            type="text"
            {checked}
            bind:value={partner.ContractPartnerName}
          />
          <div class="text-red-500 text-xs mt-1">{errors.ContractPartnerName}</div>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Company</div>
          <Input
            type="text"
            {checked}
            bind:value={partner.CompanyName}
          />
          <div class="text-red-500 text-xs mt-1">{errors.CompanyName}</div>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Email</div>
          <Input
            type="text"
            {checked}
            bind:value={partner.Email}
          />
          <div class="text-red-500 text-xs mt-1">{errors.Email}</div>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Contact</div>
          <Input
            type="text"
            {checked}
            bind:value={partner.Contact}
          />
          <div class="text-red-500 text-xs mt-1">{errors.Contact}</div>
        </div>
        <div class="pt-4 w-full px-5 my-5 flex items-center justify-left">
          <!-- Use onclick={handleSubmit} instead of onclick={()=>checked = true} -->
          <button
            type="submit"
            class="w-full border rounded p-3 text-white bg-[#343B4D]"
          >Update Partner
          </button>
        </div>
      </form>
    </div>
  </div>
{/if}

<PageHeader />
<PartnerComponent pop={PartnerPop}/>
<PageBody>
  <Table
    {actionList}
    {actions}
    {availableColumns}
    {bulkActions}
    {columns}
    {isLabel}
    {label}
    rootAccessPath="data.listContractPartnersDDB.edges"
    {searchableColumns}
    {tableDataSource}
  >
    {#snippet buttons()}
        <span >
        <AddNewButton
          btnText="New Partner"
          openAsPopup={true}
          onclick={() => {PartnerPop = !PartnerPop; console.log(PartnerPop);}}
        />
      </span>
      {/snippet}
  </Table>
  <Confirmation
    visible={showModal}
    message="Are you sure you want to delete this partner?"
    on:confirm={handleConfirmDelete}
    on:cancel={handleCancelDelete}
  />
</PageBody>
