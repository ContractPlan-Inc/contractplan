package cache

import (
	"context"
	
	"github.com/go-redis/redis/v8"
	
	"cloudparallax.com/backend/config"
)

var RedisClient redis.UniversalClient = nil
var redisEndpoint = config.EnvVariable("REDIS_ENDPOINT", "localhost")
var redisPort = config.EnvVariable("REDIS_PORT", "6379")

func UniversalRedis() redis.UniversalClient {
	recreate := false
	if RedisClient == nil {
		recreate = true
	} else {
		result, err := RedisClient.Ping(context.Background()).Result()
		if err != nil || result != "PONG" {
			recreate = true
		}
	}
	if recreate {
		RedisClient = redis.NewClient(&redis.Options{
			Addr:     redisEndpoint + ":" + redisPort,
			Password: "", // no password set
		})
		result, err := RedisClient.Ping(context.Background()).Result()
		if err != nil || result != "PONG" {
			RedisClient = redis.NewClusterClient(&redis.ClusterOptions{
				Addrs:    []string{redisEndpoint + ":" + redisPort},
				Password: "", // no password set
			})
		}
		return RedisClient
	}
	return RedisClient
}
