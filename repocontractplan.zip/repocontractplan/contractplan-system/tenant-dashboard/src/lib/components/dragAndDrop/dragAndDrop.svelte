<script>
  import Column from "./column.svelte";
  import { flip } from "svelte/animate";
  import { dndzone } from "svelte-dnd-action";

  const flipDurationMs = 300;

  export let columns;
  export let onFinalUpdate;

  // triggered when a column position is temporarily changed in hover state before releasing the mouse
  function handleDndConsiderColumns(e) {
    // console.log("handleDndConsiderColumns")
    columns = e.detail.items;
  }

  // triggered when a column position is changed
  function handleDndFinalizeColumns(e) {
    // console.log("handleDndFinalizeColumns")
    onFinalUpdate(e.detail.items);
  }

  function handleItemFinalize(columnIdx, newItems) {
    // console.log("handleItemFinalize")
    columns[columnIdx].items = newItems;
    onFinalUpdate([...columns]);
  }
</script>
<section class="flex space-x-2 px-2" on:consider={handleDndConsiderColumns}
         on:finalize={handleDndFinalizeColumns} use:dndzone={{items:columns, flipDurationMs, type:'column'}}>
  {#each columns as { id, name, items }, idx (id)}
    <div class="w-full" animate:flip="{{duration: flipDurationMs}}">
      <Column name={name} items={items} onDrop={(newItems) => handleItemFinalize(idx, newItems)} on:contractStatus />
    </div>
  {/each}
</section>
