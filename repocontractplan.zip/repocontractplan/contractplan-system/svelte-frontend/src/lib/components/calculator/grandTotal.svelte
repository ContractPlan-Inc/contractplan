<script lang="ts">
  import type { ContractInterface } from './store';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import { page } from '$app/stores';


  interface ServiceProps {
    contract: ContractInterface;
  }

  // export let services
  let { contract = $bindable() }: ServiceProps = $props();


</script>


<div class="flex flex-col px-2 pt-2 space-y-2 w-full lg:pt-0 lg:w-full">
  <div class="flex flex-col p-2 space-y-2 w-full bg-white rounded-xl border dark:bg-dark-bg dark:text-white">
    <div class="ml-4 text-2xl">Payment Details</div>
    {#each contract.Services as service}
      {#if service.ServiceName != ''}
        <div class="flex items-center pl-2 w-full">
          <div class="ml-4">Cost for {service.ServiceName}</div>
          <div class="flex-grow pr-2 h-10 text-right border-none focus:ring-0 focus:ring-offset-0"
               style="white-space: nowrap; overflow: visible;">
            <span class="ml-6 text-xl text-gray-500">$</span>
            <span class="ml-2 text-xl" style="color: black dark:text-primary-dark-text; ">
                            {service?.ServiceTotal?.majorUnits.toFixed(2)}
                        </span>
          </div>
        </div>
      {/if}
    {/each}


    <div class="flex items-center pt-2 pr-2 pl-2 w-full border-t">
      <div class="ml-4 w-3/4">Grand Total</div>
      <div class="flex-grow h-10 text-right border-none focus:ring-0 focus:ring-offset-0"
           style="white-space: nowrap; overflow: visible;">
        <span class="ml-6 text-xl text-gray-500">$</span>
        <span class="ml-2 text-xl" style="color: black dark:text-primary-dark-text;;">
                    {(contract?.ContractValue?.majorUnits).toFixed(2)}
                </span>
      </div>
    </div>
  </div>
  {#if ($page.url.pathname !== '/app/contract/create/') }
    <AddNewButton btnText="New Contract" path="/app/contract/create" />
  {/if}
</div>
