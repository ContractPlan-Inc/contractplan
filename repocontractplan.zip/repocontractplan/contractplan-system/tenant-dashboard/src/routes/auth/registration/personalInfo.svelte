<script lang="ts">
  import Input from "$lib/components/elements/input.svelte";
  import { registrationSchema, validation } from "./service.svelte";
  import type { SignUpInput } from "$lib/generated/graphql";
  import Loader from "$lib/components/elements/loader.svelte";
  import { goto } from "$app/navigation";
  import { auth, authState } from "$lib/state/auth";

  interface RegFormProps {
    regForm: SignUpInput;
    status: string;
  }

  let { regForm = $bindable(), status = $bindable() }: RegFormProps = $props();
  let errors: { [key: string]: string } = $state({});
  let loading = $state(false);

  async function validatePersonalInfo() {
    let returnedErrors = await validation(regForm, registrationSchema);
    if (returnedErrors != null) {
      errors = returnedErrors;
      console.log("x", returnedErrors);
    } else {
      loading = true;

      setTimeout(() => {
        loading = false;
        status = "company";
      }, 2000);
    }
  }

  function isValidForm() {
    try {
      registrationSchema.validateSync(regForm, { abortEarly: false });
      errors = {};
      return true; // Form is valid
    } catch (validationErrors) {
      return false; // Form is invalid
    }
  }

    console.log("($*$)", auth.loginAs?.displayName);
</script>

<div class="w-full p-9">
  <h1 class="text-2xl font-bold text-left">Personal Information</h1>
  <form class=" w-full" onsubmit={(event)=>{event.preventDefault();validatePersonalInfo}}>
    <div class="space-y-2 mt-4">
      <div class="relative flex flex-col items-start w-full">
        <label class="text-sm my-2" for="fullName"> Full Name </label>
        <input
          bind:value={regForm.firstName}
          type="text"
          class="bg-gray-50 border mb-1 {errors.firstName
            ? 'border-red-500'
            : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          id="fullName"
          placeholder="John Doe"
        />
        <div class=" h-2">
          {#if errors.firstName}
            <p class="text-xs text-red-500">{errors.firstName}</p>
          {/if}
        </div>
      </div>

      <div class="relative flex flex-col items-start w-full">
        <label class="text-sm my-2" for="telephone"> Telephone </label>
        <input
          bind:value={regForm.telephone}
          type="tel"
          class="bg-gray-50 border mb-1 {errors.telephone
            ? 'border-red-500'
            : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          id="telephone"
          placeholder="222-333-4444"
        />
        <div class=" h-2">
          {#if errors.telephone}
            <p class="text-xs text-red-500">{errors.telephone}</p>
          {/if}
        </div>
      </div>

      <div class="relative flex flex-col items-start w-full">
        <label class="text-sm my-2" for="email"> Email </label>
        <input
          bind:value={regForm.email}
          type="email"
          class="bg-gray-50 border mb-1 {errors.email
            ? 'border-red-500'
            : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          id="email"
          placeholder="joshndoe@example.com"
        />
        <div class=" h-2">
          {#if errors.email}
            <p class="text-xs text-red-500">{errors.email}</p>
          {/if}
        </div>
      </div>

      <div class="relative flex flex-col items-start w-full">
        <label class="text-sm my-2" for="password"> Password </label>
        <input
          bind:value={regForm.password}
          type="password"
          class="bg-gray-50 border mb-1 {errors.password
            ? 'border-red-500'
            : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          id="password"
          placeholder="********"
        />
        <div class=" h-2">
          {#if errors.password}
            <p class="text-xs text-red-500">{errors.password}</p>
          {/if}
        </div>
      </div>
    </div>

    <!-- <Input bind:value={regForm.firstName} label="Full Name" type="text" />
    {#if errors.firstName}
      <div class="text-xs text-red-500 ">{errors.firstName}</div>
    {/if} -->
    <!-- <Input bind:value={regForm.telephone} label="Telephone" type="tel" />
    {#if errors.telephone}
      <p class="text-xs text-red-500">{errors.telephone}</p>
    {/if} -->
    <!-- <Input bind:value={regForm.email} label="Email" type="email" />
    {#if errors.email}
      <p class="text-xs text-red-500">{errors.email}</p>
    {/if} -->
    <!-- <Input bind:value={regForm.password} label="Password" type="password" />
    {#if errors.password}
      <p class="text-xs text-red-500">{errors.password}</p>
    {/if} -->

    <div class=" space-y-3 mt-6">
      <button
        class=" w-full p-2 rounded-lg justify-center items-center inline-flex text-white text-lg font-semibold {isValidForm()
          ? 'bg-black'
          : ' bg-gray-400'}"
        onclick={()=>{
          if(isValidForm()) {
            validatePersonalInfo();
          }
        }}
      >
        Let's Begin
      </button>
      <button
        class=" w-full p-2 rounded-lg justify-center items-center gap-2 inline-flex text-white text-lg font-semibold bg-primary"
        onclick={() => {
          goto("/auth/signin");
        }}
      >
        Already have an account ? Sign In
      </button>
    </div>
  </form>
</div>

<Loader {loading} type="pageLoader" />
