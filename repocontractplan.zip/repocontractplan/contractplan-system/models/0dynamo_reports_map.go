package models

type ReportMapItem[T any] struct {
	Model T
}

var ReportsMap = map[string]map[string]ReportMapItem[any]{
	"CONTRACT_DAY_RECORD": {
		"DAILY_REPORT": {
			Model: ContractReport{},
		},
		"WEEKLY_REPORT": {
			Model: ContractReport{},
		},
		"MONTHLY_REPORT": {
			Model: ContractReport{},
		},
	},
}

var ReportsGenMap = map[string]map[string]map[string][]string{
	"CONTRACT_DAY_RECORD": {
		"SK": {
			"PK": {"øTENANTø", "Tenant", "øCONTRACTSø"},
			"SK": {"øTENANTø", "Tenant", "øCONTRACTø", "Id"},
		},
		"DAILY_REPORT": {
			"EntityName":   {"øContract Day Reportø"},
			"EntityStream": {"øCONTRACTø"},
			"EntityType":   {"øTENANTø", "Tenant", "øCONTRACTø"},
			"EntitySK":     {"øTENANTø", "Tenant", "øCONTRACTø", "CreatedAt"},
			"PK":           {"øTENANTø", "Tenant", "øCONTRACTSø"},
			"SK":           {"øTENANTø", "Tenant", "øCONTRACTø", "EngagementDate/DATE/TimezoneField"},
		},
		"WEEKLY_REPORT": {
			"EntityName":   {"øContractø"},
			"EntityType":   {"øTENANTø", "Tenant", "øCONTRACTø"},
			"EntityStream": {"øCONTRACTø"},
			"EntitySK":     {"øTENANTø", "Tenant", "øCONTRACTø", "CreatedAt"},
			"PK":           {"øTENANTø", "Tenant", "øCONTRACTSø"},
			"SK":           {"øTENANTø", "Tenant", "øCONTRACTø", "EngagementDate/WEEK/TimezoneField"},
		},
		"MONTHLY_REPORT": {
			"EntityName":   {"øContractø"},
			"EntityType":   {"øTENANTø", "Tenant", "øCONTRACTø"},
			"EntityStream": {"øCONTRACTø"},
			"EntitySK":     {"øTENANTø", "Tenant", "øCONTRACTø", "CreatedAt"},
			"PK":           {"øTENANTø", "Tenant", "øCONTRACTSø"},
			"SK":           {"øTENANTø", "Tenant", "øCONTRACTø", "EngagementDate/MONTH/TimezoneField"},
		},
	},
}
