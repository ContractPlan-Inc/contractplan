package chargebee

import (
	"fmt"

	"github.com/chargebee/chargebee-go/v3"
	"github.com/chargebee/chargebee-go/v3/actions/customer"
	subscriptionAction "github.com/chargebee/chargebee-go/v3/actions/subscription"
	"github.com/chargebee/chargebee-go/v3/filter"
	customer2 "github.com/chargebee/chargebee-go/v3/models/customer"
	"github.com/chargebee/chargebee-go/v3/models/subscription"
)

func GetSubscription(tenantId string) (*subscription.Subscription, error) {

	if tenantId == "" {
		return nil, fmt.Errorf("invalid token")
	}

	res, err := subscriptionAction.List(&subscription.ListRequestParams{
		Limit:      chargebee.Int32(2),
		CustomerId: &filter.StringFilter{Is: tenantId},
	}).ListRequest()

	var subscription *subscription.Subscription

	if err != nil {
		return nil, err
	}

	if res == nil || len(res.List) == 0 {
		return nil, fmt.Errorf("no subscription found")
	}

	if len(res.List) > 1 {
		subscription = res.List[len(res.List)-1].Subscription
	} else {
		subscription = res.List[0].Subscription
	}

	return subscription, nil
}
func CreateCustomerInChargebee(id string, email string, firstName string, lastName string, address string) {

	res, err := customer.Create(&customer2.CreateRequestParams{
		Id:        id,
		FirstName: firstName,
		LastName:  "",
		Email:     email,
		Locale:    "",
		BillingAddress: &customer2.CreateBillingAddressParams{
			FirstName: firstName,
			LastName:  "",
			Line1:     address,
			City:      "",
			State:     "",
			Zip:       "",
			Country:   "US",
		},
	}).Request()
	if err != nil {
		fmt.Println(err)
	} else {
		Customer := res.Customer
		//Card := res.Card

		fmt.Println(Customer)
	}
}
