package chargebee

import (
	"context"
	"encoding/json"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/secretsmanager"
	"github.com/chargebee/chargebee-go/v3"
	"github.com/kr/pretty"
	"github.com/opensearch-project/opensearch-go/v2"

	"cloudparallax.com/backend/config"
	serviceConfig "cloudparallax.com/backend/services/aws/config"
)

type ChargebeeSecret struct {
	ChargebeeSite string `json:"chargebee_site"`
	ChargebeeKey  string `json:"chargebee_key"`
}

var secretCache = &ChargebeeSecret{}

var (
	Client               *opensearch.Client
	secretsManagerClient = secretsmanager.NewFromConfig(serviceConfig.AWSConfig)
)

func init() {
	var err error
	secret := config.EnvVariable("CHARGEBEE_SECRET")
	pretty.Println("SECRET ARN", secret)
	result, err := secretsManagerClient.GetSecretValue(
		context.Background(),
		&secretsmanager.GetSecretValueInput{
			SecretId: aws.String(secret),
		},
	)
	if err != nil {
		pretty.Println("SECRET ERR", err)
	}
	pretty.Println("SECRET", *result.SecretString)
	err = json.Unmarshal([]byte(*result.SecretString), secretCache)
	if err != nil {
		pretty.Println("JSON ERR", err)
		//return nil, err
	}
	chargebee.Configure(secretCache.ChargebeeKey, secretCache.ChargebeeSite)
}
