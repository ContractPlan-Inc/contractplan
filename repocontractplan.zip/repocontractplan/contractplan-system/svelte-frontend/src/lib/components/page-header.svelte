<script lang="ts">
  interface Props {
    Title?: string;
    Subtitle?: string;
    children?: import('svelte').Snippet;
  }

  let { Title = '', Subtitle = '', children }: Props = $props();
</script>

{@render children?.()}

