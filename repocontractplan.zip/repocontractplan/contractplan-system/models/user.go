package models

type User struct {
	DynamoDBModel
	Tenant          string
	ID              string `dynamodbav:"a,omitempty"`
	CognitoID       string
	VisibleName     string
	Username        string
	Email           string
	ProfileImageURL string
	CreatedAt       string
	UpdatedAt       string
	AutoLogout      int
	Roles           []*Role
	Policies        []*Policy
}

func (User) IsNode() {}
func (this User) GetID() string {
	return this.ID
}
