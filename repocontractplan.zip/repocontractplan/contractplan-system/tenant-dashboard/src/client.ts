import { cacheExchange, Client, fetchExchange } from "@urql/svelte";
import { PUBLIC_API_URL } from "$env/static/public";

import { auth, authState } from "$lib/state/auth";
//
auth.viewLoaded = true;
authState.set(auth);
export const client = new Client({
  url: `${PUBLIC_API_URL}`,
  fetchOptions: () => {
    console.log(auth);
    if (auth.token.length > 0) {
      return {
        headers: {
          authorization: auth.token.length > 0 ? `Bearer ${auth.token}` : "",
        },
      };
    }
    return {};
  },
  exchanges: [cacheExchange, fetchExchange],
  requestPolicy: "cache-and-network",
});
export default client;
