<script lang="ts">
  import { onMount } from 'svelte';

  import Input from '$lib/components/elements/input.svelte';
  import Select from '$lib/components/elements/select.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Table from '$lib/components/table/table.svelte';
  import { editId, title } from '$lib/state/store';
  import editIcon from '$lib/assets/svg/edit.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import { GetMembersDoc, type Member, type MemberInput, UpdateMemberDoc } from '$lib/generated/graphql';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import * as yup from 'yup';

  title.set('Members');

  let recordCount = 0;

  let schema = yup.object().shape({
    FullName: yup.string().required('Full Name is required'),
    Email: yup
      .string()
      .email('Invalid email format')
      .required('Email is required')
    // Add other validations as needed
  });

  // table attributes
  let queryRepository = new GraphQLQueryRepository<Member>();
  let tableDataSource = new DataSourceConnector<Member>(
    queryRepository,
    GetMembersDoc
  );
  const columns = [
    { key: 'ID', title: 'ID', sortable: true },
    { key: 'FullName', title: 'Full Name', sortable: true },
    { key: 'Designation', title: 'Designation', sortable: false },
    { key: 'Email', title: 'Email Address', sortable: true },
    { key: 'Status', title: 'Status', sortable: true }
  ];
  let isLabel = true;
  let label = 'Columns';
  let availableColumns = ['ID', 'FullName', 'Designation', 'Email', 'Status'];
  let searchableColumns = ['ID', 'FullName', 'Designation', 'Email', 'Status'];
  let actions = true;
  let actionList = [
    { name: 'Edit', icon: editIcon, function: editFunction },
    { name: 'Delete', icon: deleteIcon, function: deleteFunction }
  ];
  let bulckActions = [
    'Activate',
    'Deactivate',
    'Delete',
    'Export to CSV',
    'Export to PDF'
  ];

  let popupTitle = 'Add New Member';
  let options = [
    { title: 'Manager', value: 'Manager' },
    { title: 'CEO', value: 'CEO' }
  ];
  let pop = false;
  let member = {
    ID: '',
    FullName: '',
    Designation: '',
    Email: ''
  };



  editId.subscribe((value) => {
    console.log('val : ', value);
    if (value != 0) {
      popupTitle = 'Edit Member';
      edit(value);
      pop = true;
      // goto('/holidays/'+value);
    }
    // goto('editId');
  });

  function handleSubmit() {
    schema
      .validate(member, { abortEarly: false })
      .then(() => {
        // Validation passed, proceed with form submission
        let queryRepository = new GraphQLQueryRepository<MemberInput>();
        const { ID, FullName, Email, Designation } = member;

        queryRepository
          .updateItem(UpdateMemberDoc, { id: ID, input: { FullName, Email, Designation } })
          .then(() => {
            checked = false;
            pop = false;
          });
      })
      .catch((err) => {
        // Validation failed, handle errors
        console.error(err.errors);
      });
  }

        function edit(id) {
    member = json.find((obj) => obj.id === id);
  }

  let checked = false;

  function popup() {
    pop = !pop;
    editId.set(0);
    popupTitle = 'Add New Member ';
    member = {
      FullName: '',
      Designation: 'Manager',
      Email: ''
    };
  }

  function editFunction(memberData: Member) {
    popupTitle = 'Edit Member';
    pop = true;
    member.ID = memberData.ID;
    member.FullName = memberData.FullName;
    member.Email = memberData.Email;
    member.Designation = memberData.Designation;
  }

  function deleteFunction() {
  }

  onMount(async () => {
    if (tableDataSource) {
      const result = await tableDataSource.currentRows;
      recordCount = result.data ? result.data.length : 0;
    }
  });
</script>

<!--{JSON.stringify(holidays)}-->

{#if pop}
  <div
    class="w-full h-full !absolute top-0 left-0 z-30 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow"
    onclick={() => popup()}
    onkeydown={(event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        popup();
      }
    }}
    tabindex="0"
    role="button"
  ></div>

  <div
    class="absolute w-full h-full top-0 left-0 flex items-center justify-center shadow"
  >
    <div
      class="relative w-full max-w-md max-h-full mx-auto z-40 bg-white rounded-lg shadow border border-black"
    >
      <form onsubmit={handleSubmit} class="w-full px-5 my-5">
        <div class="w-full px-5 my-5 flex items-center justify-left">
          <h1 class="text-gray-800 text-[32px] font-bold font-poppins">
            {popupTitle}
          </h1>
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Full Name</div>
          <Input
            type="text"
            {checked}
            bind:value={member.FullName}
            required
            validationText="Full Name is required"
          />
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <div class="mb-1">Email Address</div>
          <Input
            type="text"
            {checked}
            bind:value={member.Email}
            required
            validationText="Email is required"
          />
        </div>
        <div class="w-full px-5 my-5 items-center justify-left">
          <Select {options} label="Type" bind:value={member.Designation} />
        </div>
        <div class="pt-4 w-full px-5 my-5 flex items-center justify-left">
          <!-- Use onclick={handleSubmit} instead of onclick={()=>checked = true} -->
          <button
            type="submit"
            class="w-full border rounded p-3 text-white bg-[#343B4D]"
          >Add Member
          </button>
        </div>
      </form>
    </div>
  </div>
{/if}

<PageHeader Title="Member" />
<PageBody>
  <Table
    {actionList}
    {actions}
    {availableColumns}
    {bulckActions}
    {columns}
    {isLabel}
    {label}
    rootAccessPath="data.listMembers.edges"
    {searchableColumns}
    {tableDataSource}
  >
    <span slot="buttons">
      <AddNewButton
        btnText="New Member"
        on:message={popup}
        openAsPopup={true}
      />
    </span>
  </Table>
</PageBody>
