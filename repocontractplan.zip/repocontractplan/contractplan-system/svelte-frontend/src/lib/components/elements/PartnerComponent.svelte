<script lang="ts">
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import * as yup from 'yup';
  import { type ContractPartnerInput, CreateContractPartnersDoc } from '$lib/generated/graphql';


  const schema = yup.object().shape({
    ContractPartnerName: yup.string().required('Name is required'),
    CompanyName: yup.string().required('Company Name is required'),
    Email: yup.string().email('Invalid Email format').required('Email is required'),
    Contact: yup.string().required('Contact is required')
  });
  interface Props {
    pop?: boolean;
  }

  let { pop = $bindable(false) }: Props = $props();
  let popupTitle = 'Add New Partner';
  let partner = $state({
    ContractPartnerName: null,
    CompanyName: null,
    Email: null,
    Contact: null
  });
  let errors = $state({});
  let checked = false;
  let clicked = false;

  const handleSubmit = () => {
    let queryRepository = new GraphQLQueryRepository<ContractPartnerInput>();
    queryRepository
      .updateItem(CreateContractPartnersDoc, { input: partner })
      .then(() => {
        console.log('New partner added:', partner);
        checked = false;
        pop = false;
      });
  };


  function validation() {
    if (!clicked) {
      clicked = true;
      try {
        schema.validateSync(partner, { abortEarly: false });
        console.log('Validation passed');
        handleSubmit();
      } catch (error) {
        errors = {};
        error.inner.forEach((e) => {
          console.log(e.path, e.message);
          errors[e.path] = e.message;
        });
        console.log(errors);
        console.log('Validation failed');
      }
    }
  }


</script>

{#if pop}
  <div class="absolute top-0 left-0 flex item-center justify-center z-50">
    <div
      id="janith"
      class="flex items-center justify-center w-full h-full  top-0 left-0 bg-white bg-opacity-10 backdrop-blur-[8.40px] shadow  "
      style="position: fixed;"
      onclick={(event) => {
        pop = false;
        console.log("event id", event);
      }}
    >
      <div
        class="w-full max-w-md left-50 max-h-full z-50 bg-white rounded-lg shadow border border-black dark:bg-dark-bg dark:text-white"
        style="left: 150px; "
        onclick={(event)=>{event.stopPropagation(); pop=true}}>
        <form class="w-full px-5 my-5 ">
          <div class="w-full px-5 my-5 flex items-center justify-left">
            <h1 class="text-gray-800 text-[32px] font-bold font-poppins dark:text-primary-dark-text">
              {popupTitle}
            </h1>
          </div>
          <div class="w-full px-5 my-5 items-center justify-left">
            <div class="mb-1">Name</div>
            <input
              class="bg-gray-50 border text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              type="text"
              bind:value={partner.ContractPartnerName}
            />
            <div class="text-red-500 text-xs mt-1">{errors.ContractPartnerName}</div>
          </div>
          <div class="w-full px-5 my-5 items-center justify-left">
            <div class="mb-1">Company</div>
            <input
              class="bg-gray-50 border text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              type="text"
              bind:value={partner.CompanyName}
            />
            <div class="text-red-500 text-xs mt-1">{errors.CompanyName}</div>
          </div>
          <div class="w-full px-5 my-5 items-center justify-left">
            <div class="mb-1">Email</div>
            <input
              class="bg-gray-50 border text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              type="text"
              bind:value={partner.Email}
            />
            <div class="text-red-500 text-xs mt-1">{errors.Email}</div>
          </div>
          <div class="w-full px-5 my-5 items-center justify-left">
            <div class="mb-1">Contact</div>
            <input
              class="bg-gray-50 border text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              type="text"
              bind:value={partner.Contact}
            />
            <div class="text-red-500 text-xs mt-1">{errors.Contact}</div>
          </div>
          <!-- <div class="w-full px-5 my-5 items-center justify-left">
                        <div class="mb-1">Status</div>
                        <Select {options} label="" bind:value="{partner.Status}"/>
                    </div> -->
          <div class="pt-4 w-full px-5 my-5 flex items-center justify-left">
            <button
              type="submit"
              class="w-full border rounded p-3 text-white bg-[#343B4D]"
              onclick={()=>{validation()}}
            >Add Partner
            </button>
            <!-- {JSON.stringify(errors)} -->
          </div>
        </form>
      </div>
    </div>
  </div>

{/if}
