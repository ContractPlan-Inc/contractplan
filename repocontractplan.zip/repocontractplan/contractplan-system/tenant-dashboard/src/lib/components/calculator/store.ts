import { writable } from 'svelte/store';
import { fromZonedTime, toZonedTime } from 'date-fns-tz';
import { addMonths, endOfMonth, getDay, startOfDay, startOfMonth } from 'date-fns';

export interface ContractInterface extends ServiceInterface {
  ContractName: string;
  ContractPartnerID: string;
  ContractAlias: string;
  ContractValue: MoneyInterface;
  Services: ServiceInterface[];
}

export interface MoneyInterface {
  amount: number;
  currency: string;
  majorUnits?: number;
}

export class Money implements MoneyInterface {
  amount: number;
  currency: string;
  majorUnits: number;

  constructor(amount: number, currency: string, majorUnits: number) {
    this.amount = amount;
    this.currency = currency;
    this.majorUnits = majorUnits;
  }

  toMajorUnits() {
    return this.amount / 100;
  }

  fromMajorUnits(amount: number) {
    this.amount = amount * 100;
  }
}

export interface UnitDefinitionInteface {
  Name: string;
  Description: string;
}

export interface ServiceInterface {
  PerDayServiceCost: number;
  ServiceName: string;
  StartDate: string;
  EndDate: string;
  ServicePeriod: string;
  Weekdays: number[];
  SelectedMonthDays: number[];
  SelectedDatesOfYear: string[];
  ServiceDays: number;
  EngagementsPerDay: number;
  EngagementCost: MoneyInterface;
  ServiceTotal: MoneyInterface;
  UnitDefinition: UnitDefinitionInteface;
  SeparatePeriod: boolean;
  ServiceDates: string[];
}

export const errors = writable({
  contractName_error: '',
  contractPartner_error: '',
  serviceDays_error: '',
  engagementsPerDay_error: '',
  hasServicesError: false
});

function isHoliday(
  date: Date,
  holidays: Date[],
  timezone: string = 'UTC'
): boolean {
  const zoned_date = toZonedTime(startOfDay(date), timezone);
  return holidays.some((holiday) => isSameDay(zoned_date, holiday, timezone));
}

function isSameDay(
  date1: Date,
  date2: Date,
  timezone: string = 'UTC'
): boolean {
  const zoned_date1 = toZonedTime(startOfDay(date1), timezone);
  const zoned_date2 = toZonedTime(startOfDay(date2), timezone);
  return zoned_date1.getTime() === zoned_date2.getTime();
}

function getFirstOccurrenceOfMonth(
  date: Date,
  dayOfWeek: number,
  timezone: string = 'UTC'
): number | null {
  const firstDayOfMonth = startOfMonth(date);
  const daysInMonth = endOfMonth(date).getDate();
  for (let day = 1; day <= daysInMonth; day++) {
    const currentDay = toZonedTime(
      new Date(firstDayOfMonth.getFullYear(), firstDayOfMonth.getMonth(), day),
      timezone
    );
    if (getDay(currentDay) === dayOfWeek) {
      return day;
    }
  }
  return null;
}

function getLastOccurrenceOfMonth(
  date: Date,
  dayOfWeek: number,
  timezone: string = 'UTC'
): number | null {
  const lastDayOfMonth = endOfMonth(date);
  const daysInMonth = endOfMonth(date).getDate();
  console.log('daysInMonth:::');
  for (let day = daysInMonth; day > 0; day--) {
    const currentDay = toZonedTime(
      new Date(lastDayOfMonth.getFullYear(), lastDayOfMonth.getMonth(), day),
      timezone
    );
    if (getDay(currentDay) === dayOfWeek) {
      return day;
    }
  }
  return null;
}

function getOccurrencesOfMonth(
  date: Date,
  dayOfWeek: number,
  timezone: string = 'UTC'
): number[] {
  const daysInMonth = endOfMonth(date).getDate();
  const occurrences: number[] = [];
  for (let day = 1; day <= daysInMonth; day++) {
    const currentDay = fromZonedTime(
      startOfDay(new Date(date.getFullYear(), date.getMonth(), day)),
      timezone
    );
    if (getDay(currentDay) === dayOfWeek) {
      occurrences.push(day);
    }
  }
  return occurrences;
}

export function generateCronDates(
  start_date: Date,
  end_date: Date,
  weekdays: number[] = [],
  days_of_month: number[] = [],
  dates_of_year: string[] = [],
  occurrence: 'first' | 'last' | 'every' = 'first',
  holidays: Date[] = [],
  timezone: string = 'UTC'
): Date[] {
  if (weekdays.length > 0 && days_of_month.length > 0) {
    throw new Error('weekdays and days_of_month are mutually exclusive');
  }
  console.log(weekdays);
  console.log(days_of_month);

  const candidates: Date[] = [];

  let current_date = startOfMonth(start_date);

  if (dates_of_year.length === 0) {
    while (current_date <= end_date) {
      if (weekdays.length > 0) {
        weekdays.forEach((dayOfWeek) => {
            const dayOfMonth =

              occurrence === 'first' ? getFirstOccurrenceOfMonth(current_date, dayOfWeek, timezone)
                : occurrence === 'last' ? getLastOccurrenceOfMonth(current_date, dayOfWeek, timezone)
                  : getOccurrencesOfMonth(current_date, dayOfWeek, timezone);

            if (dayOfMonth) {
              const dates = Array.isArray(dayOfMonth) ? dayOfMonth : [dayOfMonth];
              dates.forEach((day) => {
                const date = fromZonedTime(startOfDay(new Date(current_date.getFullYear(), current_date.getMonth(), day)), timezone);
                if (!isHoliday(date, holidays, timezone)) {
                  candidates.push(date);
                }
              });
            }
          }
        );
      }
      if (days_of_month.length > 0) {
        const filteredAndTransformedDays = [];

        for (let i = 0; i < days_of_month.length; i++) {
          const day = days_of_month[i] + 1;

          const date = toZonedTime(new Date(current_date.getFullYear(), current_date.getMonth(), day), timezone);

          if (!isHoliday(date, holidays, timezone) && day <= endOfMonth(current_date).getDate()) {

            filteredAndTransformedDays.push(date);
          }
        }
        candidates.push(...filteredAndTransformedDays);
      }

      current_date = addMonths(current_date, 1);
    }
  } else {
    let dates = [];
    let currentDate = new Date(start_date);

    console.log('||  currentDate:', currentDate, 'end_date:', end_date, '  ||');

    while (currentDate < end_date) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    let formattedDates_of_year: Date[] = [];

    for (let i = 0; i < dates_of_year.length; i++) {
      formattedDates_of_year[i] = new Date(dates_of_year[i]);
    }

    const equalDates = dates.filter((date) => {
      return formattedDates_of_year.some(targetDate => {
        return date.getFullYear() === targetDate.getFullYear() && date.getMonth() === targetDate.getMonth() && date.getDate() === targetDate.getDate();
      });
    });

    console.log('||  equalDates:', equalDates);

    return equalDates;
  }

  candidates.sort((a, b) => a.getTime() - b.getTime());
  return candidates;
}
