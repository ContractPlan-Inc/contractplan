<script lang="ts">
  import {GraphQLQueryRepository} from '$lib/api/query-repository';
  import {type SignUpInput, VerificationDoc, type VerificationInput} from '$lib/generated/graphql';
  import {onMount} from 'svelte';
  import {signupFormData} from '../registrationStore';
  import {autoLogin} from './service.svelte';
  import Loader from '$lib/components/elements/loader.svelte';
  import {authError} from '$lib/state/store';

  interface RegFormProps {
    regForm: SignUpInput;
    status: string;
  }

  let loading = $state(false);

  let {regForm = $bindable(), status = $bindable()}: RegFormProps = $props();
  let isError: boolean = false;

  let email = $signupFormData.email;
  let verificationCode: string[] = [];

  async function handleVerification() {
    console.log('clicked email verification');
    loading = true;
    try {
      const data = {
        email: regForm.email,
        token: verificationCode.join('')
      };

      let queryRepository = new GraphQLQueryRepository<VerificationInput>();
      let response: any = await queryRepository.Verification(VerificationDoc, {
        input: data
      });

      console.log(response.data.Verification);

      if (response.data.Verification.success == false) {
        //display the isError if code doesn't match
        isError = true;
      } else if (response.data.Verification.success == true) {

        authError.set('');
        const err = await autoLogin(regForm.email, regForm.password);

        if (err != null) {
          isError = true;
          return;
        }
        loading = false;
        console.log(response.data.Verification);
        status = 'plan';

      }
    } catch (error: any) {
      loading = false;
      console.log('errorerrorerror', error);

      isError = true;
    }
  }

  function focusNextInput(e: KeyboardEvent) {
    console.log('validarion code', verificationCode.join(''));

    const target = e.target as HTMLInputElement;
    target.value = target.value.replace(/[^0-9]/g, '');

    if (target.value.length == 1 && e.key.match(/^[0-9]+$/)) {
      if (target.nextElementSibling == null) {
        target.blur();
        return;
      }
      const nextTarget = target.nextElementSibling as HTMLInputElement | null;
      nextTarget?.focus();
    }

    if (e.key == 'Backspace') {
      const prevTarget =
        target.previousElementSibling as HTMLInputElement | null;

      if (prevTarget) {
        prevTarget?.focus();
      }
    }
  }

  let resendAvailable = $state(false);

  function countdown() {
    let timerEl: HTMLSpanElement | null = document.getElementById('timer');

    if (timerEl) {
      timerEl.className = 'inline-block text-black';
    }

    let timeleft = 30;

    let timer: NodeJS.Timeout = setInterval(() => {
      if (timeleft <= 0) {
        clearInterval(timer);
        if (timerEl) {
          timerEl.className = 'hidden';
        }
        resendAvailable = true;
      } else {
        timeleft -= 1;

        if (timerEl) {
          timerEl.innerHTML = Math.floor(timeleft / 60) + ':' + (timeleft % 60);
        }
      }
    }, 1000);
  }

  onMount(() => {
    countdown();
    console.log('mounted');
  });
</script>

<div class="w-full p-9">
  <!-- <div class="items-start py-4">
    <button
      class="mr-1 text-orange-400 back-arrow"
      onclick={() => {
        = "companyInformation";
      }}
      >&larr; Back
    </button>
  </div> -->
  <form class=" space-y-9  mx-auto" onsubmit={(event)=>{event.preventDefault();handleVerification()}}>
    <div class="  space-y-3">
      <h1 class="text-2xl font-bold">Email Verification</h1>
      <p>
        We have sent you an email with the verification code. Please enter
        following code from the email we sent.
      </p>
      <p class="text-primary-light">{$signupFormData.email}</p>
    </div>

    <div class="">
      <p class="text-medium">Enter Code</p>
      <div class="flex flex-row items-center  justify-between my-4">
        <input
          bind:value={verificationCode[0]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />
        <input
          bind:value={verificationCode[1]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />
        <input
          bind:value={verificationCode[2]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />

        <input
          bind:value={verificationCode[3]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />

        <input
          bind:value={verificationCode[4]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />

        <input
          bind:value={verificationCode[5]}
          class="py-2 rounded max-w-[50px] border border-gray-300 text-center"
          maxlength="1"
          onkeyup={focusNextInput}
          type="text"
        />
      </div>
    </div>

    <p class="text-black text-center ">
      <span class="" id="timer"/>
      <button
        class=" {!resendAvailable
          ? 'text-gray-400'
          : 'text-orange-400'} underline"
        disabled={!resendAvailable}
        onclick={(event) => {
          event.preventDefault();
          countdown();
          resendAvailable = false;
        }}
        type="button"
      >
        Resend code
      </button>
    </p>

    <div class="w-full">
      <button
        class="justify-center p-2.5 px-8 w-full text-white bg-black rounded-lg py-[11px]"
        type="submit"

      >Next
      </button>
    </div>

  </form>
</div>

<Loader {loading} type="pageLoader"/>


