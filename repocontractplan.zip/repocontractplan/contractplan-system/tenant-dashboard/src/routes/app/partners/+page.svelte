<script lang="ts">
  import { onMount } from 'svelte';

  import Input from '$lib/components/elements/input.svelte';
  import PageBody from '$lib/components/page-body.svelte';
  import PageHeader from '$lib/components/page-header.svelte';
  import Table from '$lib/components/table/table.svelte';
  import json from '$lib/mock/holidays.json';
  import { editId, title } from '$lib/state/store';
  import editIcon from '$lib/assets/svg/edit.svg';
  import deleteIcon from '$lib/assets/svg/trash.svg';
  import { DataSourceConnector } from '$lib/api/table-datasource';
  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import * as yup from 'yup';

  import {
    type ContractPartner,
    type ContractPartnerInput,
    CreateContractParternsDoc,
    GetContractPartnersDoc
  } from '$lib/generated/graphql';
  import AddNewButton from '$lib/components/elements/AddNewButton.svelte';
  import PartnerComponent from "$lib/components/elements/PartnerComponent.svelte";

  title.set('Partners');
  let recordCount = 0;

  let partner = {
    ContractPartnerName: '',
    CompanyName: '',
    Email: '',
    Contact: ''
    // Status: ""
  };
  let PartnerPop = $state(false);

  let checked = false;
  let pop = $state(false);
  let popupTitle = 'Add New Partner';
  let errors = $state({});


  let queryRepository = new GraphQLQueryRepository<ContractPartner>();
  let tableDataSource = new DataSourceConnector<ContractPartner>(
    queryRepository,
    GetContractPartnersDoc
  );

  const columns = [
    { key: 'ID', title: 'ID', sortable: true },
    { key: 'ContractPartnerName', title: 'Partner Name', sortable: true },
    { key: 'CompanyName', title: 'Company', sortable: false },
    { key: 'Email', title: 'Email Address', sortable: true },
    { key: 'Contact', title: 'Contact', sortable: true },
    { key: 'Status', title: 'Status', sortable: true }
  ];

  let isLabel = true;
  let label = 'Columns';
  let availableColumns = [
    'ID',
    'ContractPartnerName',
    'CompanyName',
    'Email',
    'Contact',
    'Status'
  ];
  let searchableColumns = ['ID', 'Status', 'CompanyName', 'Email', 'Contact'];

  let actions = true;
  let actionList = [
    { name: 'Edit', icon: editIcon, function: editFunction },
    { name: 'Delete', icon: deleteIcon, function: deleteFunction }
  ];

  let bulkActions = [
    'Activate',
    'Deactivate',
    'Delete',
    'Export to CSV',
    'Export to PDF'
  ];

  let options = [
    { title: 'Active', value: 'active' },
    { title: 'Inactive', value: 'inactive' }
  ];

  editId.subscribe((value) => {
    console.log('val : ', value);
    if (value != 0) {
      popupTitle = 'Edit Partner';
      edit(value);
      pop = true;
    }
  });

  function handleSubmit() {
    let queryRepository = new GraphQLQueryRepository<ContractPartnerInput>();
    queryRepository
      .updateItem(CreateContractParternsDoc, { input: partner })
      .then(() => {
        console.log('New partner added:', partner);
        checked = false;
        pop = false;
      });
  }

  function edit(id) {
    partner = json.find((obj) => obj.id === id);
  }

  function popup() {
    pop = !pop;
    editId.set(0);
    popupTitle = 'Add New Partner';
    partner = {
      ContractPartnerName: '',
      CompanyName: '',
      Email: '',
      Contact: ''
    };
  }

  function editFunction() {
  }

  function deleteFunction() {
  }

  const schema = yup.object().shape({
    ContractPartnerName: yup.string().required('Name is required'),
    CompanyName: yup.string().required('Company Name is required'),
    Email: yup.string().email('Invalid Email format').required('Email is required'),
    Contact: yup.string().required('Contact is required'),
  });

  function validation() {
    errors = {};
    try {
      schema.validateSync(partner, { abortEarly: false });
      console.log('Validation passed');
      handleSubmit();
    } catch (validationErrors) {
      if (yup.ValidationError.isError(validationErrors)) {
        validationErrors.inner.forEach((error) => {
          if (error.path) {
            errors[error.path] = error.message;
          }
        });
      }
      console.log(errors);
      console.log('Validation failed');
    }
}

  onMount(async () => {
    if (tableDataSource) {
      const result = await tableDataSource.currentRows;
      recordCount = result.data ? result.data.length : 0;
    }
  });

</script>

<PageHeader />
<PartnerComponent pop={PartnerPop}/>
<PageBody>
  <Table
    {actionList}
    {actions}
    {availableColumns}
    {bulkActions}
    {columns}
    {isLabel}
    {label}
    rootAccessPath="data.listContractPartnersDDB.edges"
    {searchableColumns}
    {tableDataSource}
  >
    <span slot="buttons">
      <AddNewButton
        btnText="New Partner"
        on:message={popup}
        openAsPopup={true}
        onclick={() => {PartnerPop = !PartnerPop; console.log(PartnerPop);}}
      />
    </span>
  </Table>
</PageBody>
