package stripeclient

import (
	"context"
	"encoding/json"
	"os"
	
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/secretsmanager"
	"github.com/kr/pretty"
	
	"github.com/stripe/stripe-go/v74/client"
	
	"cloudparallax.com/backend/config"
	serviceConfig "cloudparallax.com/backend/services/aws/config"
)

type StripeSecret struct {
	SecretKey string `json:"secret_key"`
}

var secretCache *StripeSecret = nil

var Client *client.API
var secretsManagerClient = secretsmanager.NewFromConfig(serviceConfig.AWSConfig)

func StripeClient(ctx context.Context) (*client.API, error) {
	// httpClient := urlfetch.Client(ctx)
	if Client != nil {
		return Client, nil
	}
	var secret = config.GC("STRIPE_SECRET", os.Getenv("STRIPE_SECRET"))
	pretty.Println("LOADED SECRET ARN", secret)
	result, err := secretsManagerClient.GetSecretValue(context.Background(), &secretsmanager.GetSecretValueInput{
		SecretId: aws.String(secret),
	})
	if err != nil {
		pretty.Println("STRIPE SECRET ERR", err)
		return nil, err
	}
	var resultMap = map[string]string{}
	err = json.Unmarshal([]byte(*result.SecretString), &resultMap)
	if err != nil {
		pretty.Println("JSON ERR", err)
		return nil, err
	}
	sc := &client.API{}
	pretty.Println("LOADED STRIPE KEY OF LENGTH: ", len(resultMap["secret_key"]))
	sc.Init(resultMap["secret_key"], nil) // the second parameter overrides the backends used if needed for mocking
	return sc, nil
	//	pretty.Println("STRIPE SECRET ", resultMap["secret_key"])
	//	Client = client.New(resultMap["secret_key"], stripe.NewBackends(httpClient))
	//	return Client, nil
}
