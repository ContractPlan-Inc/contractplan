package models

import (
	"bytes"
	"testing"

	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

func TestDynamoLastEvaluatedKey_MarshalGQL(t *testing.T) {
	type fields struct {
		GsiKeyMap map[string]map[string]types.AttributeValue
	}
	tests := []struct {
		name   string
		fields fields
		wantW  string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			y := DynamoLastEvaluatedKey{
				GsiKeyMap: tt.fields.GsiKeyMap,
			}
			w := &bytes.Buffer{}
			y.MarshalGQL(w)
			if gotW := w.String(); gotW != tt.wantW {
				t.Errorf("MarshalGQL() = %v, want %v", gotW, tt.wantW)
			}
		})
	}
}

func TestDynamoLastEvaluatedKey_UnmarshalGQL(t *testing.T) {
	type fields struct {
		GsiKeyMap map[string]map[string]types.AttributeValue
	}
	type args struct {
		v interface{}
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			y := DynamoLastEvaluatedKey{
				GsiKeyMap: tt.fields.GsiKeyMap,
			}
			if err := y.UnmarshalGQL(tt.args.v); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalGQL() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
