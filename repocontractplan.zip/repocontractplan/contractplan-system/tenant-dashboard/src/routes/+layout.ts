export const prerender = false;
export const trailingSlash = "always";

import { authState } from "$lib/state/auth";
import { goto } from "$app/navigation";
import type { auth } from "$lib/state/auth";
import { redirect } from "@sveltejs/kit";
