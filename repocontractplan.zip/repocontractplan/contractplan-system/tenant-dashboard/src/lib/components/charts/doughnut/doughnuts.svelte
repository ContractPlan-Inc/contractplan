<script lang="ts">

</script>
<main class="flex items-center justify-between w-full p-2 bg-white rounded-md">
  <slot />
</main>
