<script lang="ts">
  import Icon from '@iconify/svelte';

  interface Props {
    status?: string;
    date: string;
    amount: string;
  }

  let { status = 'not paid', date, amount }: Props = $props();

</script>

{#if status === 'paid'}
  <div class="w-full">
    <div class="flex justify-between items-center h-0.5 w-full mb-8  bg-green-400  ">
      <div class="w-5 h-5 flex justify-center items-center text-white bg-green-400 rounded-full">
        <Icon icon="mdi:tick" />
      </div>
    </div>
    <p class=" text-gray-500 text-sm">{date}</p>
    <p class=" font-medium text-sm">${amount}</p>
  </div>
{:else if status === 'pending'}
  <div class="w-full">
    <div class="flex justify-between items-center h-0.5 w-full mb-8   bg-gray-300  ">
      <div class="w-5 h-5 flex justify-center items-center text-white  bg-primary-orange rounded-full">
        <span class=" w-3 h-3 bg-white rounded-full"></span>
      </div>
    </div>
    <p class=" text-gray-500 text-sm">{date}</p>
    <p class=" font-medium text-sm">${amount}</p>
  </div>
{:else}
  <div class="w-full">
    <div class="flex justify-between items-center h-0.5 w-full mb-8  bg-gray-300  ">
      <div class="w-4 h-4 flex justify-center items-center text-white bg-gray-300 rounded-full">
      </div>
    </div>
    <p class=" text-gray-500 text-sm">{date}</p>
    <p class=" font-medium text-sm">${amount}</p>
  </div>
{/if}


