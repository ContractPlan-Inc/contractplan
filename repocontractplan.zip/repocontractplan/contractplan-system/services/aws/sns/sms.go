package sns

import (
	"context"
	
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sns"
	
	"cloudparallax.com/backend/services/aws/config"
)

func SendSMSMessage(phoneNumber, message string) (*sns.PublishOutput, error) {
	
	client := sns.NewFromConfig(config.AWSConfig)
	
	params := &sns.PublishInput{
		Message:     aws.String(message),
		PhoneNumber: aws.String(phoneNumber),
	}
	resp, err := client.Publish(context.TODO(), params)
	
	if err != nil {
		return nil, err
	}
	
	// Pretty-print the response data.
	return resp, nil
}
