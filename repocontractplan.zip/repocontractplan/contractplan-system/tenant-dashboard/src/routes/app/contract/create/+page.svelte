<script lang="ts">
  import PartnerComponent from "$lib/components/elements/PartnerComponent.svelte";
  import PageHeader from "$lib/components/page-header.svelte";
  import PageBody from "$lib/components/page-body.svelte";
  import Calculator from "$lib/components/calculator/calculator.svelte";
  import type { ContractInterface } from "$lib/components/calculator/store";
  import * as yup from "yup";
  import { GraphQLQueryRepository } from "$lib/api/query-repository";
  import type {
    ContractInput,
    ContractPartner,
    GetContractPartnersQuery,
  } from "$lib/generated/graphql";
  import {
    CreateContractDoc,
    GetContractPartnersDoc,
  } from "$lib/generated/graphql";
  import { onMount, tick } from "svelte";
  import { title } from "$lib/state/store";
  import { contract } from "$lib/state/calculator-store.svelte";
  import { goto } from "$app/navigation";
  import Loader from "$lib/components/elements/loader.svelte";

  let errors = $state({})
  let PartnerPop = $state(false);
  title.set("Contracts");
  let schema = yup .object() .shape({
      ContractName: yup.string().required("is Required"),
      ContractPartnerID: yup.string().required("is Required"),
    });
  let successMessage = $state("");
  let errorMessage = $state("");
  let searchTerm = $state("");

  let allContractPartners = $state<ContractPartner[]>([]);
  let isPartnersLoading = $state(false)

  async function passData() {
    console.log("Contract", contract);
    const isvalid = true;
    if (isvalid) {
      contract.StartDate = new Date(contract.StartDate).toISOString();
      contract.EndDate = new Date(contract.EndDate).toISOString();
      contract.UnitDefinition = {
        Name: "Unit 1",
        Description: "Description for Unit 1",
      };
      contract.Services.forEach((service) => {
        service.StartDate = new Date(service.StartDate).toISOString();
        service.EndDate = new Date(service.EndDate).toISOString();
      });
      let queryRepository = new GraphQLQueryRepository<ContractInput>();
      const contractInput: { [key: string]: any } = {};
      type contractTypeObj = Record<keyof ContractInput, undefined>;
      let conType: contractTypeObj = {
        Status: undefined,
        ContractName: undefined,
        ContractPartnerID: undefined,
        ContractAlias: undefined,
        ContractValue: undefined,
        Services: undefined,
        StartDate: undefined,
        EndDate: undefined,
        ServicePeriod: undefined,
        Weekdays: undefined,
        SelectedMonthDays: undefined,
        SelectedDatesOfYear: undefined,
        ServiceDays: undefined,
        EngagementsPerDay: undefined,
        UnitDefinition: undefined,
        ServiceDates: undefined,
      };
      Object.keys(conType).forEach((key) => {
        console.log(key);
        console.log(contract[key as keyof Contract]);
        contractInput[key as keyof ContractInterface] =
          contract[key as keyof Contract];
      });
      console.log("keysof Props;", contractInput.Services);
      queryRepository = new GraphQLQueryRepository<ContractInput>();
      console.log("json", JSON.stringify(contractInput));
      localStorage.setItem("contract", JSON.stringify(contractInput));
      try {
        const response = await queryRepository.updateItem(CreateContractDoc, {
          input: contractInput,
        });
        console.log("Res$$:", response);
        response.error ? console.log("Error", response.error) : null;
        successMessage = "New Contract has been added successfully!";
        errorMessage = "";
        await tick();
        goto("/app/contract");
      } catch (error) {
        errorMessage = "Error submitting contract. Please try again.";
        successMessage = "";
        console.error(error);
      }
    } else {
      errorMessage = "Please fix validation errors before submitting.";
      successMessage = "";
    }
  }

  async function fetchAndFilterContractPartners(input: {}) {
    try {
      allContractPartners = [];
      isPartnersLoading = true;

      const queryRepository =
        new GraphQLQueryRepository<GetContractPartnersQuery>();
      const partnersQuery = await queryRepository.getItems(
        GetContractPartnersDoc,
        { input: input },
        0,
        5,
      ).finally(() => {
        isPartnersLoading = false;
      });
      const partners =
        partnersQuery?.data?.listContractPartnersDDB?.edges?.reduce(
          (acc, partner) => {
            acc.push(partner?.node as ContractPartner);
            return acc;
          },
          [] as ContractPartner[],
        );
      allContractPartners = partners as ContractPartner[];
    } catch (error) {
      console.error("Error fetching contract partners:", error);
    }
  }

  // onMount(async () => {
  //   // await fetchAndFilterContractPartners({});
  // });

  function selectContract(partner: ContractPartner) {
    searchTerm = partner.ContractPartnerName;
    contract.ContractPartnerID = partner.ID;
    console.log("contract", contract);
    allContractPartners = [];
  }

  function validation() {
    console.log('contract',contract)
    try {
      schema.validateSync(contract, { abortEarly: false });
      console.log('Validation passed');
      passData();
    } catch (error) {
      errors = {};
      error.inner.forEach((e) => {
        console.log(e.path, e.message);
        errors[e.path] = e.message;
      });
      console.log(errors);
      console.log('Validation failed');
    }
  }

</script>

<PartnerComponent pop={PartnerPop}/>
<div class="w-full bg-white">
  <PageHeader Subtitle="Add Contract Information Below" Title="Contracts"
  ></PageHeader>
  <PageBody>
    <Calculator {contract}>
      <div class="w-full" slot="fields">

        <!-- You can add more fields and send it using passData() function -->
        <form>
          <div class="items-center my-3 space-y-1 w-full">
            <div class="w-full">Contract No</div>
            <div class="w-full">
              <input
                bind:value={contract.ContractAlias}
                class="w-full h-10 bg-gray-50 rounded-lg border border-gray-200 focus:ring-0 focus:ring-offset-0 indent-2 focus:border-primary-orange"
                type="text"
              />
            </div>
          </div>
          <div class="items-center my-3 space-y-1 w-full">
            <div class="flex w-full items-center">Contract Name
              {#if errors.ContractName !== ""}
                <div class="m-1 text-xs text-red-500">
                  {errors.ContractName}
                </div>
              {/if}
            </div>
            <div class="w-full">
              <input
                bind:value={contract.ContractName}
                class="bg-gray-50 focus:ring-0 focus:ring-offset-0  focus:border-primary-orange w-full h-10 border rounded-lg indent-2
                  {errors.ContractName === '' || errors.ContractName === undefined
                  ? 'border-gray-200'
                  : 'border-red-500'}"
                type="text"
              />
            </div>
          </div>
          <div class="flex relative flex-wrap gap-x-2 items-center my-3 space-y-1 w-ful" >
            <div class="flex w-full items-center">Contract Partner
              {#if errors.ContractPartnerID !== ""}
                <div class="m-1 text-xs text-red-500">

                  {errors.ContractPartnerID}
                </div>
              {/if}
            </div>
            <input
              bind:value={searchTerm}
              class="class-set
              { errors.ContractPartnerID === '' || errors.ContractPartnerID === undefined
              ? 'border-gray-200 '
              : 'border-red-500'}"
              onkeyup={() =>
                fetchAndFilterContractPartners({
                  ContractPartnerName: searchTerm,
                })}
              type="text"
            />
            <button
              class="px-3 py-2 bg-white z-30 border flex flex-row gap-1 text-sm shadow-md items-center justify-center rounded-md text-gray-900"
              onclick={() => {PartnerPop = true; console.log(PartnerPop);}}
            >
              New partner
            </button>
            <div
              class="hide-item w-300 absolute top-16 bg-gray-50 rounded-lg border-gray-200 peer-focus:block"
            >
              {#if isPartnersLoading}
                <div class="bg-gray-400 z-40 rounded w-fit p-1">
                  <Loader loading={true} type="dataLoader" />
                </div>
              {/if}
              {#if allContractPartners !== undefined && allContractPartners.length !== 0}
                <div class="bg-gray-400 z-40 rounded w-full p-1">

                    {#each allContractPartners as partner}
                      {#if partner.ContractPartnerName != "" && partner.ContractPartnerName != null }
                        <div
                          role="button"
                          onclick={(event) => {
                            event.preventDefault()
                            selectContract(partner)
                          }}
                          class="w-full py-2 px-4 text-sm mb-1 bg-gray-600 rounded-md text-white cursor-pointer first:border-t-0 hover:bg-gray-700 border-t-gray-400"
                        >
                          {partner.ContractPartnerName}
                        </div>
                      {/if}
                    {/each}
                </div>
              {/if}
            </div>
          </div>
        </form>
      </div>

      <div slot="button">
        <button
          class="py-2 mr-4 w-full text-white bg-gray-700 rounded-xl border hover:text-white"
          onclick={() => {validation()}}
        >
          Submit
        </button>
      </div>
    </Calculator>
  </PageBody>
  {#if successMessage !== ""}
    <div class="flex fixed inset-x-0 top-0 justify-center items-center">
      <div class="flex items-center p-4 bg-green-200 rounded-md">
        <svg
          width="18"
          height="18"
          viewBox="0 0 18 18"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g clip-path="url(#clip0_559_2359)">
            <path
              d="M9 16.5C13.1422 16.5 16.5 13.1422 16.5 9C16.5 4.85775 13.1422 1.5 9 1.5C4.85775 1.5 1.5 4.85775 1.5 9C1.5 13.1422 4.85775 16.5 9 16.5Z"
              stroke="#1AE081"
              stroke-width="1.4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
            <path
              d="M6.75 9L8.25 10.5L11.25 7.5"
              stroke="#1AE081"
              stroke-width="1.4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </g>
          <defs>
            <clipPath id="clip0_559_2359">
              <rect width="18" height="18" fill="white" />
            </clipPath>
          </defs>
        </svg>

        <span class="ml-2">{successMessage}</span>
      </div>
    </div>
  {/if}

  {#if errorMessage !== ""}
    <div class="flex fixed inset-x-0 top-0 justify-center items-center">
      <div class="p-4 bg-red-200 rounded-md">
        {errorMessage}
      </div>
    </div>
  {/if}
</div>

<style lang="postcss">
  .class-set {
    @apply flex-grow bg-gray-50  focus:ring-0 focus:ring-offset-0 focus:border-primary-orange h-10 border rounded-lg indent-2;
  }
</style>
