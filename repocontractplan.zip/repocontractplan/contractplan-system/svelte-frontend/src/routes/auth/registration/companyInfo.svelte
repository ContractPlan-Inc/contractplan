<script lang="ts">
  import {GraphQLQueryRepository} from '$lib/api/query-repository';
  import {SignUpDoc, type SignUpInput} from '$lib/generated/graphql';
  import Input from '$lib/components/elements/input.svelte';
  import {companySchema, validation} from './service.svelte';
  import Loader from '$lib/components/elements/loader.svelte';
  import CompanySizeButton from '$lib/components/elements/companySizeButton.svelte';

  let countries = [
    {
      'code2': 'US',
      'code3': 'USA',
      'name': 'United States',
      'capital': 'Washington, D.C.',
      'region': 'Americas',
      'subregion': 'Northern America',
      'states': [
        {
          'code': 'DC',
          'name': 'District of Columbia',
          'subdivision': 'district'
        },
        {
          'code': 'AS',
          'name': 'American Samoa',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'GU',
          'name': 'Guam',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'MP',
          'name': 'Northern Mariana Islands',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'PR',
          'name': 'Puerto Rico',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'UM',
          'name': 'United States Minor Outlying Islands',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'VI',
          'name': 'Virgin Islands, U.S.',
          'subdivision': 'outlying territory'
        },
        {
          'code': 'AL',
          'name': 'Alabama',
          'subdivision': 'state'
        },
        {
          'code': 'AK',
          'name': 'Alaska',
          'subdivision': 'state'
        },
        {
          'code': 'AZ',
          'name': 'Arizona',
          'subdivision': 'state'
        },
        {
          'code': 'AR',
          'name': 'Arkansas',
          'subdivision': 'state'
        },
        {
          'code': 'CA',
          'name': 'California',
          'subdivision': 'state'
        },
        {
          'code': 'CO',
          'name': 'Colorado',
          'subdivision': 'state'
        },
        {
          'code': 'CT',
          'name': 'Connecticut',
          'subdivision': 'state'
        },
        {
          'code': 'DE',
          'name': 'Delaware',
          'subdivision': 'state'
        },
        {
          'code': 'FL',
          'name': 'Florida',
          'subdivision': 'state'
        },
        {
          'code': 'GA',
          'name': 'Georgia',
          'subdivision': 'state'
        },
        {
          'code': 'HI',
          'name': 'Hawaii',
          'subdivision': 'state'
        },
        {
          'code': 'ID',
          'name': 'Idaho',
          'subdivision': 'state'
        },
        {
          'code': 'IL',
          'name': 'Illinois',
          'subdivision': 'state'
        },
        {
          'code': 'IN',
          'name': 'Indiana',
          'subdivision': 'state'
        },
        {
          'code': 'IA',
          'name': 'Iowa',
          'subdivision': 'state'
        },
        {
          'code': 'KS',
          'name': 'Kansas',
          'subdivision': 'state'
        },
        {
          'code': 'KY',
          'name': 'Kentucky',
          'subdivision': 'state'
        },
        {
          'code': 'LA',
          'name': 'Louisiana',
          'subdivision': 'state'
        },
        {
          'code': 'ME',
          'name': 'Maine',
          'subdivision': 'state'
        },
        {
          'code': 'MD',
          'name': 'Maryland',
          'subdivision': 'state'
        },
        {
          'code': 'MA',
          'name': 'Massachusetts',
          'subdivision': 'state'
        },
        {
          'code': 'MI',
          'name': 'Michigan',
          'subdivision': 'state'
        },
        {
          'code': 'MN',
          'name': 'Minnesota',
          'subdivision': 'state'
        },
        {
          'code': 'MS',
          'name': 'Mississippi',
          'subdivision': 'state'
        },
        {
          'code': 'MO',
          'name': 'Missouri',
          'subdivision': 'state'
        },
        {
          'code': 'MT',
          'name': 'Montana',
          'subdivision': 'state'
        },
        {
          'code': 'NE',
          'name': 'Nebraska',
          'subdivision': 'state'
        },
        {
          'code': 'NV',
          'name': 'Nevada',
          'subdivision': 'state'
        },
        {
          'code': 'NH',
          'name': 'New Hampshire',
          'subdivision': 'state'
        },
        {
          'code': 'NJ',
          'name': 'New Jersey',
          'subdivision': 'state'
        },
        {
          'code': 'NM',
          'name': 'New Mexico',
          'subdivision': 'state'
        },
        {
          'code': 'NY',
          'name': 'New York',
          'subdivision': 'state'
        },
        {
          'code': 'NC',
          'name': 'North Carolina',
          'subdivision': 'state'
        },
        {
          'code': 'ND',
          'name': 'North Dakota',
          'subdivision': 'state'
        },
        {
          'code': 'OH',
          'name': 'Ohio',
          'subdivision': 'state'
        },
        {
          'code': 'OK',
          'name': 'Oklahoma',
          'subdivision': 'state'
        },
        {
          'code': 'OR',
          'name': 'Oregon',
          'subdivision': 'state'
        },
        {
          'code': 'PA',
          'name': 'Pennsylvania',
          'subdivision': 'state'
        },
        {
          'code': 'RI',
          'name': 'Rhode Island',
          'subdivision': 'state'
        },
        {
          'code': 'SC',
          'name': 'South Carolina',
          'subdivision': 'state'
        },
        {
          'code': 'SD',
          'name': 'South Dakota',
          'subdivision': 'state'
        },
        {
          'code': 'TN',
          'name': 'Tennessee',
          'subdivision': 'state'
        },
        {
          'code': 'TX',
          'name': 'Texas',
          'subdivision': 'state'
        },
        {
          'code': 'UT',
          'name': 'Utah',
          'subdivision': 'state'
        },
        {
          'code': 'VT',
          'name': 'Vermont',
          'subdivision': 'state'
        },
        {
          'code': 'VA',
          'name': 'Virginia',
          'subdivision': 'state'
        },
        {
          'code': 'WA',
          'name': 'Washington',
          'subdivision': 'state'
        },
        {
          'code': 'WV',
          'name': 'West Virginia',
          'subdivision': 'state'
        },
        {
          'code': 'WI',
          'name': 'Wisconsin',
          'subdivision': 'state'
        },
        {
          'code': 'WY',
          'name': 'Wyoming',
          'subdivision': 'state'
        }
      ]
    }
  ];

  interface RegFormProps {
    regForm: SignUpInput;
    status: string;
  }

  let loading = $state(false);



  let {regForm = $bindable(), status = $bindable()}: RegFormProps = $props();
  let includeCompany = $state(true);
  let isCustomSize = $state(false);
  let errors: { [key: string]: string } = $state({});
  let isValid = $derived(errors.name == '' && errors.country == '' && errors.state == '' && errors.companySize == '');
  let selectedCountry = $state({
    states: [
      {
        code: '',
        name: ''
      }
    ]
  });
  $effect(() => {
    if (regForm.company !== undefined && regForm.company !== null && 'country' in regForm.company
      && regForm.company.country !== undefined && regForm.company.country !== '' && regForm.company.country !== null) {
      selectedCountry = countries.find((country) => country.code2 === regForm.company?.country) as typeof selectedCountry;
    }
    console.log('selectedCountryselectedCountry', regForm.company);

  });


  function isValidForm(field: string) {
    console.log("isValidForm");
    try {
      companySchema.validateSyncAt(field, regForm.company);
      console.log("y", field);
      errors[field] = '';
      return true;
    } catch (validationError: any ){
      console.log("z", field);
      errors[field] = validationError.message;
      return false;
    }
  }

  async function validateCompanyInfo() {
    console.log('validating');
    let returnedErrors = await validation(regForm.company, companySchema);
    console.log('companssssy', regForm.company);
    if (returnedErrors != null) {
      errors = returnedErrors;
      console.log('errors', returnedErrors);
    } else {
      console.log('validated');
       handleSubmit();
    }
  }

  async function handleSubmit() {
    console.log('submitting');
    loading = true;
    try {
      let queryRepository = new GraphQLQueryRepository<SignUpInput>();
      let response: any = await queryRepository.Signup(SignUpDoc, {
        input: {
          email: regForm.email,
          password: regForm.password,
          firstName: regForm.firstName,
          telephone: regForm.telephone,
          middleName: '',
          address: '',
          lastName: regForm.lastName,
          company: regForm.company
        }
      });
      console.log('$signupFormData: ', regForm);

      console.log('--------response----------');
      console.log(response?.data?.SignUp);

      if (response?.data?.SignUp?.success == false) {
        console.log('errors', response?.data?.SignUp?.errors);
        errors['signupError'] = 'An error occurred while signing up';
        loading = false;
      } else if (response.data.SignUp.success == true) {
        loading = false;
        status = 'email';
      }
    } catch (e) {
      console.log(e);
    }
  }

  function setCompanySize(size: number) {
    if (regForm.company) {
      regForm.company.companySize = size;
    }
  }

</script>


<div class=" absolute  top-0 left-0 pl-8">
  <button class="text-sm text-orange-400 back-arrow" onclick={() => {status="personal"}}><span
    class=" text-2xl">&larr;</span> Back
  </button>
</div>

<div class="w-full space-y-4 p-9">

  <h1 class="text-2xl font-bold">Business Information</h1>
  <label class=" block" for="companyInfo">
    <input bind:checked={includeCompany} id="companyInfo" name="companyInfo" type="checkbox"/>
    Include Company Information
  </label>
  {#if 'company' in regForm && regForm.company !== undefined && 'name' in regForm.company && includeCompany}
    <form  class="space-y-6">
      <div class="mx-auto space-y-3 w-full">

        <div class="relative flex flex-col items-start w-full ">
          <label class="text-sm my-2" for="email">
            Company
          </label>
          <input bind:value={regForm.company.name}
                 type="text"
                 class="bg-gray-50 border mb-1 {errors.name ? 'border-red-500' : 'border-gray-300'} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                 id="email"
                 placeholder="ABC"
                 oninput={() => {
                  isValidForm("name");
                }}
                  
          />
          <div class=" h-2">
            {#if errors.name}
              <p class="text-xs text-red-500 ">{errors.name}</p>
            {/if}
          </div>
        </div>


        <div class="relative flex flex-col items-start w-full ">

          <label class="block pt-2 mb-2 text-sm  text-gray-900 dark:text-white"
                 for="country">Country</label>
          <select
            class="block p-2.5 w-full text-sm text-gray-900 mb-1 {errors.country ? 'border-red-500' : 'border-gray-300'} bg-gray-50 rounded-lg border border-gray-300 dark:placeholder-gray-400 dark:text-white dark:bg-gray-700 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 dark:focus:ring-blue-500 dark:focus:border-blue-500"
            id="country" bind:value={regForm.company.country} onblur={() => {
              isValidForm("country");
            }} onchange={() => {
              isValidForm("country");
            }}>

            {#each countries as country}
              <option value={country.code2}>{country.name}</option>
            {/each}
          </select>
          <div class=" h-2">
            {#if errors.country}
              <p class="text-xs text-red-500">{errors.country}</p>
            {/if}
          </div>

        </div>


        <div class="relative flex flex-col items-start w-full ">

          <label class="block pt-2 mb-2 text-sm  text-gray-900 dark:text-white"
                 for="state">State/Teritory</label>
          <select
            class="{errors.state ? 'border-red-500' : 'border-gray-300'} block p-2.5 w-full  mb-1 text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 dark:placeholder-gray-400 dark:text-white dark:bg-gray-700 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 dark:focus:ring-blue-500 dark:focus:border-blue-500"
            id="state" bind:value={regForm.company.state} onblur={() => {
              isValidForm("state"); 
            }} onchange={() => {
              isValidForm("state");
            }}>
            <option></option>

            {#each selectedCountry.states as state}
              <option value={state.code}>{state.name}</option>
            {/each}
          </select>

          <div class="h-2">
            {#if errors.state}
              <p class="text-xs text-red-500">{errors.state}</p>
            {/if}
          </div>

        </div>


        <div class="justify-start  rounded-lg ">
          <label class="block pt-2 mb-2  text-sm  text-gray-900 dark:text-white" for="size">Company
            Size</label>
          <div class="flex  justify-between mb-1 ">


            <CompanySizeButton setCompanySize={(event: { preventDefault: () => void; }) => {
              event.preventDefault();
              setCompanySize(5);
              isValidForm("companySize");
              }} companySize={5} regForm={regForm} errors={errors} text="1-5"/>

            <CompanySizeButton setCompanySize={(event: { preventDefault: () => void; }) => {
              event.preventDefault();
              setCompanySize(10);
              isValidForm("companySize");
              }} companySize={10} regForm={regForm} errors={errors} text="5-10"/>


            <CompanySizeButton setCompanySize={(event: { preventDefault: () => void; }) => {
              event.preventDefault();
              setCompanySize(15);
              isValidForm("companySize");
              }} companySize={15} regForm={regForm} errors={errors} text="10-15"/>


            <CompanySizeButton setCompanySize={(event: { preventDefault: () => void; }) => {
              event.preventDefault();
              setCompanySize(20);
              isValidForm("companySize");
              }} companySize={20} regForm={regForm} errors={errors} text="15-20"/>


            <button
              class="py-2 px-3 text-sm font-medium text-gray-900 bg-gray-50 rounded border {errors.companySize ? 'border-red-500' : 'border-gray-300'} border-gray-300 dark:text-white focus:border-blue-500 focus:ring focus:outline-none"
              onclick={(event) => {
                event.preventDefault();
                isCustomSize = !isCustomSize;
              }}>
              Custom
            </button>

          </div>
          {#if isCustomSize}
              <input bind:value={regForm.company.companySize} type="number" placeholder="Enter custom size"
                   class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 dark:placeholder-gray-400 dark:text-white dark:bg-gray-700 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 dark:focus:ring-blue-500 dark:focus:border-blue-500" oninput={() => {
                    isValidForm("companySize");
                }}/>
          {/if}

          <div class="h-2"> 
            {#if errors.companySize}
              <p class="text-xs text-red-500">{errors.companySize}</p>
            {/if}
          </div>

        </div>


      </div>


      <div class="w-full">
        <button onclick={(event)=>{event.preventDefault();validateCompanyInfo(); console.log("errorserrors", errors)}} type="submit" class="justify-center p-2.5 px-8 w-full text-white bg-black rounded-lg py-[11px] {isValid ? 'bg-black' : 'bg-gray-500'}">
          Next
        </button>
      </div>
    </form>
  {/if}

  {#if !includeCompany}
    <div class="space-y-6 w-full">
        <button onclick={(event)=>{event.preventDefault();handleSubmit()}} type="submit" class="justify-center p-2.5 px-8 w-full text-white bg-black rounded-lg py-[11px]">
          Next
        </button>
    </div>
  {/if}

  {#if errors.signupError}
    <div class="text-xs text-red-500">{errors.signupError}</div>
  {/if}

</div>

<Loader {loading} type="pageLoader"/>

