package opensearch

import (
	"context"
	"encoding/json"
	"os"
	
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/secretsmanager"
	"github.com/kr/pretty"
	"github.com/opensearch-project/opensearch-go/v2"
	
	"cloudparallax.com/backend/config"
	serviceConfig "cloudparallax.com/backend/services/aws/config"
)

type OpensearchSecret struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

var secretCache *OpensearchSecret = nil

var Client *opensearch.Client
var secretsManagerClient = secretsmanager.NewFromConfig(serviceConfig.AWSConfig)

func NewClient() (*opensearch.Client, error) {
	var err error
	if Client != nil {
		return Client, nil
	}
	var secret = config.GC("OPENSEARCH_SECRET", os.Getenv("OPENSEARCH_SECRET"))
	pretty.Println("SECRET ARN", secret)
	result, err := secretsManagerClient.GetSecretValue(context.Background(), &secretsmanager.GetSecretValueInput{
		SecretId: aws.String(secret),
	})
	if err != nil {
		pretty.Println("SECRET ERR", err)
		return nil, err
	}
	var resultMap = map[string]string{}
	err = json.Unmarshal([]byte(*result.SecretString), &resultMap)
	if err != nil {
		pretty.Println("JSON ERR", err)
		return nil, err
	}
	Client, err = opensearch.NewClient(opensearch.Config{
		Addresses: []string{"https://" + os.Getenv("OPENSEARCH_ADDRESS")},
		Username:  resultMap["username"], // For testing only. Don't store credentials in code.
		Password:  resultMap["password"], // For testing only. Don't store credentials in code.
	})
	return Client, err
}
