import * as cdk from "aws-cdk-lib";
import { CfnOutput, Duration, PhysicalName } from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import { IVpc } from "aws-cdk-lib/aws-ec2";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { ISecret } from "aws-cdk-lib/aws-secretsmanager";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import * as sqs from "aws-cdk-lib/aws-sqs";
import { Queue } from "aws-cdk-lib/aws-sqs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";

// import * as sqs from 'aws-cdk-lib/aws-sqs';

export interface BaseStackProps extends cdk.StackProps {
    environment: string;
}


export class BaseStack extends cdk.Stack {
    public readonly vpc: IVpc;
    public readonly stripeSecret: ISecret;

    constructor(parent: Construct, id: string, props: BaseStackProps) {
        super(parent, id, props);
        this.vpc = ec2.Vpc.fromVpcAttributes(this, 'vpc', {
            vpcId: cdk.Fn.importValue('VPC-vpc-id'),
            availabilityZones: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-azs`)),
            publicSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-public-subnets`)),
            privateSubnetIds: cdk.Fn.split(',', cdk.Fn.importValue(`VPC-private-subnets`)),
        })
        const kmsKey = cdk.aws_kms.Key.fromKeyArn(this, 'kmsKey', cdk.Fn.importValue('BaseInfrastructure-kms-arn'));
        this.stripeSecret = new secretsmanager.Secret(
            this,
            "StripeSecret",
            {
                encryptionKey: kmsKey,
                description: "Stripe Secret",
            }
        );


        new CfnOutput(this, `Stripe-Secret-ARN`, {
            description: "StripeSecretArn",
            exportName: `StripeSecretARN`,
            value: this.stripeSecret.secretArn,
        });
    }

}
