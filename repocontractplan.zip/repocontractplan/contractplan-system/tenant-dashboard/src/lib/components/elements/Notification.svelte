<script>
  export let title;
  export let time;
  export let description;

</script>

<div>
  <a
    class="block p-3    text-sm text-gray-700 border-b w-full hover:bg-gray-50"
    href="#"
  >
    <div class=" flex flex-row items-start gap-2  justify-between ">
      <span class=" bg-primary  w-2 h-2 block rounded-xl items-center mt-[5px]"></span>
      <div class=" flex flex-col gap-1 w-11/12  ">
        <div class=" flex  justify-between">
          <p class=" font-bold  ">{title}</p>
          <p class=" font-medium">{time}</p>
        </div>
        <p class=" text-justify text-xs text-gray-500">{description}</p>
      </div>
    </div>
  </a>
</div>
