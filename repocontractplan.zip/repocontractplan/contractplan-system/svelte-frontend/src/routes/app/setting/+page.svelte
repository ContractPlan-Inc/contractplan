<script>
  import { title } from "$lib/state/store";

  title.set('Settings');

  function toggleDarkMode(event) {
    const isChecked = event.target.checked;
    document.documentElement.classList.toggle('dark', isChecked);
    document.body.style.backgroundColor = isChecked ? '#1f3548' : '';
    localStorage.setItem('dark-mode', isChecked.toString());

    window.dispatchEvent(new CustomEvent('dark-mode-toggled', {
      detail: { isDarkMode: isChecked }
    }));
  }

  function changePrimaryColor(event) {
    const selectedColor = event.target.value;

    document.documentElement.classList.remove('blue-theme', 'red-theme', 'green-theme');

    if (selectedColor === 'blue') {
      document.documentElement.classList.add('blue-theme');
    } else if (selectedColor === 'red') {
      document.documentElement.classList.add('red-theme');
    }else if (selectedColor === 'green') {
      document.documentElement.classList.add('green-theme');
    }

    localStorage.setItem('primary-color', selectedColor);

    // Dispatch event for chart color update
    window.dispatchEvent(new CustomEvent('primary-color-changed', {
      detail: { color: selectedColor }
    }));
  }

  let isDarkMode = localStorage.getItem('dark-mode') === 'true';
  let selectedColor = $state(localStorage.getItem('primary-color') || 'orange');

  if (typeof window !== 'undefined') {
    if (selectedColor === 'blue') {
      document.documentElement.classList.add('blue-theme');
    } else if (selectedColor === 'red') {
      document.documentElement.classList.add('red-theme');
    } else if (selectedColor === 'green') {
      document.documentElement.classList.add('green-theme');
    }
  }
</script>

<div class="p-6">
<div class="relative border rounded-lg border-gray-200 p-4">
  <div class="flex items-center justify-between py-3">
    <p class="text-xs text-gray-500 my-1">User Preferences</p>
  </div>
  <div class="flex items-center justify-between py-3">
    <p class="text-sm dark:text-white">Dark Mode</p>
    <label class="relative inline-flex items-center cursor-pointer">
      <input
        type="checkbox"
        class="sr-only peer"
        onchange={toggleDarkMode}
        checked={isDarkMode}
      />
      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer dark:bg-gray-700 peer-checked:bg-blue-600 transition-colors duration-300"></div>
      <span class="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform duration-300 transform peer-checked:translate-x-5"></span>
    </label>
  </div>

  <div class="flex items-center justify-between py-3">
    <p class="text-sm dark:text-white">Select Primary Color</p>
    <select class="mt-2 p-2 border rounded-md" onchange={changePrimaryColor} bind:value={selectedColor}>
      <option value="orange">Orange</option>
      <option value="blue">Blue</option>
      <option value="red">Pink</option>
      <option value="green">Green</option>
    </select>
  </div>
</div>
</div>

<style>

</style>
