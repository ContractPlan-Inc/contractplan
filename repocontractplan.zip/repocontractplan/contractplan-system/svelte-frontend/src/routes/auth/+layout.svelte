<style>
  /* Global styles */
  body {
    height: 100vh;
    margin: 0;
  }

  /* Full-screen background style */
  .full-screen-background {
    background-color: bg-gray-500;
    min-height: 100vh;
    display: flex; /* Center child content vertically */
    justify-content: center;
    align-items: center;
  }
</style>
<svelte:head>
  <title>ContractPlan: Login</title>
</svelte:head>
<script lang="ts">
  interface Props {
    children?: import('svelte').Snippet;
  }

  let { children }: Props = $props();</script>
<div class="full-screen-background bg-gray-200 min-h-screen h-full">
  <div class="mx-auto max-w-fit rounded-xl min-h-screen relative">
    <div class="flex flex-row items-start py-8">
      <div class="">
        <a class="flex flex-row items-center gap-2" href="/">
          <enhanced:img alt="Landing Logo" src="../../lib/assets/svg/logo.svg" />
        </a>
        <div class="flex-grow"></div>
      </div>
    </div>
    <div class="flex flex-row  max-w-[900px] w-full min-h-[500px]  h-full md:mx-2  bg-white rounded-xl">
      <div class="w-full h-full p-4 md:block ">
        {@render children?.()}
      </div>
      <div class="hidden w-full h-full p-4 md:block">
        <div class="relative w-full flex-row bg-[#FFF1E3] max-h-full max-w-[600px] min-h-[500px]  rounded-xl">
          <div class="absolute item-center top-24 ">
            <div class="relative w-full">
              <div class="text-3xl relative text-center">
                An accessible solution for
              </div>
              <div class="top-40 pt-2 text-3xl text-primary text-center">
                Contract Management
              </div>
              <enhanced:img class="p-10 w-full" src="../../lib/assets/signin-2.png" />
            </div>
          </div>
          <enhanced:img alt="" src="../../lib/assets/signin.png" />
        </div>
      </div>
    </div>
  </div>
</div>
