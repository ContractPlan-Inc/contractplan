package s3

import (
	"bytes"
	"context"
	"errors"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	v4 "github.com/aws/aws-sdk-go-v2/aws/signer/v4"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"

	"cloudparallax.com/backend/services/aws/config"
)

var S3Client *s3.Client
var S3Bucket string

func init() {
	if S3Bucket = os.Getenv("BUCKET_NAME"); S3Bucket == "" {
		log.Fatal("BUCKET_NAME environment variable is not set")
	}

	region := os.Getenv("AWS_REGION")
	if region == "" {
		log.Fatal("AWS_REGION environment variable is not set")
	}

	log.Printf("Initializing S3 client for bucket: %s in region: %s", S3Bucket, region)
	log.Printf("AWS Access Key ID length: %d", len(os.Getenv("AWS_ACCESS_KEY_ID")))
	log.Printf("AWS Secret Access Key length: %d", len(os.Getenv("AWS_SECRET_ACCESS_KEY")))

	S3Client = s3.NewFromConfig(config.AWSConfig)
}
func PresignClient() (*s3.PresignClient, error) {
	var err error
	PresignClient := s3.NewPresignClient(S3Client, func(options *s3.PresignOptions) {
		options.Expires = 3600 * time.Second
	})

	return PresignClient, err
}

// GetSignedUrl makes a presigned request that can be used to get an object from a bucket.
// The presigned request is valid for the specified number of seconds.
func GetSignedUrl(objectKey string, lifetimeSecs int64) (*v4.PresignedHTTPRequest, error) {
	Client, err := PresignClient()
	request, err := Client.PresignGetObject(context.TODO(), &s3.GetObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(objectKey),
	}, func(opts *s3.PresignOptions) {
		opts.Expires = time.Duration(lifetimeSecs * int64(time.Second))
	})
	if err != nil {
		log.Printf("Couldn't get a presigned request to get %v:%v. Here's why: %v\n",
			S3Bucket, objectKey, err)
	}
	return request, err
}

// PutSignedUrl makes a presigned request that can be used to get an object from a bucket.
// The presigned request is valid for the specified number of seconds.
func PutSignedUrl(objectKey string, lifetimeSecs int64) (*v4.PresignedHTTPRequest, error) {
	Client, err := PresignClient()
	request, err := Client.PresignPutObject(context.TODO(), &s3.PutObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(objectKey),
	}, func(opts *s3.PresignOptions) {
		opts.Expires = time.Duration(lifetimeSecs * int64(time.Second))
	})
	if err != nil {
		log.Printf("Couldn't get a presigned request to get %v:%v. Here's why: %v\n",
			S3Bucket, objectKey, err)
	}
	return request, err
}

// GetObject used to get an object in a bucket.
func GetObject(Key string) (*s3.GetObjectOutput, error) {
	return S3Client.GetObject(context.TODO(), &s3.GetObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(Key),
	})
}

// PutObject used to put an object in a bucket.
func PutObject(Key string, object []byte) (*s3.PutObjectOutput, error) {
	return S3Client.PutObject(context.TODO(), &s3.PutObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(Key),
		Body:   bytes.NewReader(object),
	})
}

// LastModified used to get lastmodified date of an object
func LastModified(Key string) (*time.Time, error) {
	resp, err := S3Client.HeadObject(context.TODO(), &s3.HeadObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(Key),
	})
	if err != nil {
		return nil, err
	}
	// Get the LastModified time from the response
	lastModified := *resp.LastModified

	return &lastModified, nil
}
func AddFileToS3(fileDir string, bucket ...string) (string, error) {
	toBucket := S3Bucket
	if bucket != nil && len(bucket[0]) > 0 {
		toBucket = bucket[0]
	}
	toFile := filepath.Base(fileDir)
	if bucket != nil && len(bucket) > 1 {
		toFile = bucket[1]
	}
	// Open the file for use
	file, err := os.Open(fileDir)
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Get file size and read the file content into a buffer
	fileInfo, _ := file.Stat()
	var size = fileInfo.Size()
	if fileInfo.Size() < 10 {
		return "", errors.New("file corrupted upload")
	}
	buffer := make([]byte, size)
	_, _ = file.Read(buffer)
	// Config settings: this is where you choose the bucket, filename, content-type etc.
	// of the file you're uploading.
	input := &s3manager.UploadInput{
		Bucket: aws.String(toBucket),
		Key:    aws.String(toFile),
		Body:   bytes.NewReader(buffer),
	}
	sess := session.Must(session.NewSession())
	u := s3manager.NewUploader(sess)
	output, err := u.Upload(input)
	if err != nil {
		panic(err)
	}
	output.Location = strings.Replace(output.Location, "https://onroutesigns.s3.us-east-1.amazonaws.com/", "https://dr7di9d8cyw3k.cloudfront.net/", 1)
	return output.Location, err
}

// ObjectExists checks if an object exists in the S3 bucket
func ObjectExists(key string) (bool, error) {
	_, err := S3Client.HeadObject(context.TODO(), &s3.HeadObjectInput{
		Bucket: aws.String(S3Bucket),
		Key:    aws.String(key),
	})

	if err != nil {
		// If the error is because the object doesn't exist, return false without error
		if strings.Contains(err.Error(), "NotFound") {
			return false, nil
		}
		// For other errors, return the error
		return false, err
	}

	return true, nil
}

// ListObjectsInBucket lists all objects in a bucket with the given prefix
func ListObjectsInBucket(prefix string) (*s3.ListObjectsV2Output, error) {
	input := &s3.ListObjectsV2Input{
		Bucket: aws.String(S3Bucket),
		Prefix: aws.String(prefix),
	}

	return S3Client.ListObjectsV2(context.TODO(), input)
}
