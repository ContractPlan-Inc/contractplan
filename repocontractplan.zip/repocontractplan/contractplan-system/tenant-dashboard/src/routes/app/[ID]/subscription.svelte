<script lang="ts">
  import PlanEl from '$lib/components/elements/plan.svelte';
  import Popup from '$lib/components/popup/popup.svelte';
  import { title } from "$lib/state/store";

  import { GraphQLQueryRepository } from '$lib/api/query-repository';
  import {
  CancelPlanDoc,
    ChangePlanDoc,
    type ChangePlanMutation,
    type CancelPlanMutation,
    GetCurrentPlanDoc,
    type GetCurrentPlanQuery,
    GetPlansDoc,
    type GetPlansQuery,
    type Plan,
    type GetCurrentPlanStatusQuery,
    GetCurrentPlanStatusDoc
  } from '$lib/generated/graphql';
  import { onMount, createEventDispatcher } from 'svelte';

  let plans: Plan[] = $state([]);
  // let isRenewAutomatically: boolean = $state(false);
  let selectPlanPopup: boolean = $state(false);
  let currentPlan: string = $state('');
  let currentPlanStatus: string = $state('');
  let selectedPlan: string = $state('');
  let { data } = $props();
  const dispatch = createEventDispatcher();

  async function showPopup() {
    await fetchPlans();
    selectPlanPopup = true;
  }

  function hidePopup() {
    selectedPlan = '';
    selectPlanPopup = false;
    getCurrentPlan();

  }

  async function fetchPlans() {
    try {
      const queryRepository = new GraphQLQueryRepository<GetPlansQuery>();
      const plansQuery = await queryRepository.getItems(GetPlansDoc, {}, 1, 10);

      plans = plansQuery?.data?.listPlans as Plan[];

      console.log('PLANS:', plans);
    } catch (e) {
      console.log('ERROR:', e);
    }
  }

  async function getCurrentPlan() {
    const queryRepository = new GraphQLQueryRepository<GetCurrentPlanQuery>();
    const currentPlanQuery = await queryRepository.getItem(GetCurrentPlanDoc);
    currentPlan = currentPlanQuery?.data?.getCurrentPlan?.ID as string;
    console.log('CURRENT PLAN:', currentPlanQuery?.data?.getCurrentPlan);

    const queryRepository1 = new GraphQLQueryRepository<GetCurrentPlanStatusQuery>();
    const currentPlanQuery2 = await queryRepository1.getItem(GetCurrentPlanStatusDoc);
    currentPlanStatus = currentPlanQuery2?.data?.getCurrentPlanStatus as string;
    console.log('CURRENT PLAN STATUS:', currentPlanQuery2?.data?.getCurrentPlanStatus);

    data = { 'currentPlanStatus': currentPlanStatus };
  console.log('data:', data);

  // Dispatch the event with the current plan status
  dispatch('planStatusUpdate', { currentPlanStatus });
  }

  function isCurrentPlan(plan: Plan) {
    return currentPlan === plan.ID;
  }

  async function changePlan() {

    if (selectedPlan !== '') {
      const queryRepository = new GraphQLQueryRepository<ChangePlanMutation>();
      const currentPlanQuery = await queryRepository.changePlan(ChangePlanDoc, { input: { PlanID: selectedPlan } });

      console.log('queryRepository-currentPlanQuery', currentPlanQuery);

      const response = currentPlanQuery.data;

      console.log('response.data', response);

      if (response?.changePlan.success) {
        alert(response?.changePlan.message);
        hidePopup();

      }
    } else {
      alert('Please select a plan');
    }
  }

  export async function cancelPlan() {
    if (currentPlanStatus === 'cancelled') {
      alert('Plan already canceled');
      return;
    }
    const queryRepository = new GraphQLQueryRepository<CancelPlanMutation>();
    const currentPlanQuery = await queryRepository.changePlan(CancelPlanDoc, { input: { PlanID: currentPlan } });

    const response = currentPlanQuery.data;
    
    console.log('response.data', response);

    if (response) {
        alert("Plan canceled successfully");
        console.log(response);
    }
  }

  // export async function enablePlan() {
  //   const queryRepository = new GraphQLQueryRepository<ChangePlanMutation>();
  //   const currentPlanQuery = await queryRepository.changePlan(ChangePlanDoc, { input: { PlanID: currentPlan } });

  //   console.log('queryRepository-currentPlanQuery', currentPlanQuery);
  //   const response = currentPlanQuery.data;
  //   console.log('response.data', response);
  // }

  onMount(async () => {
    await getCurrentPlan();
  });

</script>

{#if selectPlanPopup}
  <Popup on:close={hidePopup} popupTitle="Select Plan" buttonText="Change Plan" submitHandler={changePlan}>
    {#each plans as plan}

      <PlanEl plan={plan} isCurrentPlan={isCurrentPlan(plan)} selected={selectedPlan == plan.ID} on:planSelected={() => {
                if(selectedPlan == plan.ID){
                    selectedPlan = ''
                }else{
                    selectedPlan = plan.ID
                }
            }} />

    {/each}
    <p class=" text-sm">Upon changing the plan you will be charged from the payment information you saved.</p>
  </Popup>
{/if}

<div class=" relative border rounded-lg border-gray-200 p-6">
  <p class=" text-xs text-gray-500 my-1">Plan</p>
  <div class=" border-b  flex  items-center justify-between  py-3">
    <div>
      <p class="text-lg font-bold">{currentPlan}</p>
      <p class="text-xs text-gray-500">Paid Annually</p>
      <p class="text-xs {currentPlanStatus=='cancelled'? 'bg-red-500' :'bg-green-500'} w-fit p-1 mt-2 rounded text-white ">{currentPlanStatus}</p>
    </div>
    <div>
      <button class="text-sm" onclick={showPopup}>Change</button>
    </div>
  </div>
  <div class=" flex items-center justify-between py-3">
    <p class="text-sm">Renew Automatically</p> <label class="relative inline-flex items-center cursor-pointer">
    <input
      class="sr-only peer"
      type="checkbox"
      value=""
    />

    <div
      class="w-11 h-6 bg-gray-200 peer-focus:focus:ring-0 focus:ring-offset-0 peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-green-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-green-400"></div>

  </label>
  </div>


</div>
