import { writable } from 'svelte/store';
import type { Company, SignUpInput } from '$lib/generated/graphql';

export let signupForm: SignUpInput = {
  firstName: '',
  middleName: '',
  lastName: '',
  telephone: '',
  address: '',
  email: '',
  password: ''
};


let companyForm: Company = {
  name: '',
  telephone: '',
  address: '',
  category: ''
};

type FormName = 'personalInformation' | 'companyInformation' | 'emailVerification' | 'planSelection';

let showingForm: FormName = 'personalInformation';

export const signupFormData = writable<SignUpInput>(signupForm);
export const companyFormData = writable<Company>(companyForm);
export const showingFormData = writable<FormName>(showingForm);
